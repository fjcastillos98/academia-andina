# Academia Andina Filo Austral · Prototipo público 0.32.0

Plataforma estática en español para estudio personal. Astro 7.4.2, TypeScript, Markdown y Zod. Implementación independiente dentro de `academia/`: no modifica el manual de Chiloé. Repositorio independiente para publicación en GitHub Pages.

## Empezar aquí

Esta es la entrega documental del ciclo de 32 etapas. Consulta [INICIO.md](INICIO.md) para instalar y usar la plataforma, [MANTENIMIENTO.md](docs/etapa32/MANTENIMIENTO.md) para actualizarla y [ACEPTACION.md](docs/etapa32/ACEPTACION.md) para las verificaciones pendientes. La validación visual e interactiva sigue pendiente; el currículo académico no está completo.

## Requisitos y ejecución

Node.js 24 LTS y npm. Desde esta carpeta:

```bash
npm ci
npm run dev
```

Abrir http://localhost:4321/ (o el puerto que imprima Astro). No abrir `index.html` con `file://`. En el entorno de pruebas de ChatGPT se utiliza el supervisor de preview; no es un requisito del proyecto descargado.

```bash
npm run check       # TypeScript y componentes Astro
npm run validate    # Alcance curricular, frontmatter y apartados
npm test            # Pruebas automatizadas de dominio y persistencia
npm run build       # Validación + generación estática en dist/
npm run test:build  # Enlaces y recursos del build
npm run preview    # Servir el resultado, normalmente puerto 4321
```

## Qué incluye

- Portada con progreso, 24 páginas de asignatura, 376 entradas pendientes y 175 lecturas con estados editoriales diferenciados.
- Catálogo filtrable, navegación anterior/siguiente y búsqueda en títulos, descripción y cuerpo; normaliza tildes y mayúsculas.
- Glosario inicial de 8 términos y biblioteca de fuentes.
- Ciento setenta y cinco cuestionarios versionados con explicaciones, historial de hasta 10.000 intentos por lección (sin descarte automático; limitado además por los 2 MB del respaldo) y criterio teórico explícito (todas correctas).
- Notas de hasta 10.000 caracteres, favoritos y estudio local; exportación/importación JSON con validación y confirmación.
- Interfaces semánticas, foco visible, enlace para saltar al contenido, formularios etiquetados y reducción de movimiento. Diseño adaptable; no es una certificación WCAG.

Las 376 entradas son un mapa de alcance, no 376 lecciones. Algunas describen requisitos de fichas (por ejemplo, campos de montañas). Ni el piloto ni las muestras cambian los estados pendientes del mapa.

## Datos y privacidad

Se usa **localStorage**, en lugar de IndexedDB propuesto en la auditoría, porque esta etapa guarda un pequeño objeto de texto. Se encapsula en `src/lib/state.ts` para permitir migración posterior. Clave: `filo-austral:academia:v1:<ruta-base>`; queda vinculada al navegador y origen. No hay cuenta, backend, sincronización entre dispositivos ni cifrado. Evitar edición simultánea en varias pestañas: no hay resolución de conflictos.

Las notas se guardan al pulsar **Guardar nota**. No introducir datos médicos, contraseñas o información de pasajeros. Los registros no se incluyen en el build ni en el repositorio. Todos los textos importados se presentan como texto, no HTML. Los errores de lectura o cuota se avisan; no se resetea silenciosamente un estado corrupto.

Exportar antes de cambiar navegador, dirección/base o borrar almacenamiento. Importación: archivo máximo 2 MB, formato/versión estrictos, identificadores conocidos y respuestas válidas. Revisar el resumen y confirmar; reemplaza el estado anterior. El respaldo versión 3 incluye hasta 500 prácticas, 500 equipos con inspecciones y respuestas abiertas; importa y migra versiones 1 y 2 sin perder estudio. La primera escritura de datos antiguos guarda una copia local bajo la clave adicional `:before-v3`. Exporta también una copia externa. Se conserva la clave local v1 para leer los datos anteriores. Una evaluación declarada exige supervisor, evaluador, fecha, criterio y evidencia; no verifica credenciales ni certifica competencias. Es un cuaderno personal, no un registro inviolable de certificaciones.

## Estructura

- `data/curriculum.json`: currículo v2 ampliable, con las 376 entradas históricas conservadas; original exacto en `data/archive/curriculum.v1.json`.
- `src/content/lecciones/*.md`: texto y metadatos JSON en frontmatter YAML compatible.
- `src/content.config.ts`, `src/lib/schemas.ts`: colección y validación.
- `src/data/`: fuentes y glosario.
- `src/pages/`: páginas estáticas y índices JSON generados.
- `src/layouts/`, `src/components/`, `src/styles/`: interfaz.
- `src/lib/learning.ts`: búsqueda, corrección y estado teórico.
- `src/lib/state.ts`: persistencia y respaldo.
- `src/lib/client.ts`: interacciones accesibles de navegador.
- `scripts/`, `tests/`: validación y pruebas.
- `docs/`: decisiones, verificación e informes históricos.

## Rutas base y GitHub Pages

Se recomienda un **repositorio independiente** llamado, por ejemplo, `academia-andina`, con el contenido de esta carpeta en su raíz. No copiar el workflow al repositorio del manual: desplegar solo `academia/dist` sobre el sitio del manual lo reemplazaría.

Comprobar localmente una base de proyecto (bash):

```bash
BASE_PATH=/academia-andina/ npm run build
BASE_PATH=/academia-andina/ npm run test:build
BASE_PATH=/academia-andina/ npm run preview
```

Abrir la ruta `/academia-andina/` del servidor de preview. Usar la misma base al compilar y servir. `BASE_PATH` debe comenzar y terminar con `/`. En PowerShell: `$env:BASE_PATH='/academia-andina/'`, ejecutar los comandos npm y luego `Remove-Item Env:BASE_PATH`. Para dominio propio o raíz, usar `/`.

`SITE_URL` configura el origen (predeterminado: `https://fjcastillos98.github.io`), **no** implica que exista publicación. Enlaces, búsqueda, índices JSON y favicon utilizan la base. Assets de Astro se prefijan automáticamente.

El workflow `.github/workflows/pages.yml` comprueba y compila el proyecto antes de publicarlo en GitHub Pages. Configurar Settings → Pages → Source: GitHub Actions. Los informes de etapas conservan el estado histórico de cada entrega.

## Contenidos y límites

Consultar `CONTRIBUTING.md`. Fuentes: SLF/KAT, OMM, USGS, NPS, NWS, Leave No Trace, UIAA, Petzl y Garmin; DMC como portal oficial de consulta, sin pronóstico local validado. Consulta documental: 21–22-10-2026. El modelo de evidencias es un criterio editorial propio. Los diez temas del piloto requieren revisión de instructor; nudos y anclajes preparan talleres supervisados, sin secuencias operativas para aplicar sin formación.

El diario guarda declaraciones personales de práctica y evaluación, con evidencia textual y una matriz de 162 habilidades. No hay verificación de instructor, matriz profesional completa, calendario, plan deportivo adaptativo, atención médica personalizada ni normativa vigente. Todo eso pertenece a etapas posteriores. Ningún cuestionario certifica una maniobra. La licencia de distribución del conjunto sigue pendiente; no se ha añadido LICENSE.

## Etapa 3: secuencia y diario

Abrir `/fundamentales/`: A riesgo → B 3×3 → C planificación → D meteorología → E nubes → F navegación → G equipo → H nudos → I cuerdas/anclajes → J comunicaciones. Los prerrequisitos orientan la secuencia, sin bloquear el acceso ni acreditar preparación práctica. `pilot.position`, `requires`, `critical`, `classifications`, `relatedModules` y `criteria` mantienen la estructura. El mapa original no se renumera.

`/practicas/` permite registrar y editar prácticas, consultar criterios y ver la matriz. Un quiz nunca actualiza una competencia. Solo las evaluaciones declaradas con todos los campos completados afectan esa columna; prevalece la evaluación más reciente y, si el mismo día hay resultados contradictorios, se muestra «En desarrollo». No hay caducidad automática ni acreditación externa. La evidencia es texto, no adjuntos.

Ver `docs/verificacion-etapa3.md` para resultados reales, `docs/etapa3.md` para alcance y pendientes, y `docs/archivos-etapa3.md` para archivos.


## Ampliación de Etapa 4

- `/programa/`: rutas, unidades, habilidades y dependencias futuras.
- `/casos/`: quince simulaciones de Calbuco, Osorno, Casablanca, Yates y cordillera de Los Lagos.
- `/planificacion/`: plantilla antes/durante/después, imprimible, sin persistencia automática ni ficha médica.
- `/equipo/`: inventario, vida útil declarada, manual, retiro e inspecciones acumulativas.
- `/practicas/`: 52 habilidades, objetivo/resultado/autonomía y vínculos con el inventario.
- `data/skills.json`, `data/learning-paths.json`: habilidades y rutas independientes del piloto.
- `src/data/assessments/`: preguntas versionadas. Nunca sobrescribir una versión usada: crear otra y conservar la anterior. Los intentos se corrigen con su versión histórica.
- `src/lib/program.ts`: integridad de referencias cruzadas; `src/lib/migrations/curriculum.ts`: migración pura v1→v2.
- `tests/etapa4.test.ts`: ampliación, migraciones, estados, equipo y referencias.
- `docs/etapa4/INFORME.md`: resultados, límites y etapa siguiente; `ARCHIVOS.md`: cambios respecto de la entrega anterior.

Los cinco estados se calculan sobre evidencia declarada. «COMPETENTE VALIDADO» exige una evaluación presencial declarada y contextualizada: no verifica identidad ni credenciales, no certifica ni habilita para guiar. Un quiz solo indica comprensión teórica. Los estados de contenido (pendiente, piloto, en desarrollo) son independientes.

Las respuestas abiertas se guardan manualmente y requieren revisión humana. El inventario no calcula caducidad ni declara material apto. No hay adjuntos de evidencia, firma de instructor ni registro inmutable. La edición de una práctica conserva su ID pero actualiza sus campos; exporta respaldos si necesitas conservar cada revisión. La importación reemplaza los datos tras mostrar un resumen: no fusiona copias.

Validación de esta entrega: `npm ci`, `npm run check`, `npm test`, build y comprobación de rutas en `/` y `/academia-andina/`. Los registros reales están en `docs/etapa4/*.log`. Las instrucciones y resultados de etapas anteriores se conservan como historia, no describen los totales actuales.

## Etapas 4.3, 4.4 y 4.5

Tres rutas nuevas, 22 unidades, 31 lecciones y 31 habilidades: fundamentos de cuerda, rescate conceptual y territorio. Incluye 10 lecciones independientes de nudos, 17 diagramas SVG, 31 respuestas abiertas con rúbricas, 6 problemas numéricos, 10 casos integradores, 7 fichas de montaña y 5 especies. `/territorio/` y `/especies/` distinguen datos documentales de información operativa pendiente.

El diario añade ejercicios, observaciones y próxima práctica; el inventario muestra fechas de uso derivadas de prácticas vinculadas. El respaldo v3 anterior admite estos campos nuevos con valores vacíos, conservando información previa.

Informe y archivos: `docs/etapa4/etapa4.3-4.4-4.5.md`. Pruebas nuevas: `tests/etapa435.test.ts`. Los datos territoriales, casos y diagramas se validan en `src/lib/territory.ts` y `src/lib/expanded.ts`. Modelos numéricos: `src/lib/mechanics.ts`. Registros de verificación en `docs/etapa4/etapa435/`.


## Etapa 5 — Montaña invernal

Ruta `/invierno/`: 26 unidades, 29 lecciones, 29 habilidades, 87 preguntas de quiz y 29 respuestas abiertas con rúbrica. Incluye 12 casos hipotéticos, 15 diagramas originales, 16 fichas educativas de equipo y 53 nuevas referencias documentales. Se amplían los módulos existentes sin eliminar las 376 entradas históricas.

- `/invierno/planificacion/`: plan de 21 apartados, guardado manual en el respaldo v3 y checklist para imprimir. Las casillas de la checklist no persisten.
- `/invierno/ejercicios/`: nueve cálculos con corrección; respuestas abiertas guardables. Los resultados numéricos no se registran como competencia.
- `/invierno/equipo/`: fichas de función, límites, inspección, compatibilidad, mantenimiento y práctica; inventario personal separado en `/equipo/`.
- `/practicas/`: nueve plantillas para preparar campos vacíos. Observación contextual y evaluación declarada aparecen por separado.

`src/lib/winter.ts` valida los nuevos datos y modelos; `src/lib/winter-client.ts` conecta la planificación al estado existente. `tests/etapa5.test.ts` comprueba integridad, conservación histórica, ejercicios y compatibilidad. Tras un build, ejecutar también `node scripts/check-winter-build.mjs`; para una base de proyecto, anteponer `BASE_PATH=/academia-andina/`.

Informe: `docs/etapa5/etapa5.md`; bibliografía y límites: `docs/etapa5/fuentes.md`; auditoría: `docs/etapa5/auditoria.md`. No hay boletín local ni rutas operativas validadas. DVA, rescate, cramponaje, piolet y autodetención requieren instrucción presencial. El contenido continúa en desarrollo y revisión.

## Etapas 5.1 y 6 · versión 0.6.0

Ocho estaciones de revisión documental en `/invierno/revision/`, acta local y suplementos visibles en las lecciones afectadas. La revisión presencial no se ha realizado. Diez unidades glaciares en `/glaciar/`, treinta preguntas nuevas, diez respuestas razonadas, cinco plantillas de práctica y tres diagramas originales. Total: 69 unidades, 91 habilidades y 7 rutas de aprendizaje.

Las fuentes y límites de cada unidad se muestran en su página. El inventario DGA no sustituye condiciones actuales; las variantes de cordada no son una configuración universal. La compatibilidad del equipo exacto, la observación de maniobras y su evaluación siguen pendientes.

Ver `docs/etapa6/INFORME.md`, `FUENTES.md` y `ARCHIVOS.md`. Prueba adicional de rutas y anclas del bloque:

```bash
node scripts/check-glacier-build.mjs
BASE_PATH=/academia-andina/ npm run build
BASE_PATH=/academia-andina/ npm run test:build
BASE_PATH=/academia-andina/ node scripts/check-glacier-build.mjs
```

No se ha publicado ni modificado el remoto.

## Etapa 7 · versión 0.7.0

Nueve unidades de escalada en hielo en `/hielo/`, 27 preguntas con explicación de cada opción, nueve respuestas razonadas, cinco plantillas de prácticas y dos diagramas originales. Laboratorio de decisiones de escritorio con guardado local y respaldo v3. Total: 78 unidades, 100 habilidades y 8 rutas; las 376 entradas históricas permanecen pendientes. No se cambió el formato de los respaldos.

Fuentes: Petzl, Black Diamond, UIAA, OMM, NSIDC y American Alpine Institute. Se distingue una fuente consultada de un manual completo o video no revisado íntegramente; los límites aparecen en las lecciones. Todas las maniobras y las compatibilidades del equipo personal requieren revisión de instructor.

Ver `docs/etapa7/INFORME.md`, `FUENTES.md` y `ARCHIVOS.md`. Verificar el bloque después del build:

```bash
node scripts/check-ice-build.mjs
BASE_PATH=/academia-andina/ npm run build
BASE_PATH=/academia-andina/ npm run test:build
BASE_PATH=/academia-andina/ node scripts/check-ice-build.mjs
```

El código conserva las etapas anteriores. Los informes de esas etapas describen sus resultados históricos; el estado actual se documenta en Etapa 11. Sin publicación ni push.

## Etapa 8 · versión 0.8.0

Ocho unidades de escalada alpina en `/alpina/`: planificación, anclajes, encordamiento, manejo de cuerda, grupo, progresión, autorescate y riesgo. Añade 24 preguntas explicadas, ocho respuestas razonadas, cinco plantillas de práctica, dos diagramas y un laboratorio de tiempos ficticios. El caso integrador se guarda manualmente en el respaldo v3; los campos del cálculo no persisten.

Total: 111 lecciones/cuestionarios, 86 unidades, 108 habilidades, 9 rutas, 164 registros de fuentes y 39 diagramas. Las 376 entradas originales siguen pendientes. Ninguna lectura, cálculo o cuestionario acredita una maniobra. Revisión presencial pendiente.

Informe: `docs/etapa8/INFORME.md`; fuentes y límites: `docs/etapa8/FUENTES.md`; cambios: `docs/etapa8/ARCHIVOS.md`. Después del build: `node scripts/check-alpine-build.mjs`. El mismo comando acepta `BASE_PATH=/academia-andina/`.

## Etapa 9 · versión 0.9.0

Diez unidades en `/altitud/`: fisiología, aclimatación, MAM, HACE, HAPE, planificación, campamentos, nutrición, hidratación y emergencias. Treinta preguntas explicadas, diez respuestas razonadas, cinco plantillas de simulación y dos diagramas. El laboratorio compara tres perfiles ficticios de pernocta y no clasifica riesgo ni aptitud. El caso integrador guarda su respuesta manualmente en el respaldo v3; el selector del laboratorio no persiste.

Total: 121 lecciones/cuestionarios, 96 unidades, 118 habilidades, 10 rutas, 170 registros bibliográficos y 41 diagramas. Se preservan 376 entradas históricas pendientes. No cambia el formato del respaldo.

Fuentes: CDC, resumen institucional WMS 2024, UIAA MedCom (nutrición histórica) y FDA. Revisión médica y de instructor pendientes. No hay prescripción, diagnóstico automático ni registro de datos clínicos.

Informe: `docs/etapa9/INFORME.md`; bibliografía: `docs/etapa9/FUENTES.md`; cambios: `docs/etapa9/ARCHIVOS.md`. Para verificar anclas del bloque tras el build: `node scripts/check-altitude-build.mjs`. Para base de proyecto, anteponer `BASE_PATH=/academia-andina/` tanto al build como a los verificadores.

## Etapa 10 · versión 0.10.0

Dieciséis unidades progresivas en `/entrenamiento/`, 48 preguntas explicadas, seis plantillas de práctica, dos diagramas originales y doce referencias con límites de acceso. Laboratorio de sesiones ficticias: duración × esfuerzo y ritmo vertical, sin puntuación de seguridad ni prescripción. Caso integrador con persistencia y respaldo JSON v3. Total: 137 lecciones, 112 unidades, 134 habilidades, 11 rutas y 182 fuentes; las 376 entradas originales continúan pendientes.

`src/lib/training.ts` valida y calcula medidas; `training-client.ts` conecta el selector; `src/pages/entrenamiento/index.astro` contiene la portada. Contenido en Markdown, cuestionarios versionados en `src/data/assessments`, plantillas en `src/data/training-templates.json`. Pruebas: `tests/etapa10.test.ts`. Después del build: `node scripts/check-training-build.mjs`; acepta `BASE_PATH=/academia-andina/`.

Resultados y limitaciones: `docs/etapa10/INFORME.md`. Bibliografía: `FUENTES.md`; inventario: `ARCHIVOS.md`. Continúan pendientes revisión del profesional del ejercicio, nutricionista y médico en sus áreas e instructor de montaña. No hay plan individual, habilitación ni certificación.

## Etapa 11 · versión 0.11.0

Diez unidades de ecología en `/ecologia/`, vinculadas al M15 histórico y dependientes de la ruta territorial. Ecosistemas, bosque, ambientes altoandinos/volcánicos, flora, fauna, endemismo/conservación, invasoras, conducta, impactos/No Deje Rastro e interpretación. Treinta preguntas con explicación por opción, seis plantillas, dos diagramas y diez fuentes atribuidas. Las cinco fichas de especies anteriores se conservan; no se presenta un inventario regional completo.

Cuaderno de observación con creación y edición: fecha, área amplia, ambiente, rasgos, hipótesis, evidencia textual, revisión declarada y cuidado. Se guarda dentro de `responses['ecology-notebook:v1']` en el respaldo v3, sin migración destructiva. Límite: 20 registros y 20.000 caracteres conjuntos; no admite adjuntos ni campos de coordenadas. El texto libre no se filtra automáticamente: no escribir localizaciones sensibles. Una observación no crea prácticas, evaluaciones ni competencias.

`src/lib/ecology.ts`: esquemas y lógica; `ecology-client.ts`: interfaz; `src/pages/ecologia/index.astro`: portada y cuaderno. `state.ts` valida el cuaderno antes de importar o guardar. `tests/etapa11.test.ts` cubre conservación, currículo, quizzes, búsqueda, persistencia y entradas inválidas. Después del build: `node scripts/check-ecology-build.mjs` (admite `BASE_PATH=/academia-andina/`).

Total al cierre de la Etapa 11: 147 lecciones/cuestionarios, 122 unidades, 144 habilidades, 12 rutas, 192 fuentes y 45 diagramas. Las 376 entradas originales continúan pendientes. No hay validación profesional, certificación ni publicación. Ver `docs/etapa11/INFORME.md`, `FUENTES.md` y `ARCHIVOS.md`.


## Etapa 12 · versión 0.12.0

Diez unidades progresivas en `/geologia/`: tectónica/subducción, edificios y nombres, magma/lava/domos, tefra/ceniza, corrientes piroclásticas, lahares, relieve volcánico/glaciar, monitoreo, mapas y síntesis territorial. Treinta preguntas explicadas, seis plantillas de taller supervisado, dos diagramas y quince registros bibliográficos consultados. Cuatro suplementos amplían Sarnoso, Casablanca, Tronador y Puntiagudo sin cambiar los datos históricos de sus fichas.

El laboratorio clasifica cuatro documentos ficticios y explica qué conclusión respaldan. No utiliza alertas actuales, no declara rutas seguras y no crea competencias. El caso integrador conserva su respuesta en `responses['plan-geologia:v1']`, incluida en el respaldo v3 existente. No hay cambios de formato ni migración de datos.

Total al cierre de la Etapa 12: 157 lecciones/cuestionarios, 132 unidades, 154 habilidades, 13 rutas, 207 registros bibliográficos y 47 diagramas. Las 376 entradas originales siguen pendientes. Contenido en desarrollo: revisión de especialista en geología/vulcanología e instructor pendiente.

Lógica y esquemas: `src/lib/geology.ts`; interfaz: `geology-client.ts`; datos: `geology-cases.json` y `geology-templates.json`; pruebas: `tests/etapa12.test.ts`. Después del build: `node scripts/check-geology-build.mjs`; admite `BASE_PATH=/academia-andina/`. Informe, fuentes y relación de archivos en `docs/etapa12/`.

El build limpia únicamente `dist/`, `.astro/` y `node_modules/.astro/` antes de generar, para evitar reutilizar contenido transformado con una ruta base anterior. Detener el servidor de desarrollo antes de comparar builds de distintas bases.


## Etapa 13 · versión 0.13.0

Ocho unidades progresivas en `/historia/`, vinculadas al M17 histórico: crítica de fuentes; alpinismo y participación; clubes chilenos; equipo y ensayos; esquí/escalada e instituciones; rescate organizado; exploración de Llanquihue; patrimonio vivo. Veinticuatro preguntas explicadas, ocho respuestas razonadas y cuatro plantillas de taller. Doce referencias con niveles de acceso explícitos; no se confunde catálogo, resumen, síntesis institucional y documento primario íntegro.

Cronología selectiva con once hitos y filtro por ámbito, tres casos ficticios de análisis de evidencia y proyecto integrador con guion local. La cronología y los casos no se guardan como evaluaciones. El guion se conserva en `responses['plan-historia:v1']` e integra el respaldo JSON v3 existente, sin migración. El texto libre no debe incluir datos de terceros, localizaciones sensibles ni conocimientos restringidos.

Lógica y validación: `src/lib/history.ts`; interfaz: `history-client.ts`; página: `src/pages/historia.astro`; datos: `history-events.json` y `history-templates.json`. Diez pruebas nuevas en `tests/etapa13.test.ts`. Después del build: `node scripts/check-history-build.mjs`, también con `BASE_PATH=/academia-andina/`.

Total actual: 165 lecciones/cuestionarios, 140 unidades, 162 habilidades, 14 rutas, 219 registros bibliográficos y 47 diagramas. Las 376 entradas originales siguen pendientes. Historiador, especialista de patrimonio e instructor deben revisar las adaptaciones; incorporar conocimientos comunitarios requiere colaboración acordada. No es una historia exhaustiva, certificación ni publicación. Informe, fuentes y cambios en `docs/etapa13/`.

## Etapa 14 · versión 0.14.0

Cuatro fichas nuevas (Hornopirén, Michinmahuida, Chaitén y Corcovado), 64 estados de evidencia y taller en `/territorio/comparar/`. Son fichas documentales parciales, no itinerarios ni lecciones declaradas terminadas. Permanecen 165 lecturas y 376 entradas originales pendientes. El taller tiene tres preguntas explicadas, comparación escrita persistente y rúbrica humana; no concede competencia ni se registra como un quiz de lección.

Desde esta carpeta, con Node 24+: `npm ci`, `npm run dev`. Verificación: `npm test`, `npm run check`, `npm run build`, `npm run test:build`. Para probar GitHub Pages: `BASE_PATH=/academia-andina/ npm run build` y `BASE_PATH=/academia-andina/ npm run test:build`. La base debe coincidir con el nombre real del repositorio de destino; no se ha publicado.

Resultados y límites: [informe de Etapa 14](docs/etapa14/INFORME.md). Fuentes: [registro documental](docs/etapa14/FUENTES.md). Archivos: [inventario](docs/etapa14/ARCHIVOS.md).


## Etapa 15 · Expedientes Calbuco y Osorno

Versión 0.15.0: contraste documental parcial, cuatro ejercicios y borrador de solicitudes con guardado local. Ver docs/etapa15/INFORME.md para alcance y límites de verificación. Ruta: /territorio/expedientes/.

## Etapa 15.1 · Selección cartográfica

Versión 0.15.1: cinco fichas IGM con límites de consulta, acta guardable y pauta local de respaldo. Ruta /territorio/cartografia/. Ver docs/etapa15_1/INFORME.md; inspección de láminas y prueba completa de navegador pendientes.


## Etapa 16 · Pedagogía, guiado y liderazgo

Seis lecciones, 18 preguntas explicadas, cuatro plantillas y plan de taller guardable. Ruta /liderazgo/. Informe y límites: docs/etapa16/INFORME.md. La revisión docente/instructora y la prueba de navegador siguen pendientes.


## Etapa 17 · Casos integradores de expedición

Tres escenarios ficticios, nueve momentos de decisión, pautas razonadas y expedientes guardables. Ruta /expediciones/. Se conservan currículo, lecciones, evaluaciones y respaldo v3. Informe y pendientes: docs/etapa17/INFORME.md.


## Etapa 18 · Auditoría curricular

Inventario de 24 módulos, 418 entradas totales y 171 lecciones; 376 entradas históricas permanecen planned. No se infiere porcentaje de cobertura. Ruta /auditoria/. Ejecutar npm run audit:curriculum para regenerar el inventario; build lo incluye. Informe: docs/etapa18/INFORME.md.


## Etapa 19 · Matriz curricular

Ruta `/trazabilidad/`: registro de las 376 entradas históricas. Primera comparación editorial de las 17 entradas M19 frente a seis lecciones de Etapa 16 y grupo-liderazgo: 14 vínculos parciales propuestos, 3 sin vínculo propuesto en ese corpus y 359 entradas sin revisar. Cada vínculo incluye pasaje literal, alcance y vacío. No se calcula porcentaje ni se cambian estados originales.

La compilación comprueba referencias, integridad de la matriz y existencia de los pasajes; falla si estos se eliminan. Acta local `trazabilidad-curricular:v1` mediante el mecanismo existente. Informe y matriz legible en `docs/etapa19/`.


## Etapa 20 · Fundamentos, riesgo y planificación

La ruta `/trazabilidad/` utiliza ahora `src/data/traceability20.json`. Se conservan la matriz de Etapa 19 y sus propuestas. Se compararon M00, M13 y M20.06/M20.08/M20.15: 28 vínculos parciales nuevos y una entrada sin vínculo propuesto (ética). Total: 42 propuestas parciales, 4 sin vínculo en el corpus comparado y 330 sin revisar. Los estados originales no cambian. La compilación valida los pasajes de la matriz vigente. Documentación: `docs/etapa20/`.


## Etapa 21 · Ética y responsabilidad

Nueva unidad `etica-responsabilidad` (M00), una habilidad de análisis y cuatro preguntas versionadas. `/etica/` reúne cuatro casos originales y acta local `etica-responsabilidad:v1`. Referencias institucionales ANGM y UIAA con alcance de consulta explícito. No se verifican obligaciones jurídicas específicas ni se acredita competencia. La matriz vigente es `traceability21.json`: 43 propuestas parciales, tres sin vínculo en corpus comparado y 330 sin revisar. Informe y matriz en `docs/etapa21/`.


## Etapa 22 · Comunicación intercultural e interpretación

Dos unidades en M19, dos habilidades y seis preguntas versionadas. `/interpretacion/` ofrece taller con tarjetas ficticias, acta local y ficha descargable Markdown. Complementa patrimonio vivo de Etapa 13 sin modificarlo. Se distingue el texto indexado UNESCO de la página NPS consultada y su adaptación a taller ambiental. No se realizaron consultas comunitarias ni verificaciones de hechos locales. Matriz vigente `traceability22.json`: 45 propuestas parciales, una sin vínculo en corpus comparado y 330 sin revisar. Documentación en `docs/etapa22/`.


## Etapa 23 · Quejas e incidentes de servicio

Una unidad M19, una habilidad y cuatro preguntas versionadas. `/atencion/` reúne tres casos ficticios, expediente local `quejas-servicio:v1` y ficha Markdown descargable. No admite casos reales ni resuelve obligaciones legales. Matriz vigente `traceability23.json`: 46 propuestas parciales y 330 sin revisar. Las 17 entradas de M19 tienen vínculo parcial propuesto, no cobertura completa. Informe en `docs/etapa23/`.

## Etapa 24 · Integración de guiado y servicio

`/integracion-guiado/` reúne un caso ficticio de aula con seis momentos y cuatro contrastes entre decisiones. Enlaza lecturas previas, incluye expediente Markdown descargable y acta local `integracion-guiado:v1`. Los momentos dependen de información anterior; la compilación valida referencias y orden. La revisión de coherencia es humana, sin puntuación automática ni certificación. No se añaden lecciones ni correspondencias curriculares. Documentación en `docs/etapa24/`.

## Etapa 25 · Ruta integrada de guiado y servicio

`/ruta-guiado/` organiza diez lecciones existentes en cuatro bloques y enlaza el integrador de Etapa 24. La ruta se registra en el programa sin modificar rutas previas. Los estados teóricos utilizan los mismos identificadores y almacenamiento existentes; no hay progreso duplicado ni migración de respaldos. Cinco accesos de navegación se agrupan bajo Guiado y servicio; las páginas conservan sus URL y enlaces de retorno. La revisión visual y de interacción sigue pendiente. Informe en `docs/etapa25/`.

## Etapa 26 · Elegir qué estudiar

`/estudiar/` organiza las 16 rutas existentes en seis objetivos. Cada grupo diferencia teoría, taller documental y revisión práctica. El programa incorpora enlaces directos estables por ruta. Sin cambios en lecciones, prerrequisitos o almacenamiento. Informe en `docs/etapa26/INFORME.md`.

## Etapa 27 · Retomar rutas

Panel compartido de prerrequisitos y progreso teórico en el programa (16 rutas) y 13 páginas temáticas. Sugiere la primera lectura pendiente, con manejo explícito de datos no disponibles. No altera el respaldo ni registra actividad por abrir una página.

## Etapa 28 · Mensajes de estado y alcance

Estados sin cargar diferenciados de lecturas no estudiadas; progreso oculto hasta disponer de datos y mensajes explícitos ante fallo de carga. Orientación de Fundamentales y asignaturas actualizada. No cambia el contenido académico ni el respaldo.

## Etapa 29 · Navegación por ruta desde las lecciones

Cada lección muestra las rutas que la incluyen, posición y vecinos de cada secuencia. Las lecturas sin ruta conservan navegación editorial identificada. Plan de cierre propuesto: tres etapas adicionales, detalladas en `docs/etapa29/CIERRE.md`.

## Etapa 30 · Revisión de uso y accesibilidad

Inspección estática reproducible en `scripts/audit-accessibility.py`; resultados, tres hallazgos para corrección y recorridos pendientes en `docs/etapa30/INFORME.md`. No constituye validación visual ni conformidad WCAG.

## Etapa 31 · Correcciones de uso

Filtro Ruta de estudio disponible, índice de lecciones visible también en móvil y aviso explícito en cuaderno e historial ante fallo inicial de carga. Ver `docs/etapa31/INFORME.md`.
