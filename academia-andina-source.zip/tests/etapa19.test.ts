import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {validateTraceability} from '../src/lib/traceability.ts';
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8'));
const entries=read('data/curriculum.json').entries.filter((e:{origin:string})=>e.origin==='etapa1');
const rows=read('src/data/traceability19.json').rows;
const lessons=new Map(readdirSync('src/content/lecciones').filter(f=>f.endsWith('.md')).map(f=>[f.slice(0,-3),readFileSync('src/content/lecciones/'+f,'utf8').split('---').slice(2).join('---')]));
test('matriz completa de entradas históricas, con pasajes comprobables',()=>{
 assert.equal(entries.length,376); assert.deepEqual(validateTraceability(rows,entries,lessons),[]);
 assert.equal(rows.filter((r:any)=>r.status==='propuesta-parcial').length,14);
 assert.equal(rows.filter((r:any)=>r.status==='sin-revisar').length,359);
});
test('detecta evidencia obsoleta, entradas omitidas y duplicadas',()=>{
 const modified=structuredClone(rows); modified[0]=structuredClone(rows[1]);
 const linked=modified.find((r:any)=>r.links.length);linked.links[0].quote='PASAJE INEXISTENTE';
 const errors=validateTraceability(modified,entries,lessons);
 assert.ok(errors.some(e=>e.includes('omitida')));assert.ok(errors.some(e=>e.includes('repetida')));assert.ok(errors.some(e=>e.includes('Evidencia ausente')));
});
test('rechaza estados que afirman cobertura y propuestas sin evidencia',()=>{
 const modified=structuredClone(rows);modified[0].status='cubierta';modified[1].status='propuesta-parcial';
 assert.ok(validateTraceability(modified,entries,lessons).some(e=>e.includes('Estado inválido')));
 assert.ok(validateTraceability(modified,entries,lessons).some(e=>e.includes('Estado incoherente')));
});
