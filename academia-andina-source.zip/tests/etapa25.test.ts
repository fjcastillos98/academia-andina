import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {validateStudyRoute} from '../src/lib/route25.ts';
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8'));
const raw=read('src/data/route25.json'),paths=read('data/learning-paths.json');
const ids=readdirSync('src/content/lecciones').filter(f=>f.endsWith('.md')).map(f=>f.slice(0,-3));
test('ruta reúne diez lecciones únicas en cuatro bloques alineados con programa',()=>{const r=validateStudyRoute(raw,paths,ids);assert.equal(r.blocks.length,4);assert.equal(r.blocks.flatMap(b=>b.lessons).length,10);});
test('rechaza duplicación, referencias desconocidas y divergencia de orden',()=>{
 for(const mutate of [(x:any)=>x.blocks[1].lessons[0]=x.blocks[0].lessons[0],(x:any)=>x.blocks[0].lessons.reverse(),(x:any)=>x.blocks[0].lessons[0]='ausente',(x:any)=>x.path='ausente']){const x=structuredClone(raw);mutate(x);assert.throws(()=>validateStudyRoute(x,paths,ids));}
});
