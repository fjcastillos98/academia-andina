import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {validateExpeditions} from '../src/lib/expeditions17.ts';
import {emptyState,parseBackup} from '../src/lib/state.ts';
const raw=JSON.parse(readFileSync('src/data/expedition-cases17.json','utf8')),ids=readdirSync('src/content/lecciones').map(f=>f.slice(0,-3));
test('Tres casos y nueve momentos enlazan lecturas existentes',()=>{const c=validateExpeditions(raw,ids);assert.equal(c.length,3);assert.equal(c.flatMap(c=>c.events).length,9);});
test('Rechaza casos duplicados, lecturas desconocidas y pautas vacías',()=>{assert.throws(()=>validateExpeditions([...raw,raw[0]],ids));for(const mutate of [(x:any)=>x[0].lessons=['falsa'],(x:any)=>x[0].events[0].review='',(x:any)=>x[0].events.pop()]){const x=structuredClone(raw);mutate(x);assert.throws(()=>validateExpeditions(x,ids));}});
test('Los tres expedientes sobreviven al respaldo sin reemplazar el plan previo',()=>{const s=emptyState();s.responses['plan-liderazgo:v1']='Anterior';for(const c of raw)s.responses[`expedicion:${c.id}:v1`]='Momento 1: hipótesis. Momento 2: cambio.';assert.deepEqual(parseBackup(JSON.stringify(s),[],[]),s);assert.equal(s.practices.length,0);});
