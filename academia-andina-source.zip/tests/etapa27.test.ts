import test from 'node:test';
import assert from 'node:assert/strict';
import {routeProgress} from '../src/lib/route-progress.ts';
test('retoma la primera lectura pendiente sin confundir aprobación con lectura',()=>{
 const p=routeProgress(['a','b','c'],id=>id==='a',id=>id==='b');
 assert.deepEqual(p,{read:1,approved:1,total:3,next:'b'});
});
test('ruta nueva, completa y compartida conservan criterios separados',()=>{
 const read=new Set(['a','b']);
 assert.equal(routeProgress(['c','d'],id=>read.has(id),()=>false).next,'c');
 assert.deepEqual(routeProgress(['a','b'],id=>read.has(id),()=>false),{read:2,approved:0,total:2,next:null});
 assert.deepEqual(routeProgress(['b','c'],id=>read.has(id),()=>false),{read:1,approved:0,total:2,next:'c'});
});
