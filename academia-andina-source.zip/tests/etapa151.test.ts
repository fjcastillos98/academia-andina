import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {emptyState,parseBackup,writeState,readState} from '../src/lib/state.ts';
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8'));
test('Cinco fichas cartográficas enlazan fuentes con límites y pendientes',()=>{const cards=read('src/data/cartography151.json'),sources=read('src/data/sources.json');assert.equal(cards.length,5);assert.equal(new Set(cards.map((c:any)=>c.id)).size,5);for(const c of cards){assert(sources.some((s:any)=>s.id===c.source));assert(c.limit.length>50);assert(c.next.length>40);assert(c.coverage);}});
test('Acta nueva y borrador anterior sobreviven al respaldo sin alterar prácticas',()=>{const s=emptyState();s.responses['cartografia-revision:v1']='Correntoso: referencia vertical pendiente.';s.responses['territorio-expedientes:v1']='Conservar discrepancia.';const data=new Map<string,string>(),storage={getItem:(k:string)=>data.get(k)??null,setItem:(k:string,v:string)=>{data.set(k,v);}};writeState(storage,'test151',s);assert.deepEqual(parseBackup(JSON.stringify(readState(storage,'test151',[],[])),[],[]),s);assert.deepEqual(s.practices,[]);});
