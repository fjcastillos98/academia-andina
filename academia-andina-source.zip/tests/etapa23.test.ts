import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {validateTraceability} from '../src/lib/traceability.ts';
import {grade} from '../src/lib/learning.ts';
import {emptyState,parseBackup} from '../src/lib/state.ts';
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8'));
test('Etapa23 añade solo correspondencia M19.17 y valida sus pasajes',()=>{
 const old=read('src/data/traceability22.json'),now=read('src/data/traceability23.json');
 for(const r of old.rows)if(r.entry!=='M19.17')assert.deepEqual(now.rows.find((n:any)=>n.entry===r.entry),r);
 const lessons=new Map(readdirSync('src/content/lecciones').filter(f=>f.endsWith('.md')).map(f=>[f.slice(0,-3),readFileSync('src/content/lecciones/'+f,'utf8').split('---').slice(2).join('---')]));
 assert.deepEqual(validateTraceability(now.rows,read('data/curriculum.json').entries.filter((e:any)=>e.origin==='etapa1'),lessons),[]);assert.equal(now.rows.filter((r:any)=>r.status==='propuesta-parcial').length,46);assert.equal(now.rows.filter((r:any)=>r.status==='sin-revisar').length,330);
});
test('cuatro preguntas explicadas se corrigen y están versionadas',()=>{
 const l=JSON.parse(readFileSync('src/content/lecciones/quejas-incidentes-servicio.md','utf8').split('---')[1]);const qs=l.quiz.questions;
 assert.equal(qs.length,4);assert.deepEqual(read('src/data/assessments/quejas-incidentes-servicio.v1.json').questions,qs);
 assert.ok(grade(qs,qs.map((q:any)=>q.answer)).passed);assert.ok(!grade(qs,qs.map((q:any)=>(q.answer+1)%q.options.length)).passed);
 for(const q of qs)assert.equal(q.rationales.length,q.options.length);
});
test('expediente ficticio se restaura junto al guion sin acreditar prácticas',()=>{
 const s=emptyState();s.responses['quejas-servicio:v1']='Preparado, falta revisión.';s.responses['guion-intercultural:v1']='Anterior';assert.deepEqual(parseBackup(JSON.stringify(s),[],[]),s);assert.equal(s.practices.length,0);
});
