import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {validateTraceability} from '../src/lib/traceability.ts';
import {grade} from '../src/lib/learning.ts';
import {emptyState,parseBackup} from '../src/lib/state.ts';
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8'));
test('nueva evidencia modifica solo M00.05 y conserva pasajes comprobables',()=>{
 const old=read('src/data/traceability20.json'),now=read('src/data/traceability21.json');
 for(const r of old.rows)if(r.entry!=='M00.05')assert.deepEqual(now.rows.find((n:any)=>n.entry===r.entry),r);
 const lessons=new Map(readdirSync('src/content/lecciones').filter(f=>f.endsWith('.md')).map(f=>[f.slice(0,-3),readFileSync('src/content/lecciones/'+f,'utf8').split('---').slice(2).join('---')]));
 assert.deepEqual(validateTraceability(now.rows,read('data/curriculum.json').entries.filter((e:any)=>e.origin==='etapa1'),lessons),[]);
 assert.equal(now.rows.filter((r:any)=>r.status==='propuesta-parcial').length,43);
});
test('cuatro casos tienen límites, fuentes válidas y preguntas corregibles',()=>{
 const cases=read('src/data/ethics21.json');assert.equal(cases.length,4);assert.equal(new Set(cases.map((c:any)=>c.id)).size,4);
 const lesson=JSON.parse(readFileSync('src/content/lecciones/etica-responsabilidad.md','utf8').split('---')[1]);
 for(const c of cases){assert.ok(lesson.sources.includes(c.source));assert.ok(c.limit.length>30);}
 const qs=lesson.quiz.questions;assert.ok(grade(qs,qs.map((q:any)=>q.answer)).passed);assert.ok(!grade(qs,qs.map((q:any)=>(q.answer+1)%q.options.length)).passed);
 for(const q of qs)assert.equal(q.rationales.length,q.options.length);
});
test('acta ética coexiste con trazabilidad sin acreditar prácticas',()=>{
 const s=emptyState();s.responses['etica-responsabilidad:v1']='Caso ficticio; primera respuesta, objeción y corrección.';s.responses['trazabilidad-curricular:v1']='Revisión pendiente';
 assert.deepEqual(parseBackup(JSON.stringify(s),[],[]),s);assert.equal(s.practices.length,0);
});
