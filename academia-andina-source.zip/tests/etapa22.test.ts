import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {validateTraceability} from '../src/lib/traceability.ts';
import {grade} from '../src/lib/learning.ts';
import {emptyState,parseBackup} from '../src/lib/state.ts';
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8'));
const ids=['comunicacion-intercultural','interpretacion-con-evidencia'];
test('Etapa22 conserva correspondencias previas y añade evidencia a dos entradas',()=>{
 const old=read('src/data/traceability21.json'),now=read('src/data/traceability22.json');
 for(const r of old.rows)if(!['M19.14','M19.15'].includes(r.entry))assert.deepEqual(now.rows.find((n:any)=>n.entry===r.entry),r);
 const lessons=new Map(readdirSync('src/content/lecciones').filter(f=>f.endsWith('.md')).map(f=>[f.slice(0,-3),readFileSync('src/content/lecciones/'+f,'utf8').split('---').slice(2).join('---')]));
 assert.deepEqual(validateTraceability(now.rows,read('data/curriculum.json').entries.filter((e:any)=>e.origin==='etapa1'),lessons),[]);
 assert.equal(now.rows.filter((r:any)=>r.status==='propuesta-parcial').length,45);
});
test('seis preguntas explicadas distinguen evidencia e inferencias',()=>{
 let total=0;
 for(const id of ids){const l=JSON.parse(readFileSync(`src/content/lecciones/${id}.md`,'utf8').split('---')[1]);const qs=l.quiz.questions;total+=qs.length;
 assert.ok(grade(qs,qs.map((q:any)=>q.answer)).passed);assert.ok(!grade(qs,qs.map((q:any)=>(q.answer+1)%q.options.length)).passed);
 for(const q of qs){assert.equal(q.options.length,q.rationales.length);assert.ok(l.sources.includes(q.source));}}
 assert.equal(total,6);
});
test('respaldo preserva guion y ética sin inventar prácticas',()=>{
 const s=emptyState();s.responses['guion-intercultural:v1']='Preparado: falta ensayo.';s.responses['etica-responsabilidad:v1']='Anterior';
 assert.deepEqual(parseBackup(JSON.stringify(s),[],[]),s);assert.equal(s.practices.length,0);
});
