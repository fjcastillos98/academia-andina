import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {validateIntegration} from '../src/lib/integration24.ts';
import {emptyState,parseBackup} from '../src/lib/state.ts';
const raw=JSON.parse(readFileSync('src/data/integration24.json','utf8'));
const ids=readdirSync('src/content/lecciones').filter(f=>f.endsWith('.md')).map(f=>f.slice(0,-3));
test('integrador enlaza seis momentos, cuatro contrastes y lecturas existentes',()=>{
 const c=validateIntegration(raw,ids);assert.equal(c.stages.length,6);assert.equal(c.checks.length,4);
 assert.deepEqual(c.stages.map(s=>s.id),['briefing','adaptacion','decision','interpretacion','queja','debriefing']);
});
test('rechaza dependencias futuras, lecturas inexistentes y contrastes incompletos',()=>{
 for(const mutate of [(x:any)=>x.stages[0].dependsOn=['queja'],(x:any)=>x.stages[1].id=x.stages[0].id,(x:any)=>x.stages[0].lessons=['no-existe'],(x:any)=>x.checks[0].stages=['briefing','ausente'],(x:any)=>x.checks[0].repair='',(x:any)=>x.checks.push(x.checks[0])]){
 const x=structuredClone(raw);mutate(x);assert.throws(()=>validateIntegration(x,ids));}
});
test('expediente integrado preserva actas anteriores y no acredita práctica',()=>{
 const s=emptyState();s.responses['integracion-guiado:v1']='Briefing inicial. Cambio al recibir queja. Pendiente de ensayo.';s.responses['quejas-servicio:v1']='Anterior';s.responses['plan-liderazgo:v1']='Anterior';
 assert.deepEqual(parseBackup(JSON.stringify(s),[],[]),s);assert.equal(s.practices.length,0);
});
