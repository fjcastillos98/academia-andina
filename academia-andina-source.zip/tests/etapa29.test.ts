import test from 'node:test';
import assert from 'node:assert/strict';
import {lessonRoutes} from '../src/lib/lesson-routes.ts';
const routes=[{id:'uno',title:'Uno',lessonIds:['a','b','c']},{id:'dos',title:'Dos',lessonIds:['b','a']}];
test('una lectura compartida conserva su posición y vecinos en cada ruta',()=>{
 assert.deepEqual(lessonRoutes('a',routes),[{id:'uno',title:'Uno',position:1,total:3,previous:null,next:'b'},{id:'dos',title:'Dos',position:2,total:2,previous:'b',next:null}]);
});
test('lectura intermedia y lectura fuera de rutas no reciben vecinos de otra secuencia',()=>{
 assert.deepEqual(lessonRoutes('b',routes)[0],{id:'uno',title:'Uno',position:2,total:3,previous:'a',next:'c'});
 assert.deepEqual(lessonRoutes('ausente',routes),[]);
 assert.deepEqual(lessonRoutes('a',[{id:'sola',title:'Sola',lessonIds:['a']}])[0],{id:'sola',title:'Sola',position:1,total:1,previous:null,next:null});
});
