import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {validateTraceability} from '../src/lib/traceability.ts';
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8'));
const previous=read('data/archive/etapa19/traceability.json');
const current=read('src/data/traceability20.json');
const entries=read('data/curriculum.json').entries.filter((e:{origin:string})=>e.origin==='etapa1');
const lessons=new Map(readdirSync('src/content/lecciones').filter(f=>f.endsWith('.md')).map(f=>[f.slice(0,-3),readFileSync('src/content/lecciones/'+f,'utf8').split('---').slice(2).join('---')]));
test('ampliación conserva propuestas anteriores e integridad de evidencia',()=>{
 assert.deepEqual(validateTraceability(current.rows,entries,lessons),[]);
 for(const row of previous.rows.filter((r:any)=>r.status!=='sin-revisar')) assert.deepEqual(current.rows.find((r:any)=>r.entry===row.entry),row);
 assert.equal(current.rows.filter((r:any)=>r.status==='propuesta-parcial').length,42);
 assert.equal(current.rows.filter((r:any)=>r.status==='sin-revisar').length,330);
});
test('alcance ampliado no convierte entradas ajenas ni elimina lagunas',()=>{
 for(const row of current.rows){
  const old=previous.rows.find((r:any)=>r.entry===row.entry);
  if(JSON.stringify(row)!==JSON.stringify(old)) assert.ok(row.entry.startsWith('M00.')||row.entry.startsWith('M13.')||['M20.06','M20.08','M20.15'].includes(row.entry));
 }
 assert.equal(current.rows.find((r:any)=>r.entry==='M00.05').status,'sin-vinculo-propuesto');
 for(const row of current.rows.filter((r:any)=>r.entry.startsWith('M13.'))) assert.ok(row.links.every((l:any)=>l.gap.length>20));
});
