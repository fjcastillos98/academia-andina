# Expediente integrado · Etapa 24

Caso ficticio de aula. No acredita competencia. No introducir datos privados.

Simulación ficticia en una sala de formación de Puerto Montt. Tres participantes trabajan con tarjetas de un paisaje inventado. No hay salida a terreno, datos de pasajeros reales ni conocimientos atribuidos a una comunidad. La invitación promete que al terminar podrán preparar un relato documentado; una diapositiva interna promete además autonomía para guiar, sin fundamento.

## briefing · Objetivo y promesa

La invitación y la diapositiva no prometen lo mismo. El facilitador dispone de 45 minutos ficticios de aula. No se ha realizado ninguna evaluación práctica de guiado.

Tarea: Redacta objetivo observable, alcance y briefing. Señala qué afirmación corriges antes de comenzar y cómo comprobarás que se entendió.

- Respuesta inicial:
- Evidencia y límites:
- Cambio respecto de momentos anteriores:
- Respuesta revisada:

## adaptacion · Dos comprensiones distintas

Una participante interpreta que debe identificar una especie; otra cree que debe inventar una leyenda. Las tarjetas solo describen colores y formas, sin identificación científica ni fuente cultural. El tercer participante pide una consigna escrita.

Tarea: Ajusta apoyos y secuencia conservando el objetivo acordado. Escribe la nueva consigna y una comprobación que no atribuya la dificultad a la identidad de nadie.

- Respuesta inicial:
- Evidencia y límites:
- Cambio respecto de momentos anteriores:
- Respuesta revisada:

## decision · Se reduce el tiempo disponible

La sala debe liberarse antes de lo previsto y quedan 15 minutos ficticios. Un participante propone saltarse la revisión de evidencia; otro señala que ese era el objetivo anunciado.

Tarea: Compara dos alternativas de aula, decide cuál permite conservar una evidencia mínima y explica qué actividad aplazas. Documenta quién coordina el cambio y cómo se comunica.

- Respuesta inicial:
- Evidencia y límites:
- Cambio respecto de momentos anteriores:
- Respuesta revisada:

## interpretacion · Un relato convincente sin apoyo

El primer borrador afirma que el turismo causó la diferencia entre dos imágenes. Las tarjetas no permiten saber si muestran el mismo sitio ni cuándo se tomaron. Una anotación anónima atribuye un significado del lugar a toda una comunidad.

Tarea: Reescribe la idea central, identifica dos afirmaciones que no puedes sostener y prepara una pregunta para comprobar qué entiende quien escucha. Mantén el alcance reducido del momento anterior.

- Respuesta inicial:
- Evidencia y límites:
- Cambio respecto de momentos anteriores:
- Respuesta revisada:

## queja · Una expectativa pendiente

Una participante reclama que se prometió autonomía para guiar. Conservó una fotografía de la diapositiva inicial. No pide atención de emergencia; quiere saber qué aprendió realmente y cómo se corregirá la información que recibió.

Tarea: Reconstruye la discrepancia sin negar el documento inicial. Propón acuse de recibo, revisión por responsable y seguimiento. Distingue la corrección ya hecha de lo que todavía necesita comprobarse.

- Respuesta inicial:
- Evidencia y límites:
- Cambio respecto de momentos anteriores:
- Respuesta revisada:

## debriefing · Cerrar con evidencia incompleta

El taller termina sin incidentes físicos. Hay un guion revisado y una queja recibida, pero todavía no se ha realizado el ensayo aplazado ni comprobado la comprensión de todos los participantes.

Tarea: Redacta un debriefing que distinga resultados, pendientes y decisiones. Propón un siguiente ensayo y una acción de mejora con evidencia de cumplimiento.

- Respuesta inicial:
- Evidencia y límites:
- Cambio respecto de momentos anteriores:
- Respuesta revisada:

## Revisión de coherencia

### promesa

¿La promesa corregida coincide con el aprendizaje que afirmas al cerrar?

- Fragmentos comparados:
- Contradicción o coherencia sustentada:
- Corrección y pendiente:

### criterio

¿Las adaptaciones y la reducción de tiempo conservan un criterio observable?

- Fragmentos comparados:
- Contradicción o coherencia sustentada:
- Corrección y pendiente:

### atribucion

¿El relato final respeta los límites de las tarjetas y de la consulta cultural?

- Fragmentos comparados:
- Contradicción o coherencia sustentada:
- Corrección y pendiente:

### cierre

¿Distingues respuesta enviada, acción ejecutada y efecto comprobado?

- Fragmentos comparados:
- Contradicción o coherencia sustentada:
- Corrección y pendiente:

## Cierre

- Preparado / ensayado (solo si ocurrió):
- Próxima revisión y evidencia necesaria:
- Lo que no puedo concluir:
