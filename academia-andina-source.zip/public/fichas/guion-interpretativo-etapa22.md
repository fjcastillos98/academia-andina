# Ficha de guion interpretativo · Etapa 22

Taller de mesa original de Academia Andina. Revisión docente pendiente.
No representa una consulta comunitaria ni una evaluación profesional.
No escribir datos privados, testimonios restringidos o permisos inventados.

## Preparación

- Material o tarjeta:
- Contexto conocido y desconocido:
- Audiencia ficticia y pregunta para conocer sus necesidades:
- Idea central:

## Evidencia

| Afirmación | Observación / documento / inferencia | Fuente y contexto | Límite o consulta pendiente |
| --- | --- | --- | --- |
| | | | |
| | | | |

## Guion inicial

- Apertura:
- Idea central y dos apoyos:
- Pregunta:
- Cierre y límite:
- Contenido excluido y razón:

## Ensayo

- Estado: preparado / realizado (solo si ocurrió):
- Reformulación recibida (o respuesta prevista, claramente identificada):
- Diferencia detectada:
- Incertidumbre reconocida:

## Revisión

- Guion corregido:
- Qué cambió y por qué:
- Evidencia todavía pendiente:
- Próxima revisión propuesta:

Leer y guardar esta ficha no registra automáticamente una práctica ni certifica guiado.
