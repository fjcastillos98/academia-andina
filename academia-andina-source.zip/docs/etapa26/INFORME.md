# Etapa 26 · Catálogo por objetivos

Fecha: 30 de octubre de 2026. Versión 0.26.0.

La página `/estudiar/` organiza las 16 rutas existentes en seis objetivos: fundamentos y planificación; cuerdas; ambientes técnicos; preparación personal; territorio; guiado. Cada grupo separa estudio teórico, taller o caso documental y revisión/práctica. Los tiempos se calculan desde las lecciones y los prerrequisitos se leen del programa existente.

Se añadieron anclas `ruta-ID` al programa, un acceso en el menú y un resultado en el buscador. La portada reemplaza su presentación de Etapa 4 por el catálogo actual. Todas las URL anteriores se conservan. Los talleres enlazados son puntos de entrada y no una evaluación completa de todas las rutas de cada grupo.

No cambian las 175 lecciones, las rutas previas, el estado local ni las correspondencias curriculares: 46 propuestas parciales y 330 entradas sin revisar. No se modificó el manual original ni se publicó o realizó push.

## Verificación

- 186 pruebas aprobadas, sin fallos.
- Astro: 136 archivos, cero errores, advertencias o sugerencias.
- 286 páginas, 12166 enlaces/recursos internos y 669 resultados de búsqueda verificados en `/` y `/academia-andina/`.
- Comprobación de datos: las 16 rutas aparecen exactamente una vez, en seis objetivos de identificadores únicos.
- Revisión visual, móvil e interacción real pendiente por la restricción de navegador previamente observada. No se intentó eludirla.

## Continuidad

Siguiente mejora propuesta: unificar la presentación de los prerrequisitos y el acceso para retomar estudio en las páginas de ruta, reutilizando el estado local existente y manteniendo separada la evidencia práctica.

Entrega: ZIP del proyecto, sin dependencias, compilados ni datos del navegador.
