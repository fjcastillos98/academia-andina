# Fuentes y alcance · Etapa 16

Consulta: 2026-10-28. No se redistribuyen páginas ni PDFs completos.

## Mountain Training

[Leadership model · Vision, Support, Challenge](https://www.mountain-training.org/about/what-we-do/mountain-trainings-leadership-model/)

Página institucional consultada. Marco británico e irlandés; no equivale a acreditación ANGM ni normativa chilena. No se revisó el curso enlazado.

## NOLS

[Expedition Behavior](https://www.nols.edu/about/expedition-behavior/)

Página institucional consultada. Principios de convivencia y responsabilidad; casos propios no son protocolos NOLS.

## Education Endowment Foundation

[Teacher Feedback to Improve Pupil Learning · overview](https://educationendowmentfoundation.org.uk/education-evidence/guidance-reports/feedback)

Resumen web consultado; PDF completo no revisado. Orientado a escolares de 5 a 18 años; transferencia a adultos en montaña pendiente de revisión docente.

Las tareas, casos, preguntas y rúbricas son propuestas originales de la academia. Las fuentes respaldan los marcos conceptuales citados, no validan cada adaptación ni una acreditación profesional.
