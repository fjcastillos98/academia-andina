# Etapa 16 · Pedagogía, guiado y liderazgo

28 de octubre de 2026 · versión 0.16.0 · desarrollo pendiente de revisión docente e instructora.

## Resultado

Seis unidades M19: objetivos y evidencia, briefing, enseñanza progresiva, comunicación y desacuerdos, decisiones de grupo y debriefing. Dieciocho preguntas con explicación por alternativa, seis respuestas abiertas con rúbricas, cuatro plantillas supervisadas y un caso integrador guardable. La ruta liderazgo depende de estival; la primera habilidad requiere s4-grupo-liderazgo y las demás siguen una secuencia. No se cambian las 376 entradas históricas del mapa.

El caso y las tareas son diseño educativo original. Se trabaja en mesa o talleres supervisados sin exposición al terreno. No hay puntuación automática de seguridad ni certificación profesional. El contenido no establece ratios, normativa chilena o condiciones de salida. Se distinguen autoevaluación, observación de compañero y evaluación declarada de instructor.

## Fuentes

Tres páginas institucionales consultadas: Mountain Training (liderazgo centrado en personas), NOLS (comportamiento de expedición) y EEF (resumen de retroalimentación). Las pautas y escenarios propios se distinguen del contenido atribuido. La guía EEF se dirige a escolares de 5–18 años: su uso para adultos en montaña requiere revisión pedagógica. No se leyó el PDF completo ni el curso enlazado de Mountain Training. No se afirma equivalencia con ANGM.

## Comprobaciones

- 161/161 tests aprobados, cero fallos.
- TypeScript/Astro: cero errores, advertencias e indicaciones.
- Build: 270 páginas. La verificación de raíz comprueba 10.134 enlaces/recursos internos y 654 resultados de búsqueda; la base /academia-andina/ pasó con los mismos totales. Resultados por base en logs/.
- Nuevas pruebas: preservación de todos los objetos curriculares previos; estructura sin ciclos; 18 preguntas y corrección de respuestas; obligatoriedad de metadatos E16; restauración del plan sin registrar prácticas.
- Los tests históricos de etapas 14 y 15 congelaban todo curriculum.json. Ahora comprueban el hash de la copia previa archivada; la prueba nueva compara cada módulo, entrada y unidad histórica con el currículo actual. Esto permite añadir unidades sin dejar sin protección las anteriores.
- Se utiliza el respaldo v3 sin cambios de formato. El plan y las respuestas abiertas no conceden competencias.

## Limitaciones de verificación

No se repitió la interacción bloqueada por la política del navegador en esta sesión ni se intentó eludirla. No se verificaron visualmente escritorio/móvil, controles, persistencia tras recarga, descarga/importación completa o impresión en esta entrega. La lógica y las rutas sí se comprobaron automáticamente. Probar localmente /liderazgo/, un quiz y el guardado del plan antes de usar la versión con estudiantes.

Revisión docente e instructora pendiente. Las verificaciones cartográficas de etapas 15 y 15.1 permanecen abiertas.

## Ejecución y continuidad

Dentro de academia, con Node.js 24: npm ci y npm run dev. Abrir /liderazgo/. Para GitHub Pages, usar la misma BASE_PATH al construir y servir.

Manual original intacto. No se hizo push ni publicación, ni se enviaron comunicaciones.

Siguiente bloque propuesto: casos integradores de planificación de expediciones (M23), conectando los conocimientos existentes y las decisiones de grupo, sin convertir la síntesis en autorización de salida.
