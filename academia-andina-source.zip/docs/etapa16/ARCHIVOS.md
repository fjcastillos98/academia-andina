# Archivos · Etapa 16

Nuevos:
- src/pages/liderazgo.astro.
- Seis lecciones: objetivos-aprendizaje, briefing-participativo, ensenanza-progresiva, comunicacion-conflictos, decisiones-grupo, debriefing-aprendizaje.
- Seis evaluaciones v1 correspondientes en src/data/assessments/.
- src/data/leadership-templates.json.
- tests/etapa16.test.ts.
- data/archive/etapa151/: copia previa de currículo, habilidades, rutas y fuentes.
- docs/etapa16/: informe, fuentes, inventario y logs.

Modificados:
- data/curriculum.json: seis unidades añadidas; módulos y entradas previos intactos.
- data/skills.json: seis habilidades añadidas.
- data/learning-paths.json: ruta liderazgo añadida.
- src/data/sources.json: tres referencias añadidas.
- src/pages/practicas.astro y src/lib/practice-client.ts: cuatro plantillas integradas.
- src/layouts/Layout.astro: navegación y versión.
- src/pages/search-index.json.ts: portada indexada; lecciones indexadas por colección.
- src/lib/program.ts y scripts/validate.ts: metadatos E16 y plantillas validados.
- tests/etapa14.test.ts y tests/etapa15.test.ts: conservación histórica compatible con adición de unidades, complementada por comparación de objetos en etapa16.
- package.json, package-lock.json: 0.16.0; dependencias sin cambios.
- README.md: versión y alcance actualizados.

ZIP: fuentes y documentación bajo academia/. Sin dependencias instaladas, builds, metadatos Git ni ZIP anteriores.
