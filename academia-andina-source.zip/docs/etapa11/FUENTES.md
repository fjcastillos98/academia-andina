# Fuentes de Etapa 11

Consulta: 26 de octubre de 2026. Las referencias respaldan hechos específicos; los casos, rúbricas y decisiones pedagógicas son originales. Consultar una fuente no acredita revisión profesional. No se verificaron decretos actuales de categorías de especies; no se atribuye vigencia legal.

## MMA / PNUD — Patricio Rodrigo Salinas — Diagnóstico del estado y tendencias de la biodiversidad: Región de Los Lagos

https://biodiversidad.mma.gob.cl/wp-content/uploads/2025/01/Diagnostico-10-Los-Lagos.pdf

Acceso: PDF, texto extraído de 75 páginas; consultados alcance, ecosistemas y límites de información

Alcance: El inventario diferencia bosques siempreverdes y caducifolios, matorral bajo templado andino y herbazal templado andino. Los nombres de formaciones no deben reemplazarse todos por estepa altoandina. El diagnóstico registra vacíos de información para tendencias; ausencia de dato no demuestra ausencia de especie.

Límites: Informe de diciembre de 2015, aunque URL se alojó en 2025. No usar porcentajes, categorías ni número de áreas como valores actuales. No identifica ecosistema de un punto solo por altitud.

## CONAF — Parque Nacional Puyehue

https://www.conaf.cl/parque_nacionales/parque-nacional-puyehue/

Acceso: Página completa; apartados datos, flora y fauna

Alcance: Describe bosque húmedo siempreverde con varios estratos: ulmo y coigüe, acompañados de olivillo y tineo en lugares bajos. El sotobosque incluye arbustos, lianas, helechos, musgos y líquenes; cerca del límite vegetacional señala lenga y coigüe de Magallanes. Relaciona protección de suelos volcánicos y regulación del agua. Enumera fauna del parque, entre ella carpintero negro, choroy, puma y monito del monte.

Límites: Lista del parque, no garantía de avistamiento ni distribución en cada ruta; algunas nomenclaturas requieren contraste taxonómico. Puyehue abarca Los Ríos y Los Lagos. No usar información de accesos como garantía operativa.

## CONAF — Parque Nacional Vicente Pérez Rosales

https://www.conaf.cl/parque_nacionales/parque-nacional-vicente-perez-rosales/

Acceso: Página completa; datos generales, flora, fauna y prohibiciones

Alcance: Bosques mayoritariamente siempreverdes; las condiciones de drenaje diferencian ambientes. El paisaje resulta de procesos volcánicos, tectónicos y glaciares. La ficha registra pudú, güiña, huillín, monito del monte, pato correntino y carpintero negro.

Límites: Presencia a escala de parque no implica probabilidad de encuentro. La página contiene erratas botánicas y geográficas; evitar copiarlas. Normas operativas deben confirmarse con administración antes de salir. No universalizar bandas de altitud.

## MMA — SIMBIO — Ficha de especie Fitzroya cupressoides

https://simbio.mma.gob.cl/Especies/Details/6535

Acceso: Página completa; taxonomía, morfología, origen y tabla de conservación

Alcance: Alerce: hojas perennes, pequeñas y escuamiformes, ordenadas en verticilos de tres. Es nativo de Chile y también se distribuye naturalmente en Argentina; no es endémico exclusivo de Chile. La tabla consultada indica En Peligro, EN A2c, toda su distribución, tercer proceso y DS51 MINSEGPRES2008.

Límites: El texto de distribución conserva referencia histórica a X Región y contiene contradicciones con límites administrativos modernos; NO usar 'exclusivo Los Lagos'. La tabla es evidencia de lo mostrado por el portal al consultar; no se abrió el decreto ni se verificaron cambios legales posteriores. No diagnosticar especie solo por un rasgo.

## MMA — Comité de Clasificación de Especies — Enicognathus leptorhynchus: ficha final del 14.º proceso RCE

https://clasificacionespecies.mma.gob.cl/wp-content/uploads/2019/10/Enicognathus_leptorhynchus_14RCE_FINAL.pdf

Acceso: PDF completo extraído, 7 páginas

Alcance: Describe al choroy como especie endémica de Chile y documenta registros de Los Lagos. Plumaje principalmente verde oscuro y marcas rojo anaranjadas en frente y entorno ocular; la identificación exige conjunto de rasgos. Describe grupos de alimentación y comportamiento de alarma; un grupo vocalizando no demuestra por sí solo que lo perturbó el observador.

Límites: Ficha incorpora evaluación del comité de 2017 y propone LC, sin verificar decreto vigente aquí. No copiar la noticia MMA2015 que lo llama vulnerable como categoría actual. Evitar publicar localizaciones de reproducción o tablas de registros precisos.

## Ministerio del Medio Ambiente — Clasificación de especies según estado de conservación

https://clasificacionespecies.mma.gob.cl/

Acceso: Página completa; explicación del sistema y estados de procesos

Alcance: La clasificación busca evaluar amenaza y orientar conservación, investigación y planificación. El portal distingue procesos en consulta de procesos finalizados: propuesta no equivale automáticamente a categoría vigente.

Límites: No es listado exhaustivo de categorías actuales ni prueba de categoría de una especie. Consultar nombre científico, población o zona, proceso y decreto; separar RCE chileno de UICN global.

## CECPAN con apoyo GEF/MMA/PNUD — La amenaza del visón — Plan de monitoreo y erradicación

https://especies-exoticas.mma.gob.cl/wp-content/uploads/2018/12/Folleto-vison.pdf

Acceso: PDF de dos páginas, texto completo

Alcance: Documenta amenaza del visón para biodiversidad de Chiloé y depredación sobre fauna nativa. Advierte confusión visual con huillín, chungungo, quique y coipo. El daño ecológico no autoriza al visitante a manipular, capturar o matar un animal de identificación dudosa.

Límites: La última frase es conclusión pedagógica de precaución, no cita de norma. Usa sinónimo histórico Neovison vison; no afirmar taxonomía actual sin revisión. No seguir contactos o programa antiguo como operativo vigente.

## Ministerio del Medio Ambiente — Tips de buenas prácticas — Especies exóticas invasoras

https://especies-exoticas.mma.gob.cl/tips-de-buenas-practicas/

Acceso: Página completa

Alcance: Limpiar calzado, ropa y equipo de campo ayuda a evitar dispersión de organismos. No trasladar tierra o leña entre sitios ni llevar animales, plantas o semillas como recuerdos. No liberar mascotas ni vaciar acuarios en ecosistemas acuáticos.

Límites: Recomendación general; no sustituye protocolo específico de desinfección, autorización de control ni normas de una unidad. No inventar concentración química o tratamiento universal.

## Leave No Trace — The 7 Principles

https://lnt.org/why/7-principles/

Acceso: Página completa

Alcance: Marco de reducción de impacto que articula preparación, tránsito, residuos, conservación del lugar, fuego, fauna y convivencia. Las decisiones deben considerar reglas locales y condiciones del área.

Límites: Marco educativo; no reemplaza regulación chilena ni autorización del administrador. Parafrasear y atribuir; no copiar cartel ni presentar certificación NDR. Su recomendación genérica sobre fuego no autoriza cocinilla o fogata donde se prohíbe.

## Leave No Trace — Principle 6: Respect Wildlife

https://lnt.org/why/7-principles/respect-wildlife/

Acceso: Página completa; distancia, alimentación, momentos sensibles

Alcance: Observar sin perseguir ni aproximarse; no alimentar fauna. La alimentación altera conductas y puede atraer animales hacia peligros humanos. Reproducción, crianza e invierno son periodos sensibles; evitar perturbarlos. Guardar alimentos y residuos según fauna y reglas locales.

Límites: Ejemplos norteamericanos no se transfieren literalmente a Chile. No fija distancia universal ni protocolo de encuentro con puma; no inventar una distancia segura. Reglas locales sobre mascotas prevalecen.
