# Archivos de Etapa 11

Comparación con ZIP de Etapa 10; se excluyen dependencias, build y paquetes de entrega.

## Creados

- `data/archive/etapa10/README.md`
- `data/archive/etapa10/curriculum.json`
- `data/archive/etapa10/diagrams.json`
- `data/archive/etapa10/learning-paths.json`
- `data/archive/etapa10/skills.json`
- `data/archive/etapa10/sources.json`
- `docs/etapa11/FUENTES.md`
- `docs/etapa11/INFORME.md`
- `docs/etapa11/briefs.json`
- `docs/etapa11/historical-sha256.json`
- `docs/etapa11/logs/build-base.txt`
- `docs/etapa11/logs/build-links-base.txt`
- `docs/etapa11/logs/build-links.txt`
- `docs/etapa11/logs/build.txt`
- `docs/etapa11/logs/check.txt`
- `docs/etapa11/logs/manual-diff.txt`
- `docs/etapa11/logs/routes-base.txt`
- `docs/etapa11/logs/routes-root.txt`
- `docs/etapa11/logs/tests.txt`
- `docs/etapa11/research.json`
- `docs/etapa11/screenshots/form-mobile.jpg`
- `docs/etapa11/screenshots/mobile.jpg`
- `public/diagramas/e11-evidencia.svg`
- `public/diagramas/e11-impacto.svg`
- `scripts/check-ecology-build.mjs`
- `src/content/lecciones/ambientes-altoandinos.md`
- `src/content/lecciones/bosque-templado.md`
- `src/content/lecciones/ecosistemas-los-lagos.md`
- `src/content/lecciones/endemismo-conservacion.md`
- `src/content/lecciones/fauna-conducta.md`
- `src/content/lecciones/fauna-evidencia.md`
- `src/content/lecciones/flora-identificacion.md`
- `src/content/lecciones/impactos-no-deje-rastro.md`
- `src/content/lecciones/interpretacion-ecologica.md`
- `src/content/lecciones/invasoras-bioseguridad.md`
- `src/data/assessments/ambientes-altoandinos.v1.json`
- `src/data/assessments/bosque-templado.v1.json`
- `src/data/assessments/ecosistemas-los-lagos.v1.json`
- `src/data/assessments/endemismo-conservacion.v1.json`
- `src/data/assessments/fauna-conducta.v1.json`
- `src/data/assessments/fauna-evidencia.v1.json`
- `src/data/assessments/flora-identificacion.v1.json`
- `src/data/assessments/impactos-no-deje-rastro.v1.json`
- `src/data/assessments/interpretacion-ecologica.v1.json`
- `src/data/assessments/invasoras-bioseguridad.v1.json`
- `src/data/ecology-templates.json`
- `src/lib/ecology-client.ts`
- `src/lib/ecology.ts`
- `src/pages/ecologia/index.astro`
- `tests/etapa11.test.ts`
- `docs/etapa11/ARCHIVOS.md`

## Modificados

- `README.md`
- `data/curriculum.json`
- `data/learning-paths.json`
- `data/skills.json`
- `package-lock.json`
- `package.json`
- `scripts/validate.ts`
- `src/data/diagrams.json`
- `src/data/sources.json`
- `src/layouts/Layout.astro`
- `src/lib/client.ts`
- `src/lib/expanded.ts`
- `src/lib/practice-client.ts`
- `src/lib/program.ts`
- `src/lib/state.ts`
- `src/pages/especies/index.astro`
- `src/pages/lecciones/[id].astro`
- `src/pages/practicas.astro`
