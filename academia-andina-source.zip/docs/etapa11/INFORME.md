# Etapa 11 — Flora, fauna y ecología de Los Lagos

26 de octubre de 2026. Versión 0.11.0. Proyecto en desarrollo, sin publicación ni push.

## Contenido agregado

Diez unidades progresivas en el módulo histórico M15: ecosistemas y escalas; bosque templado lluvioso y siempreverde; ambientes altoandinos y volcánicos; identificación de flora; fauna y detectabilidad; endemismo y conservación; invasoras y bioseguridad; conducta y seguridad frente a fauna; impactos turísticos y No Deje Rastro; interpretación ambiental y registro.

Cada lección incorpora objetivos, prerrequisitos, conceptos, teoría, procedimiento de observación, caso, errores, seguridad, equipo, autoevaluación, cuestionario, ejercicio, práctica supervisada propuesta, registro, criterios, referencias, nivel y relaciones curriculares. Se distinguen TEORÍA, PROCEDIMIENTO, PRÁCTICA INDIVIDUAL, PRÁCTICA SUPERVISADA y COMPETENCIA. Son 30 preguntas con explicación por opción, diez respuestas abiertas con rúbrica, seis plantillas y dos diagramas originales. La nueva ruta depende de la ruta territorial, no del bloque de entrenamiento.

Se conservan las cinco fichas anteriores de especies; no se presenta un inventario completo. Ejemplos documentales: alerce, choroy, fauna descrita para Vicente Pérez Rosales y visón en Chiloé. Las categorías legales actuales no se declaran verificadas. El diagnóstico regional es de 2015, aunque su URL incluya 2025.

Totales: 147 lecciones/cuestionarios, 122 unidades, 144 habilidades, 12 rutas, 192 fuentes y 45 diagramas. Las 376 entradas originales permanecen pendientes.

## Cuaderno de observación

Creación y edición de registros con fecha, área general, ambiente, rasgos, hipótesis, estado de conocimiento, evidencia textual, revisión declarada y acción de cuidado. Una revisión declarada exige revisor y referencia. No genera prácticas ni competencia automáticamente.

Persistencia en `responses['ecology-notebook:v1']`, dentro del respaldo JSON v3 existente. Esquema estricto y validación antes de guardar/importar; rechaza fechas inválidas, duplicados, estados desconocidos y campos inesperados. Límite de 20 registros y 20.000 caracteres conjuntos, sin descarte automático. Se puede editar; no se añadió eliminación de registros.

Sin adjuntos ni campos de coordenadas. El texto libre NO detecta automáticamente localizaciones sensibles; el usuario debe omitirlas. No se incorporaron datos personales de salud ni contraseñas. La identidad del revisor y la existencia de la evidencia no son verificadas por la plataforma.

## Verificación real

- `npm run check`: 89 archivos, 0 errores, 0 advertencias, 0 sugerencias.
- `npm test`: 119 pruebas aprobadas, 0 fallos.
- `npm run build`: 236 páginas; ejecución exitosa en raíz y con `/academia-andina/`.
- Verificador global: 236 páginas, 8.131 enlaces/recursos internos y 618 entradas de búsqueda, en ambas bases.
- Verificador de ecología: 11 páginas, 637 enlaces/recursos internos y sus anclas, en ambas bases.
- Conservación: 317 archivos académicos históricos (137 lecciones, 137 cuestionarios y 43 diagramas) comparados por SHA-256, además de objetos de currículo, habilidades, rutas, fuentes y diagramas anteriores.
- Navegador: portada → primera lección → siguiente; fuentes y límites visibles; búsqueda «bioseguridad» encuentra la lección nueva y la histórica.
- Quiz: intento 0/3 y luego 3/3, explicaciones por opción; aprobación teórica conservada después de recargar, sin acreditar competencia práctica.
- Cuaderno: rechazo de revisión sin revisor; creación de observación ficticia; persistencia después de recargar; edición del mismo registro sin duplicado.
- Responsive: inspección visual en iframe de 390 × 844; ancho útil 375 px por barra vertical y scrollWidth 375, tanto en portada como formulario. No es prueba en teléfono físico ni auditoría WCAG.
- Dos SVG nuevos analizados como XML.
- `git diff --exit-code`: sin cambios en archivos rastreados del manual original. Academia continúa en carpeta independiente.

Se detectó en QA que `crypto.randomUUID` no estaba disponible en la vista HTTP local. Se reemplazó la generación de identificadores por fecha y valores aleatorios de `crypto.getRandomValues`, y se verificaron creación, edición y recarga después de la corrección.

Los logs están en `logs/`; capturas en `screenshots/`. Dependencias existentes reutilizadas, sin cambios de versiones ni nueva instalación. Los tests comprueban lógica de respaldo/restauración, incluidas observaciones. La descarga/importación mediante controles del navegador no se volvió a verificar: ese flujo fue bloqueado por la política de URL del entorno en una etapa anterior. No se afirma una prueba integral del flujo de archivo en esta etapa.

## Fuentes y revisión pendiente

Diez fuentes de MMA/PNUD, CONAF, SIMBIO, clasificación de especies, materiales sobre invasoras y Leave No Trace. Véase FUENTES.md para URL, acceso, alcance y limitaciones. Las propuestas pedagógicas y casos son originales; no se atribuyen como protocolos oficiales.

Pendientes: revisión por especialista en ecología, identificación botánica/faunística e instructor territorial; verificación de categorías normativas por instrumento; claves de identificación completas, protocolos específicos de encuentros y ampliación de fichas regionales. Las pruebas de software no validan científicamente el contenido ni certifican competencia.

## Etapa 12 propuesta

Geología y vulcanología de Los Lagos: secuencia sobre tectónica/subducción, volcanes y productos, peligros, monitoreo, lectura crítica de información y relación con relieve glaciar. Ampliar las siete fichas territoriales existentes con fuentes SERNAGEOMIN y académicas. Investigar topónimos llamados «cerros», incluido Cerro Sarnoso, manteniendo origen geológico y rutas como pendientes donde falte evidencia. Diferenciar información científica estable de alertas, accesos y condiciones operativas que deben comprobarse antes de cada salida. No publicar ni desplegar sin autorización.
