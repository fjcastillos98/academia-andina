# Etapa 31 · Correcciones y regresión

30 de octubre de 2026 · Versión 0.31.0.

## Hallazgos corregidos en código

| ID | Corrección | Verificación disponible |
| --- | --- | --- |
| U30-01 | Se añadió Ruta de estudio al selector del buscador | Los 11 tipos presentes en el índice compilado tienen opción de filtro; prueba de búsqueda existente aprobada |
| U30-02 | El índice lateral ya no se oculta a 800 px o menos: se presenta en una columna, ancho completo, enlaces con separación y ajuste de palabras | Inspección de CSS y destinos de anclas; aceptación visual y teclado pendiente |
| U30-03 | Ante fallo inicial de carga de lecciones o evaluaciones, cuaderno e historial muestran un aviso explícito con role=status | Inspección de las dos llamadas a unavailableProgress; no se escribe ni elimina almacenamiento en esa función; simulación real del fallo pendiente |

El índice mantiene enlaces nativos a apartados, rutas, cuestionario y notas. El aviso de error sustituye el texto Cargando; no presenta una lista vacía como si no existieran registros. No cambia el contenido académico, las rutas, el esquema de respaldos o el criterio de aprobación.

## Regresión

- 190 pruebas aprobadas, cero fallos.
- Astro: 142 archivos sin errores, advertencias ni sugerencias.
- Compilación y enlaces comprobados en `/` y `/academia-andina/`.
- Auditoría estática en ambas bases: 286 páginas, 1974 controles y 4180 enlaces con fragmento, sin hallazgos en las reglas parciales del script.
- Los resultados de enlaces, auditoría y filtros se incluyen junto a este informe.

La revisión visual, móvil y con teclado, el guardado real, exportación/restauración y simulación de errores en navegador continúan pendientes por la restricción de acceso ya observada. No se declara conformidad WCAG ni cierre de esas pruebas por haber aplicado los cambios de código.

El manual original permanece intacto. Sin publicación ni push.

## Siguiente paso

Queda la etapa 32 del plan de cierre: entrega documentada de la versión local con instrucciones de instalación, uso, respaldo, mantenimiento y pendientes. El cierre del software disponible no equivale a completar o validar todo el currículo académico.
