# Etapa 19 · Trazabilidad curricular

Fecha editorial: 28 de octubre de 2026.

Se añadió `/trazabilidad/`, accesible desde navegación, auditoría y buscador. La matriz registra las 376 entradas históricas sin alterar su estado. Las 42 entradas posteriores quedan fuera del alcance de esta primera matriz.

La comparación editorial inicial abarca las 17 entradas M19 frente a las seis lecciones de Etapa 16 y grupo-liderazgo. Resultado: 14 correspondencias parciales propuestas, tres entradas sin vínculo propuesto en ese corpus (comunicación intercultural, interpretación ambiental y gestión de quejas e incidentes) y 359 entradas sin revisar. No encontrar un vínculo en ese corpus no demuestra ausencia de material en toda la academia.

Cada propuesta tiene lección, pasaje literal, alcance observado y vacío. No implica validación docente, cobertura íntegra ni competencia. El acta utiliza el guardado local existente y no modifica la matriz. No hay una aprobación automática ni nuevas evaluaciones prácticas.

La compilación valida las referencias y los pasajes exactos y detecta entradas omitidas, repetidas y estados incoherentes. Un cambio de texto que invalide una cita obliga a revisar la correspondencia antes de compilar.

## Verificación

- 170/170 pruebas.
- Astro: cero errores, advertencias y sugerencias.
- 276 páginas, 11378 enlaces/recursos internos y 659 resultados de búsqueda verificados tanto en `/` como en `/academia-andina/`.
- Interfaz visual, móvil y persistencia del formulario en navegador no comprobadas en esta etapa: continúa el bloqueo de acceso de la herramienta de navegador. No se intentó eludirlo.

## Entrega y continuidad

Incluye fuentes, pruebas, matriz legible y registros de verificación. No incluye dependencias, dist ni datos del navegador del usuario. Manual original intacto; sin push ni publicación.

Siguiente trabajo propuesto: ampliar la comparación a M00 y a los bloques transversales de planificación y riesgo, manteniendo pasajes y vacíos explícitos. Los contenidos médicos, jurídicos y técnicos conservan sus revisiones especializadas pendientes.
