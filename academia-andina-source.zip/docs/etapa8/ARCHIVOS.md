# Archivos · Etapa 8

Comparación de contenido con Academia_Andina_Etapa7.zip. Excluye dependencias, build y paquetes de entrega.

## Creados

- `data/archive/etapa7/README.md`
- `data/archive/etapa7/curriculum.json`
- `data/archive/etapa7/diagrams.json`
- `data/archive/etapa7/learning-paths.json`
- `data/archive/etapa7/skills.json`
- `data/archive/etapa7/sources.json`
- `docs/etapa8/ARCHIVOS.md`
- `docs/etapa8/FUENTES.md`
- `docs/etapa8/INFORME.md`
- `docs/etapa8/briefs.json`
- `docs/etapa8/historical-sha256.json`
- `docs/etapa8/logs/alpine-routes-base.log`
- `docs/etapa8/logs/alpine-routes.log`
- `docs/etapa8/logs/build-base.log`
- `docs/etapa8/logs/build.log`
- `docs/etapa8/logs/check.log`
- `docs/etapa8/logs/routes-base.log`
- `docs/etapa8/logs/routes.log`
- `docs/etapa8/logs/tests.log`
- `docs/etapa8/research.json`
- `docs/etapa8/screenshots/alpina-mobile.jpg`
- `public/diagramas/e8-funciones.svg`
- `public/diagramas/e8-transicion.svg`
- `scripts/check-alpine-build.mjs`
- `src/content/lecciones/anclajes-alpinos.md`
- `src/content/lecciones/autorescate-alpino.md`
- `src/content/lecciones/cuerda-alpina.md`
- `src/content/lecciones/encordamiento-alpino.md`
- `src/content/lecciones/grupo-alpino.md`
- `src/content/lecciones/planificacion-alpina.md`
- `src/content/lecciones/progresion-alpina.md`
- `src/content/lecciones/riesgo-alpino.md`
- `src/data/alpine-templates.json`
- `src/data/assessments/anclajes-alpinos.v1.json`
- `src/data/assessments/autorescate-alpino.v1.json`
- `src/data/assessments/cuerda-alpina.v1.json`
- `src/data/assessments/encordamiento-alpino.v1.json`
- `src/data/assessments/grupo-alpino.v1.json`
- `src/data/assessments/planificacion-alpina.v1.json`
- `src/data/assessments/progresion-alpina.v1.json`
- `src/data/assessments/riesgo-alpino.v1.json`
- `src/lib/alpine-client.ts`
- `src/lib/alpine.ts`
- `src/pages/alpina/index.astro`
- `tests/etapa8.test.ts`

## Modificados

- `README.md`
- `data/curriculum.json`
- `data/learning-paths.json`
- `data/skills.json`
- `package-lock.json`
- `package.json`
- `scripts/validate.ts`
- `src/data/diagrams.json`
- `src/data/sources.json`
- `src/layouts/Layout.astro`
- `src/lib/expanded.ts`
- `src/lib/practice-client.ts`
- `src/lib/program.ts`
- `src/pages/lecciones/[id].astro`
- `src/pages/practicas.astro`
