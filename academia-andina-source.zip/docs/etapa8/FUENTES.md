# Fuentes · Etapa 8

Consulta documental: 2026-10-25. Los ejercicios, cifras hipotéticas y rúbricas son originales y requieren revisión docente. Las fuentes no avalan la academia.

## e8-plan · Mountaineering Scotland

[Planning your route](https://www.mountaineering.scot/activities/hillwalking/getting-started/planning-your-route)

Límites: Fuente de senderismo escocés; transferir principios de decisión, no rutas, tiempos universales ni recomendaciones locales de Chile.

## e8-decision · Mountaineering Scotland

[Decisions en route](https://www.mountaineering.scot/activities/hillwalking/getting-started/decisions-en-route)

Límites: No es una escala cuantitativa del riesgo ni determina proporciones guía/cliente; contexto de senderismo.

## e8-scramble · Mountaineering Scotland

[Scrambling in Scotland](https://www.mountaineering.scot/activities/mountaineering/scrambling)

Límites: Graduación escocesa no equivale automáticamente a escalas alpinas o chilenas; no autoriza progresar sin protección.

## e8-radline · Petzl

[Other progression situations that are incompatible with the RAD LINE hyperstatic cord](https://www.petzl.com/INT/en/Sport/Other-progression-situations-that-are-incompatible-with-the-RAD-LINE-hyperstatic-cord-?ProductName=RAD-LINE-6-mm)

Límites: Documento específico de RAD LINE. No generalizar resultados a todas las cuerdas ni recomendar su empleo en cuerda corta. Esta técnica se reserva a líderes expertos y exige formación práctica.

## e8-anchor · Petzl

[Building a belay anchor and belaying on a bolted multi-pitch route](https://www.petzl.com/no/en/sport/tech-tips/basic-techniques/building-a-belay-anchor-and-belaying-on-a-bolted-multi-pitch-route/Relais-grande-voie_SPO_a77Tx000000E3MEIA0.html)

Límites: Ejemplos para vías equipadas con anclajes fijos sólidos; no trasladar sin evaluación a roca natural, nieve o hielo. No presentar un montaje universal.

## e8-inspection · Petzl

[Inspection of anchors on rock, ice or mixed routes.](https://www.petzl.com/no/en/sport/tech-tips/basic-techniques/inspection-of-anchors-on-rock-ice-or-mixed-routes./Verification-des-ancrages-sur-rocher--glace-ou-mix_SPO_a77bK000007PH4rQAG.html)

Límites: Una inspección visual o prueba manual no certifica resistencia. No convertir sus ejemplos de mantenimiento en instrucciones para modificar equipamiento de una vía.

## e8-simul · American Alpine Institute

[Simul-Climbing Technique](https://www.alpineinstitute.com/articles/simul-climbing-technique/)

Límites: Escuela técnica concreta, no procedimiento universal. No se verificó el video incrustado. Omitir afirmaciones de supervivencia, separaciones o número de seguros como garantía.

## e8-rope · Petzl

[Consequences of poor rope drag management in a common fall](https://www.petzl.com/no/en/sport/tech-tips/basic-techniques/consequences-of-poor-rope-drag-management-in-a-common-fall/CORDES-chute-tirage_SPO_a77w0000000KywZAAS.html)

Límites: Ensayo con rozamiento deliberadamente exagerado. Ilustra mecanismos, no predice fuerzas de una caída real ni prescribe longitudes universales de cintas.

## e8-single · Petzl

[Belaying multi-pitch routes on single rope with a GRIGRI.](https://www.petzl.com/no/en/sport/tech-tips/basic-techniques/belaying-multi-pitch-routes-on-single-rope-with-a-grigri./Assurer-en-grande-voie-sur-corde-a-simple-avec-un-_SPO_a775I0000004HblQAE.html)

Límites: Ejemplo específico GRIGRI/REVERSO; no instrucciones de ATC Guide ni autorización de compatibilidad con cualquier cuerda. El propio texto restringe el caso a escaladores experimentados.

## e8-rescue · Petzl

[Second climber stuck: hauling on a loaded rope](https://www.petzl.com/US/en/Sport/Second-climber-stuck--hauling-on-a-loaded-rope?ActivityName=Multi-pitch-climbing)

Límites: Ejemplo con REVERSO 4 y MICRO TRAXION para un segundo, no receta de ATC Guide ni rescate universal. Requiere entrenamiento específico; no cubre toda emergencia médica o evacuación.

## e8-rope-cuts · UIAA / Norwegian Climbing Federation

[Sharp edges and rope cuts (2025)](https://www.theuiaa.org/documents/safety/UIAA_NFK_SHARPEDGES_2025_ENG.pdf)

Límites: Informe con recomendaciones contextualizadas; no prescribe por sí solo todo el sistema de aseguramiento en hielo. No deducir riesgo individual de sus estadísticas ni confundir marcado con resistencia universal al corte.

