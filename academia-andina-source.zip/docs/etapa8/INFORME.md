# Etapa 8 · Escalada alpina · 0.8.0

Implementación académica en desarrollo. No se ha realizado revisión presencial ni se han acreditado competencias. El manual original no se modificó y no se hizo push ni despliegue.

## Contenido

Ocho unidades progresivas: planificación, anclajes, encordamiento, manejo de cuerda, gestión de grupo, progresión, autorescate y gestión del riesgo. Cada lección incluye objetivos, prerrequisitos, desarrollo conceptual, decisiones, errores, equipo, autoevaluación, tres preguntas explicadas, ejercicio individual, propuesta supervisada, evidencia, criterios y fuentes con límites.

Se añadieron 24 preguntas, ocho rúbricas de respuesta abierta, cinco plantillas de taller, dos SVG conceptuales y un caso integrador guardable. El laboratorio de tiempos ficticios separa aproximación, largos, transiciones y descenso; no emite una decisión de seguridad. Se preservaron 103 lecciones, 103 quizzes y 37 SVG históricos mediante 243 hashes. Las 376 entradas originales conservan su estado pendiente.

## Verificación real

- `npm run check`: 74 archivos, cero errores, advertencias e indicaciones.
- `npm test`: 85 pruebas aprobadas, cero fallos. Incluye conservación histórica, currículo, búsqueda, quizzes, respaldo, plantillas y límites del cálculo.
- Build en raíz y con `BASE_PATH=/academia-andina/`: 197 páginas en ambos casos; ambas comprobaciones de enlaces aprobadas. Se restauró el build de raíz al terminar. Validación de 6118 enlaces/recursos y 582 entradas de búsqueda en raíz; el bloque alpino tiene nueve páginas y 488 enlaces/recursos con anclas.
- Navegador: apertura de portada alpina, lección de planificación y siguiente lección de anclajes. Fuentes, fechas y límites visibles en planificación.
- Quiz de planificación: 2/3 con error, después 3/3; mensaje explícito de no acreditación práctica. La portada alpina conserva la aprobación después de navegar y recargar.
- Caso integrador: texto de prueba guardado y recuperado tras recargar. El roundtrip del respaldo v3 está cubierto por pruebas automatizadas; descarga/importación JSON completa en navegador no repetida en esta etapa. La descarga había sido bloqueada por la política del entorno en una etapa anterior.
- Calculadora: 435 minutos y diferencia de 45; al cambiar a 60 minutos por largo, 495 y exceso de 15. Los campos numéricos no persisten, conforme a la interfaz.
- Búsqueda «cuerda corta»: diez resultados, entre ellos encordamiento y progresión alpinos.
- Responsive: portada alpina en iframe de 390 × 844 px; ancho útil 375 y scrollWidth 375, sin desbordamiento del documento. Navegación horizontal deliberada. No equivale a una prueba en teléfono físico. Captura en `screenshots/alpina-mobile.jpg`.
- Dos SVG nuevos analizados como XML válido.

## Límites y revisión necesaria

La instrucción de anclajes, cambios de método, cuerda corta, movimiento simultáneo, aseguramiento y autorescate requiere instructor competente, práctica protegida y evaluación contextual. Las variantes de Petzl son específicas del equipo y escenario; no se extrapolan a ATC Guide, otras cuerdas ni anclajes naturales. No se verificaron manuales y compatibilidades del equipo personal ni condiciones de rutas chilenas. No se revisaron íntegramente todos los videos enlazados. No hay certificación, norma de ratios guía/cliente ni garantía de rescate.

La prueba de navegador es una muestra funcional, no una auditoría exhaustiva de accesibilidad o compatibilidad. No se repitieron impresión/PDF ni descarga JSON. Las dependencias ya instaladas se reutilizaron; no se afirma una reinstalación en esta etapa.

## Siguiente bloque propuesto · Etapa 9

Altitud: fisiología, aclimatación, mal agudo de montaña, HACE, HAPE, planificación, campamentos, nutrición, hidratación y emergencias. Investigar primero guías primarias de medicina de montaña; separar educación de diagnóstico y prescripción, y encargar revisión médica. Integrar casos y decisiones de descenso/comunicación con el diario sin almacenar datos médicos sensibles.
