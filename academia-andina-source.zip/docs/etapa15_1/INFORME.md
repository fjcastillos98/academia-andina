# Etapa 15.1 · Selección cartográfica y respaldo

Entrega: 28 de octubre de 2026. Versión 0.15.1. Seguimiento documental, no cierre de validación cartográfica.

## Qué se incorporó

Cinco fichas de productos IGM: Correntoso H-052, Calbuco H-069, Osorno 1:250.000, Puerto Montt 1:250.000 y Las Cascadas H-043. Cada una separa cobertura, hallazgo, límite de consulta y siguiente solicitud. Tres ejercicios razonados desplegables, acta guardable y pauta de prueba local del respaldo. Enlaces desde territorio, expedientes y búsqueda.

Hallazgo principal: la ficha Correntoso incluye el volcán Calbuco; la hoja Calbuco H-069 cubre el sector insular. La hoja regional Osorno termina en 41° S y no contiene la coordenada GVP del volcán, 41,105° S. Estas conclusiones son inferencias geométricas sobre metadatos publicados, no lectura de las láminas.

La descripción IGM de Puerto Montt atribuye 2.003 m al Calbuco y 2.652 m al Osorno. No se adoptan como cotas únicas ni se alteran las atribuciones históricas de la Etapa 15. Las Cascadas se registra como producto localizado, con cobertura por verificar.

## Fuentes y límites

- Correntoso SHP: https://www.igm.cl/tiendaonline/inicio/3174-correntoso-shp.html — página abierta; descripción recuperada también por índice.
- Calbuco papel: https://www.igm.cl/tiendaonline/inicio/3243-calbuco-papel.html — extracto indexado; apertura 503.
- Osorno papel: https://www.igm.cl/tiendaonline/inicio/5690-osorno-papel.html — extracto indexado; apertura agotó tiempo.
- Puerto Montt papel: https://www.igm.cl/tiendaonline/inicio/5724-puerto-montt-papel.html — apertura y descripción indexada; consultas internas posteriores fallaron.
- Las Cascadas papel: https://www.igm.cl/tiendaonline/inicio/3139-las-cascadas-papel.html — registro indexado sin descripción; apertura 503.

Consulta: 2026-10-28. No se compraron productos ni se inspeccionaron archivos cartográficos. No se publican precios. La lectura de PET Calbuco y catálogo SERNAGEOMIN 2017 volvió a fallar con 502; no se incorporó contenido de sus láminas como verificado. La fecha de levantamiento y el datum vertical siguen pendientes.

## Validación

Build raíz: 263 páginas, 9.613 enlaces/recursos internos y 647 resultados de búsqueda. TypeScript/Astro: cero errores, advertencias e indicaciones. 156 pruebas aprobadas, sin fallos; la base /academia-andina/ también supera el comprobador de enlaces con los mismos totales. Registros en logs/.

Se añadieron pruebas de integridad de las cinco fichas y restauración simultánea del acta nueva y el borrador anterior sin registrar prácticas. Se mantiene el formato de respaldo v3.

No se repitió la interacción de navegador bloqueada por su política en la sesión anterior, ni se intentó eludirla con otro mecanismo. Formularios, descarga/importación completa, vista móvil e impresión siguen pendientes de prueba local. La pauta visible permite ejecutarla con datos ficticios en perfiles descartables.

## Archivos

Nuevos: src/data/cartography151.json, src/pages/territorio/cartografia.astro, tests/etapa151.test.ts y docs/etapa15_1/.

Modificados: sources.json (cinco registros añadidos), índice territorial, expedientes, índice de búsqueda, Layout, package.json, package-lock.json y README.md. No cambia ninguna lección, ficha histórica, competencia ni esquema de respaldo.

Manual intacto. No hubo push, publicación, compra ni envío de solicitudes.

## Siguiente paso

Obtener las láminas y metadatos pendientes y ejecutar la pauta de restauración en un navegador local. La ampliación documental no reemplaza revisión especializada. No se declara concluida la validación territorial.
