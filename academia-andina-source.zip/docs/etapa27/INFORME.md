# Etapa 27 · Retomar rutas de estudio

Fecha: 30 de octubre de 2026. Versión 0.27.0.

Panel compartido de orientación y avance teórico en las 16 rutas del programa y 13 páginas temáticas. Muestra los prerrequisitos con enlaces y cuenta por separado lecturas estudiadas y evaluaciones aprobadas. Sugiere la primera lectura no marcada como estudiada en el orden de la ruta, no la última página visitada. Cuando todas las lecturas están registradas, dirige al cuaderno para revisión, sin declarar competencia o aprobación de la ruta.

Las lecciones compartidas reutilizan su registro existente. No hay nuevas claves de almacenamiento, migración, cambios de respaldo ni escritura por visitar la ruta. Las aprobaciones siguen el criterio existente de al menos un intento aprobado en una versión registrada; no se añade un criterio distinto de vigencia de evaluaciones.

Si los datos locales no pueden leerse, el panel declara progreso no disponible y oculta la sugerencia. Sin JavaScript ofrece acceso estático a la primera lección; el aviso indica que el progreso no se ha cargado. Los enlaces a cuaderno y diario mantienen separadas teoría y evidencia práctica.

## Verificación

- 188 pruebas aprobadas, cero fallos.
- Pruebas nuevas: primera lectura pendiente, distinción lectura/aprobación, ruta nueva, lecturas completas sin evaluaciones aprobadas y reutilización de lecciones compartidas.
- Astro: 139 archivos, cero errores, advertencias y sugerencias.
- 286 páginas, 12311 enlaces/recursos internos y 669 resultados de búsqueda verificados en `/` y `/academia-andina/`.
- Revisión visual, móvil y comprobación de interacción real (incluida recuperación de respaldos y error de almacenamiento) pendientes por la restricción de navegador previamente observada. Las pruebas de lógica no sustituyen esas comprobaciones.

Se conservan 175 lecciones, las rutas y los prerrequisitos existentes, y la matriz curricular. El manual original permanece intacto. No se publicó ni se realizó push.

## Continuidad

Siguiente etapa propuesta: revisar la coherencia de los textos de estado y orientación en las páginas históricas, identificando mensajes desactualizados y distinguiendo el alcance de cada bloque respecto del catálogo actual.

ZIP con código, contenido, pruebas e informe; sin dependencias, compilados ni datos del navegador.
