# Revisión de integración · Etapa 24

La revisión se limita al diseño del caso y la coherencia de sus relaciones con las lecturas enlazadas. No es una auditoría exhaustiva del módulo ni validación docente externa.

| Relación examinada | Criterio conservado en el caso | Evidencia que deberá producir el alumno | Pendiente |
| --- | --- | --- | --- |
| Objetivos, briefing y ética | Una tarea de aula no acredita autonomía para guiar | Promesa corregida y comprobación de comprensión | Ensayo con participantes y revisión docente |
| Adaptación y comunicación intercultural | Ajustar el apoyo sin atribuir causas a una identidad | Consigna revisada y diferencia observada | Comprobar accesibilidad con audiencia real |
| Decisiones y presión de tiempo | Declarar qué se aplaza y conservar criterios observables | Alternativas, responsable y cambio comunicado | Revisar si el tiempo de aula permite el ejercicio |
| Interpretación y patrimonio vivo | No inventar causalidad ni representación colectiva | Guion con afirmaciones retiradas y preguntas pendientes | Verificar fuentes si se sustituye material ficticio por real |
| Quejas y debriefing | Responder, ejecutar y comprobar son estados distintos | Cronología y seguimiento pendiente | Observar la revisión del expediente, sin inferir satisfacción |

No se modificaron los textos de las lecciones, los estados curriculares ni las 46 correspondencias parciales de la matriz. El caso no añade cobertura demostrada. Las discrepancias de la invitación y la diapositiva son deliberadas y ficticias; no se presentan como errores encontrados en la operación real de Filo Austral.

## Criterios para revisar el ensayo

- Localizar fragmentos de dos respuestas que se contradicen, o justificar su coherencia.
- Distinguir lo observado de una hipótesis sobre comprensión.
- Corregir una promesa sin atribuir una competencia que no se evaluó.
- Mantener explícitas las partes aplazadas y las comprobaciones pendientes.
- Registrar quién revisó únicamente si esa participación ocurrió.

El expediente ofrece una pauta de revisión humana; no hay detección semántica automática de contradicciones, historial automático ni comunicación con evaluadores.
