# Etapa 24 · Integración de pedagogía, guiado y servicio

Fecha editorial: 29 de octubre de 2026.

Se añadió `/integracion-guiado/`, accesible desde navegación, buscador y página de liderazgo. El caso original «El taller que cambió de plan» se desarrolla en una sala ficticia y conecta seis momentos: objetivo/briefing, adaptación, decisión, interpretación, queja y debriefing.

Cada momento incluye información nueva, tarea, evidencia esperada, referencias a lecturas previas y una pauta desplegable. Cuatro contrastes examinan promesa, criterio, atribución y cierre entre respuestas de distintos momentos. La revisión es humana; no hay detector semántico de contradicciones ni nota automática.

El expediente se guarda manualmente con la clave `integracion-guiado:v1` y utiliza el respaldo existente. Las versiones se conservan únicamente si el usuario las escribe; abrir apartados no se guarda. Se entrega también ficha Markdown descargable con las seis consignas y cuatro contrastes.

## Alcance y revisión

El documento `REVISION.md` describe las relaciones y límites del caso. No constituye auditoría exhaustiva de M19 ni revisión docente externa. Las contradicciones del escenario son deliberadas y ficticias, no hallazgos sobre operaciones reales.

No se añadieron lecciones, habilidades ni correspondencias curriculares. Se mantienen 175 lecciones, 46 correspondencias parciales y 330 entradas sin revisar. Los estados históricos y lecciones anteriores permanecen intactos. No se verificaron nuevamente fuentes externas ni condiciones territoriales.

## Validación

- 184/184 pruebas aprobadas.
- Astro: cero errores, advertencias y sugerencias en 132 archivos.
- 284 páginas, 12866 enlaces/recursos internos y 667 resultados de búsqueda comprobados en `/` y `/academia-andina/`.
- El validador del caso rechaza momentos duplicados, dependencias no anteriores, lecturas ausentes y contrastes inválidos o vacíos; se ejecuta al compilar la página.
- Serialización/restauración comprobada junto con actas anteriores, sin prácticas añadidas.
- Interfaz visual, móvil y persistencia mediante interacción real pendientes por la restricción de acceso al navegador previamente observada. No se intentó eludirla.

## Entrega y continuidad

Código, caso, ficha, pruebas e informes incluidos. Dependencias, compilados y datos del navegador excluidos. Manual original intacto; sin publicación ni push.

Siguiente mejora propuesta: organizar una ruta de estudio que reúna pedagogía, ética, interpretación, servicio y este integrador, para que el alumno encuentre la secuencia por objetivos de aprendizaje además de por etapas de construcción.
