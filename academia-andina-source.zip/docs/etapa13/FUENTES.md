# Fuentes de la Etapa 13

Consulta: 27 de octubre de 2026. Doce registros, incluidas reconsultas de obras previamente citadas. Verificación documental no equivale a validación de historiador ni instructor. Las fuentes institucionales retrospectivas no se presentan como diarios contemporáneos.

## e13-uiaa

UIAA — History of the UIAA

[History of the UIAA](https://www.theuiaa.org/inside-the-uiaa/history/)

**Acceso:** Página HTML completa

**Afirmaciones respaldadas:**

- Fundación en Chamonix en agosto de 1932 por veinte asociaciones.
- Desarrollo de estándares y pruebas de cuerdas desde 1960; aprobación internacional del sello en 1965.
- La historia institucional incluye conservación de montañas, educación y cooperación, además del deporte.

**Límites:** No es una historia mundial exhaustiva. No trasladar estándares históricos a requisitos actuales. Evitar extrapolar fechas organizativas a la invención de prácticas; otra memoria UIAA distingue comisión 1964/reorganización 1975.

## e13-chamonix

Office de Tourisme de la Vallée de Chamonix-Mont-Blanc — Chamonix, l’histoire extraordinaire - l'aventure scientifique

[Chamonix, l’histoire extraordinaire - l'aventure scientifique](https://www.chamonix.com/infos-et-services/espace-presse/chamonix-l-histoire-extraordinaire-l-aventure-scientifique)

**Acceso:** Página HTML completa

**Afirmaciones respaldadas:**

- Jacques Balmat y Michel-Gabriel Paccard alcanzaron el Mont Blanc el 8 de agosto de 1786.
- Horace-Bénédict de Saussure realizó mediciones en la cumbre en 1787 acompañado por Balmat.
- El episodio permite estudiar vínculos entre conocimiento local, ascensión y preguntas científicas.

**Límites:** Síntesis turística, no diario original de la ascensión. No equivale al comienzo de toda relación humana con las montañas. No usar las cotas históricas o el itinerario como datos operativos.

## e13-dav

Club Alemán Andino (DAV) — Deutscher Ausflugverein Valparaíso

[Deutscher Ausflugverein Valparaíso](https://dav.cl/club/historia/deutscher-ausflugverein-valparaiso/)

**Acceso:** Página HTML completa

**Afirmaciones respaldadas:**

- El club relata la fundación del Club Excursionista Concón o Ausflugverein Mitmit en 1909.
- El mismo relato sitúa el cambio de nombre a Deutscher Ausflugverein Valparaíso en 1910.

**Límites:** Atribuir expresamente las fechas al relato institucional. No prueba que fuera el primer montañismo, primera presencia humana ni primer club de toda clase en Chile. Las actas originales no fueron consultadas.

## e13-andina

Club Alemán Andino (DAV) — Revista Andina — archivo digital

[Revista Andina — archivo digital](https://dav.cl/revista/)

**Acceso:** Índice HTML; lista Heft 1 y Heft 2 de 1919. No lectura completa de cada número

**Afirmaciones respaldadas:**

- El archivo presenta la publicación iniciada en 1919 bajo el nombre DAV Mitteilungen.
- Hay números digitalizados que permiten buscar relatos y contrastar fecha del evento con fecha de publicación.

**Límites:** No adoptar sin contraste el superlativo de la página 'primer registro de actividades de montaña en Chile'. El catálogo acredita existencia y metadatos, no todas las ascensiones descritas dentro de cada número.

## e13-philippi

Biblioteca Nacional de Chile / Memoria Chilena — Bernardo Eunom Philippi (1811-1852)

[Bernardo Eunom Philippi (1811-1852)](https://www.memoriachilena.gob.cl/602/w3-article-644499.html)

**Acceso:** Página HTML completa

**Afirmaciones respaldadas:**

- Philippi escribió Relación del descubrimiento del lago Llanquihue (1842) y elaboró un mapa de Valdivia publicado en Kassel en 1846.
- La síntesis advierte que Philippi creyó descubrir el lago e ignoraba la visita anterior de Claudio Gay.
- Las exploraciones se vincularon a proyectos de colonización.

**Límites:** No equiparar descubrimiento escrito con primera presencia humana ni reducir la discusión a cuál europeo llegó antes. Distinguir Bernardo Eunom de su hermano Rodulfo Amando Philippi. No convierte un mapa histórico en delimitación actual.

## e13-etica

UNESCO — Patrimonio Cultural Inmaterial — Ethics and Intangible Cultural Heritage

[Ethics and Intangible Cultural Heritage](https://ich.unesco.org/en/ethics-and-ich-00866)

**Acceso:** Principios 1–5 recuperados por búsqueda indexada; apertura directa exige desafío, sin lectura completa

**Afirmaciones respaldadas:**

- Las comunidades tienen papel principal en salvaguardar su patrimonio.
- Las interacciones deben basarse en colaboración, diálogo, consulta y consentimiento libre, previo, sostenido e informado.

**Límites:** Orientación ética internacional, no resumen exhaustivo de ley chilena ni permiso para usar contenidos culturales. La aplicación local debe acordarse con portadores y comunidades; no inventar una voz comunitaria.

## e13-recuerdos-ficha

Biblioteca Nacional de Chile / Memoria Chilena — Recuerdos del pasado: 1814–1860. Capítulos XIX–XXIII (edición catalogada de 1882)

[Recuerdos del pasado: 1814–1860. Capítulos XIX–XXIII (edición catalogada de 1882)](https://www.memoriachilena.gob.cl/602/w3-article-7828.html)

**Acceso:** Ficha bibliográfica completa; no lectura integral del facsímil

**Afirmaciones respaldadas:**

- Autor, edición 1882, capítulos XIX–XXIII y páginas 233–286 de la edición catalogada.

**Límites:** No atribuir eventos al año de publicación. La ficha no acredita todos los episodios de la obra.

## e13-recuerdos-critica

Biblioteca Nacional de Chile / Memoria Chilena — Recuerdos del pasado (1882) — reseña crítica

[Recuerdos del pasado (1882) — reseña crítica](https://www.memoriachilena.gob.cl/602/w3-article-7678.html)

**Acceso:** Página completa; apartados sobre género, colonización y lectura crítica

**Afirmaciones respaldadas:**

- Mezcla de memoria y autobiografía; episodios difíciles de verificar.
- Capítulos finales vinculados al agente de colonización y recorridos por el sur.

**Límites:** No adoptar la cronología editorial completa: la página contiene fechas/denominaciones de ediciones que requieren contraste. No se lee aquí la obra íntegra ni se atribuyen primeras ascensiones.

## e13-mujeres

American Alpine Club Library — Sallie Greenwood — Women in High Places, 1880–1950

[Women in High Places, 1880–1950](https://library.americanalpineclub.org/exhibits/show/womenclimbing)

**Acceso:** Página introductoria completa

**Afirmaciones respaldadas:**

- Cuatro mujeres entre los 45 miembros originales del AAC en 1902.
- Distintas posibilidades de pertenencia a clubes según institución.

**Límites:** Selección histórica, no historia mundial completa. No se adoptan récords de altitud ni primeras ascensiones sin contrastar expedientes.

## e13-fis

FIS — 1924 – Chamonix (FRA)

[1924 – Chamonix (FRA)](https://www.fis-ski.com/inside-fis/governance/congress-history/1924-chamonix-fra)

**Acceso:** Página completa

**Afirmaciones respaldadas:**

- Constitución de FIS el 2 de febrero de 1924 en el octavo Congreso Internacional de Esquí.
- Transformación de comisión en federación.

**Límites:** No fecha la invención del esquí ni representa toda su historia o reglas vigentes.

## e13-csa

Cuerpo de Socorro Andino de Chile — Historia institucional — cronología

[Historia institucional — cronología](https://socorroandinochile.cl/?page=2)

**Acceso:** Sección Historia, página completa

**Afirmaciones respaldadas:**

- Propuesta organizativa en 1949, primer rescate a nombre del CSA en 1951 y corporación en 1969.
- Ayuda a Puerto Montt después del terremoto de 1960 según la institución.

**Límites:** No actas originales ni contraste completo de operaciones. No informa cobertura, tiempos de respuesta o protocolos actuales.

## e13-futahuillimapu

Cristián Enrique Perucci González / Servicio Nacional del Patrimonio Cultural — El censo indígena de 1907–1908: un episodio de expoliación burocrática en Futahuillimapu (2024), reconsulta

[El censo indígena de 1907–1908: un episodio de expoliación burocrática en Futahuillimapu (2024), reconsulta](https://www.investigacion.patrimoniocultural.gob.cl/publicaciones/el-censo-indigena-de-1907-1908-un-episodio-de-expoliacion-burocratica-en)

**Acceso:** Ficha y resumen completos; no artículo completo ni fichas de archivo

**Afirmaciones respaldadas:**

- Estudio de fichas del censo de 1907–1908 entre río Bueno y seno de Reloncaví.
- El autor vincula documentación y desposesión mapuche-huilliche.

**Límites:** Reconsulta de referencia previa. No representa todas las comunidades ni autoriza reproducir saberes ceremoniales. No se consultó el archivo completo.
