# Etapa 13 · Historia de la montaña y patrimonio

Entrega local del 27 de octubre de 2026. Versión 0.13.0. Bloque piloto en desarrollo; la academia no está terminada ni emite certificaciones.

## Contenido agregado

Ocho unidades progresivas vinculadas al módulo histórico M17 y a la ruta territorial:

1. Leer historia: testimonio, archivo y afirmación.
2. Alpinismo: hitos, ciencia y personas visibles.
3. Andinismo chileno: clubes y archivos de expediciones.
4. Historia del equipo: de objetos a ensayos.
5. Esquí y escalada: prácticas e instituciones distintas.
6. Rescate organizado: memoria institucional y servicio.
7. Los Lagos: exploración escrita y relato de colonización.
8. Patrimonio vivo: construir un guion responsable.

Cada unidad contiene objetivos, prerrequisitos, conceptos, teoría, procedimiento documental, caso ficticio, errores y seguridad, equipo, autoevaluación, tres preguntas con explicaciones por opción, ejercicios individuales, propuesta de taller supervisado, registro y criterios de revisión humana. Se distinguen TEORÍA, PROCEDIMIENTO, PRÁCTICA INDIVIDUAL, PRÁCTICA SUPERVISADA y COMPETENCIA. Ningún resultado teórico certifica guiado o maniobras.

Se incorporan 24 preguntas, ocho habilidades, cuatro plantillas de taller y una ruta nueva. La portada presenta once hitos documentados con fuente y límite, filtro por ámbito, tres ejercicios de inferencia y un guion integrador que se guarda localmente. Los casos y filtros no crean evaluaciones ni competencias. El guion usa responses['plan-historia:v1'] y se incluye en el respaldo v3 existente sin cambiar el formato.

## Fuentes y calidad editorial

Doce registros consultados: Biblioteca Nacional/Memoria Chilena, Chamonix, American Alpine Club Library, DAV, UIAA, FIS, Cuerpo de Socorro Andino, Servicio Nacional del Patrimonio Cultural y UNESCO. FUENTES.md detalla URL, afirmaciones respaldadas y límites de acceso.

Las historias institucionales se atribuyen como tales; no se presentan como actas originales. Recuerdos del pasado se trabaja desde catálogo y reseña, sin afirmar lectura integral. Del estudio sobre Futahuillimapu se consultó el resumen institucional, no el artículo ni el archivo completo. Los principios de UNESCO se recuperaron mediante búsqueda indexada; la apertura directa tuvo una restricción, indicada en la bibliografía. No se reutilizaron cifras demográficas o referencias legales antiguas de una fuente museográfica evaluada durante la investigación.

No se inventaron primeras ascensiones regionales ni tradiciones comunitarias. No se reproduce una voz comunitaria sin colaboración. La cronología es una selección para aprender a interpretar documentos, no una historia universal ni un inventario exhaustivo.

## Resultados reales

| Comprobación | Resultado |
|---|---|
| TypeScript/Astro | 100 archivos; 0 errores, 0 advertencias, 0 sugerencias |
| Tests | 142 aprobados; 0 fallos, incluidos 10 nuevos |
| Build raíz | 256 páginas, correcto |
| Build /academia-andina/ | 256 páginas, correcto |
| Verificador global, ambas bases | 9374 enlaces/recursos y 640 entradas de búsqueda, correcto |
| Verificador Etapa 13, ambas bases | 9 páginas y 522 enlaces/recursos/anclas, correcto |
| Navegación en navegador | Primera a segunda lección, enlaces contiguos correctos |
| Búsqueda | Llanquihue encuentra la nueva lección y ficha territorial |
| Quiz | 3/3 con explicaciones; resultado teórico persistente tras recarga |
| Taller de evidencia | Corrección incorrecta/correcta, cambio de caso y respuesta vacía comprobados |
| Guion local | Guardado y recarga con texto ficticio comprobados |
| Responsive | Iframe 390×844; ancho interior y scrollWidth 375px; controles operables |
| JSON | Roundtrip automatizado y rechazo de datos inválidos; sin creación de prácticas |
| Conservación | 361 archivos académicos históricos por hash y comparación de objetos previos |
| Manual | git diff vacío en archivos versionados; cambios solo dentro de academia/ |

La descarga/importación del respaldo por interfaz no se repitió debido a un bloqueo de política del navegador observado en una etapa anterior. No se afirma haber comprobado nuevamente ese flujo completo. Los tests validan su lógica y la integración del guion. La prueba móvil usa un iframe local, no un dispositivo físico ni una auditoría WCAG.

Dependencias sin cambios de versión: se utilizó la instalación existente; no se ejecutó una reinstalación innecesaria. El build limpia únicamente archivos generados como se implementó en Etapa 12. Se verificó la secuencia base de proyecto → raíz y se conserva un build final para raíz. La página temporal de QA fue eliminada antes del build final.

Totales: 165 lecciones/cuestionarios, 140 unidades, 162 habilidades, 14 rutas, 219 registros bibliográficos y 47 diagramas. Las 376 entradas originales mantienen su estado pendiente. No se añadieron diagramas a este bloque; la cronología accesible es HTML.

## Ejecución

Desde la carpeta academia descomprimida, con Node.js 24:

```bash
npm ci
npm run dev
```

Abrir http://localhost:4321/ o el puerto indicado por Astro. Para verificar:

```bash
npm run check
npm test
npm run build
npm run test:build
node scripts/check-history-build.mjs
```

Para verificar una base de GitHub Pages, con el servidor de desarrollo detenido:

```bash
BASE_PATH=/academia-andina/ npm run build
BASE_PATH=/academia-andina/ npm run test:build
BASE_PATH=/academia-andina/ node scripts/check-history-build.mjs
```

No se publicó, hizo push ni modificó el remoto.

## Pendientes y próxima etapa

Revisión del contenido por historiador, especialista de patrimonio e instructor. Cualquier incorporación de conocimientos comunitarios requiere colaboración acordada con sus portadores; esta entrega no acredita ese consentimiento. Pendientes: historia detallada de técnicas, escuelas de escalada y esquí chileno, objetos de equipo, testimonios locales y expedientes de primeras ascensiones. Las fuentes verificadas no equivalen a validación profesional de las adaptaciones didácticas.

Etapa 14 propuesta: conocimiento territorial de Los Lagos. Ampliar primero las fichas faltantes de Hornopirén, Michinmahuida, Chaitén y Corcovado, con registro de evidencia por campo, fechas y discrepancias. Separar datos geográficos relativamente estables de accesos, restricciones, peligros y condiciones que requieren consulta actual. Añadir un ejercicio de comparación territorial y preparación de consulta, sin publicar itinerarios ni dificultades no corroborados. Mantener las fichas existentes y el manual intactos.
