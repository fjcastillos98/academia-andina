# Archivos de la Etapa 13

Comparación con ZIP de Etapa 12; excluye dependencias, build y entregas. Manual original fuera de academia/.

## Creados

- `data/archive/etapa12/README.md`
- `data/archive/etapa12/curriculum.json`
- `data/archive/etapa12/diagrams.json`
- `data/archive/etapa12/learning-paths.json`
- `data/archive/etapa12/skills.json`
- `data/archive/etapa12/sources.json`
- `docs/etapa13/FUENTES.md`
- `docs/etapa13/INFORME.md`
- `docs/etapa13/briefs.json`
- `docs/etapa13/historical-sha256.json`
- `docs/etapa13/logs/browser-qa.txt`
- `docs/etapa13/logs/build-base.txt`
- `docs/etapa13/logs/build-links-base.txt`
- `docs/etapa13/logs/build-links.txt`
- `docs/etapa13/logs/build.txt`
- `docs/etapa13/logs/check.txt`
- `docs/etapa13/logs/git-status.txt`
- `docs/etapa13/logs/manual-tracked-diff.txt`
- `docs/etapa13/logs/routes-base.txt`
- `docs/etapa13/logs/routes-root.txt`
- `docs/etapa13/logs/tests.txt`
- `docs/etapa13/research.json`
- `docs/etapa13/screenshots/historia-390px.jpg`
- `scripts/check-history-build.mjs`
- `src/content/lecciones/historia-alpes-personas.md`
- `src/content/lecciones/historia-clubes-chile.md`
- `src/content/lecciones/historia-equipo.md`
- `src/content/lecciones/historia-esqui-escalada.md`
- `src/content/lecciones/historia-evidencia.md`
- `src/content/lecciones/historia-llanquihue.md`
- `src/content/lecciones/historia-patrimonio-vivo.md`
- `src/content/lecciones/historia-socorro.md`
- `src/data/assessments/historia-alpes-personas.v1.json`
- `src/data/assessments/historia-clubes-chile.v1.json`
- `src/data/assessments/historia-equipo.v1.json`
- `src/data/assessments/historia-esqui-escalada.v1.json`
- `src/data/assessments/historia-evidencia.v1.json`
- `src/data/assessments/historia-llanquihue.v1.json`
- `src/data/assessments/historia-patrimonio-vivo.v1.json`
- `src/data/assessments/historia-socorro.v1.json`
- `src/data/history-events.json`
- `src/data/history-templates.json`
- `src/lib/history-client.ts`
- `src/lib/history.ts`
- `src/pages/historia.astro`
- `tests/etapa13.test.ts`
- `docs/etapa13/ARCHIVOS.md`

## Modificados

- `README.md`
- `data/curriculum.json`
- `data/learning-paths.json`
- `data/skills.json`
- `package-lock.json`
- `package.json`
- `scripts/validate.ts`
- `src/data/sources.json`
- `src/layouts/Layout.astro`
- `src/lib/expanded.ts`
- `src/lib/practice-client.ts`
- `src/lib/program.ts`
- `src/pages/lecciones/[id].astro`
- `src/pages/practicas.astro`

## Eliminados

Ninguno.
