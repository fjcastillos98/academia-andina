# Academia Andina Filo Austral · Etapa 3 — piloto

Plataforma estática en español para estudio personal. Astro 7.4.2, TypeScript, Markdown y Zod. Implementación independiente dentro de `academia/`: no modifica el manual de Chiloé. No se ha publicado ni hecho push.

## Requisitos y ejecución

Node.js 24 LTS y npm. Desde esta carpeta:

```bash
npm ci
npm run dev
```

Abrir http://localhost:4321/ (o el puerto que imprima Astro). No abrir `index.html` con `file://`. En el entorno de pruebas de ChatGPT se utiliza el supervisor de preview; no es un requisito del proyecto descargado.

```bash
npm run check       # TypeScript y componentes Astro
npm run validate    # Alcance curricular, frontmatter y apartados
npm test            # Pruebas automatizadas de dominio y persistencia
npm run build       # Validación + generación estática en dist/
npm run test:build  # Enlaces y recursos del build
npm run preview    # Servir el resultado, normalmente puerto 4321
```

## Qué incluye

- Portada con progreso, 24 páginas de asignatura, 376 entradas pendientes y 13 lecturas: 10 temas de Fundamentales y 3 ejemplos conservados.
- Catálogo filtrable, navegación anterior/siguiente y búsqueda en títulos, descripción y cuerpo; normaliza tildes y mayúsculas.
- Glosario inicial de 8 términos y biblioteca de fuentes.
- Trece cuestionarios con explicaciones, historial de hasta 100 intentos por lección y criterio teórico explícito (todas correctas).
- Notas de hasta 10.000 caracteres, favoritos y estudio local; exportación/importación JSON con validación y confirmación.
- Interfaces semánticas, foco visible, enlace para saltar al contenido, formularios etiquetados y reducción de movimiento. Diseño adaptable; no es una certificación WCAG.

Las 376 entradas son un mapa de alcance, no 376 lecciones. Algunas describen requisitos de fichas (por ejemplo, campos de montañas). Ni el piloto ni las muestras cambian los estados pendientes del mapa.

## Datos y privacidad

Se usa **localStorage**, en lugar de IndexedDB propuesto en la auditoría, porque esta etapa guarda un pequeño objeto de texto. Se encapsula en `src/lib/state.ts` para permitir migración posterior. Clave: `filo-austral:academia:v1:<ruta-base>`; queda vinculada al navegador y origen. No hay cuenta, backend, sincronización entre dispositivos ni cifrado. Evitar edición simultánea en varias pestañas: no hay resolución de conflictos.

Las notas se guardan al pulsar **Guardar nota**. No introducir datos médicos, contraseñas o información de pasajeros. Los registros no se incluyen en el build ni en el repositorio. Todos los textos importados se presentan como texto, no HTML. Los errores de lectura o cuota se avisan; no se resetea silenciosamente un estado corrupto.

Exportar antes de cambiar navegador, dirección/base o borrar almacenamiento. Importación: archivo máximo 2 MB, formato/versión estrictos, identificadores conocidos y respuestas válidas. Revisar el resumen y confirmar; reemplaza el estado anterior. El respaldo versión 2 incluye hasta 500 prácticas; importa y migra también la versión 1 sin perder estudio. Se conserva la clave local v1 para leer los datos anteriores. Una evaluación declarada exige supervisor, evaluador, fecha, criterio y evidencia; no verifica credenciales ni certifica competencias. Es un cuaderno personal, no un registro inviolable de certificaciones.

## Estructura

- `data/curriculum.json`: única fuente del mapa original, conservada.
- `src/content/lecciones/*.md`: texto y metadatos JSON en frontmatter YAML compatible.
- `src/content.config.ts`, `src/lib/schemas.ts`: colección y validación.
- `src/data/`: fuentes y glosario.
- `src/pages/`: páginas estáticas y dos índices JSON generados.
- `src/layouts/`, `src/components/`, `src/styles/`: interfaz.
- `src/lib/learning.ts`: búsqueda, corrección y estado teórico.
- `src/lib/state.ts`: persistencia y respaldo.
- `src/lib/client.ts`: interacciones accesibles de navegador.
- `scripts/`, `tests/`: validación y pruebas.
- `docs/`: decisiones, verificación y plantilla de publicación inactiva.

## Rutas base y GitHub Pages

Se recomienda un **repositorio independiente** llamado, por ejemplo, `academia-andina`, con el contenido de esta carpeta en su raíz. No copiar el workflow al repositorio del manual: desplegar solo `academia/dist` sobre el sitio del manual lo reemplazaría.

Comprobar localmente una base de proyecto (bash):

```bash
BASE_PATH=/academia-andina/ npm run build
BASE_PATH=/academia-andina/ npm run test:build
BASE_PATH=/academia-andina/ npm run preview
```

Abrir la ruta `/academia-andina/` del servidor de preview. Usar la misma base al compilar y servir. `BASE_PATH` debe comenzar y terminar con `/`. En PowerShell: `$env:BASE_PATH='/academia-andina/'`, ejecutar los comandos npm y luego `Remove-Item Env:BASE_PATH`. Para dominio propio o raíz, usar `/`.

`SITE_URL` configura el origen (predeterminado: `https://fjcastillos98.github.io`), **no** implica que exista publicación. Enlaces, búsqueda, índices JSON y favicon utilizan la base. Assets de Astro se prefijan automáticamente.

`docs/github-pages.yml.example` es una plantilla **inactiva** para un futuro repositorio separado. Solo tras autorización: copiarla a `.github/workflows/pages.yml` en ese nuevo repositorio, configurar Pages con GitHub Actions y ejecutarla manualmente. No contiene secretos. Revisa las versiones de acciones al activarla. Este trabajo no cambió el remoto ni activó ningún workflow.

## Contenidos y límites

Consultar `CONTRIBUTING.md`. Fuentes: SLF/KAT, OMM, USGS, NPS, NWS, Leave No Trace, UIAA, Petzl y Garmin; DMC como portal oficial de consulta, sin pronóstico local validado. Consulta documental: 21–22-10-2026. El modelo de evidencias es un criterio editorial propio. Los diez temas del piloto requieren revisión de instructor; nudos y anclajes preparan talleres supervisados, sin secuencias operativas para aplicar sin formación.

El diario guarda declaraciones personales de práctica y evaluación, con evidencia textual y una matriz de diez habilidades. No hay verificación de instructor, matriz profesional completa, calendario, plan deportivo adaptativo, contenido médico ni normativa vigente. Todo eso pertenece a etapas posteriores. Ningún cuestionario certifica una maniobra. La licencia de distribución del conjunto sigue pendiente; no se ha añadido LICENSE.

## Etapa 3: secuencia y diario

Abrir `/fundamentales/`: A riesgo → B 3×3 → C planificación → D meteorología → E nubes → F navegación → G equipo → H nudos → I cuerdas/anclajes → J comunicaciones. Los prerrequisitos orientan la secuencia, sin bloquear el acceso ni acreditar preparación práctica. `pilot.position`, `requires`, `critical`, `classifications`, `relatedModules` y `criteria` mantienen la estructura. El mapa original no se renumera.

`/practicas/` permite registrar y editar prácticas, consultar criterios y ver la matriz. Un quiz nunca actualiza una competencia. Solo las evaluaciones declaradas con todos los campos completados afectan esa columna; prevalece la evaluación más reciente y, si el mismo día hay resultados contradictorios, se muestra «En desarrollo». No hay caducidad automática ni acreditación externa. La evidencia es texto, no adjuntos.

Ver `docs/verificacion-etapa3.md` para resultados reales, `docs/etapa3.md` para alcance y pendientes, y `docs/archivos-etapa3.md` para archivos.
