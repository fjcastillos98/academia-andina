# Entrega local · Etapas 4.1 y 4.2

Fecha de revisión: 22 de octubre de 2026. Proyecto en desarrollo; sin publicación, push ni cambios al manual original.

## Implementación

Currículo v2 ampliable, 376 entradas originales y 11 entradas nuevas en borrador; 11 unidades nuevas, 21 habilidades y dos rutas. Archivo histórico exacto `data/archive/curriculum.v1.json`. Veinticuatro evaluaciones teóricas versionadas; las 13 anteriores se conservan con las mismas preguntas. Respaldo v3 con migración v1/v2, equipo, inspecciones, respuestas abiertas y diario ampliado. La clave de almacenamiento original permanece estable.

Programa navegable, matriz de cinco estados, inventario con revisión/aislamiento/retiro, cinco casos con respuestas guardables y plantilla de salida antes/durante/después. Búsqueda incluye casos y nuevas lecturas. Teoría, práctica, supervisión y evaluación permanecen diferenciadas. Los avances teóricos no generan competencia.

## Contenido escrito

Once lecturas nuevas (aproximadamente 9.461 palabras de cuerpo Markdown; no incluye metadatos, preguntas ni casos):

| Unidad | Contenido desarrollado |
|---|---|
| Montaña estival | Terreno, marcha, esfuerzo/exposición, campamento, retirada y práctica observacional |
| Planificación y operación | Expediente antes/durante/después, roles, información pendiente, permisos, seguros y revisión de requisitos |
| Riesgo y decisiones 3×3 | Peligro, exposición, vulnerabilidad, consecuencias, incertidumbre, controles, sesgos, presión y criterios de aborto |
| Carta y brújula | Escala, relieve, coordenadas, norte/declinación, azimut/rumbo, orientación y ejercicios de mesa |
| GPS y contingencias | Señal, mapas offline, tracks, waypoints, errores, batería, redundancia, pérdida de orientación y límites ante whiteout |
| Atmósfera | Presión, temperatura, humedad/rocío, estabilidad, frentes, inversión, viento, precipitación, visibilidad y tormentas |
| Pronósticos | Emisión/validez, modelo, incertidumbre, alerta, observación y decisión operacional |
| Nubes | Diez géneros, especie lenticularis, ondas, formación orográfica y registro de observación |
| Guiado de grupos | Briefing, comunicación, distribución, ritmo, ansiedad, fatiga, conflicto y decisiones difíciles |
| Incidentes | Límites de actuación, comunicaciones, retirada, mensaje de situación y debriefing sin diagnóstico ni tratamiento avanzado |
| Preparación física | Fuerza, hipertrofia, potencia, resistencia, economía de marcha, desnivel/carga, recuperación y especificidad; sin prescripción personal |

Cada unidad contiene objetivos, prerrequisitos, teoría, vocabulario, decisiones, errores/señales de alerta, caso, autoevaluación explicada, quiz de dos preguntas, ejercicio, evidencia y fuentes. Los casos adicionales incluyen Calbuco (aproximación, ascenso, refugio por verificar, pirámide, descenso, viento y posible nieve/hielo), Osorno, Casablanca, Yates y cordillera de Los Lagos. Son ejercicios originales: no fichas de ruta, ni información actual de acceso, condiciones o dificultad.

## Fuentes

35 registros en `src/data/sources.json`: 15 históricos y 20 añadidos. De los añadidos, 19 tienen consulta documental y uno queda pendiente. Los enlaces dentro de las lecturas llevan a su ficha y a la fuente externa. Cada ficha identifica organización, título, URL, consulta, publicación cuando se conoce y limitaciones. Consulta documental no significa aprobación por instructor.

- **National Park Service — Hike Smart**. Consulta documental realizada. [nps-marcha](https://www.nps.gov/articles/hiking-safety.htm). Respalda: estival-terreno, gps-contingencias, preparacion-andinismo. Límite: Planificación de caminatas y capacidades del grupo; no una clasificación local de rutas.
- **National Park Service — Camping Safely Step 1 — Before the Trip**. Consulta documental realizada. [nps-campamento](https://www.nps.gov/articles/camp-safety-before-the-trip.htm). Respalda: estival-terreno. Límite: Preparación y restricciones de campamento; no permisos chilenos.
- **National Park Service — Trip Planning Guide**. Consulta documental realizada. [nps-plan](https://www.nps.gov/subjects/healthandsafety/trip-planning-guide.htm). Respalda: plan-operacion, riesgo-decisiones. Límite: Marco para visita diurna/pernocta; no protocolo integral de expedición.
- **National Park Service — Trip Planning Guide — During your trip**. Consulta documental realizada. [nps-grupo](https://www.nps.gov/subjects/healthandsafety/trip-planning-guide.htm). Respalda: grupo-liderazgo. Límite: Permanecer juntos y revisar el plan; las simulaciones de liderazgo son elaboración didáctica.
- **National Park Service — Hike Smart — Have an Emergency Plan**. Consulta documental realizada. [nps-emergencia](https://www.nps.gov/articles/hiking-safety.htm). Respalda: incidentes-retirada. Límite: Preparación ante pérdida o lesión; no enseña atención clínica.
- **SERNATUR — Actualización normativa del turismo aventura: consulta los parámetros aplicables a cada actividad**. Consulta documental realizada. [sernatur-2026](https://www.sernatur.cl/actualizacion-normativa-del-turismo-aventura-consulta-los-parametros-aplicables-a-cada-actividad/). Respalda: plan-operacion, grupo-liderazgo. Límite: Nota institucional consultada. No se revisaron íntegramente todos los instrumentos enlazados ni se acredita cumplimiento de Filo Austral.
- **NOAA NCEI — Magnetic Declination**. Consulta documental realizada. [noaa-declinacion](https://www.ncei.noaa.gov/products/magnetic-declination). Respalda: carta-brujula. Límite: Definición y convención angular; no valor local calculado.
- **USGS — What do the different north arrows on a USGS topographic map mean?**. Consulta documental realizada. [usgs-nortes](https://www.usgs.gov/faqs/what-do-different-north-arrows-a-usgs-topographic-map-mean). Respalda: carta-brujula. Límite: Nortes y cambio temporal; no carta local actualizada.
- **GPS.gov — GPS Accuracy**. Consulta documental realizada. [gps-precision](https://www.gps.gov/gps-accuracy). Respalda: gps-contingencias. Límite: Factores de precisión y errores cartográficos; no garantía para un receptor.
- **Garmin — What is GPS?**. Pendiente. [garmin-gps](https://www.garmin.com/en-US/aboutgps/). Respalda: gps-contingencias. Límite: Principio de posicionamiento. Menús y prestaciones del equipo concreto requieren manual. Página localizada, pero el cuerpo depende de JavaScript: verificación documental completa pendiente. No se usa como único respaldo técnico.
- **NOAA JetStream — Air Pressure**. Consulta documental realizada. [noaa-presion](https://www.noaa.gov/jetstream/atmosphere/air-pressure). Respalda: atmosfera-montana. Límite: Conceptos de presión y referencia de altura; no pronóstico.
- **National Weather Service — A Discussion of Water Vapor, Humidity, and Dewpoint**. Consulta documental realizada. [nws-humedad](https://www.weather.gov/lmk/humidity). Respalda: atmosfera-montana. Límite: Humedad, saturación y punto de rocío; no previsión local.
- **Met Office — What is a temperature inversion?**. Consulta documental realizada. [met-inversion](https://weather.metoffice.gov.uk/learn-about/weather/types-of-weather/temperature/temperature-inversion). Respalda: atmosfera-montana. Límite: Perfil e inversión térmica; no aplica un gradiente fijo a Los Lagos.
- **Met Office — Weather fronts**. Consulta documental realizada. [met-frentes](https://weather.metoffice.gov.uk/learn-about/weather/atmosphere/weather-fronts). Respalda: atmosfera-montana. Límite: Frentes y masas de aire; ejemplos británicos no trasladados como pronóstico chileno.
- **National Weather Service — Full Weather Glossary**. Consulta documental realizada. [nws-glosario](https://www.weather.gov/otx/full_weather_glossary). Respalda: atmosfera-montana. Límite: Vocabulario meteorológico; no umbrales operacionales universales.
- **ECMWF — Quantifying forecast uncertainty**. Consulta documental realizada. [ecmwf-incertidumbre](https://www.ecmwf.int/en/research/modelling-and-prediction/quantifying-forecast-uncertainty). Respalda: pronostico-decision. Límite: Incertidumbre y conjuntos; no se reproducen especificaciones actuales del sistema.
- **National Weather Service — Mountain Wave Activity Over the Southern Rockies**. Consulta documental realizada. [nws-ondas](https://www.weather.gov/abq/features_mountainwaves). Respalda: nubes-observacion. Límite: Mecanismo y nubes de onda; no extrapola cifras del estudio a Chile.
- **SENAPRED — Planos de Evacuación Los Lagos**. Consulta documental realizada. [senapred-lagos](https://www.senapred.cl/planos-de-evacuacion-los-lagos/). Respalda: incidentes-retirada. Límite: Directorio de amenazas específicas; no rutas de rescate de montaña.
- **American College of Sports Medicine — ACSM Unveils Landmark 2026 Resistance Training Guidelines**. Consulta documental realizada. [acsm-fuerza](https://acsm.org/resistance-training-guidelines-update-2026/). Respalda: preparacion-andinismo. Límite: Síntesis institucional de posición para adultos sanos; no prescripción individual ni prueba de aptitud.
- **American College of Sports Medicine — Physical Activity Guidelines**. Consulta documental realizada. [acsm-aerobico](https://acsm.org/education-resources/trending-topics-resources/physical-activity-guidelines/). Respalda: preparacion-andinismo. Límite: Marco general; no dosis de entrenamiento de montaña personalizada.


Se conservan las fuentes previas OMM, SLF, Petzl, UIAA, Garmin SOS, DMC, NPS, USGS y Leave No Trace. La consulta de SERNATUR identifica una actualización de septiembre de 2026, pero no se ha realizado una revisión jurídica integral de sus instrumentos: no se afirma un ratio de pasajeros/guía ni cumplimiento normativo. No se publica una alerta actual o una ruta autorizada. La página Garmin «What is GPS?» requiere JavaScript y queda marcada pendiente; GPS.gov respalda las limitaciones de posicionamiento.

## Pruebas reales

- `npm ci`: 274 paquetes instalados.
- `npm run check`: 42 archivos, cero errores, advertencias o hints de TypeScript/Astro.
- `npm test`: 36 pruebas, 36 aprobadas, cero fallos.
- `npm run build`: 66 páginas, sin errores.
- Build con `BASE_PATH=/academia-andina/`: 66 páginas, sin errores.
- `npm run test:build` en ambas bases: 1.526 enlaces/recursos internos válidos, 437 resultados en el índice. Se comprueban también los destinos de las citas internas. No es un rastreo de todos los enlaces externos.
- Comparación byte a byte contra el ZIP de Etapa 3: 13 lecturas intactas y copia histórica de currículo exacta. `git diff` y `git diff --cached` sin cambios en los archivos originales rastreados.
- Navegador: navegación a programa, diario, inventario, búsqueda, lección, cuaderno y caso; búsqueda «lenticulares» con tres resultados; búsqueda vacía sin coincidencias; quiz de nubes 2/2 con explicaciones e intento guardado; respuesta abierta conservada tras recargar.
- Navegador: alta de equipo, inspección, práctica nueva, edición y vínculo de equipo; exportación real v3 y restauración con resumen; rechazo de JSON roto. El archivo exportado contiene equipo, inspección, práctica, respuesta e intento.
- Escritorio: inspección visual y salto por teclado a `#contenido`. Vista estrecha: iframe de 390 px (375 px de área útil por scrollbar), programa y caso Calbuco sin desbordamiento del documento; formulario del caso utilizable. No se probó en un teléfono físico ni en Safari.

## Errores encontrados y corregidos

Validador antiguo exigía apartados del piloto a las unidades nuevas; se añadió su contrato editorial específico. Se reforzó la conservación del currículo histórico. La prueba de migración esperaba v2 y ahora comprueba v3 y preservación de datos. Se corrigieron tipos de campos HTML y claves de pruebas. En HTTP local, `crypto.randomUUID` no estaba disponible: se añadió alternativa con aleatoriedad del navegador. Se corrigió una carrera de carga que podía sobrescribir texto introducido temprano en búsqueda o respuesta abierta. Se eliminó el descarte automático de intentos antiguos.

Aviso no bloqueante del entorno: npm informa de la variable `http-proxy` desconocida. No procede de la configuración del proyecto.

## Límites y revisión de instructor

Todas las prácticas presenciales y evaluaciones requieren revisión competente. Especialmente navegación en condiciones degradadas, cuerda/anclajes del piloto, gestión de incidentes, decisión en terreno expuesto y cualquier propuesta para pirámide cumbrera. Ningún montaje se declara seguro por estar descrito. Los casos regionales necesitan reconocimiento, información oficial actual y revisión local antes de convertirse en material operativo.

No hay firma o verificación de credenciales del evaluador. Los registros son declaraciones editables. La plataforma no emite certificaciones. Los cuestionarios de dos preguntas son una comprobación inicial, no una evaluación exhaustiva. La meteorología es formación conceptual, no un servicio de pronóstico. El entrenamiento es introductorio, no un plan individual. Las técnicas avanzadas solo tienen dependencias preparadas.

Almacenamiento local sin cuenta, cifrado o sincronización; no se resuelven cambios simultáneos de distintas pestañas. Límite total de respaldo 2 MB. No introducir información médica, contraseñas ni datos privados de pasajeros. La plantilla de salida no se persiste: se imprime; no se comprobó una impresora ni el diálogo PDF del sistema. El inventario almacena inspecciones sin certificar material apto. Importar reemplaza, no fusiona: exportar antes.

## Etapa 4.3 propuesta

1. Revisión por instructor de las 11 unidades y cinco casos, registrando observaciones, versión, fecha y alcance.
2. Ejecutar tres talleres progresivos: planificación/3×3 en mesa, carta-brújula/GPS en entorno controlado y marcha/gestión de grupo en terreno adecuado con supervisión. Registrar evidencia por criterio.
3. Convertir un solo caso regional en expediente territorial documentado: fuentes oficiales, permisos/accesos verificados y fecha de reconocimiento; mantener separados datos vigentes de hipótesis.
4. Mejorar evaluación con rúbricas por criterio, conservación de revisiones del diario y mayor banco de preguntas versionado. No abrir todavía técnicas avanzadas sin resolver prerrequisitos.
5. Validación de accesibilidad más amplia, prueba en teléfono físico y ensayo de recuperación entre navegadores antes de autorizar publicación.

## Abrir localmente

Desde la carpeta `academia`, con Node 24:

```bash
npm ci
npm run dev
```

Abrir `http://localhost:4321/`. Para revisión estática: `npm run build` y `npm run preview`. Cambiar origen o base cambia el espacio local de datos: exportar e importar para trasladarlo.
