# Academia Andina Filo Austral · Etapas 4.1 y 4.2

Plataforma estática en español para estudio personal. Astro 7.4.2, TypeScript, Markdown y Zod. Implementación independiente dentro de `academia/`: no modifica el manual de Chiloé. No se ha publicado ni hecho push.

## Requisitos y ejecución

Node.js 24 LTS y npm. Desde esta carpeta:

```bash
npm ci
npm run dev
```

Abrir http://localhost:4321/ (o el puerto que imprima Astro). No abrir `index.html` con `file://`. En el entorno de pruebas de ChatGPT se utiliza el supervisor de preview; no es un requisito del proyecto descargado.

```bash
npm run check       # TypeScript y componentes Astro
npm run validate    # Alcance curricular, frontmatter y apartados
npm test            # Pruebas automatizadas de dominio y persistencia
npm run build       # Validación + generación estática en dist/
npm run test:build  # Enlaces y recursos del build
npm run preview    # Servir el resultado, normalmente puerto 4321
```

## Qué incluye

- Portada con progreso, 24 páginas de asignatura, 376 entradas pendientes y 24 lecturas: 13 históricas intactas y 11 unidades nuevas en desarrollo.
- Catálogo filtrable, navegación anterior/siguiente y búsqueda en títulos, descripción y cuerpo; normaliza tildes y mayúsculas.
- Glosario inicial de 8 términos y biblioteca de fuentes.
- Veinticuatro cuestionarios versionados con explicaciones, historial de hasta 10.000 intentos por lección (sin descarte automático; limitado además por los 2 MB del respaldo) y criterio teórico explícito (todas correctas).
- Notas de hasta 10.000 caracteres, favoritos y estudio local; exportación/importación JSON con validación y confirmación.
- Interfaces semánticas, foco visible, enlace para saltar al contenido, formularios etiquetados y reducción de movimiento. Diseño adaptable; no es una certificación WCAG.

Las 376 entradas son un mapa de alcance, no 376 lecciones. Algunas describen requisitos de fichas (por ejemplo, campos de montañas). Ni el piloto ni las muestras cambian los estados pendientes del mapa.

## Datos y privacidad

Se usa **localStorage**, en lugar de IndexedDB propuesto en la auditoría, porque esta etapa guarda un pequeño objeto de texto. Se encapsula en `src/lib/state.ts` para permitir migración posterior. Clave: `filo-austral:academia:v1:<ruta-base>`; queda vinculada al navegador y origen. No hay cuenta, backend, sincronización entre dispositivos ni cifrado. Evitar edición simultánea en varias pestañas: no hay resolución de conflictos.

Las notas se guardan al pulsar **Guardar nota**. No introducir datos médicos, contraseñas o información de pasajeros. Los registros no se incluyen en el build ni en el repositorio. Todos los textos importados se presentan como texto, no HTML. Los errores de lectura o cuota se avisan; no se resetea silenciosamente un estado corrupto.

Exportar antes de cambiar navegador, dirección/base o borrar almacenamiento. Importación: archivo máximo 2 MB, formato/versión estrictos, identificadores conocidos y respuestas válidas. Revisar el resumen y confirmar; reemplaza el estado anterior. El respaldo versión 3 incluye hasta 500 prácticas, 500 equipos con inspecciones y respuestas abiertas; importa y migra versiones 1 y 2 sin perder estudio. La primera escritura de datos antiguos guarda una copia local bajo la clave adicional `:before-v3`. Exporta también una copia externa. Se conserva la clave local v1 para leer los datos anteriores. Una evaluación declarada exige supervisor, evaluador, fecha, criterio y evidencia; no verifica credenciales ni certifica competencias. Es un cuaderno personal, no un registro inviolable de certificaciones.

## Estructura

- `data/curriculum.json`: currículo v2 ampliable, con las 376 entradas históricas conservadas; original exacto en `data/archive/curriculum.v1.json`.
- `src/content/lecciones/*.md`: texto y metadatos JSON en frontmatter YAML compatible.
- `src/content.config.ts`, `src/lib/schemas.ts`: colección y validación.
- `src/data/`: fuentes y glosario.
- `src/pages/`: páginas estáticas y índices JSON generados.
- `src/layouts/`, `src/components/`, `src/styles/`: interfaz.
- `src/lib/learning.ts`: búsqueda, corrección y estado teórico.
- `src/lib/state.ts`: persistencia y respaldo.
- `src/lib/client.ts`: interacciones accesibles de navegador.
- `scripts/`, `tests/`: validación y pruebas.
- `docs/`: decisiones, verificación y plantilla de publicación inactiva.

## Rutas base y GitHub Pages

Se recomienda un **repositorio independiente** llamado, por ejemplo, `academia-andina`, con el contenido de esta carpeta en su raíz. No copiar el workflow al repositorio del manual: desplegar solo `academia/dist` sobre el sitio del manual lo reemplazaría.

Comprobar localmente una base de proyecto (bash):

```bash
BASE_PATH=/academia-andina/ npm run build
BASE_PATH=/academia-andina/ npm run test:build
BASE_PATH=/academia-andina/ npm run preview
```

Abrir la ruta `/academia-andina/` del servidor de preview. Usar la misma base al compilar y servir. `BASE_PATH` debe comenzar y terminar con `/`. En PowerShell: `$env:BASE_PATH='/academia-andina/'`, ejecutar los comandos npm y luego `Remove-Item Env:BASE_PATH`. Para dominio propio o raíz, usar `/`.

`SITE_URL` configura el origen (predeterminado: `https://fjcastillos98.github.io`), **no** implica que exista publicación. Enlaces, búsqueda, índices JSON y favicon utilizan la base. Assets de Astro se prefijan automáticamente.

`docs/github-pages.yml.example` es una plantilla **inactiva** para un futuro repositorio separado. Solo tras autorización: copiarla a `.github/workflows/pages.yml` en ese nuevo repositorio, configurar Pages con GitHub Actions y ejecutarla manualmente. No contiene secretos. Revisa las versiones de acciones al activarla. Este trabajo no cambió el remoto ni activó ningún workflow.

## Contenidos y límites

Consultar `CONTRIBUTING.md`. Fuentes: SLF/KAT, OMM, USGS, NPS, NWS, Leave No Trace, UIAA, Petzl y Garmin; DMC como portal oficial de consulta, sin pronóstico local validado. Consulta documental: 21–22-10-2026. El modelo de evidencias es un criterio editorial propio. Los diez temas del piloto requieren revisión de instructor; nudos y anclajes preparan talleres supervisados, sin secuencias operativas para aplicar sin formación.

El diario guarda declaraciones personales de práctica y evaluación, con evidencia textual y una matriz de diez habilidades. No hay verificación de instructor, matriz profesional completa, calendario, plan deportivo adaptativo, contenido médico ni normativa vigente. Todo eso pertenece a etapas posteriores. Ningún cuestionario certifica una maniobra. La licencia de distribución del conjunto sigue pendiente; no se ha añadido LICENSE.

## Etapa 3: secuencia y diario

Abrir `/fundamentales/`: A riesgo → B 3×3 → C planificación → D meteorología → E nubes → F navegación → G equipo → H nudos → I cuerdas/anclajes → J comunicaciones. Los prerrequisitos orientan la secuencia, sin bloquear el acceso ni acreditar preparación práctica. `pilot.position`, `requires`, `critical`, `classifications`, `relatedModules` y `criteria` mantienen la estructura. El mapa original no se renumera.

`/practicas/` permite registrar y editar prácticas, consultar criterios y ver la matriz. Un quiz nunca actualiza una competencia. Solo las evaluaciones declaradas con todos los campos completados afectan esa columna; prevalece la evaluación más reciente y, si el mismo día hay resultados contradictorios, se muestra «En desarrollo». No hay caducidad automática ni acreditación externa. La evidencia es texto, no adjuntos.

Ver `docs/verificacion-etapa3.md` para resultados reales, `docs/etapa3.md` para alcance y pendientes, y `docs/archivos-etapa3.md` para archivos.


## Ampliación de Etapa 4

- `/programa/`: rutas, unidades, habilidades y dependencias futuras.
- `/casos/`: cinco simulaciones de Calbuco, Osorno, Casablanca, Yates y cordillera de Los Lagos.
- `/planificacion/`: plantilla antes/durante/después, imprimible, sin persistencia automática ni ficha médica.
- `/equipo/`: inventario, vida útil declarada, manual, retiro e inspecciones acumulativas.
- `/practicas/`: 21 habilidades, objetivo/resultado/autonomía y vínculos con el inventario.
- `data/skills.json`, `data/learning-paths.json`: habilidades y rutas independientes del piloto.
- `src/data/assessments/`: preguntas versionadas. Nunca sobrescribir una versión usada: crear otra y conservar la anterior. Los intentos se corrigen con su versión histórica.
- `src/lib/program.ts`: integridad de referencias cruzadas; `src/lib/migrations/curriculum.ts`: migración pura v1→v2.
- `tests/etapa4.test.ts`: ampliación, migraciones, estados, equipo y referencias.
- `docs/etapa4/INFORME.md`: resultados, límites y etapa siguiente; `ARCHIVOS.md`: cambios respecto de la entrega anterior.

Los cinco estados se calculan sobre evidencia declarada. «COMPETENTE VALIDADO» exige una evaluación presencial declarada y contextualizada: no verifica identidad ni credenciales, no certifica ni habilita para guiar. Un quiz solo indica comprensión teórica. Los estados de contenido (pendiente, piloto, en desarrollo) son independientes.

Las respuestas abiertas se guardan manualmente y requieren revisión humana. El inventario no calcula caducidad ni declara material apto. No hay adjuntos de evidencia, firma de instructor ni registro inmutable. La edición de una práctica conserva su ID pero actualiza sus campos; exporta respaldos si necesitas conservar cada revisión. La importación reemplaza los datos tras mostrar un resumen: no fusiona copias.

Validación de esta entrega: `npm ci`, `npm run check`, `npm test`, build y comprobación de rutas en `/` y `/academia-andina/`. Los registros reales están en `docs/etapa4/*.log`. Las instrucciones y resultados de etapas anteriores se conservan como historia, no describen los totales actuales.
