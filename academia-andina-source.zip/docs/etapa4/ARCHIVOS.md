# Archivos de Etapa 4

Comparación contra la entrega ZIP de Etapa 3. No incluye dependencias, build ni paquetes ZIP.

## Creados

- `CONTRIBUTING.md`
- `data/archive/curriculum.v1.json`
- `data/learning-paths.json`
- `data/skills.json`
- `docs/etapa4/INFORME.md`
- `docs/etapa4/README-etapa3.md`
- `docs/etapa4/academia-etapa4-desktop.jpg`
- `docs/etapa4/build-local.log`
- `docs/etapa4/build-pages.log`
- `docs/etapa4/check.log`
- `docs/etapa4/npm-ci.log`
- `docs/etapa4/nuevas-unidades.json`
- `docs/etapa4/preservacion.txt`
- `docs/etapa4/routes-local.log`
- `docs/etapa4/routes-pages.log`
- `docs/etapa4/tests.log`
- `src/content/lecciones/atmosfera-montana.md`
- `src/content/lecciones/carta-brujula.md`
- `src/content/lecciones/estival-terreno.md`
- `src/content/lecciones/gps-contingencias.md`
- `src/content/lecciones/grupo-liderazgo.md`
- `src/content/lecciones/incidentes-retirada.md`
- `src/content/lecciones/nubes-observacion.md`
- `src/content/lecciones/plan-operacion.md`
- `src/content/lecciones/preparacion-andinismo.md`
- `src/content/lecciones/pronostico-decision.md`
- `src/content/lecciones/riesgo-decisiones.md`
- `src/data/assessments/aprender-con-evidencia.v1.json`
- `src/data/assessments/atmosfera-montana.v1.json`
- `src/data/assessments/carta-brujula.v1.json`
- `src/data/assessments/cartografia-orientacion.v1.json`
- `src/data/assessments/comunicaciones-emergencia.v1.json`
- `src/data/assessments/cuerdas-anclajes.v1.json`
- `src/data/assessments/equipamiento.v1.json`
- `src/data/assessments/estival-terreno.v1.json`
- `src/data/assessments/gestion-del-riesgo.v1.json`
- `src/data/assessments/gps-contingencias.v1.json`
- `src/data/assessments/grupo-liderazgo.v1.json`
- `src/data/assessments/incidentes-retirada.v1.json`
- `src/data/assessments/leer-curvas-de-nivel.v1.json`
- `src/data/assessments/meteorologia-montana.v1.json`
- `src/data/assessments/nubes-observacion.v1.json`
- `src/data/assessments/nubes-reconocimiento.v1.json`
- `src/data/assessments/nudos-fundamentales.v1.json`
- `src/data/assessments/plan-operacion.v1.json`
- `src/data/assessments/planificacion-salida.v1.json`
- `src/data/assessments/planificar-con-impacto.v1.json`
- `src/data/assessments/preparacion-andinismo.v1.json`
- `src/data/assessments/pronostico-decision.v1.json`
- `src/data/assessments/riesgo-decisiones.v1.json`
- `src/data/assessments/sistema-3x3.v1.json`
- `src/data/cases.json`
- `src/lib/assessments.ts`
- `src/lib/competencies.ts`
- `src/lib/equipment-client.ts`
- `src/lib/equipment.ts`
- `src/lib/migrations/curriculum.ts`
- `src/lib/program.ts`
- `src/pages/casos/[id].astro`
- `src/pages/casos/index.astro`
- `src/pages/equipo.astro`
- `src/pages/planificacion.astro`
- `src/pages/program-data.json.ts`
- `src/pages/programa.astro`
- `tests/etapa4.test.ts`
- `docs/etapa4/ARCHIVOS.md`

## Modificados

- `README.md`
- `data/curriculum.json`
- `package-lock.json`
- `package.json`
- `scripts/validate.ts`
- `src/components/LessonCard.astro`
- `src/data/sources.json`
- `src/layouts/Layout.astro`
- `src/lib/client.ts`
- `src/lib/practice-client.ts`
- `src/lib/schemas.ts`
- `src/lib/state.ts`
- `src/pages/fuentes.astro`
- `src/pages/index.astro`
- `src/pages/lecciones/[id].astro`
- `src/pages/practicas.astro`
- `src/pages/search-index.json.ts`
- `src/styles/global.css`
- `tests/pilot.test.ts`

Las 13 lecturas originales y los archivos rastreados del manual no se modificaron.
