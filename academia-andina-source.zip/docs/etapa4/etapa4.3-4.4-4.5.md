# Etapas 4.3, 4.4 y 4.5 — entrega de desarrollo

Fecha: 22 de octubre de 2026. Se continúa sobre la arquitectura Astro/TypeScript/Markdown/Zod existente. No se hizo push, deploy ni modificación del manual original. Este bloque es material académico en desarrollo, no una academia terminada ni una acreditación profesional.

## Cantidades verificadas

| Elemento | Nuevo | Total actual |
|---|---:|---:|
| Módulos históricos | 0 | 24 |
| Rutas / bloques pedagógicos | 3 | 5 |
| Unidades | 22 | 33 |
| Lecciones | 31 | 55 |
| Habilidades con ID estable | 31 | 52 |
| Cuestionarios versionados | 31 | 55 |
| Preguntas nuevas de quiz | 62 | — |
| Respuestas abiertas nuevas con rúbrica | 31 | — |
| Preparaciones para práctica | 31 | — |
| Problemas numéricos interactivos | 6 | 6 |
| Casos | 10 | 15 |
| Fuentes registradas | 41 | 76 |
| Diagramas SVG educativos | 17 | 17 |
| Fichas de montaña | 7 | 7 |
| Fichas de especie | 5 | 5 |

Los tres bloques solicitados se integran como rutas y unidades vinculadas a los módulos existentes; no se duplicaron ni renumeraron los módulos. Las 376 entradas originales permanecen pendientes. Las preguntas, las rúbricas y los problemas se cuentan por separado para no confundir instrumentos con competencias.

## Contenido incorporado

Cuerda: física y materiales, nomenclatura, diez nudos en lecciones independientes, revisión, encordamiento por contexto, aseguramiento, anclajes y reuniones, análisis de fallos y descenso. Cada nudo desarrolla función, usos y exclusiones, ventajas, límites, características, errores, inspección, compatibilidad, montaña, guiado, práctica presencial y fuente.

Rescate conceptual: ventaja ideal/real, conservación del trabajo, seis cálculos, poleas y captura de progreso, Micro Traxion como ejemplo documentado, arquitectura de izado, prioridades, escenarios de autorrescate y pasajeros. Los diagramas son modelos de fuerzas y funciones: no son planos de montaje ni secuencias operativas para suspender personas.

Territorio: nombres y clasificación, vulcanología, lectura geológica, glaciología introductoria, ecología, historia documental y patrimonio. Fichas: Calbuco, Osorno, Casablanca, Yates/Yate, Tronador, Sarnoso y Puntiagudo. Especies: alerce, monito del monte, carpintero negro, lagartija manchada y ranita de Darwin. Diez casos integradores cruzan planificación, riesgo, navegación, meteorología, grupo, comunicación, territorio y decisiones. Los casos son ficticios y no describen rutas verificadas.

## Sistema de aprendizaje y datos

Las habilidades nuevas incluyen descripción, nivel, prerrequisitos, lecciones, práctica, supervisión, evidencia, evaluación y estado. Se validan referencias y ciclos. La matriz separa estudio, práctica, supervisión, evaluación y competencia declarada; no verifica identidad del instructor ni emite certificación.

El diario añade ejercicios, observaciones y próxima práctica. Los campos anteriores y sus identificadores se conservan. El inventario muestra fechas de uso a partir de prácticas vinculadas: no se duplican fechas en dos registros. La copia v3 admite los campos nuevos con valores vacíos al importar una copia anterior. Se mantienen las migraciones v1/v2 y el archivo histórico de evaluaciones.

## Pruebas ejecutadas y resultados reales

| Prueba | Resultado |
|---|---|
| `npm ci` | Correcto; 274 paquetes instalados |
| `npm run check` | 51 archivos; 0 errores, 0 advertencias, 0 hints |
| `npm test` | 46/46 pasan; 0 fallos, 0 omitidas |
| `npm run build` | Correcto en raíz |
| `npm run test:build` | 121 páginas, 3057 enlaces/recursos internos, 490 resultados; correcto |
| `BASE_PATH=/academia-andina/ npm run build` | Correcto |
| `BASE_PATH=/academia-andina/ npm run test:build` | Mismos recuentos; correcto con subruta |
| Preservación histórica | SHA-256 de 24 lecturas, 24 evaluaciones y currículo v1 sin cambios; IDs y objetos previos conservados |
| Currículo/habilidades/dependencias | Duplicados, ausencias y ciclos detectados en pruebas negativas |
| JSON/migración/prácticas/equipo | Roundtrip, referencias inválidas, campos nuevos, cuota, versiones y evaluación declarada cubiertos |
| Fuentes/evaluaciones/diagramas | Referencias rotas, explicaciones incompletas y diagramas ausentes rechazados |
| Navegador: cálculo | Seis resultados correctos, incluida coma decimal |
| Navegador: quiz | 2/2, explicación de cada alternativa e intento guardado |
| Navegador: persistencia | Respuesta abierta y tres campos nuevos del diario recuperados tras recarga |
| Navegador: JSON | Descarga y reimportación real, resumen, confirmación y éxito; JSON inválido rechazado |
| Navegador: inventario | Estado vacío, creación de equipo ficticio, vínculo a práctica y fecha de uso visible |
| Navegador: búsqueda | Sarnoso devuelve lección, ficha, asignatura y entrada pendiente; navegación a ficha correcta |
| Navegador: fuentes | Fuentes y limitaciones visibles en lección mecánica y ficha Sarnoso |
| Escritorio | Catálogo territorial revisado visualmente |
| 390 px | Iframe de 390 px; ancho útil 375 px por scrollbar, scrollWidth 375; sin desborde global en lección mecánica |
| Teclado | Activación del salto al contenido lleva hash y foco a `contenido`; Tab sobre enlaces de diagrama |

Registros: `etapa435/npm-ci.log`, `check.log`, `tests.log`, `build.log`, `build-pages.log`, `routes-root.log`, `routes-pages.log`. Capturas: `etapa435/desktop.jpg` y `mobile.jpg`. La revisión móvil es una simulación por iframe, no una prueba en dispositivo físico. No se afirma auditoría WCAG completa ni cobertura visual de cada una de las 121 páginas. Los mensajes de extensión del navegador observados no provenían de la aplicación.

Durante QA un formulario incompleto no se guardó hasta completar «Correcciones y próximos pasos», campo obligatorio; después persistió correctamente. La primera puesta en marcha del preview coincidió con la reinstalación de dependencias; se reinició una vez terminada y funcionó. Se corrigió un import sin uso y la presentación de prerrequisitos para mostrar títulos en vez de IDs. Los objetivos técnicos se reformularon como resultados de aprendizaje observables.

## Revisión de instructor necesaria

Toda selección, confección e inspección de nudos con función de seguridad; conexión al arnés; aseguramiento; elección de anclajes; diseño/revisión de reuniones; rápel, descenso de pasajeros, liberación bajo carga, uso de bloqueadores, izado, transferencia de carga y autorrescate. Se requiere práctica presencial, instructor competente, entorno controlado y evaluación contextualizada. Resolver el laboratorio o el quiz no autoriza estas maniobras. No se desarrolló rescate en grietas como competencia práctica.

## Incertidumbres y posibles errores académicos detectados

- «Ocho doble» no tiene un significado universal: se distingue de ocho por seno y se explicita la necesidad de reconocer la variante de la fuente.
- Los nombres Machard, autobloqueante y fuga/liberación requieren identificar configuración y escuela; no se tratan como equivalentes automáticos.
- No se inventan longitudes de chicotes, diámetros compatibles, límites de carga, ángulos admisibles o vida útil universales.
- Ventaja mecánica ideal no es eficiencia real ni resistencia del montaje. Los números son ejemplos didácticos, no capacidades de productos.
- Calbuco: catálogo GVP consultado 1974 m frente a referencias históricas 2003 m. Osorno: 2659 m frente a leyenda histórica 2652 m. Se atribuyen las cifras y se deja su reconciliación cartográfica pendiente.
- El Complejo Sarnoso tiene respaldo geológico; su correspondencia exacta con la cumbre popular «Cerro Sarnoso», cota y acceso requieren cartografía. No se etiqueta todo el conjunto como extinto.
- Casablanca, Antillanca y sus unidades no son objetos geográficos idénticos. Tronador, complejo y grupo tampoco.
- Los registros de conservación de especies no se presentan como certificación de normativa vigente. No se garantizan avistamientos.

## Pendiente de verificación territorial y ampliación

Comunas/provincias de cumbres y límites oficiales, cotas faltantes, rutas, dificultad, accesos, permisos, estado de caminos, condiciones estacionales, glaciares actuales, primeras ascensiones y áreas protegidas donde no hubo evidencia suficiente. El portal de alertas SERNAGEOMIN no pudo verificarse de forma suficiente: se conserva como consulta pendiente, sin afirmar alertas actuales. Antes de planificar hay que consultar fuentes oficiales vigentes y administración territorial competente.

Historia es una introducción al trabajo documental, no una historia exhaustiva: primeras ascensiones, cronologías de clubes y expediciones regionales necesitan archivos adicionales. Ecología tiene cinco fichas iniciales: ampliar flora de altura, distribución local documentada e invasoras con fuentes específicas. No se rellenan estos vacíos con supuestos. Falta revisión pedagógica independiente de todos los contenidos y validación de diagramas por instructor. Las ilustraciones de nudos muestran familias/criterios; las secuencias exactas deben contrastarse con las láminas técnicas del fabricante y el taller.

## Prerrequisitos y propuesta para Etapa 5

1. Revisión de este bloque por instructor: nomenclatura, imágenes, rúbricas y compatibilidades de modelos concretos. Registrar observaciones y crear nuevas versiones de evaluación si cambian preguntas.
2. Talleres presenciales de nudos, control cruzado, encordamiento, aseguramiento y reuniones; documentar contextos, errores y evaluación. No avanzar por aprobar quizzes.
3. Verificación cartográfica de las siete fichas y dossier oficial de accesos/administración, separado de la teoría estable. Ampliar historia e invasoras antes de presentar cobertura territorial completa.
4. Piloto de montaña invernal: nieve y decisiones de no entrada, uso de boletines, reconocimiento del terreno y preparación de prácticas con instructor. Después, formación presencial específica antes de progresión glaciar y rescate en grietas.

## Ejecución local

Desde la carpeta `academia`, Node 24 o posterior:

```bash
npm ci
npm run dev
```

Abrir la dirección que muestra Astro (normalmente `http://localhost:4321/`). No se desplegó la aplicación. Para verificar producción: `npm run check`, `npm test`, `npm run build`, `npm run test:build`.

## Lecciones nuevas

- `analisis-reunion.md` — Análisis de una reunión y fallos comunes
- `anclajes-reuniones.md` — Anclajes y reuniones: diseñar para un escenario
- `aseguramiento-fundamentos.md` — Aseguramiento, dispositivos y descenso controlado
- `autorrescate-escenarios.md` — Autorrescate en cuerda: siete escenarios de análisis
- `autorrescate-prioridades.md` — Autorrescate: prioridades y límites de actuación
- `ballestrinque.md` — Ballestrinque
- `ecologia-los-lagos.md` — Flora, fauna y ecosistemas: interpretar sin perturbar
- `encordamiento-contexto.md` — Encordamiento según actividad y grupo
- `fisica-cuerda.md` — Física, materiales e inspección de cuerda
- `fuga-liberacion.md` — Fuga/liberación
- `geologia-lectura-terreno.md` — Geología de montaña: leer materiales y procesos
- `glaciologia-intro.md` — Glaciología introductoria: hielo que cambia
- `historia-montanismo-documentos.md` — Historia de montaña: documentos, personas y versiones
- `izado-conceptual.md` — Sistemas de izado: arquitectura y control
- `machard.md` — Machard
- `nudo-dinamico.md` — Nudo dinámico
- `ocho-doble-gaza.md` — Ocho doble
- `ocho-reconstituido.md` — Ocho reconstituido
- `ocho-seno.md` — Ocho por seno
- `ocho-simple.md` — Ocho simple
- `patrimonio-etica-territorial.md` — Patrimonio y cultura: interpretar con responsabilidad
- `pescador-doble.md` — Pescador doble
- `poleas-bloqueadores.md` — Poleas, captura de progreso y Micro Traxion
- `prusik.md` — Prusik
- `rapel-descenso.md` — Rápel y descenso de un pasajero: funciones y límites
- `rescate-pasajeros.md` — Rescate con pasajeros y coordinación de apoyo
- `revision-nudos.md` — Revisión de nudos: observar, describir y detener
- `terminologia-cuerda.md` — Terminología y lectura visual de un sistema
- `territorio-nombres.md` — Montañas de Los Lagos: nombre, estructura y evidencia
- `ventaja-mecanica.md` — Ventaja mecánica: modelos, fuerzas y trabajo
- `vulcanologia-territorial.md` — Vulcanología: procesos, señales y decisiones territoriales

## Fuentes nuevas registradas

Las URLs, fecha de consulta, alcance y limitaciones también aparecen en la biblioteca de la aplicación. Algunas fuentes respaldan conceptos, no procedimientos completos.

- **Petzl** — [Knots](https://www.petzl.com/us/en/sport/tech-tips/basic-techniques/knots/Noeuds_SPO_a77w0000000GnbmAAC.html). Estado: verified. Variantes y funciones del ejemplo; no valida una maniobra local ni la aplicación del ocho simple como tope.
- **Petzl** — [Friction hitches](https://www.petzl.com/int/en/sport/tech-tips/basic-techniques/friction-hitches/Noeuds-autobloquants_SPO_a77w0000000GnbrAAC.html). Estado: verified. Configuraciones de la fuente; equivalencias locales de Machard requieren instructor.
- **CMC** — [Learn Your Knots: Double Fisherman’s Bend](https://www.cmcpro.com/double-fishermans-bend/). Estado: verified. Unión y anillo en su ejemplo; no universaliza extremos, materiales o aplicaciones.
- **Petzl** — [Munter Hitch With Mule Knot and Stopper Knot](https://www.petzl.com/fi/en/sport/tech-tips/basic-techniques/video-%E2%80%93-munter-hitch-with-mule-knot-and-stopper-knot/Video---Demi-cabestan-avec-un-noeud-de-mule-et-noe_SPO_a77bK000007VEnRQAW.html). Estado: verified. Bloqueo dentro de un sistema; no se ofrece secuencia de liberación autónoma.
- **Petzl** — [PARTNER CHECK](https://www.petzl.com/us/en/sport/tech-tips/basic-techniques/partner-check/PARTNER-CHECK_SPO_a77w0000000PBmDAAW.html). Estado: verified. Revisión en escalada; no checklist exhaustiva para rescate o glaciar.
- **Petzl** — [Fall factor and impact force — theory](https://www.petzl.com/gb/en/operators/tech-tips-by-product/basic-techniques/fall-factor-and-impact-force---theory/CORDES-chute-theorie_OPE_a77w0000000KywUAAS.html). Estado: verified. Modelo conceptual; no predice por sí solo fuerza real o aptitud.
- **Petzl** — [Building a belay anchor and belaying on a bolted multi-pitch route](https://www.petzl.com/int/en/sport/tech-tips/basic-techniques/building-a-belay-anchor-and-belaying-on-a-bolted-multi-pitch-route/Relais-grande-voie_SPO_a77Tx000000E3MEIA0.html). Estado: verified. Alcance explícito: vías equipadas; no extrapolar a puntos naturales, nieve o hielo.
- **Petzl** — [How to calculate mechanical advantage](https://www.petzl.com/us/en/operators/tech-tips-by-product/basic-techniques/how-to-calculate-mechanical-advantage/MAESTRO-Pe06-RapportsMouflage_OPE_a771r000000Co9vAAC.html). Estado: verified. Modelos ideales; cifras de ejercicios son originales y no capacidades reales de rescate.
- **Black Diamond** — [ATC Guide / ATC Alpine Guide — instrucciones M10798_D](https://s3.us-west-2.amazonaws.com/catsy.865/M10798_D_ATC-Guide_IS-WEB.pdf). Estado: verified. Identificar modelo exacto y revisión; no generalizar rangos de diámetro ni funciones.
- **Petzl** — [MICRO TRAXION — ficha de producto](https://www.petzl.com/US/EN/Sport/Pulleys/MICRO-TRAXION). Estado: verified. Ficha verificada; obtener instrucciones exactas del ejemplar antes de uso. No se importan rangos de otras revisiones.
- **ICAR, Comisión de Rescate Terrestre** — [Rope Differentiation — Recommendation No. 7](https://www.alpine-rescue.org/articles/230--rope-differentiation-static-low-stretch-dynamic-ropes-tercom-recommendation-nr-7). Estado: verified. Identificación entre categorías; no prescribe elección universal de cuerda.
- **DMM** — [Slings and Rope Inspection](https://us.dmmwales.com/blogs/knowledge/slings-and-rope-inspection). Estado: verified. Revisión y consulta del fabricante; no se generaliza vida útil de un producto.
- **OpenStax, Rice University** — [College Physics 2e — 9.5 Simple Machines](https://openstax.org/books/college-physics-2e/pages/9-5-simple-machines). Estado: verified. Física de máquinas ideales; no dimensiona sistemas de montaña.
- **Petzl** — [Release and rescue of a co-worker suspended on a long rope](https://www.petzl.com/us/en/operators/tech-tips-by-product/rescue/release-and-rescue-of-a-co-worker-suspended-on-a-long-rope/ID-pe13c-decrochage-evacuation-kit-secours-dynamiq_OPE_a77w0000000PBnVAAW.html). Estado: verified. Contexto profesional y configuración específica; se usa para analizar límites, no para instruir transferencia en Calbuco.
- **Petzl** — [Professional Catalog 2026 — General Rescue Principles](https://catalogs.petzl.com/Petzl-pro-catalog-2026/en/22-General-Rescue-Principles.html). Estado: verified. Marco de rescate profesional; no protocolo médico ni técnica universal de montaña.
- **Smithsonian Institution, Global Volcanism Program** — [Calbuco — perfil 358020](https://volcano.si.edu/volcano.cfm?vn=358020). Estado: verified. Ficha geológica y datos atribuidos; los reportes de 2015 no representan una alerta vigente. La tabla actual indica 1.974 m, discrepante con referencias históricas de 2.003 m.
- **Smithsonian Institution, Global Volcanism Program** — [Osorno — perfil 358010](https://volcano.si.edu/volcano.cfm?vn=358010). Estado: verified. La tabla consultada indica 2.659 m, mientras una fotografía del mismo catálogo menciona 2.652 m. No resuelve accesos ni autorización de ascenso.
- **Smithsonian Institution, Global Volcanism Program** — [Puntiagudo-Cordón Cenizos — perfil 357160](https://volcano.si.edu/volcano.cfm?vn=357160). Estado: verified. El registro corresponde al conjunto Puntiagudo-Cordón Cenizos; no trasladar la erupción atribuida al cordón a la aguja sin distinguir centros.
- **Smithsonian Institution, Global Volcanism Program** — [Volcano Photo Collection — Image GVP-04926](https://volcano.si.edu/gallery/ShowImage.cfm?photo=GVP-04926). Estado: verified. Leyenda científica de una fotografía: respalda ubicación relativa y descripción geológica, no altitud, actividad actual ni ruta.
- **Carlos Antonio Carrasco Lira, Universidad de Chile** — [Petrología y geoquímica del volcán Casablanca y centros eruptivos cercanos, Complejo volcánico Antillanca (2016)](https://repositorio.uchile.cl/handle/2250/140293). Estado: verified. Resumen y metadatos de tesis leídos; no se revisó el PDF íntegro. No extrapolar composición estudiada a toda roca del sendero.
- **Luis Lara, Carolina Rodríguez, Hugo Moreno y Carlos Pérez de Arce; Revista Geológica de Chile** — [Geocronología K-Ar y geoquímica del volcanismo plioceno superior-pleistoceno de los Andes del sur (39–42°S), 2001](https://www.scielo.cl/scielo.php?pid=S0716-02082001000100004&script=sci_arttext). Estado: verified. Descripción del Complejo Sarnoso y otros centros erosionados. No identifica una cumbre turística, altitud o itinerario; no sustenta llamar extinto a todo el conjunto.
- **Mella y colaboradores; Revista Geológica de Chile** — [Petrogénesis del Grupo Volcánico Pleistoceno Tronador, 2005](https://www.scielo.cl/scielo.php?pid=S0716-02082005000100008&script=sci_arttext). Estado: verified. Artículo primario: distinguir Grupo Volcánico, Complejo y cumbre. Cita histórica de altitud 3.554 m no adoptada como cota operativa actual.
- **SERNAGEOMIN** — [Alertas volcánicas](https://www.sernageomin.cl/alertas-volcanicas/). Estado: pending. Portal oficial localizado mediante búsqueda; apertura devolvió 502. No se verificó ninguna alerta actual ni se reproduce un nivel.
- **USGS** — [Volcano Hazards Program Glossary](https://www.usgs.gov/glossary/volcano-hazards-program-glossary). Estado: verified. Vocabulario general; no es mapa de amenaza ni interpretación de un volcán particular.
- **National Park Service** — [Anatomy of a Volcano](https://www.nps.gov/subjects/volcanoes/anatomy-of-a-volcano.htm). Estado: verified. Modelo educativo; un volcán real no tiene necesariamente una cámara única ni geometría simétrica.
- **USGS** — [Glossary of Glacier Terminology (2004)](https://pubs.usgs.gov/of/2004/1216/text.html). Estado: verified. Definiciones, no instrucciones de progresión ni evaluación de resistencia de puentes.
- **Dirección General de Aguas, MOP** — [Inventario Público de Glaciares 2022](https://dga.mop.gob.cl/inventario-publico-glaciares/). Estado: verified. Inventario y geometrías de referencia; no informa la ubicación actual de grietas ni condiciones de transitabilidad.
- **National Park Service** — [Crevasses](https://www.nps.gov/articles/crevasses.htm). Estado: verified. Formación y ocultación de grietas; no certifica una ruta glaciar.
- **CONAF** — [Parque Nacional Puyehue](https://www.conaf.cl/parque_nacionales/parque-nacional-puyehue/). Estado: verified. Inventario descriptivo de ecosistemas/especies. No garantiza avistamientos; administración y accesos deben comprobarse en la institucionalidad actual.
- **CONAF** — [Monumento Natural Lahuen Ñadi](https://www.conaf.cl/parque_nacionales/monumento-natural-lahuen-nadi/). Estado: verified. Asociaciones vegetales y fauna descritas para este espacio; no extender registros a todas las montañas de la región.
- **Ministerio del Medio Ambiente, SIMBIO** — [Ficha Fitzroya cupressoides](https://simbio.mma.gob.cl/Especies/Details/6535). Estado: verified. Ficha consultada con texto histórico y campos inconsistentes de distribución administrativa; usar rasgos y distribución Chile/Argentina, no frase antigua de exclusividad regional.
- **Ministerio del Medio Ambiente, SIMBIO** — [Ficha Dromiciops gliroides](https://simbio.mma.gob.cl/Especies/Details/4508). Estado: verified. Rasgos e historia natural. Taxonomía histórica y frases como fósil viviente no se reproducen como diagnóstico moderno.
- **Ministerio del Medio Ambiente, SIMBIO** — [Ficha Campephilus magellanicus](https://simbio.mma.gob.cl/Especies/Details/4717). Estado: verified. Identificación y hábitat. Campo de decreto/categoría presenta inconsistencia interna; no se afirma norma vigente ni categoría legal definitiva.
- **Ministerio del Medio Ambiente, SIMBIO** — [Ficha Liolaemus pictus](https://simbio.mma.gob.cl/Especies/VistaImpresion/19012). Estado: verified. Identificación introductoria y hábitat; la propia ficha advierte revisión taxonómica de subespecies. No identificar por color solamente.
- **Ministerio del Medio Ambiente, SIMBIO** — [Ficha Rhinoderma darwinii](https://simbio.mma.gob.cl/Especies/VistaImpresion/12276). Estado: verified. Ficha con numerosos campos vacíos; la categoría EN está indicada, pero la distribución local necesita otra fuente.
- **Servicio de Biodiversidad y Áreas Protegidas** — [Plan RECOGE para las ranitas de Darwin ya es realidad: Contraloría toma razón del instrumento](https://sbap.gob.cl/sala-de-prensa/noticias-y-comunicados/detalle/2026/03/20/plan-recoge-para-las-ranitas-de-darwin-ya-es-realidad--contralor%C3%ADa-toma-raz%C3%B3n-del-instrumento). Estado: verified. Noticia institucional sobre el plan; no constituye autorización de manejo de fauna.
- **Museo Histórico Nacional** — [El llamado de la montaña. Pioneros de los Andes centrales (1927–1942)](https://www.mhn.gob.cl/noticias/el-llamado-de-la-montana-pioneros-de-los-andes-centrales-1927-1942). Estado: verified. Extracto institucional indexado consultado; apertura directa devolvió 403. Solo se usa el hecho de exposición, rango documental y centenario DAV; primeras ascensiones pendientes.
- **CONAF** — [Parque Nacional Vicente Pérez Rosales conmemora 100 años como símbolo de la conservación en Chile](https://www.conaf.cl/parque-nacional-vicente-perez-rosales-conmemora-100-anos-como-simbolo-de-la-conservacion-en-chile/). Estado: verified. Historia institucional y transición de administración en 2026; no permite inferir automáticamente quién autoriza cada actividad al momento de viajar.
- **CONAF** — [Parque Nacional Puyehue: 85 años de vida, un legado en conservación y una gran vinculación](https://www.conaf.cl/parque-nacional-puyehue-85-anos-de-vida-un-legado-en-conservacion-y-una-gran-vinculacion/). Estado: verified. Fecha de creación y vínculo comunitario, no cronología completa de ocupación territorial.
- **Subdirección de Investigación, Servicio Nacional del Patrimonio Cultural** — [El censo indígena de 1907–1908: un episodio de expoliación burocrática en Futahuillimapu](https://www.investigacion.patrimoniocultural.gob.cl/publicaciones/el-censo-indigena-de-1907-1908-un-episodio-de-expoliacion-burocratica-en). Estado: verified. Estudio situado; no representa una única cosmovisión ni autoriza interpretar conocimientos ceremoniales.
- **Museo Regional de Ancud** — [Miércoles de cine: Huilliche](https://www.museodeancud.gob.cl/cartelera/miercoles-de-cine-huilliche). Estado: verified. Presentación de testimonios comunitarios. No atribuir un relato particular a todos los pueblos o comunidades.

Estados de las 76 fuentes: {None: 15, 'verified': 59, 'pending': 2}.

## Archivos

Lista detallada de archivos nuevos y modificados frente al ZIP anterior: [ARCHIVOS-435.md](ARCHIVOS-435.md). Se conservan los informes anteriores, README de 4.2 y snapshots del currículo, habilidades y rutas.
