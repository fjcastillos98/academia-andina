# Archivos · Etapa 14

Creados:
- src/data/mountains14.json: cuatro fichas parciales.
- src/data/mountain-evidence14.json: 64 estados de evidencia por campo.
- src/lib/mountains.ts: agregación de fichas históricas y nuevas.
- src/lib/territory14.ts: validación y tres casos teóricos con explicaciones.
- src/pages/territorio/comparar.astro: taller secuenciado y borrador persistente.
- tests/etapa14.test.ts: siete pruebas nuevas.
- docs/etapa14/: informe, fuentes, inventario, hashes históricos, logs y captura móvil.
- entrega/Academia_Andina_Etapa14.zip: entrega local del proyecto.

Modificados:
- src/data/sources.json: cuatro referencias añadidas; objetos anteriores intactos.
- src/pages/territorio/index.astro: once fichas y acceso al taller.
- src/pages/territorio/[id].astro: fichas nuevas y trazabilidad por campo.
- src/pages/search-index.json.ts: cuatro fichas y taller indexados.
- src/pages/buscar.astro: filtro Taller documental.
- src/pages/fuentes.astro: texto de fechas coherente con registros individuales.
- src/layouts/Layout.astro: versión visible.
- scripts/validate.ts: nuevos conjuntos y evidencias validados antes de compilar.
- package.json y package-lock.json: versión 0.14.0; dependencias sin cambios.
- README.md: alcance y resultados de etapa.

No se modifica el manual original, mountains.json histórico, currículo ni lecturas existentes. Los hashes previos se comprueban automáticamente. dist/ y .astro/ son resultados locales regenerados, no fuentes de autoría.
