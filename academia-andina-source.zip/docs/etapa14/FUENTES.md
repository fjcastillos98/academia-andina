# Fuentes y alcance · Etapa 14
Consulta: 27 de octubre de 2026. Fuente incorporada: Smithsonian Institution, Global Volcanism Program (GVP), catálogo institucional y síntesis de bibliografía geológica. No se presenta como lectura directa de todos los trabajos originales de su bibliografía.

| Perfil consultado | Afirmaciones incorporadas | Límites |
| --- | --- | --- |
| [Hornopirén](https://volcano.si.edu/volcano.cfm?vn=358023) | Coordenadas, 1.572 m atribuidos, estratovolcán; registro 340 d. C. ± 200 años calibrado; mención de 1835 sin detalles | Cota cartográfica oficial, rutas, accesos y alerta pendientes |
| [Michinmahuida](https://volcano.si.edu/volcano.cfm?vn=358040) | Coordenadas, 2.452 m atribuidos, caldera y cobertura glaciar descritas, episodio de 1835 | No se determina extensión actual del hielo |
| [Chaitén](https://volcano.si.edu/volcano.cfm?vn=358041) | Coordenadas, 1.122 m atribuidos, caldera y domos riolíticos; comienzo eruptivo de mayo de 2008 | No se deduce alerta vigente desde el historial |
| [Corcovado](https://volcano.si.edu/volcano.cfm?vn=358050) | Coordenadas, 1.826 m atribuidos, edificio erosionado y conos; reportes de 1834/1835 inciertos en tabla | No se adopta una cota operacional ni se resuelve la atribución histórica |

Las cuatro cotas se conservan con atribución al catálogo y solicitud de contraste IGM. No son cotas oficiales verificadas por esta academia. Las fichas no asignan comuna, límites protegidos, accesos, primeras ascensiones ni traducciones culturales sin evidencia específica.

Se intentó consultar documentación SERNAGEOMIN durante la investigación preliminar; los PDF no recuperados no se usaron para sustentar contenido. Tampoco se incorporaron como consultados sus trabajos bibliográficos indirectos. Las referencias GVP aparecen en cada ficha y en Fuentes y criterios; los enlaces «Lecturas» relacionan el registro con la lección territorial previa, cuyo contenido histórico permanece intacto.

Pendiente: contraste con cartografía oficial, inventarios DGA fechados, administración territorial, documentación académica original y revisión regional especializada. SERNAGEOMIN y SENAPRED se mencionan como organismos a consultar, sin reproducir un estado de alerta actual.
