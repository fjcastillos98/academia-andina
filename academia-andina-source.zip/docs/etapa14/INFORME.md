# Etapa 14 · ampliación documental territorial

27 de octubre de 2026. Versión 0.14.0. Trabajo local, sin push ni deploy. La academia continúa en desarrollo.

## Implementado

Cuatro fichas parciales: Hornopirén, Michinmahuida, Chaitén y Corcovado. Once fichas territoriales en total. Se añaden coordenadas y cotas atribuidas, clasificación geológica, antecedentes y límites de interpretación. Los datos no resueltos permanecen pendientes.

64 registros de evidencia, uno por campo territorial de las fichas nuevas. Zod y validación cruzada rechazan campos, fuentes o montañas desconocidas, duplicados, atribuciones sin fuente y registros incompletos antes del build. Los enlaces llevan a la referencia dentro de cada ficha.

Taller secuenciado: prerrequisito territorial → lectura comparada por parejas → tres preguntas teóricas con corrección explicada → expediente escrito → rúbrica humana y enlace al diario. El borrador persiste con el mecanismo existente y entra en el respaldo JSON v3. El taller no concede competencia, no crea prácticas ficticias ni aumenta el contador de quizzes de lección. No requiere migrar datos.

Se mantienen 165 lecturas, 376 entradas originales pendientes, currículo anterior y manual original. La aplicación conserva Astro/TypeScript y sus dependencias. No se añaden cientos de páginas: cinco páginas nuevas.

## Verificación real

| Comprobación | Resultado |
| --- | --- |
| npm test | 149/149; siete pruebas nuevas |
| npm run check | 104 archivos, 0 errores, 0 advertencias, 0 hints |
| npm run build | 261 páginas; éxito |
| npm run test:build | 9.536 enlaces/recursos internos y 645 resultados de búsqueda; éxito |
| BASE_PATH=/academia-andina/ build y test:build | mismos resultados; éxito |
| Navegación UI | inicio → territorio → taller → Corcovado |
| Búsqueda UI | «Hornopiren» sin tilde devuelve ficha y taller, además de contenido histórico y pendiente |
| Cuestionario UI | tres formularios; dos aciertos y un error con explicaciones observados |
| Persistencia UI | borrador ficticio guardado y conservado después de recargar |
| Respaldo JSON | ida/vuelta automatizada del borrador; flujo de descarga/importación de navegador no repetido |
| Responsive | iframe 390×844; área útil 375 px con barra, scrollWidth=clientWidth=375; inspección visual del taller |
| Fuentes UI | Corcovado muestra atribución por campo, referencia, fecha y límites |
| Integridad | hashes de lecturas, evaluaciones, diagramas, mountains.json y currículo previos comprobados; git diff de archivos rastreados vacío |

Logs en `logs/`. La prueba de enlaces comprueba destinos locales, no garantiza disponibilidad futura de fuentes externas. Vista móvil mediante marco estrecho, no prueba en teléfono físico. No se recorrieron manualmente las 261 páginas. No se reinstalaron dependencias: ya estaban instaladas y sus versiones no cambiaron. El último build queda en base `/`.

## Fuentes y revisión pendiente

Cuatro perfiles GVP, con consulta y atribución explícitas; detalle en FUENTES.md. Las cotas requieren contraste cartográfico IGM. Los límites administrativos, áreas protegidas, rutas, accesos, condiciones, primeras ascensiones y patrimonio local no se completan por inferencia.

Requiere revisión especializada regional: interpretación geológica y reconciliación de cotas; revisión pedagógica del taller. Todo reconocimiento en terreno y evaluación de capacidad de guiado requiere supervisión competente. Este bloque es preparación documental, no formación técnica suficiente para una salida.

## Próxima Etapa 15 propuesta

Resolver un expediente piloto completo de Calbuco y Osorno antes de extenderlo: cartografía y metadatos IGM, límites y administración verificables, documentación volcánica oficial con fecha y alcance, y registro de discrepancias. Crear una lista de solicitudes pendientes y una pauta de revisión regional. Mantener rutas operativas pendientes hasta disponer de evidencia pertinente y revisión de terreno; no crear una falsa validación de instructor.

## Ejecutar

Desde la carpeta academia (Node 24 o posterior):

```bash
npm ci
npm run dev
```

Verificar:

```bash
npm test
npm run check
npm run build
npm run test:build
```

Inventario de archivos: ARCHIVOS.md. Entrega ZIP excluye dependencias, compilaciones, versiones ZIP previas y datos transitorios.
