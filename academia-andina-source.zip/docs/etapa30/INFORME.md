# Etapa 30 · Revisión estática de uso y accesibilidad

30 de octubre de 2026 · Versión 0.30.0.

Se realizó la parte estática de la revisión prevista. La aceptación visual, móvil y de interacción real permanece pendiente por la restricción del navegador previamente observada. No se intentó eludir esa restricción ni se declara conformidad WCAG.

## Evidencia reproducible

`scripts/audit-accessibility.py` usa Python 3 y su biblioteca estándar sobre `dist`. Ejecutar después de compilar, con el mismo `BASE_PATH`; emite JSON por salida estándar. Revisa idioma, un h1 y un main por página, identificadores duplicados, presencia de alt, etiquetas detectables de controles y destinos de fragmentos internos. Es una inspección parcial, no un motor de accesibilidad; no analiza nombres accesibles completos, calidad de textos alternativos, contraste, disposición, foco o DOM creado por JavaScript. Informa hallazgos sin bloquear automáticamente el proceso.

En ambas bases se inspeccionaron 286 páginas, 1974 controles y 4180 enlaces con fragmento. Cero hallazgos en esas reglas. Los resultados completos están en audit-root.json y audit-base.json.

190 pruebas aprobadas. Astro: 142 archivos sin errores, advertencias o sugerencias. Comprobador habitual: 286 páginas, 12687 enlaces/recursos y 669 resultados de búsqueda, en `/` y `/academia-andina/`.

## Hallazgos de revisión de código para etapa 31

| ID | Evidencia | Efecto | Corrección y criterio de cierre |
| --- | --- | --- | --- |
| U30-01 | buscar.astro: select search-kind omite Ruta de estudio, presente en search-index.json | Las rutas aparecen en Todos, pero no pueden filtrarse por su tipo | Añadir opción y verificar correspondencia con tipos del índice |
| U30-02 | global.css: a 800 px o menos, lesson-aside nav tiene display:none | El índice de apartados y acceso rápido a rutas desaparecen en móvil | Conservar un índice accesible en móvil, revisar teclado y ausencia de desbordamiento cuando sea posible |
| U30-03 | client.ts: fallo inicial de los JSON llama unavailableProgress y retorna; esa función no actualiza notebook ni practice-history | Cuaderno e historial pueden conservar Cargando aunque ya hubo un error | Mostrar fallo explícito en las zonas afectadas, sin presentar registros vacíos ni alterar datos |

Estos hallazgos no se corrigieron en esta etapa, destinada a revisión. La etapa 31 concentra las correcciones y regresión. No se añadieron funcionalidades académicas, no cambió el respaldo ni se modificó el manual original. Sin publicación ni push.

## Recorridos inspeccionados y pendientes

| Recorrido | Evidencia estática o de lógica disponible | Pendiente en navegador |
| --- | --- | --- |
| Elegir objetivo → programa → lección → siguiente lectura | Destinos y fragmentos válidos; pruebas de secuencias compartidas | Foco, legibilidad, navegación táctil y teclado |
| Buscar → filtrar → abrir resultado | Índice y enlaces comprobados; pruebas de búsqueda | Escritura, cambio de filtro y anuncio de resultados |
| Lección → quiz → nota → cuaderno | Pruebas de corrección y estado; etiquetas inspeccionadas | Guardado real, recarga, fallos de almacenamiento y mensajes |
| Exportar → importar → cancelar/confirmar | Validación de respaldos probada; revisión del control de confirmación | Descarga, selección de archivo, cancelación y reemplazo real |
| Diario de prácticas | Etiquetas y región desplazable con tabindex y nombre; pruebas del modelo | Edición, foco, lectura de tabla y persistencia real |

## Cierre

Quedan las etapas 31 (correcciones) y 32 (entrega documentada) del plan de cierre. Si continúa bloqueado el navegador, la entrega conservará explícitamente su aceptación interactiva pendiente. El currículo académico completo es un alcance distinto.
