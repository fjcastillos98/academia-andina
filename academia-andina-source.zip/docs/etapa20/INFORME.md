# Etapa 20 · Fundamentos, planificación y riesgo

Fecha editorial: 28 de octubre de 2026.

Se amplió la matriz vigente de `/trazabilidad/` mediante comparación de texto interno. No se añadieron lecciones ni se verificaron nuevamente fuentes externas. Se preservaron el currículo original, las propuestas de Etapa 19 y el mecanismo de guardado del acta.

## Alcance y resultado

Se compararon las siete entradas M00, las diecinueve M13 y tres entradas M20 (planes de emergencia, gestión documental y planificación comercial). Se añadieron 28 correspondencias parciales con pasaje literal, alcance y vacío. Ética y responsabilidad profesional queda sin vínculo propuesto en el corpus consultado: las menciones a límites no desarrollan íntegramente ese tema.

Total de las 376 entradas históricas: 42 propuestas parciales, cuatro sin vínculo propuesto en el corpus comparado y 330 sin revisar. Las 42 entradas posteriores al mapa histórico siguen fuera de esta matriz. Estos conteos no equivalen a cobertura o competencias acreditadas.

El corpus adicional consta en la página y en `src/data/traceability20.json`. No se buscó exhaustivamente en todas las lecciones. Las comparaciones de planificación no certifican cumplimiento normativo ni autorizan una operación. El vínculo de casos regionales solo documenta el caso ficticio de Osorno; conserva como vacío la comparación de los otros lugares.

## Implementación

La página calcula los conteos desde los datos vigentes y enlaza las lecciones del corpus. La compilación rechaza pasajes inexistentes, entradas omitidas o duplicadas y estados incoherentes. La matriz anterior permanece disponible; su copia de referencia está en `data/archive/etapa19/traceability.json`. Las pruebas protegen las propuestas previas y delimitan qué entradas cambiaron.

## Verificación

- 172/172 pruebas aprobadas.
- Astro: cero errores, advertencias y sugerencias.
- Ambas rutas, `/` y `/academia-andina/`: 276 páginas, 11415 enlaces/recursos internos y 659 resultados de búsqueda comprobados.
- Sin nueva verificación visual, móvil ni de persistencia en navegador: continúa la restricción de acceso previamente observada. No se intentaron vías alternativas.

## Continuidad

La siguiente etapa propuesta es desarrollar el vacío de ética y responsabilidad profesional con fuentes y casos, distinguiendo criterios éticos, límites de competencia y obligaciones que requieran revisión jurídica. Las correspondencias siguen pendientes de revisión especialista.

Entrega local, sin publicación ni push. Manual original intacto. El ZIP contiene código, matrices, pruebas e informes; excluye dependencias, compilados y datos del navegador del usuario.
