# Matriz curricular · Etapa 20

42 correspondencias parciales propuestas; 4 entradas sin vínculo propuesto en corpus limitado; 330 sin revisar. No se mide cobertura ni competencia.

Corpus adicional comparado: aprender-con-evidencia, factores-humanos-invierno, gestion-del-riesgo, grupo-liderazgo, incidentes-retirada, matriz-riesgo-invernal, plan-operacion, riesgo-decisiones, sistema-3x3.

## M00.01 · Evaluación de conocimientos actuales.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: aprender-con-evidencia

> escribe lo que puedes explicar hoy y lo que necesitas volver a observar o practicar.

Alcance: Diagnóstico reflexivo de conocimientos y necesidades.

Vacío: Falta diagnóstico integral por objetivos, con instrumentos revisados.

## M00.02 · Fundamentos de montañismo.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: gestion-del-riesgo

> Un peligro es una fuente posible de daño

Alcance: Introducción a peligro, exposición y decisiones.

Vacío: Solo un componente de fundamentos; falta contrastar el resto del bloque.

## M00.03 · Terminología y sistemas.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: riesgo-decisiones

> Un **checklist** reduce omisiones de tareas conocidas

Alcance: Diferencia vocabulario de riesgo y herramientas de decisión.

Vacío: No cubre toda la terminología ni los sistemas técnicos del montañismo.

## M00.04 · Factores humanos.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: factores-humanos-invierno

> Los factores humanos incluyen cómo percibimos, seleccionamos y discutimos información.

Alcance: Introducción contextual a sesgos y comunicación.

Vacío: Falta comprobar transferencia a otros contextos y conducta observada.

## M00.05 · Ética y responsabilidad profesional.

sin-vinculo-propuesto. Etapa 20: sin vínculo propuesto en el corpus comparado. Las menciones a límites de actuación no desarrollan por sí solas ética y responsabilidad profesional; ampliar revisión.

## M00.06 · Cómo estudiar, practicar y registrar competencias.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: aprender-con-evidencia

> Tu respuesta debe separar los tres tipos de evidencia

Alcance: Distingue estudio, práctica y evaluación; propone registro de brechas.

Vacío: Falta revisar método de estudio completo y calidad de registros reales.

## M00.07 · Diferencia entre experiencia, formación y competencia demostrada.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: aprender-con-evidencia

> La experiencia previa orienta el diagnóstico, pero no completa automáticamente ninguna casilla.

Alcance: Diferencia experiencia, teoría y evidencia presencial.

Vacío: No verifica antecedentes ni acredita competencias individuales.

## M01.01 · Marco legal, incumbencias y registro SERNATUR.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M01.02 · Geografía, geología, glaciología y ecología andina.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M01.03 · Cartografía, orientación y navegación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M01.04 · Meteorología y lectura de pronósticos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M01.05 · Fisiología, nutrición y entrenamiento en montaña.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M01.06 · Pedagogía, técnicas de guiado y liderazgo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M01.07 · Gestión del riesgo y rescate organizado.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M01.08 · Telecomunicaciones y radiocomunicaciones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M01.09 · Planificación, operación turística y patrimonio.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M01.10 · Técnicas de marcha.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M01.11 · Nudos y fundamentos de cuerda.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M01.12 · Campamento.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M01.13 · Conducción 4x4 en contexto de montaña, con seguridad y límites legales.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M01.14 · Guiado en trekking y montaña estival.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M01.15 · Evaluación de clientes y briefing.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M01.16 · Gestión de horarios, puntos de decisión y retirada.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M02.01 · Nivología.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M02.02 · Avalanchas y rescate en alud.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M02.03 · Medicina de montaña y fisiología del frío.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M02.04 · Hipotermia y congelaciones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M02.05 · Equipamiento y técnicas de marcha en nieve.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M02.06 · Crampones y piolet.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M02.07 · Nudos, cuerdas y anclajes en terreno nevado.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M02.08 · Esquí de pista: fundamentos, seguridad y prerrequisitos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M02.09 · Progresión con raquetas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M02.10 · Planificación invernal.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M02.11 · Gestión del riesgo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M02.12 · Guiado en montaña invernal.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M02.13 · Limitaciones de cada técnica y condiciones de no salida.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M03.01 · Fisiología de altura y aclimatación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M03.02 · Mal agudo de montaña.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M03.03 · Edema pulmonar y cerebral de altura.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M03.04 · Medio ambiente y patrimonio altoandino.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M03.05 · Planificación de salidas y campamentos de altitud.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M03.06 · Gestión del riesgo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M03.07 · Rescate organizado y cuerdas en altitud.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M03.08 · Nutrición, hidratación, carga y recuperación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M03.09 · Guiado en montañismo de altitud.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M04.01 · Glaciología.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M04.02 · Formación, dinámica y clasificación de glaciares.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M04.03 · Conocimiento del terreno glaciar.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M04.04 · Grietas y puentes de nieve.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M04.05 · Técnicas de cramponaje.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M04.06 · Uso del piolet.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M04.07 · Configuraciones de cordada en terreno glaciar.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M04.08 · Gestión de cuerda y progresión.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M04.09 · Detección de peligros.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M04.10 · Anclajes en nieve/hielo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M04.11 · Autorrescate en grietas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M04.12 · Extracción y manejo posterior de la víctima.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M04.13 · Planificación, comunicación y gestión del grupo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M04.14 · Prerrequisitos y evaluación práctica.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M05.01 · Formación y características del hielo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M05.02 · Evaluación de condiciones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M05.03 · Equipamiento.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M05.04 · Técnicas de progresión.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M05.05 · Crampones y piolets técnicos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M05.06 · Aseguramiento.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M05.07 · Anclajes y reuniones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M05.08 · Protección y gestión de cuerda.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M05.09 · Descensos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M05.10 · Seguridad en escalada en hielo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M05.11 · Riesgos de caída de hielo, temperatura y exposición.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M05.12 · Evaluación práctica supervisada.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M05.13 · Prerrequisitos de técnica, condición física y experiencia.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M06.01 · Planificación de una salida a terreno alpino.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M06.02 · Evaluación de ruta, dificultad y retirada.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M06.03 · Anclajes en terreno alpino.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M06.04 · Encordamiento en terreno alpino.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M06.05 · Uso y manejo de la cuerda.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M06.06 · Aseguramiento y reuniones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M06.07 · Gestión de grupos en terreno alpino.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M06.08 · Progresión en terreno mixto.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M06.09 · Gestión de material.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M06.10 · Rápel y descensos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M06.11 · Autorrescate en glaciares de acumulación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M06.12 · Comunicación y factores humanos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M06.13 · Gestión del riesgo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M06.14 · Prácticas supervisadas y evaluación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.01 · Propiedades de cuerdas dinámicas y auxiliares.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.02 · Materiales, diámetros, elongación y compatibilidad.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.03 · Inspección, mantenimiento, limpieza, almacenamiento y retiro.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.04 · Nudo ocho y variantes.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.05 · Ballestrinque.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.06 · Dinámico/Munter.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.07 · Pescador doble.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.08 · Prusik y Machard.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.09 · Nudos de unión y de bloqueo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.10 · Función, limitaciones y fallos de cada nudo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.11 · Conceptos de aseguramiento y rápel.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.12 · Fricción, tensión, carga y fuerzas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.13 · Ventaja mecánica teórica y real.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.14 · Sistemas 2:1, 3:1, 5:1 y compuestos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.15 · Pérdidas por fricción.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.16 · Poleas y bloqueadores.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.17 · Transferencia de carga.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.18 · Fundamentos de autorrescate.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M07.19 · Evaluación práctica.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M08.01 · Evaluación previa de ruta y viabilidad.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M08.02 · Capacidad del guía y límites del sistema.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M08.03 · Selección y evaluación de anclajes.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M08.04 · Configuración de la reunión y dirección de carga.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M08.05 · Compatibilidad del equipo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M08.06 · Sistemas de descenso guiado/asistido.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M08.07 · Control del cliente.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M08.08 · Comunicación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M08.09 · Gestión de extremos y recuperación de cuerda.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M08.10 · Fallos potenciales y contingencias.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M08.11 · Evaluación de la víctima o cliente.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M08.12 · Gestión de los demás integrantes.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M08.13 · Criterios de no ejecución y alternativas de retirada.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M08.14 · Inspección y comprobaciones cruzadas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M08.15 · Plan de rescate.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M09.01 · Formación y metamorfismo del manto nivoso.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M09.02 · Estratos y pruebas de estabilidad: alcances y limitaciones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M09.03 · Viento, placas, temperatura y precipitación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M09.04 · Boletines de peligro.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M09.05 · Terreno de avalanchas y trampas de terreno.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M09.06 · Planificación y toma de decisiones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M09.07 · DVA, pala y sonda.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M09.08 · Búsqueda primaria, secundaria y fina.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M09.09 · Sondeo y excavación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M09.10 · Múltiples víctimas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M09.11 · Gestión de grupo y comunicación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M09.12 · Primeros auxilios posteriores.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M09.13 · Registro y revisión de decisiones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M09.14 · Prácticas de rescate supervisadas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M10.01 · Presión, temperatura, humedad y viento.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M10.02 · Frentes y masas de aire.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M10.03 · Nubosidad y precipitación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M10.04 · Isoterma 0 °C y nivel de congelación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M10.05 · Viento en altura y efecto orográfico.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M10.06 · Tormentas eléctricas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M10.07 · Visibilidad y navegación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M10.08 · Modelos meteorológicos y discrepancias entre ellos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M10.09 · Incertidumbre de los pronósticos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M10.10 · Nubes lenticulares y ondas de montaña.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M10.11 · Föhn y otros efectos locales cuando correspondan.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M10.12 · Cumulonimbos, altocúmulos, estratos, nieblas, nubes orográficas y señales de cambio.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M10.13 · Limitaciones de inferir peligro únicamente a partir de la forma o color de una nube.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M10.14 · Umbrales de decisión, ventanas meteorológicas y retirada.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M10.15 · Ejercicios de interpretación de pronósticos reales archivados y actuales.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M11.01 · Tectónica de placas y arco volcánico andino.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M11.02 · Tipos de volcanes y erupciones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M11.03 · Magma, lava, cenizas y productos piroclásticos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M11.04 · Fumarolas, gases, lahares y peligros secundarios.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M11.05 · Morfología volcánica.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M11.06 · Cráteres, conos, domos, calderas y edificios volcánicos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M11.07 · Actividad volcánica y monitoreo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M11.08 · Alertas oficiales y fuentes SERNAGEOMIN.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M11.09 · Riesgos específicos del Volcán Calbuco y otros volcanes de Los Lagos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M11.10 · Planificación de expediciones en terreno volcánico.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M11.11 · Criterios de cierre y cancelación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M11.12 · Comunicación de riesgos al cliente.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M11.13 · Casos históricos y lecciones aprendidas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.01 · Integración con formación WFR.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.02 · Evaluación primaria y secundaria.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.03 · Trauma.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.04 · Hipotermia y congelaciones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.05 · Altitud.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.06 · Deshidratación y agotamiento.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.07 · Hipoglucemia.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.08 · Fracturas y lesiones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.09 · Alergias y anafilaxia.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.10 · Pérdida de conciencia.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.11 · Emergencias cardiovasculares.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.12 · Evacuación y priorización.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.13 · Botiquín y protocolos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.14 · Comunicación con servicios de emergencia.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.15 · Seguridad de la escena.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.16 · Gestión médica de múltiples pacientes.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.17 · Documentación del incidente.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M12.18 · Limitaciones de atención remota.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M13.01 · Modelo 3x3: planificación regional, evaluación local y evaluación continua en terreno.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: sistema-3x3

> tres escalas de decisión: preparación, evaluación en el terreno y valoración del punto concreto.

Alcance: Describe factores y escalas de una adaptación pedagógica.

Vacío: Falta evaluación situada y formación específica para aplicaciones nivológicas.

## M13.02 · Aclarar que el modelo 3x3 tiene versiones y aplicaciones según el marco de referencia; identificar la fuente utilizada.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: sistema-3x3

> El folleto SLF/KAT lo presenta en prevención de avalanchas

Alcance: Identifica fuente y declara adaptación estival.

Vacío: Falta comparación sistemática de versiones; no equivale al método de reducción.

## M13.03 · Identificación de peligros.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: gestion-del-riesgo

> peligro → exposición → consecuencia plausible → información faltante → acción.

Alcance: Ficha para reconocer peligros vinculados a decisiones.

Vacío: Falta observar identificación de peligros en terreno y contexto específico.

## M13.04 · Exposición, probabilidad y consecuencias.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: riesgo-decisiones

> **probabilidad**: posibilidad de un resultado en un contexto definido

Alcance: Relaciona variables de riesgo y limita inferencias.

Vacío: No proporciona estimaciones cuantitativas ni valoración local validada.

## M13.05 · Matrices de riesgo y sus limitaciones.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: matriz-riesgo-invernal

> No se impone una tabla de colores ni se asignan números que aparenten una precisión inexistente.

Alcance: Explica límites de una matriz cualitativa.

Vacío: Falta revisar aplicación y supuestos con instructor; no es estándar operativo.

## M13.06 · Riesgo residual.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: matriz-riesgo-invernal

> No es sinónimo de riesgo aceptable.

Alcance: Distingue riesgo residual y aceptabilidad.

Vacío: Falta criterio contextual de decisión y revisión competente.

## M13.07 · Capas de protección.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: matriz-riesgo-invernal

> Dos controles pueden depender de un mismo recurso

Alcance: Analiza dependencia y fallo compartido de controles.

Vacío: Falta desarrollar un análisis completo de capas y fallos por actividad.

## M13.08 · Factores humanos.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: factores-humanos-invierno

> Conocer nieve y terreno no elimina sesgos.

Alcance: Relaciona información, heurísticas y discusión grupal.

Vacío: No demuestra causa de accidentes ni elimina sesgos por leer.

## M13.09 · Sesgo de compromiso.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: factores-humanos-invierno

> El compromiso con un objetivo aparece cuando el tiempo o esfuerzo invertido se usa como razón para continuar

Alcance: Explica inversión previa usada como argumento de continuidad.

Vacío: Falta observar reconocimiento y respuesta en escenarios supervisados.

## M13.10 · Presión comercial.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: factores-humanos-invierno

> la presión puede incluir expectativas del pasajero, una fotografía prometida, transporte o temor a decepcionar.

Alcance: Identifica presiones comerciales en ejercicios de guiado.

Vacío: Falta revisar políticas comerciales y decisiones operativas reales.

## M13.11 · Fatiga y carga de trabajo.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: riesgo-decisiones

> una persona fatigada cambia el tiempo necesario y la exposición a un cambio meteorológico.

Alcance: Conecta fatiga con tiempo y exposición.

Vacío: No desarrolla evaluación completa de carga de trabajo ni diagnóstico clínico.

## M13.12 · Gestión de incertidumbre.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: matriz-riesgo-invernal

> Si no puedes defender la probabilidad con evidencia

Alcance: Declara incertidumbre y limita estimaciones.

Vacío: Falta contrastar calidad de evidencia y alternativas en contexto real.

## M13.13 · Plan A/B/C.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: plan-operacion

> El plan B necesita recursos y salida propios

Alcance: Explica alternativas y opción de cancelar.

Vacío: Falta verificar alternativas concretas, accesos, recursos y condiciones.

## M13.14 · Horarios límite y puntos de decisión.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: plan-operacion

> no obliga a esperar hasta esa hora si aparece otro motivo para abandonar.

Alcance: Horario de retorno como límite condicionado.

Vacío: No fija tiempos ni puntos de decisión para una ruta real.

## M13.15 · Criterios de retirada.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: riesgo-decisiones

> el retorno deja de ser compatible con la reserva prevista

Alcance: Ejemplos de condiciones observables de retirada.

Vacío: Falta definir umbrales sustentados y evaluar ejecución del retorno.

## M13.16 · Plan de emergencia.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: plan-operacion

> organiza la solicitud de ayuda y acciones dentro de la competencia del equipo.

Alcance: Distingue emergencia de contingencia y contempla recursos.

Vacío: No es un protocolo operativo completo; requiere verificación local y formación.

## M13.17 · Briefing y debriefing.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: grupo-liderazgo

> **debriefing** revisa hechos y decisiones después.

Alcance: Define briefing y debriefing como coordinación.

Vacío: Falta comparar además las unidades detalladas y observar ambos ejercicios.

## M13.18 · Análisis de incidentes y casi accidentes.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: incidentes-retirada

> Primero reconstruye decisiones con la información disponible entonces

Alcance: Revisión de cronología, controles y acciones posteriores.

Vacío: Falta comprobar seguimiento y calidad de investigación de incidentes.

## M13.19 · Casos prácticos en Calbuco, Osorno, Casablanca y Yates.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: riesgo-decisiones

> ## Caso práctico: Osorno, escenario ficticio

Alcance: Caso escrito de Osorno con retraso, viento y presión.

Vacío: No cubre por sí solo los cuatro lugares; faltan contrastar Calbuco, Casablanca y Yates. No describe condiciones vigentes.

## M14.01 · Cartografía topográfica.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M14.02 · Curvas de nivel.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M14.03 · Brújula, azimut y rumbo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M14.04 · Coordenadas y datum.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M14.05 · GPS y navegación offline.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M14.06 · Tracks, rutas y waypoints.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M14.07 · Navegación nocturna.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M14.08 · Navegación con niebla y mala visibilidad.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M14.09 · Errores de posicionamiento.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M14.10 · Planificación de evacuación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M14.11 · VHF: fundamentos, uso, limitaciones y normativa.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M14.12 · InReach y comunicación satelital.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M14.13 · Mensajes de emergencia.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M14.14 · Baterías, redundancia y planes de comunicación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M14.15 · Formatos de reporte de emergencia.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.01 · Ecología de bosques templados lluviosos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.02 · Selva valdiviana.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.03 · Bosques andinos y subantárticos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.04 · Bosques de alerce y araucaria según distribución.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.05 · Matorrales, turberas, humedales, ríos, lagos y ambientes altoandinos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.06 · Sucesión ecológica y dinámica de perturbaciones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.07 · Flora nativa y endémica.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.08 · Fauna nativa.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.09 · Aves, mamíferos, anfibios, reptiles e invertebrados relevantes.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.10 · Especies amenazadas y conservación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.11 · Especies invasoras.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.12 · Identificación de especies y límites de identificación a distancia.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.13 · Interacciones ecológicas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.14 · Impacto del turismo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.15 · No Deje Rastro.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.16 · Áreas protegidas, normas y restricciones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M15.17 · Interpretación ambiental para pasajeros.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M16.01 · Geografía física y humana de la Región de Los Lagos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M16.02 · Cordillera de los Andes.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M16.03 · Cordillera de la Costa.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M16.04 · Valles, cuencas, lagos y ríos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M16.05 · Geología regional.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M16.06 · Glaciaciones y modelado del paisaje.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M16.07 · Tectónica y vulcanismo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M16.08 · Geomorfología.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M16.09 · Cuencas hidrográficas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M16.10 · Historia natural del paisaje.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M16.11 · Patrimonio natural y cultural.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M16.12 · Pueblos originarios, historia local y contexto cultural mediante fuentes fiables.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M16.13 · Turismo responsable e interpretación territorial.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M17.01 · Historia global del alpinismo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M17.02 · Historia del montañismo en Chile.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M17.03 · Exploraciones y primeras ascensiones documentadas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M17.04 · Desarrollo de técnicas, equipo y escuelas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M17.05 · Historia del andinismo patagónico y austral.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M17.06 · Expediciones destacadas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M17.07 · Historia de los volcanes de Los Lagos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M17.08 · Evolución de la seguridad y del rescate.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M17.09 · Ética de la montaña.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M17.10 · Fuentes primarias y controversias históricas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M17.11 · Biografías y cronologías verificadas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.01 · Volcán Calbuco.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.02 · Volcán Osorno.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.03 · Volcán Puntiagudo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.04 · Volcán Tronador, incluyendo las denominaciones locales y su ubicación transfronteriza.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.05 · Volcán Casablanca y sector Antillanca.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.06 · Volcán Yates.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.07 · Volcán Hornopirén.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.08 · Volcán Michinmahuida.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.09 · Volcán Chaitén.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.10 · Volcán Corcovado.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.11 · Volcán Puyehue.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.12 · Volcán Cordón Caulle.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.13 · Cerro Sarnoso y otras cumbres con toponimia relevante.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.14 · Otras cumbres y macizos regionales que se identifiquen durante la investigación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.15 · Nombre oficial y variantes locales.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.16 · Coordenadas y ubicación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.17 · Altitud y fuente.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.18 · Clasificación geomorfológica/volcánica.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.19 · Geología.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.20 · Historia y ascensiones documentadas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.21 · Accesos y permisos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.22 · Estacionalidad.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.23 · Dificultades y peligros generales.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.24 · Ecosistemas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.25 · Fuentes oficiales.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.26 · Fecha de última revisión.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M18.27 · Aviso de que las condiciones, accesos y restricciones deben verificarse antes de una salida.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M19.01 · Diseño de una experiencia educativa.

propuesta-parcial. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

Lección: objetivos-aprendizaje

> Define primero la tarea, después la evidencia y finalmente el criterio.

Alcance: Diseño de tarea, evidencia y criterio.

Vacío: Falta observar una experiencia completa y revisar su diseño con un docente.

## M19.02 · Comunicación clara.

propuesta-parcial. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

Lección: briefing-participativo

> Pide a alguien que reformule el acuerdo con sus palabras

Alcance: Comprobación de comprensión y adaptación del mensaje.

Vacío: Falta evaluar comunicación en un contexto real con distintas necesidades.

## M19.03 · Briefing de seguridad.

propuesta-parcial. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

Lección: grupo-liderazgo

> Presenta objetivo y alternativas, recorrido por etapas

Alcance: Componentes educativos del briefing y comprobación.

Vacío: Falta un briefing específico validado para actividad, grupo y condiciones.

## M19.04 · Demostraciones técnicas.

propuesta-parcial. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

Lección: ensenanza-progresiva

> Una demostración puede hacer visible la decisión, pero mirar no demuestra ejecución.

Alcance: Distingue demostración, ensayo y ejecución.

Vacío: No desarrolla demostraciones de maniobras concretas; requieren formación específica.

## M19.05 · Evaluación inicial del pasajero.

propuesta-parcial. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

Lección: objetivos-aprendizaje

> Pregunta qué experiencia tiene la persona con la tarea

Alcance: Exploración inicial de experiencia respecto de una tarea.

Vacío: No constituye una evaluación integral del pasajero ni un protocolo de aptitud.

## M19.06 · Adaptación a distintos niveles.

propuesta-parcial. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

Lección: ensenanza-progresiva

> Cambia una dificultad por vez para saber qué produjo el error.

Alcance: Adaptación progresiva basada en observación.

Vacío: Falta evaluación docente de adaptaciones en grupos diversos.

## M19.07 · Ritmo y control de grupo.

propuesta-parcial. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

Lección: grupo-liderazgo

> dónde se reúne el grupo y cómo se confirma que nadie falta.

Alcance: Organización, recuento y caso de ritmos distintos.

Vacío: No fija ritmo ni organización universal; falta observación situada.

## M19.08 · Gestión del miedo.

propuesta-parcial. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

Lección: grupo-liderazgo

> explica opciones reales y escucha qué situación preocupa.

Alcance: Escucha del miedo y alternativas sin falsas garantías.

Vacío: Falta práctica supervisada y criterios para situaciones fuera del alcance del guía.

## M19.09 · Liderazgo bajo presión.

propuesta-parcial. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

Lección: decisiones-grupo

> cuatro personas quieren mantener el objetivo anunciado

Alcance: Caso de presión grupal y dato faltante del descenso.

Vacío: Un caso escrito no demuestra liderazgo bajo presión real.

## M19.10 · Resolución de conflictos.

propuesta-parcial. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

Lección: comunicacion-conflictos

> Escuchar incluye pedir aclaración y resumir antes de responder.

Alcance: Escucha, observación y petición en juego de roles.

Vacío: Falta evaluar resolución de conflictos sostenidos y límites de intervención.

## M19.11 · Toma de decisiones.

propuesta-parcial. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

Lección: decisiones-grupo

> Documenta quién tiene autoridad para modificar el plan y cuándo será revisado.

Alcance: Responsabilidad, incertidumbres y revisión de decisiones.

Vacío: Falta juicio técnico contextual y evaluación de ejecución.

## M19.12 · Cultura de seguridad.

propuesta-parcial. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

Lección: decisiones-grupo

> Un participante puede aportar un dato decisivo aunque sea nuevo.

Alcance: Participación y contraste de decisiones.

Vacío: No desarrolla por completo cultura organizacional, reporte y seguimiento.

## M19.13 · Límites de competencia.

propuesta-parcial. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

Lección: ensenanza-progresiva

> el procedimiento técnico, los límites y la supervisión pertenecen a su formación específica

Alcance: Explicita límites del taller respecto de habilidades críticas.

Vacío: Falta mapa individual de competencias y evaluación por especialidad.

## M19.14 · Comunicación intercultural.

sin-vinculo-propuesto. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

## M19.15 · Interpretación ambiental.

sin-vinculo-propuesto. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

## M19.16 · Debriefing.

propuesta-parcial. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

Lección: debriefing-aprendizaje

> Describe una corrección concreta y reserva una nueva oportunidad para ponerla a prueba.

Alcance: Revisión de observación, criterio, corrección y siguiente ensayo.

Vacío: Falta observación docente de la aplicación y seguimiento de correcciones.

## M19.17 · Gestión de quejas e incidentes.

sin-vinculo-propuesto. Comparación editorial limitada a las seis lecciones de Etapa 16 y grupo-liderazgo. Validación docente pendiente.

## M20.01 · Requisitos actuales de SERNATUR.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M20.02 · Registro y especialidades.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M20.03 · Turismo aventura.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M20.04 · Obligaciones de información y seguridad.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M20.05 · Consentimientos y fichas de pasajero.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M20.06 · Planes de emergencia.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: plan-operacion

> plan de emergencia; escapes; horario límite y criterios de aborto.

Alcance: Incluye emergencia y retirada en expediente previo.

Vacío: Falta plan específico completo y revisión de requisitos aplicables; no verifica cumplimiento legal.

## M20.07 · Seguros y responsabilidades.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M20.08 · Gestión documental.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: plan-operacion

> Para cada fila anota dato, fuente/fecha, responsable y estado.

Alcance: Estructura documental de un expediente operativo.

Vacío: Faltan política de conservación, control de versiones y revisión jurídica específica.

## M20.09 · Contratación y operación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M20.10 · Protección de datos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M20.11 · Facturación, registros y aspectos tributarios básicos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M20.12 · Permisos, acceso a predios y áreas protegidas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M20.13 · Gestión de proveedores.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M20.14 · Atención al cliente.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M20.15 · Planificación de una salida comercial.

propuesta-parcial. Etapa 20: comparación editorial del pasaje y alcance indicado; revisión por especialista pendiente. No se revisó exhaustivamente todo el catálogo.

Lección: plan-operacion

> La oferta comercial promete cumbre y horario fijo

Alcance: Caso de contradicción entre oferta y alternativa realizable.

Vacío: Falta expediente comercial completo y verificación de condiciones, costos y obligaciones.

## M20.16 · Cancelaciones y reembolsos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M20.17 · Comunicación de dificultad y riesgos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.01 · Cascos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.02 · Arneses.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.03 · Cuerdas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.04 · Cordines.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.05 · Mosquetones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.06 · Dispositivos de aseguramiento.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.07 · Poleas y bloqueadores.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.08 · Cintas cosidas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.09 · Piolets.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.10 · Crampones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.11 · Tornillos de hielo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.12 · Estacas y anclajes.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.13 · DVA, pala y sonda.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.14 · GPS, VHF e InReach.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.15 · Vestimenta y capas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.16 · Calzado.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.17 · Equipo de campamento.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.18 · Botiquín.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.19 · Inspección, trazabilidad, compatibilidad y retiro.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.20 · Uso individual frente a uso comercial.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.21 · Documentación de mantenimiento.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M21.22 · Lectura de manuales y certificaciones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.01 · Evaluación inicial.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.02 · Capacidad aeróbica.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.03 · Zonas de entrenamiento y limitaciones de relojes ópticos.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.04 · Umbral aeróbico y pruebas apropiadas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.05 · Fuerza máxima y relativa.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.06 · Hipertrofia útil para montaña.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.07 · Resistencia muscular.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.08 · Fuerza excéntrica.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.09 · Capacidad de subida y descenso.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.10 · Tolerancia al desnivel.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.11 · Trabajo con mochila.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.12 · Estabilidad de tobillo, rodilla, cadera y tronco.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.13 · Movilidad.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.14 · Equilibrio y coordinación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.15 · Prevención y gestión de lesiones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.16 · Recuperación, sueño y fatiga.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.17 · Nutrición e hidratación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.18 · Periodización.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.19 · Bloques de base, desarrollo, especificidad y taper.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.20 · Preparación para expediciones largas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.21 · Tests de seguimiento.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M22.22 · Planificación semanal y registro de cargas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M23.01 · Volcán Calbuco.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M23.02 · Volcán Osorno.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M23.03 · Volcán/sector Casablanca.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M23.04 · Volcán Yates.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M23.05 · Otras montañas regionales verificadas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M23.06 · Información geográfica.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M23.07 · Planificación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M23.08 · Pronóstico y condiciones.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M23.09 · Equipamiento.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M23.10 · Perfil del grupo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M23.11 · Gestión de riesgo.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M23.12 · Puntos de decisión.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M23.13 · Comunicación.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M23.14 · Emergencias hipotéticas.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M23.15 · Retirada.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.

## M23.16 · Revisión posterior.

sin-revisar. Pendiente de comparar contenido y evidencia; no significa ausencia de material.
