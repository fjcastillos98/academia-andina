# Inventario reproducible · Etapa 18

24 módulos, 418 entradas (376 planned), 175 lecciones. Estados: {"development":162,"example":3,"pilot":10}.

175 lecciones declaran pendientes. reviewDate es una fecha editorial; no prueba revisión externa.

| Módulo | Entradas del mapa | Lecciones adscritas | Unidades | Habilidades | Fuentes distintas |
|---|---:|---:|---:|---:|---:|
| M00 | 7 | 6 | 1 | 5 | 7 |
| M01 | 17 | 7 | 1 | 6 | 12 |
| M02 | 13 | 7 | 7 | 7 | 16 |
| M03 | 9 | 10 | 10 | 10 | 6 |
| M04 | 15 | 11 | 11 | 11 | 13 |
| M05 | 13 | 9 | 9 | 9 | 14 |
| M06 | 14 | 8 | 8 | 8 | 11 |
| M07 | 39 | 20 | 11 | 20 | 14 |
| M08 | 16 | 1 | 1 | 1 | 3 |
| M09 | 14 | 13 | 10 | 13 | 29 |
| M10 | 18 | 4 | 4 | 4 | 14 |
| M11 | 14 | 11 | 11 | 11 | 18 |
| M12 | 18 | 1 | 1 | 1 | 3 |
| M13 | 20 | 4 | 4 | 4 | 9 |
| M14 | 17 | 4 | 2 | 3 | 7 |
| M15 | 18 | 11 | 11 | 11 | 18 |
| M16 | 15 | 2 | 2 | 2 | 6 |
| M17 | 12 | 9 | 9 | 9 | 16 |
| M18 | 28 | 1 | 1 | 1 | 7 |
| M19 | 19 | 12 | 12 | 12 | 13 |
| M20 | 18 | 1 | 1 | 1 | 2 |
| M21 | 22 | 1 | 1 | 1 | 4 |
| M22 | 23 | 17 | 17 | 17 | 15 |
| M23 | 19 | 5 | 5 | 5 | 8 |

Títulos normalizados idénticos: []. Cuerpos normalizados idénticos: []. La ausencia de coincidencias exactas no descarta solapamiento conceptual.

La adscripción por module no captura contenidos transversales ni fichas/talleres fuera de la colección de lecciones. No se calcula porcentaje de cobertura: no existe una correspondencia validada entrada–lección.
