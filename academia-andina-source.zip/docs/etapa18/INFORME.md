# Etapa 18 · Auditoría curricular

28 de octubre de 2026 · versión 0.18.0. Auditoría interna de estructura y prioridades editoriales, no acreditación externa.

## Hallazgos

24 módulos, 418 entradas totales, 376 de ellas con estado planned. 171 lecciones: 158 development, 10 pilot y 3 example. Todas declaran pendientes. No existe una correspondencia validada entrada–lección que permita calcular porcentaje de cobertura. Una fecha editorial de revisión no demuestra validación especializada.

M12, M20, M08 y M21 tienen una lección adscrita cada uno. Esto no significa ausencia de todo contenido relacionado: altitud, cuerda, rescate y equipo aparecen en otros módulos y recursos. Antes de ampliar, hay que mapear las relaciones transversales.

Se propone revisar posibles solapamientos entre liderazgo general y Etapa 16, planificación e integradores, y geología introductoria y Etapa 12. Son candidatos de revisión, no duplicidades conceptuales confirmadas. La detección automática solo compara títulos y cuerpos normalizados; sus resultados exactos figuran en INVENTARIO.md. No se fusionó ni eliminó contenido.

## Entrega

Página /auditoria/ con inventario de 24 módulos y sus lecciones/pedientes, cinco prioridades con evidencia, acción y criterio de cierre, y acta guardable en el respaldo v3. Inventario JSON y Markdown reproducibles mediante npm run audit:curriculum; el build lo regenera automáticamente.

Prioridades: trazabilidad entrada–lección; revisión clínica transversal; revisión operativa y normativa; revisión de descenso/equipo por contexto; comprobaciones interactivas y cartográficas. El orden es una propuesta editorial y no una puntuación de riesgo.

## Método y límites

Fuentes de auditoría: data/curriculum.json, data/skills.json, colección src/content/lecciones y los informes de etapas 15–17. Los recuentos usan la adscripción module y referencias source de cada lección. No cuentan como lecciones los talleres, fichas territoriales ni recursos de equipo independientes.

No se realizó verificación externa nueva de normativa, medicina, técnicas o fuentes bibliográficas. Esta etapa no afirma cumplimiento jurídico, competencia clínica, seguridad ni completitud de un programa profesional. No se cambió el estado de las entradas ni se certificó ninguna habilidad.

## Validación

167 tests aprobados, cero fallos. TypeScript/Astro: cero errores, advertencias e indicaciones. Build raíz: 275 páginas, 11.056 enlaces/recursos internos y 658 resultados de búsqueda. La base /academia-andina/ pasó con los mismos totales. Resultados por base en logs/.

Las pruebas nuevas comprueban correspondencia del inventario con los archivos actuales, duplicados normalizados y restauración del acta sin alterar planes ni registrar prácticas.

No se repitió la interacción bloqueada por política del navegador ni se intentó eludirla. Comprobación visual, controles, recarga, descarga/importación completa e impresión permanecen pendientes de prueba local; los tests automatizados no equivalen a esa comprobación.

## Archivos

Nuevos: src/lib/curriculum-audit.ts, scripts/audit-curriculum.ts, src/data/curriculum-audit18.json, src/data/audit-priorities18.json, src/pages/auditoria.astro, tests/etapa18.test.ts y docs/etapa18/.

Modificados: package.json (comando de auditoría y build), package-lock.json (versión), Layout (navegación), índice de búsqueda y README. Dependencias y contenido académico anterior intactos.

## Ejecución y continuación

Node.js 24; npm ci, npm run dev; abrir /auditoria/. El acta es un registro personal, sin envío a revisores ni cambios automáticos del currículo.

Siguiente etapa propuesta: matriz de trazabilidad entrada–lección, comenzando por las 376 entradas históricas; las relaciones deben quedar justificadas y sujetas a revisión, sin asignar cobertura por coincidencia de palabras.

Manual intacto. Sin push ni publicación.
