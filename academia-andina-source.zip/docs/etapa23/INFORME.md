# Etapa 23 · Gestión de quejas e incidentes de servicio

Fecha editorial: 29 de octubre de 2026.

Se añadió una unidad M19 en desarrollo con una habilidad de análisis, cuatro preguntas versionadas y evaluación abierta. Desarrolla recepción, registro atribuido, prioridades, responsables, respuesta, ejecución y comprobación de acciones. Diferencia atención comercial de necesidades que requieren el plan de seguridad o revisión especializada.

El taller `/atencion/` contiene tres casos originales: instrucciones incompatibles, una queja que revela peligro vigente y una respuesta sin corrección ejecutada. Incluye ficha Markdown descargable y expediente ficticio local `quejas-servicio:v1`. No se enviaron mensajes, tramitaron casos reales ni registraron prácticas automáticamente.

## Fuente y límites

Public Service Ombudsman: https://www.ombudsman.org.uk/about-us/our-principles/principles-good-complaint-handling/getting-it-right

Página institucional consultada. Se utiliza un resumen conceptual sobre responsabilidades, atención y aprendizaje; el flujo y casos son originales. La orientación se dirige al ámbito público británico y no se presenta como norma para turismo chileno. No se revisó el manual completo ni se verificaron plazos legales, derechos económicos o procedimientos regulatorios específicos. Revisión docente y operativa pendiente.

## Trazabilidad

M19.17 incorpora correspondencia parcial; se conservan las demás filas. La matriz vigente `traceability23.json` contiene 46 propuestas parciales y 330 entradas sin revisar. Las 17 entradas históricas de M19 tienen algún vínculo propuesto, sin que ello implique cobertura íntegra o validación de competencia. Permanecen intactos los estados curriculares originales. Inventario actualizado: 175 lecciones.

## Verificación

- 181/181 pruebas aprobadas.
- Astro: cero errores, advertencias y sugerencias en 129 archivos. Se repitió la comprobación porque la primera salida se detuvo tras sincronizar contenido sin emitir diagnóstico final.
- 283 páginas, 12533 enlaces/recursos internos y 666 resultados de búsqueda verificados en `/` y `/academia-andina/`.
- Serialización y restauración del expediente junto al guion previo, sin prácticas añadidas.
- Revisión visual, móvil y persistencia mediante interacción real pendientes: continúa la restricción de acceso del navegador previamente observada. No se intentó eludirla.

## Entrega y siguiente trabajo

Código, contenidos, ficha, pruebas, informes y matriz incluidos; dependencias, compilados y datos del navegador excluidos. Manual original intacto, sin push ni publicación.

Siguiente trabajo propuesto: revisión integrada de la secuencia de pedagogía y servicio, con un caso que conecte briefing, adaptación, decisiones, interpretación, quejas y debriefing; identificar contradicciones y tareas pendientes antes de ampliar otros módulos.
