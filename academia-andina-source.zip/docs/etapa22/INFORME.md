# Etapa 22 · Comunicación intercultural e interpretación ambiental

Fecha editorial: 28 de octubre de 2026.

Dos nuevas unidades en desarrollo de M19: comunicación intercultural e interpretación ambiental con evidencia. Incluyen objetivos, teoría, casos, revisión, seis preguntas versionadas con explicación de opciones y dos habilidades de análisis. Complementan patrimonio vivo de Etapa 13, que permanece intacto.

La página `/interpretacion/` integra secuencia, tarjetas ficticias descritas en texto, pautas de contraste, rúbrica y acta local `guion-intercultural:v1`. Se incluye una ficha descargable Markdown en `public/fichas/guion-interpretativo-etapa22.md`. No se realizaron consultas comunitarias, ensayos con audiencia real ni verificaciones de hechos ambientales locales.

## Fuentes

- UNESCO, Ethics and Intangible Cultural Heritage: https://ich.unesco.org/en/ethics-and-ich-00866 — principios consultados en texto indexado. La apertura directa en español e inglés presentó comprobación humana; no se afirma lectura directa de página ni de documentos jurídicos.
- NPS, History in the National Park Service: https://www.nps.gov/articles/historyinnps.htm — página consultada con foco en interpretación y educación. Marco histórico estadounidense; adaptación original al taller ambiental pendiente de revisión docente. La tentativa de consultar themes.pdf devolvió 404; no se utilizó ese PDF como fundamento.

Los ejercicios y guiones son propuestas originales. No se atribuyen a UNESCO ni NPS, ni se presenta una voz comunitaria inventada. Las alusiones a consentimiento son criterios éticos educativos, no un análisis jurídico específico.

## Trazabilidad

M19.14 y M19.15 pasan a correspondencia parcial con pasajes comprobables. El resto de la matriz de Etapa 21 se conserva. Total: 45 propuestas parciales, una entrada sin vínculo propuesto en corpus comparado (M19.17, gestión de quejas e incidentes) y 330 entradas sin revisar. No se calcula cobertura ni se alteran estados históricos. El inventario actualizado contiene 174 lecciones.

## Verificación

- 178/178 pruebas aprobadas.
- Astro: cero errores, advertencias y sugerencias en 127 archivos.
- En ambas rutas `/` y `/academia-andina/`: 281 páginas, 12172 enlaces/recursos internos y 664 resultados de búsqueda.
- La primera comprobación de ruta raíz detectó contenido residual de la base anterior. Se reconstruyó explícitamente cada base en ejecuciones separadas y se verificaron ambas salidas.
- Prueba de serialización/restauración del guion junto con el acta ética, sin registrar prácticas.
- Comprobación visual, móvil y persistencia mediante navegador pendientes por la restricción de acceso previamente observada. No se intentó eludirla.

## Entrega y continuidad

Fuentes, contenidos, ficha, pruebas, informes y matriz incluidos en ZIP; dependencias, compilados y datos del navegador excluidos. Manual original intacto. Sin publicación ni push.

Siguiente bloque propuesto: gestión de quejas e incidentes de servicio, distinguiendo recepción, registro de hechos, respuesta, seguimiento y situaciones que requieren otros responsables o asesoría especializada.
