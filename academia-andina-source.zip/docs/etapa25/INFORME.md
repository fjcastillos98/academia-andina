# Etapa 25 · Ruta integrada de guiado y servicio

Fecha editorial: 29 de octubre de 2026.

Nueva ruta `/ruta-guiado/`: diez lecciones existentes agrupadas en cuatro bloques por objetivo —preparar, comunicar/adaptar, decidir/representar y responder/aprender— con talleres y caso integrador final. Incluye orientación previa, tiempos estimados derivados de las lecciones, productos para revisar y enlaces de retorno.

La ruta se añadió a `data/learning-paths.json` conservando las anteriores. El orden de los bloques se contrasta con el programa durante la compilación. La lectura continúa abierta, sin bloqueos ni aprobación automática.

Los estados teóricos se presentan mediante el mecanismo `data-state` ya existente. Se reutilizan identificadores de lección; no se modifican almacenamiento, cuestionarios, respaldos ni competencias. Sin JavaScript se puede navegar, pero no se carga estado local.

## Navegación

Cinco accesos —liderazgo, ética, interpretación, atención e integración— se agrupan bajo Guiado y servicio. Sus URL permanecen operativas y se enlazan desde la nueva ruta. Cada página incorpora un enlace de retorno y mantiene activo el grupo correspondiente en el menú. El programa y buscador también enlazan la ruta.

No se añadieron lecciones ni correspondencias: permanecen 175 lecciones, 46 correspondencias parciales y 330 entradas sin revisar. No se modificó el manual original ni se realizó publicación o push.

## Verificación

- 186/186 pruebas aprobadas.
- Astro: cero errores, advertencias y sugerencias en 135 archivos.
- 285 páginas, 11798 enlaces/recursos internos y 668 resultados de búsqueda comprobados en `/` y `/academia-andina/`.
- Validación del orden compartido, identificadores y ausencia de duplicados en la nueva ruta.
- Revisión visual, móvil y funcionamiento de los estados mediante interacción real pendientes por la restricción de acceso al navegador previamente observada. No se intentó eludirla.

La reducción del número de enlaces respecto de Etapa 24 corresponde a los accesos del menú agrupados en todas las páginas, no a la eliminación de contenidos.

## Entrega y continuidad

ZIP con código, contenido, pruebas e informe; dependencias, compilados y datos del navegador excluidos.

Siguiente mejora propuesta: organizar el resto del catálogo en accesos por objetivos y rutas, conservando las URL y separando claramente estudio teórico, talleres y revisión presencial. Requiere revisión de la estructura existente antes de cambiar otros grupos.
