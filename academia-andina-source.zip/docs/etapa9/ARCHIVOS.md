# Archivos · Etapa 9

Comparación con el ZIP Etapa 8. Excluye dependencias, build y paquetes de entrega.

## Creados

- `data/archive/etapa8/README.md`
- `data/archive/etapa8/curriculum.json`
- `data/archive/etapa8/diagrams.json`
- `data/archive/etapa8/learning-paths.json`
- `data/archive/etapa8/skills.json`
- `data/archive/etapa8/sources.json`
- `docs/etapa9/ARCHIVOS.md`
- `docs/etapa9/FUENTES.md`
- `docs/etapa9/INFORME.md`
- `docs/etapa9/briefs.json`
- `docs/etapa9/historical-sha256.json`
- `docs/etapa9/logs/altitude-routes-base.log`
- `docs/etapa9/logs/altitude-routes.log`
- `docs/etapa9/logs/build-base.log`
- `docs/etapa9/logs/build.log`
- `docs/etapa9/logs/check.log`
- `docs/etapa9/logs/routes-base.log`
- `docs/etapa9/logs/routes.log`
- `docs/etapa9/logs/tests.log`
- `docs/etapa9/research.json`
- `docs/etapa9/screenshots/altitud-mobile.jpg`
- `public/diagramas/e9-observar.svg`
- `public/diagramas/e9-pernocta.svg`
- `scripts/check-altitude-build.mjs`
- `src/content/lecciones/aclimatacion-altitud.md`
- `src/content/lecciones/campamentos-altitud.md`
- `src/content/lecciones/emergencias-altitud.md`
- `src/content/lecciones/fisiologia-altitud.md`
- `src/content/lecciones/hace-altitud.md`
- `src/content/lecciones/hape-altitud.md`
- `src/content/lecciones/hidratacion-altitud.md`
- `src/content/lecciones/mam-altitud.md`
- `src/content/lecciones/nutricion-altitud.md`
- `src/content/lecciones/planificacion-altitud.md`
- `src/data/altitude-templates.json`
- `src/data/assessments/aclimatacion-altitud.v1.json`
- `src/data/assessments/campamentos-altitud.v1.json`
- `src/data/assessments/emergencias-altitud.v1.json`
- `src/data/assessments/fisiologia-altitud.v1.json`
- `src/data/assessments/hace-altitud.v1.json`
- `src/data/assessments/hape-altitud.v1.json`
- `src/data/assessments/hidratacion-altitud.v1.json`
- `src/data/assessments/mam-altitud.v1.json`
- `src/data/assessments/nutricion-altitud.v1.json`
- `src/data/assessments/planificacion-altitud.v1.json`
- `src/lib/altitude-client.ts`
- `src/lib/altitude.ts`
- `src/pages/altitud/index.astro`
- `tests/etapa9.test.ts`

## Modificados

- `README.md`
- `data/curriculum.json`
- `data/learning-paths.json`
- `data/skills.json`
- `package-lock.json`
- `package.json`
- `scripts/validate.ts`
- `src/data/diagrams.json`
- `src/data/sources.json`
- `src/layouts/Layout.astro`
- `src/lib/expanded.ts`
- `src/lib/practice-client.ts`
- `src/lib/program.ts`
- `src/pages/lecciones/[id].astro`
- `src/pages/practicas.astro`
