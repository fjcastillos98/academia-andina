# Etapa 9 · Altitud · versión 0.9.0

Integración del 26 de octubre de 2026. Bloque académico en desarrollo; revisión médica y de instructor pendientes. No se publicaron cambios ni se hizo push. El manual original permanece intacto.

## Contenido implementado

Diez lecciones conectadas: fisiología, aclimatación, mal agudo de montaña, HACE, HAPE, planificación, campamentos, nutrición, hidratación y emergencias. Integración en M03 histórico, conservando sus entradas originales. Se añaden diez unidades y habilidades, una ruta dependiente académicamente del bloque alpino, treinta preguntas con explicación por opción y diez respuestas abiertas con rúbrica.

Cada lección incorpora objetivos, prerrequisitos, conceptos, teoría, decisiones, errores, equipo, recuperación activa, quiz, ejercicio individual, propuesta supervisada, diario, criterios, fuentes, dificultad y relaciones. Cinco plantillas preparan simulaciones de aclimatación, planificación, campamento, nutrición y emergencia; no registran prácticas realizadas ni evaluaciones. Dos SVG conceptuales originales.

El laboratorio de pernoctas compara tres escenarios ficticios: noches intermedias, calendario comprimido y retorno. Calcula diferencias sin clasificar riesgo ni aptitud. No solicita síntomas. El selector no persiste; el caso integrador sí guarda manualmente el texto en el respaldo v3. Se recuerda no introducir información médica personal. Los campos libres existentes no pueden garantizar que un usuario no escriba datos sensibles: la plataforma no es una ficha clínica y no incorpora campos clínicos nuevos.

Totales: 121 lecciones y quizzes, 96 unidades, 118 habilidades, 10 rutas, 170 registros de fuentes, 41 SVG. Las 376 entradas originales siguen pendientes. Conservación comprobada de 261 archivos históricos (111 lecciones, 111 evaluaciones versionadas y 39 SVG), además de objetos curriculares anteriores.

## Comprobación real

- `npm run check`: 79 archivos, 0 errores, 0 advertencias, 0 indicaciones.
- `npm test`: 96 aprobadas, 0 fallos. Incluye currículo, dependencias, fuente inválida, conservación, búsqueda, quizzes, persistencia/respaldo y aritmética de pernoctas. Se añadió rechazo de arrays incompletos, datos no finitos y cotas fuera de rango; la prueba pasó tras ese ajuste.
- `npm run build`: 208 páginas. Comprobaciones en raíz y en `/academia-andina/`; se restaura el build de raíz al terminar.
- `npm run test:build`: 6695 enlaces/recursos internos y 592 entradas de búsqueda.
- `node scripts/check-altitude-build.mjs`: 11 páginas del bloque, 586 enlaces/recursos y sus anclas.
- Navegador: navegación desde inicio a Altitud, lección de aclimatación y siguiente lección de MAM. Fuentes CDC/WMS y sus límites visibles.
- Laboratorio: escenario comprimido cambia la tabla a 2800, 3600, 4000, 4000 m; incremento +800 m en la segunda noche, sin aprobación automática.
- Quiz: respuesta errónea produce 2/3 y revisión; corrección produce 3/3 con aviso de no acreditación práctica. Estado «Estudiada» conservado después de recargar.
- Caso integrador: texto de QA ficticio recuperado tras recarga. Los tests verifican serialización y restauración de respaldo; no se repitió la descarga/importación completa en navegador.
- Buscar HAPE: dos resultados, incluida su nueva lección y emergencias de altitud.
- Responsive: iframe de 390 × 844 px; portada con ancho útil y scrollWidth de 375 px. Sin desbordamiento horizontal del documento; menú horizontal intencional. No equivale a teléfono físico ni revisión exhaustiva de todas las páginas. Captura en `screenshots/altitud-mobile.jpg`.
- Ambos SVG nuevos se analizaron como XML válido.

Las dependencias ya instaladas se reutilizaron; no se afirma reinstalación. Logs completos en `logs/`.

## Límites y revisión pendiente

Revisar con médico de montaña los textos clínicos, señales, matices, casos y rúbricas; con instructor, las simulaciones y criterios. No hay dosis ni recomendación farmacológica individual. Oxígeno, cámara hiperbárica, movilización y evacuación técnica requieren formación específica y evaluación contextual. Ninguna respuesta de quiz habilita a atender clínicamente o guiar.

Las referencias históricas se limitan a su ámbito declarado. Se consultó resumen WMS, no su guía íntegra. No hay rutas operativas, teléfonos de emergencia o disponibilidad de recursos locales validados. No se repitió impresión/PDF ni descarga JSON por navegador; la descarga había sido bloqueada por política del entorno en una etapa previa. No se certifica accesibilidad WCAG ni compatibilidad con todos los navegadores.

## Siguiente etapa propuesta · Entrenamiento para andinismo

Construir progresivamente el módulo científico: evaluación inicial y límites de las pruebas, fuerza, hipertrofia, fuerza-resistencia, base aeróbica, zonas y umbrales, VO2max, especificidad de ascenso/carga, movilidad, estabilidad, recuperación, sueño, nutrición y periodización hasta taper de expedición. Distinguir preparación general de específica, integrar planificación y diario sin prescripciones clínicas automáticas. Investigar fuentes primarias y consensos deportivos, con revisión de profesional del ejercicio y nutrición para aplicación individual.
