# Fuentes · Etapa 9

Investigación inicial: 25 de octubre de 2026. Integración: 26 de octubre de 2026. Fuentes consultadas, no aval de la academia. Los escenarios, preguntas y rúbricas son propuestas pedagógicas originales.

## e9-cdc · CDC

[High-Altitude Travel and Altitude Illness · Yellow Book 2026](https://www.cdc.gov/yellow-book/hcp/environmental-hazards-risks/high-altitude-travel-and-altitude-illness.html)

Consulta: 2026-10-25. Límites: Guía clínica para profesionales. No asignar umbral de SpO2 de autorización ni garantía a un itinerario. No copiar dosis o convertir estas notas en indicación personal. Una lectura no forma para valoración clínica.

## e9-wms · Wilderness Medical Society

[Summary of WMS Practice Guidelines for Prevention, Diagnosis and Treatment of Acute Altitude Illness: 2024](https://wms.org/magazine/magazine/1463/2024-Altitude-Summary/default.aspx)

Consulta: 2026-10-25. Límites: Resumen institucional de la guía 2024 consultado; no se revisó íntegramente la publicación original. Recomendaciones clínicas generales, no autorización individual. Revisión médica pendiente.

## e9-nutrition · UIAA Medical Commission

[Nutritional Considerations in Mountaineering · Consensus Statement No.4 (2008, V1-2)](https://theuiaa.org/documents/mountainmedicine/UIAA_MedCom_Rec_No_4_Nutrition_2008_V1-2.pdf)

Consulta: 2026-10-25. Límites: Documento histórico2008: útil para logística, no como prescripción actual de calorías, hierro, electrolitos o líquidos. No reutilizar afirmaciones rígidas sobre pérdidas de peso, volumen de orina o mortalidad por deshidratación. Fecha anual verificada, día no disponible.

## e9-water · CDC

[About Water Treatment Options When Hiking, Camping, or Traveling](https://www.cdc.gov/drinking-water/prevention/water-treatment-hiking-camping-traveling.html)

Consulta: 2026-10-25. Límites: Consejo general de salud pública, no certificación de agua local chilena ni de equipo personal. Si se incluyen tiempos: fuente indica hervor1min,3min sobre6500pies; no confundir con recomendación histórica UIAA. Uso específico requiere instrucciones de fabricante.

## e9-fda-oximeter · FDA

[Pulse Oximeter Basics](https://www.fda.gov/consumers/consumer-updates/pulse-oximeter-basics)

Consulta: 2026-10-25. Límites: Información al consumidor, principalmente uso domiciliario. No importar rangos del nivel del mar a altitud ni construir autorización de ascenso basada en un número. Fecha confirmada en resultado indexado.

## e9-co · CDC · MMWR

[Carbon Monoxide Poisoning Deaths Associated with Camping — Georgia, March 1999](https://www.cdc.gov/mmwr/preview/mmwrhtml/mm4832a1.htm)

Consulta: 2026-10-25. Límites: Informe epidemiológico histórico, no ensayo de un modelo actual ni protocolo de rescate. No presentar tasas estadounidenses históricas como riesgo actual chileno.

## Decisiones editoriales

Se atribuyen por separado las formulaciones de descanso de CDC y WMS. No se implementa una regla combinada ni un algoritmo de diagnóstico. El original completo de la guía WMS no se revisó íntegramente; se consultó su resumen institucional.

UIAA nutrición 2008 se utiliza para preparación y logística, sin copiar prescripciones de calorías, hierro o líquidos. El documento UIAA de agua 2012 se examinó durante investigación y se excluyó del contenido para evitar trasladar recomendaciones históricas; se usa CDC 2025 sobre tratamiento. El informe CDC de CO es histórico y no aporta tasas actuales para Chile. FDA se usa para límites instrumentales, sin trasladar cifras del nivel del mar a una autorización de ascenso.

No se verifican rutas, hospitales, cobertura satelital, servicios de rescate, normativa chilena ni aptitud personal mediante estas fuentes. Todo ello requiere una revisión específica antes de una salida real.
