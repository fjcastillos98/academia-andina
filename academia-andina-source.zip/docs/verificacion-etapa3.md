# Verificación de Etapa 3

22-10-2026. Pruebas sobre el checkout local, sin push ni despliegue.

- `npm run build`: correcto en raíz y con `BASE_PATH=/academia-andina/`; 46 páginas HTML.
- `npm run test:build`: 852 enlaces/recursos internos y 421 resultados de búsqueda; 376 temas pendientes conservados. También comprueba destinos de citas internas `#fuente-*`.
- `npm run check`: 0 errores, 0 advertencias, 0 sugerencias.
- `npm test`: 25 pruebas aprobadas, 0 fallidas (17 anteriores + 8 del piloto).
- `git diff --exit-code` y `git diff --cached --exit-code`: correctos; archivos originales rastreados del manual sin cambios. Academia y documentación preparada siguen sin commit. No se modificó `curriculum.json`.

## Interacción real en navegador

Preview local de desarrollo; no publicación. Comprobaciones manuales mediante UI:

1. Portada → Fundamentales → Gestión del riesgo → siguiente Sistema 3×3.
2. Quiz de riesgo: 2/2, explicaciones y aviso de no competencia. Nota conservada tras recarga; intento visible en cuaderno.
3. Búsqueda «Micro Traxion», filtro Lección: encuentra Equipamiento personal y colectivo por el cuerpo del texto.
4. Diario: alta de práctica ficticia, recarga y persistencia. Confianza 5/5 + quiz aprobado mantiene competencia «Sin evaluar».
5. Edición: resultado «lograda» sin campos requeridos rechazado con mensaje; con supervisor/evaluador/fecha/criterio/evidencia ficticios se guarda como «declaración no verificada».
6. Exportación JSON descargada; importación del mismo archivo, resumen con práctica/nota/intento, confirmación y diario restaurado. La migración v1 se verificó en pruebas unitarias, no mediante importación v1 en navegador en esta etapa.
7. Responsive: diario y lección de nubes en marcos de 390×844 px; viewport útil de 375 px por barra vertical. En ambos, `scrollWidth=clientWidth=375`. Matriz con desplazamiento horizontal contenido. Inspección visual de tipografía, navegación y avisos. No es prueba de dispositivo físico ni auditoría WCAG completa.
8. Fuentes: ficha SLF visible con enlace, consulta y límites; fuente/lesson IDs validados en build. No se probaron todos los enlaces externos en el navegador ni su disponibilidad futura.

La captura móvil está en `docs/etapa3-responsive.jpg`. Archivo temporal de QA retirado antes del build final. Los datos ficticios de QA permanecen solo en el navegador de prueba; no se incorporan al código ni al paquete.

## Correcciones durante las pruebas

- Tipado de `input.type` del formulario corregido con una tupla literal.
- Respaldo ampliado a v2 y pruebas de rechazo de versión desconocida actualizadas.
- Identificadores de práctica admiten generación en entorno HTTP de desarrollo.
- Enlaces de citas del cuerpo llevan a fichas visibles dentro de cada lección.
- Prueba de búsqueda ajustada para consultar texto realmente incluido en el cuerpo («aire húmedo»), no una palabra presente únicamente en objetivos.

Npm avisa de una configuración `http-proxy` heredada del entorno; no impide build ni pruebas. No se añadieron dependencias en esta etapa.
