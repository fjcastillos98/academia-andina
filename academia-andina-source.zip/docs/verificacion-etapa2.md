# Verificación de la Etapa 2

Fecha de trabajo: 21 de octubre de 2026 (America/Santiago).

## Resultado

Aplicación local implementada en `academia/`, separada del manual original. Sin push, despliegue, cambios de remoto o workflows activos. La auditoría y el currículo preparados se conservaron.

| Comprobación ejecutada | Resultado |
| --- | --- |
| Instalación npm y lockfile | Completada |
| `npm run check` | 0 errores, 0 advertencias, 0 hints |
| `npm test` | 17 aprobadas, 0 fallidas |
| `npm run build` | 34 páginas estáticas generadas |
| `npm run test:build` con base `/` | 523 enlaces/recursos internos comprobados; 411 entradas de búsqueda |
| Build y comprobación con base `/academia-andina/` | Correctos; rutas prefijadas válidas |
| `git diff --exit-code` sobre archivos originales | Sin diferencias |

Las 411 entradas del índice son: 376 temas pendientes, 24 asignaturas, 3 lecciones y 8 términos de glosario. El build final se deja con base `/`.

## Pruebas en navegador

Se sirvió la aplicación con Astro en un preview local. Se comprobó:

- Portada y navegación a lección.
- Cuestionario de fundamentos con 2/2, explicaciones y resultado guardado.
- Nota y favorito; persistencia de los tres registros tras recargar.
- Cuaderno con nota, favorito e historial del intento.
- Búsqueda por «superficie de referencia» (texto del contenido); filtro de lecciones reduce los resultados a la lectura cartográfica.
- Catálogo filtrado por «crampones»: 3 asignaturas; módulo invernal con 13 entradas explícitamente pendientes.
- Exportación de JSON desde el botón de la aplicación. Cambio temporal de nota y restauración mediante selección de ese archivo, revisión del resumen y confirmación. Tras recargar se recuperó la nota original junto con favorito e intento.
- Portada con progreso 1/3 y una evaluación teórica aprobada después de la prueba. Estos son datos sintéticos del navegador de QA, no vienen precargados en el código.
- Adaptación de portada y lección en un iframe de 390 × 844 px: ancho útil y scrollWidth de 375 px (15 px corresponden a la barra vertical), sin desbordamiento del documento. No equivale a pruebas sobre teléfonos físicos.

El servidor requirió configurar host y admitir específicamente `terminal.local` para el entorno gestionado. El primer chequeo de tipos detectó falta de tipos Node; se instalaron y se corrigió una API obsoleta de Zod. Las comprobaciones finales pasaron.

## Cobertura automatizada

Currículo íntegro, duplicados, relaciones inexistentes, ciclos, campos de lección obligatorios, apartados faltantes, búsqueda con tildes y múltiples términos, filtros, rutas base, aciertos/fallos, respuestas inválidas, persistencia de notas/favoritos/intentos, respaldo round-trip, formato/versión/identificadores inválidos, rechazo de campos de certificación práctica, almacenamiento corrupto, errores de cuota y límite de tamaño.

## Límites pendientes

- No se ha ejecutado el workflow de GitHub Pages; la plantilla es inactiva.
- No hay auditoría integral WCAG, lector de pantalla, pruebas de Safari/Firefox ni teléfonos físicos.
- Las verificaciones de enlaces internos no garantizan disponibilidad futura de fuentes externas. No se implementó aún monitor periódico de enlaces.
- Las tres lecciones son ejemplos con fuentes y alcance explícitos; requieren revisión pedagógica externa. No constituyen currículo profesional completo ni validación técnica presencial.
- Almacenamiento local, sin sincronización, cifrado ni resolución de conflictos entre pestañas. Las respuestas de cuestionarios son visibles en una aplicación estática.
- Falta registro formal de práctica/evaluador, matrices guía/deportista, calendario y entrenamiento adaptable. La interfaz no permite obtener competencia práctica por cuestionarios.

## Siguiente etapa

Completar diagnóstico por objetivos y registro explícito de prácticas supervisadas, con fecha, evaluador, contexto y observaciones; mantener estados teóricos separados. Desarrollar el siguiente lote de lecciones fundacionales con revisión técnica y editorial. Acordar repositorio/destino antes de habilitar publicación.
