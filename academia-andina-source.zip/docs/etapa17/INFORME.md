# Etapa 17 · Casos integradores de expedición

28 de octubre de 2026 · versión 0.17.0 · en desarrollo, revisión instructora pendiente.

## Implementación

Tres casos originales: travesía estival, expedición invernal y expedición en altitud. Cada uno tiene contexto ficticio, lecturas previas, tres momentos con información nueva, pregunta y pauta razonada, entrega y rúbrica. Total: nueve momentos. Portada /expediciones/ y tres páginas de caso. Se añaden navegación y búsqueda.

El expediente se guarda manualmente en responses del respaldo v3 mediante el cliente existente. Cada caso tiene clave propia; no altera notas o planes anteriores. El usuario registra sus versiones en el texto: no existe historial automático de cambios. Los apartados desplegados no se persisten. No hay calificación automática, aprobación de salida, itinerarios operativos, diagnóstico médico ni secuencias de rescate.

Se conserva el currículo existente, las 171 lecciones y sus evaluaciones. Es un taller de síntesis asociado a M23, no tres nuevas lecciones ni nuevas competencias.

## Validación

164 tests aprobados, cero fallos. TypeScript/Astro: cero errores, advertencias e indicaciones. Build de 274 páginas. Verificador raíz: 10.546 enlaces/recursos internos y 657 resultados de búsqueda. La base /academia-andina/ pasa con los mismos totales. Verificación de ambas bases en logs/.

Tres pruebas nuevas: integridad y referencias de casos; rechazo de duplicados, referencias inválidas y pautas vacías; restauración de tres expedientes junto con un plan anterior sin registrar prácticas. La validación de casos se ejecuta al generar las páginas.

No se repitieron interacciones bloqueadas por la política del navegador en esta sesión; no se buscó un mecanismo para eludirla. La presentación visual, controles, persistencia tras recarga, impresión y flujo de descarga/importación completo siguen pendientes de verificación local. Las pruebas de lógica y enlaces no sustituyen esa comprobación.

## Fuentes y límites

NPS, Trip Planning Guide: https://www.nps.gov/subjects/healthandsafety/trip-planning-guide.htm (consulta 2026-10-28). Principios generales de preparación, comunicación y alternativa; la propia guía limita su alcance a visitas diurnas o con pernocta y excluye la planificación adicional que requieren expediciones de varios días. No valida estos casos ni una operación chilena.

Los escenarios, cifras ausentes, cambios de información y rúbricas son diseño original, no eventos reales. Las lecturas internas conservan sus fuentes originales y limitaciones, sin nueva verificación integral en esta etapa. La revisión docente e instructora sigue pendiente, y el caso de altitud remite las cuestiones médicas a su revisión específica.

## Archivos

Nuevos: src/data/expedition-cases17.json, src/lib/expeditions17.ts, src/pages/expediciones/index.astro, src/pages/expediciones/[id].astro, tests/etapa17.test.ts y docs/etapa17/.

Modificados: src/layouts/Layout.astro, src/pages/search-index.json.ts, src/pages/casos/index.astro, package.json, package-lock.json y README.md. Dependencias sin cambios.

## Ejecución y pendientes

Node.js 24; dentro de academia: npm ci y npm run dev. Abrir /expediciones/. Probar un expediente con texto ficticio, guardar, recargar y restaurar una copia en un perfil de pruebas.

Manual original intacto. Sin push, publicación ni comunicaciones enviadas. Las verificaciones cartográficas anteriores permanecen abiertas.

Siguiente etapa propuesta: auditoría integral de cobertura curricular y prioridades, para identificar vacíos, duplicidades y revisiones pendientes antes de seguir ampliando contenidos.
