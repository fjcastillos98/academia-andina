# Fuentes y alcance · Etapas 5.1 y 6


Consulta documental: 23 de octubre de 2026. Los enlaces no certifican prácticas ni compatibilidad del equipo personal.


## National Snow and Ice Data Center — Science of Glaciers


https://nsidc.org/learn/parts-cryosphere/glaciers/science-glaciers


Apoya: Formación, firn, acumulación/ablación, deformación y desplazamiento del hielo; retroceso del frente no equivale a flujo cuesta arriba.


Límites: Síntesis científica educativa. No determina estado, espesor, grietas ni transitabilidad de un glaciar chileno. No reutilizar cifras globales fechadas como actuales.


## U.S. National Park Service — Crevasses


https://www.nps.gov/articles/crevasses.htm


Apoya: Fracturas asociadas a deformación y cambios del flujo; nieve persistente puede ocultar grietas.


Límites: Artículo educativo actualizado 2018. No permite localizar todas las grietas a partir de formas superficiales ni demuestra resistencia de puentes.


## Petzl — Approaching a glacier as a roped team of two


https://www.petzl.com/us/en/sport/tech-tips/basic-techniques/approaching-a-glacier-as-a-roped-team-of-two/alpinisme-approche-glaciaire_SPO_a77w0000000KynNAAS.html


Apoya: Función de separación, reserva de cuerda, coordinación y control de holgura; papel del labio y nudos de frenado en nieve.


Límites: Ejemplo para dos personas, no receta general. Los nudos complican el izado. Requiere manuales y práctica profesional. No copiar distancias como universales.


## Petzl — Three types of tie-in with or without chest coils.


https://www.petzl.com/us/en/sport/tech-tips/basic-techniques/three-types-of-tie-in-with-or-without-chest-coils./alpinisme-encordement_SPO_a77w0000000KynSAAS.html


Apoya: Variantes de encordamiento y gestión de reserva según necesidad de ajustar separación.


Límites: La página compara ejemplos, con ventajas y restricciones. No establece que toda variante sirva en cada arnés o sistema; no sustituye revisión de instructor.


## Petzl — Crevasse rescue no. 1: transferring the victim’s weight to an anchor


https://www.petzl.com/gb/en/sport/tech-tips/rescue/crevasse-rescue-no.-1--transferring-the-victims-weight-to-an-anchor/MICRO-TRAXION---sport-2---Secours-crevasse-n-1--_SPO_a77w0000000KyrPAAS.html


Apoya: Distingue sostener la caída y transferir una carga a un anclaje; dirección de tracción y evitar cargas bruscas.


Límites: Ejemplo con MICRO TRAXION. No valida un anclaje por una imagen ni prueba compatibilidad del equipo del usuario. Se consultó texto, sin reproducir los diagramas del fabricante.


## Petzl — Crevasse rescue no. 2: accessing the edge of the crevasse to evaluate the situation


https://www.petzl.com/gb/en/sport/tech-tips/rescue/crevasse-rescue-no.-2--accessing-the-edge-of-the-crevasse-to-evaluate-the-situation/MICRO-TRAXION---sport3---Secours-crevasse-n-2_SPO_a77w0000000KyrUAAS.html


Apoya: Evaluar a la persona antes del izado; exposición del rescatista, cargas compartidas y daño potencial por carga de choque.


Límites: Variantes técnicas concretas. No prescribe aproximarse sin protección ni autoriza una carga adicional sobre un anclaje no evaluado.


## Petzl — Crevasse rescue no. 3: haul systems for crevasse rescue


https://www.petzl.com/US/en/Sport/Crevasse-rescue-no--3--haul-systems-for-crevasse-rescue?ActivityName=Mountaineering


Apoya: Compara sistemas y sus compromisos de complejidad, cuerda, colaboración de la víctima y fricción; relaciones de ventaja mecánica teóricas.


Límites: 2:1, 3:1 y 7:1 son modelos del artículo, no rendimiento real garantizado ni capacidad nominal del sistema. No sustituye formación, inspección ni instrucciones de cada pieza.


## UIAA — How to extricate yourself from a crevasse


https://www.theuiaa.org/how-to-extricate-yourself-from-a-crevasse/


Apoya: Autorescate condicionado por capacidad de movimiento, técnica de ascenso y estabilización del sistema en superficie.


Límites: Artículo de 2020 con ejemplos de dispositivos. No asumir que una persona ilesa puede ejecutar la maniobra; no es protocolo para lesión, inconsciencia o todo tipo de cuerda.


## Alpine Club of Canada — Doug Latimer — Mountain Safety: Glacier travel and crevasse rescue for two-person teams


https://blog.alpineclubofcanada.ca/blog/2021/11/29/mountain-safety-glacier-travel-and-crevasse-rescue-for-two-person-teams


Apoya: Vulnerabilidad de cordadas de dos; ayuda condicionada de nudos de frenado y dificultades posteriores; reserva y fricción en el rescate.


Límites: Artículo de guía publicado 20-06-2022, conservado en archivo. Opinión técnica contextual con observaciones propias, no norma universal ni probabilidad de éxito cuantificada para Chile.


## Dirección General de Aguas — Ministerio de Obras Públicas de Chile — Inventario Público de Glaciares


https://dga.mop.gob.cl/inventario-publico-glaciares/


Apoya: Fuente oficial para consultar inventario y cartografía de glaciares chilenos, con versión y metodología.


Límites: Página de acceso a IPG2022; inventario no equivale a mapa de grietas ni información operacional de hoy. No se descargó y validó una ficha local ni ruta. Existen diferencias de conteo entre publicaciones históricas; citar versión al usar cifras.


# Contrastes de la revisión 5.1


## DVA: comprobar, buscar y comunicar

El diagrama de Etapa 5 agrupa tareas de la respuesta general. No representa las cuatro fases de búsqueda de ICAR como cuatro bloques equivalentes: escena y excavación son funciones distintas. El término búsqueda primaria no debe sustituir la identificación del objetivo de cada fase.

- [ICAR — fases de búsqueda, actualización 2025](https://www.alpine-rescue.org/articles/1681--phases-in-an-avalanche-search-recommendation-009-2008-updated-2025)

- [ICAR — Personal Avalanche Transceiver](https://www.alpine-rescue.org/articles/1458--avalanche-transceiver)

## Sonda: referencia y tipo de búsqueda

Una referencia gráfica no define un patrón universal. El método de ICAR para localización y su recomendación de búsqueda organizada tienen ámbitos diferentes.

- [Avalanche Canada — Probing](https://avysavvy.avalanche.ca/en-ca/probing)

- [ICAR — Organized Probing Strategies 2025](https://www.alpine-rescue.org/articles/1682--organized-avalanche-rescue-probing-strategies-2015-updated-2025)

## Pala: acceso y transporte de nieve

El diagrama conceptual no prescribe geometría ni dimensiones. La función cambia con número de rescatistas, profundidad, pendiente y consistencia.

- [Avalanche Canada — Shovelling](https://avysavvy.avalanche.ca/en-ca/shovelling)

## Rescate: seguridad de escena y continuidad

El estudio no aporta autorización clínica ni un criterio para abandonar la reanimación. La evaluación de seguridad de escena y la evaluación clínica secundaria son conceptos distintos.

- [WMS — resumen de guías 2024](https://wms.org/magazine/magazine/1487/2024-Avalanche-Summary/default.aspx)

## Crampones: combinación real y control

Una fijación de correas no demuestra compatibilidad con cualquier bota. La selección no puede decidirse por el nombre de un volcán ni por tener más puntas.

- [Mountaineering Scotland — Crampons](https://www.mountaineering.scot/activities/mountaineering/winter-mountaineering/getting-started/crampons)

- [Petzl — procedimiento de inspección 210725 — enlace localizado; lectura completa pendiente](https://www.petzl.com/sfc/servlet.shepherd/version/download/068Tx00000IeoF3IAJ)

## Piolet: función, modelo y limitación

Que una escuela enseñe un anclaje con piolet no autoriza ese uso para todo modelo. Es necesario contrastar la ficha del producto exacto; una página de catálogo no sustituye sus instrucciones.

- [Petzl — documentación técnica GLACIER](https://www.petzl.com/INT/en/Sport/Ice-Axes/technical-content-product/GLACIER)

## Autodetención: prevención y contexto

La referencia BMC de Etapa 5 trata principalmente de calzado y tracción: no es un manual suficiente de autodetención. Este suplemento incorpora una fuente específica y mantiene pendiente la evaluación presencial.

- [ORTOVOX — LAB ICE, Self-arrest techniques](https://www.ortovox.com/uk/safety-academy-lab-ice/chapter-2/self-arrest-techniques)

## Frío y WFR: revisión sanitaria pendiente

Esta estación es una revisión educativa para instructor sanitario. No acredita WFR ni verifica la vigencia de un certificado personal.

- [CDC — Preventing Hypothermia](https://www.cdc.gov/winter-weather/prevention/index.html)

- [WMS — resumen de guías 2024](https://wms.org/magazine/magazine/1487/2024-Avalanche-Summary/default.aspx)


La lectura completa del PDF de inspección de crampones Petzl sigue pendiente; el enlace se localizó, pero su descarga no se pudo consultar completamente. La página de producto de un piolet tampoco sustituye el manual de su modelo exacto.