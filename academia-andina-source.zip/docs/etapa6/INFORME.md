# Entrega de desarrollo · Etapas 5.1 y 6

Fecha de entrega: 24 de octubre de 2026. Versión 0.6.0. La academia continúa en desarrollo; no se presenta como formación certificada ni contenido validado presencialmente.

## Trabajo incorporado

La Etapa 5.1 incorpora ocho estaciones de revisión: DVA, sonda, pala, rescate, crampones, piolet, autodetención y frío/WFR. Cada estación tiene objetivo, hallazgo documental, comprobaciones, propuesta de taller, criterios observables, motivos de parada y fuentes. Incluye acta local guardable. No se ha realizado ninguna revisión presencial ni práctica por un instructor.

Se añadieron suplementos visibles sin reescribir las 84 lecciones anteriores. Dos aclaraciones relevantes: el diagrama anterior de respuesta a avalancha no equivale a las cuatro fases de búsqueda ICAR; la referencia BMC anterior sobre calzado/tracción no basta como fuente de autodetención. Se agregó contraste específico de ORTOVOX. Los usos del piolet dependen del modelo y manual real.

La Etapa 6 añade diez unidades secuenciales: glaciología, terreno glaciar, grietas, progresión, configuración de cordada, encordamiento, detención de caída, autorescate, izado y gestión del grupo. Incluye 30 preguntas con corrección explicada, diez respuestas razonadas, cinco plantillas para el diario y tres diagramas conceptuales originales. Los ejercicios individuales son de escritorio; las maniobras requieren taller supervisado. El ejemplo de izado distingue fuerza, recorrido y trabajo ideal de las pérdidas y cargas reales.

Las fuentes distinguen contextos y variantes, particularmente cordadas de dos personas. No se añadieron rutas operativas ni condiciones supuestas de Tronador. El inventario DGA no se presenta como información de transitabilidad actual.

Totales: 24 asignaturas, 69 unidades, 94 lecciones y cuestionarios, 91 habilidades, 7 rutas de aprendizaje, 139 registros bibliográficos y 35 diagramas. Se mantienen las 376 entradas originales pendientes. Los registros bibliográficos incluyen distintos estados de verificación, no 139 fuentes nuevas verificadas.

## Verificación ejecutada

- TypeScript/Astro: 0 errores, 0 advertencias y 0 sugerencias.
- Pruebas automatizadas: 67 aprobadas, 0 fallidas. Incluyen conservación histórica, referencias y dependencias, rechazo de ciclos/datos inválidos, búsqueda, quiz, matriz, persistencia y migración de respaldos.
- Build en `/` y `/academia-andina/`: 178 páginas.
- Comprobación del build: 5.112 enlaces/recursos internos y 565 entradas de búsqueda, en ambas bases.
- Comprobación específica: 12 páginas de revisión/glaciar, 631 enlaces/recursos y sus anclas, en ambas bases.
- Navegador: diez enlaces de la secuencia visibles; navegación de Izado a Grupo glaciar; fuentes de la lección y sus límites presentes.
- Quiz de izado: 0/3 y 3/3, mensajes de corrección e intento guardado. Tras volver a cargar se mostró «Evaluación teórica aprobada» y «Estudiada», sin competencia práctica.
- Persistencia: plan glaciar y acta de revisión guardados y recuperados tras recargar.
- Búsqueda: «BMC» con filtro de pautas devuelve la aclaración de autodetención; «grietas» con filtro de lecciones devuelve siete resultados.
- Diario: plantilla de autorescate/izado rellena objetivo y equipo, mantiene resultado vacío, autonomía no evaluada y evaluación pendiente. No se guardó una práctica ficticia.
- Responsive: portada glaciar y pauta en iframe de 390 px; ancho útil y ancho de contenido 375 px, sin desbordamiento horizontal de página. No equivale a ensayo en un teléfono físico.
- Tres SVG nuevos analizados como XML. Capturas en `screenshots/`.

Los registros de ejecución están en `logs/`. Las dependencias no cambiaron en esta etapa y no se repitió la instalación; se utilizó la instalación existente. Para una instalación limpia: `npm ci` con Node.js 24.

## Límites y pendientes

La revisión de instructor sigue pendiente para las ocho estaciones y todas las maniobras glaciares. La parte sanitaria requiere un instructor sanitario competente. No se han comprobado físicamente los modelos del equipo, compatibilidades, manuales específicos, credenciales ni evidencia práctica del usuario.

El PDF de inspección de crampones Petzl quedó con lectura completa pendiente, visible en su referencia. No se extrapolan instrucciones entre fabricantes.

El respaldo v3, su validación y migraciones pasan pruebas automatizadas. La descarga de exportación JSON en el navegador no se volvió a intentar: una restricción de URL del navegador bloqueó ese flujo en la verificación anterior. No se afirma una verificación completa de descarga en esta entrega. La importación se había comprobado en la etapa anterior. La impresión física/PDF de la pauta tampoco se verificó.

No hay backend, autenticación de instructores, sincronización ni certificación. Los datos de práctica son declaraciones personales. No guardar datos médicos, contraseñas ni datos privados de pasajeros. La prueba responsive cubre dos nuevas páginas, no toda combinación de dispositivo/navegador ni una auditoría WCAG.

## Conservación y archivos

Se preservaron los 200 hashes de contenidos históricos (84 Markdown, 84 cuestionarios y 32 diagramas), los objetos previos del currículo y sus 376 entradas originales. Los cambios se limitan a la academia independiente. El manual original no fue modificado; no se hizo push ni despliegue.

`ARCHIVOS.md` compara la entrega con el ZIP de Etapa 5. `FUENTES.md` detalla referencias y límites. El ZIP incluye código y evidencias, excluye dependencias, build generado y ZIP anteriores.

## Continuación concreta

1. Realizar revisión presencial con la pauta: instructor, modelo/manual de equipo, observación, corrección y contexto no evaluado. Registrar únicamente lo ocurrido.
2. Corregir las unidades a partir de esa evidencia sin convertir el quiz en competencia.
3. Construir el siguiente bloque de escalada en hielo: formación y tipos de hielo; cramponaje y piolet; progresión, aseguramiento, anclajes, descenso y gestión del riesgo. Mantener el mismo esquema de fuentes, variantes, talleres y evaluación separada.

## Ejecución local

Descomprimir y entrar en `academia/`:

```bash
npm ci
npm run dev
```

Abrir la dirección local que indique Astro, habitualmente `http://localhost:4321/`. Para validar:

```bash
npm run check
npm test
npm run build
npm run test:build
node scripts/check-glacier-build.mjs
```
