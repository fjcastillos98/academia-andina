# Archivos de la entrega · diferencia respecto de Etapa 5

Rutas relativas a `academia/`. Se excluyen dependencias, build y paquetes de entrega.

## Creados (60)

- `data/archive/etapa5/cases.json`
- `data/archive/etapa5/curriculum.json`
- `data/archive/etapa5/diagrams.json`
- `data/archive/etapa5/learning-paths.json`
- `data/archive/etapa5/skills.json`
- `data/archive/etapa5/sources.json`
- `docs/etapa5/logs/packaging.log`
- `docs/etapa6/FUENTES.md`
- `docs/etapa6/INFORME.md`
- `docs/etapa6/README-anterior.md`
- `docs/etapa6/historical-sha256.json`
- `docs/etapa6/logs/build-base-final.log`
- `docs/etapa6/logs/build-base.log`
- `docs/etapa6/logs/build-final.log`
- `docs/etapa6/logs/build.log`
- `docs/etapa6/logs/check-final.log`
- `docs/etapa6/logs/check.log`
- `docs/etapa6/logs/glacier-base-final.log`
- `docs/etapa6/logs/glacier-base.log`
- `docs/etapa6/logs/glacier-final.log`
- `docs/etapa6/logs/routes-base-final.log`
- `docs/etapa6/logs/routes-base.log`
- `docs/etapa6/logs/routes-final.log`
- `docs/etapa6/logs/routes.log`
- `docs/etapa6/logs/tests-final.log`
- `docs/etapa6/logs/tests.log`
- `docs/etapa6/research.json`
- `docs/etapa6/screenshots/glaciar-390.jpg`
- `docs/etapa6/screenshots/glaciar-portada.jpg`
- `docs/etapa6/screenshots/plan-persistente.jpg`
- `public/diagramas/e6-decision.svg`
- `public/diagramas/e6-evidencia.svg`
- `public/diagramas/e6-objetivos.svg`
- `scripts/check-glacier-build.mjs`
- `src/content/lecciones/autorescate-grieta.md`
- `src/content/lecciones/configuracion-cordada.md`
- `src/content/lecciones/detencion-grieta.md`
- `src/content/lecciones/encordamiento-glaciar.md`
- `src/content/lecciones/glaciologia.md`
- `src/content/lecciones/grietas.md`
- `src/content/lecciones/grupo-glaciar.md`
- `src/content/lecciones/izado-glaciar.md`
- `src/content/lecciones/progresion-glaciar.md`
- `src/content/lecciones/terreno-glaciar.md`
- `src/data/assessments/autorescate-grieta.v1.json`
- `src/data/assessments/configuracion-cordada.v1.json`
- `src/data/assessments/detencion-grieta.v1.json`
- `src/data/assessments/encordamiento-glaciar.v1.json`
- `src/data/assessments/glaciologia.v1.json`
- `src/data/assessments/grietas.v1.json`
- `src/data/assessments/grupo-glaciar.v1.json`
- `src/data/assessments/izado-glaciar.v1.json`
- `src/data/assessments/progresion-glaciar.v1.json`
- `src/data/assessments/terreno-glaciar.v1.json`
- `src/data/glacier-templates.json`
- `src/data/review51.json`
- `src/lib/review.ts`
- `src/pages/glaciar/index.astro`
- `src/pages/invierno/revision.astro`
- `tests/etapa6.test.ts`

## Modificados (18)

- `README.md`
- `data/curriculum.json`
- `data/learning-paths.json`
- `data/skills.json`
- `package-lock.json`
- `package.json`
- `scripts/validate.ts`
- `src/data/diagrams.json`
- `src/data/sources.json`
- `src/layouts/Layout.astro`
- `src/lib/expanded.ts`
- `src/lib/practice-client.ts`
- `src/lib/program.ts`
- `src/pages/buscar.astro`
- `src/pages/invierno/index.astro`
- `src/pages/lecciones/[id].astro`
- `src/pages/practicas.astro`
- `src/pages/search-index.json.ts`

## Ausentes respecto al ZIP anterior (0)

Ninguno.
