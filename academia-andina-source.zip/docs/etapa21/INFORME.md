# Etapa 21 · Ética y responsabilidad profesional

Fecha editorial: 28 de octubre de 2026.

Se incorporó una unidad en desarrollo en M00 con objetivos, teoría, ficha de decisión, caso resuelto, ejercicios, rúbrica abierta y cuatro preguntas versionadas con explicación de cada opción. Se añadió una habilidad de análisis, sin equivaler a certificación o aprobación profesional.

El taller `/etica/` contiene cuatro casos originales: representación de credenciales, presión por una fotografía de cumbre, trato descalificador y acceso/comunidad no consultados. Las orientaciones se despliegan después de la consigna. El acta usa el mecanismo existente de respuesta local y respaldo, sin añadir prácticas automáticamente.

## Fuentes y límites

- ANGM: https://www.angm.cl/quienes-somos/reglamentos/codigo-de-etica-y-conducta/ — página institucional consultada íntegramente. Se distingue su destinatario asociativo de la habilitación del lector.
- UIAA: https://www.theuiaa.org/uiaa-declaration/ — página de presentación y principios consultados. No se revisó el PDF completo ni los desarrollos enlazados.

Los textos de consulta no se reproducen íntegramente. Los casos, preguntas y ficha son creación editorial de la academia, no material aprobado por esas instituciones. No se verifican leyes, permisos, seguros ni obligaciones contractuales específicas. La revisión docente y profesional sigue pendiente.

## Trazabilidad y conservación

M00.05 cambia de sin vínculo propuesto a correspondencia parcial con la nueva unidad. Las restantes filas de Etapa 20 se conservan. Totales: 43 propuestas parciales, tres sin vínculo propuesto en el corpus comparado y 330 entradas sin revisar. No se alteran estados originales ni se calcula cobertura acreditada.

La academia contiene ahora 172 lecciones. Se regeneró el inventario; su prueba compara el número de lecciones con el catálogo actual, conservando la igualdad exacta de datos y la protección de las 376 entradas históricas. No se debilitan las pruebas de conservación de contenido anterior.

## Verificación

- 175/175 pruebas aprobadas.
- Astro: cero errores, advertencias y sugerencias en 125 archivos.
- 278 páginas, 11772 enlaces/recursos internos y 661 resultados de búsqueda verificados en `/` y `/academia-andina/`.
- Prueba de serialización/restauración de la nueva acta junto con la anterior, sin prácticas añadidas.
- Sin comprobación visual, móvil o de persistencia por interacción real en navegador: permanece la restricción previamente observada. No se intentó eludirla.

## Entrega

ZIP de fuentes, contenido, pruebas, informes y matriz legible. No contiene dependencias, compilados ni datos del navegador del usuario. Manual original intacto; sin push ni publicación.

Siguiente bloque propuesto: comunicación intercultural e interpretación ambiental con casos situados y atribución cuidadosa, manteniendo pendientes las consultas que requieran participación de comunidades reales.
