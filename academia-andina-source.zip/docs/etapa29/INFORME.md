# Etapa 29 · Navegación de lecciones por ruta

Fecha: 30 de octubre de 2026. Versión 0.29.0.

Cada lección muestra las rutas del programa que la incluyen, su posición y los enlaces anterior/siguiente de cada secuencia. El panel está al final de la lectura y tiene acceso desde el índice lateral. Para las lecciones compartidas se muestran todas las rutas, sin seleccionar automáticamente una ni cambiar el registro de progreso.

La primera lección no inventa un paso anterior. La última ofrece volver a revisar la ruta, sin declarar aprobación. Las lecturas no incorporadas a rutas lo indican y conservan la navegación por orden editorial, identificada como tal. La navegación de las lecciones con ruta ya no depende de agrupaciones históricas por código.

No requiere JavaScript ni modifica el almacenamiento, evaluaciones, contenido académico o estructura de rutas. Las URL existentes se conservan. El manual original permanece intacto; no se publicó ni se realizó push.

## Verificación

- 190 pruebas aprobadas, cero fallos.
- Casos nuevos: lección compartida con distinto orden, extremos de secuencia, lectura intermedia, ruta de una sola lección y lectura sin ruta.
- Astro: 142 archivos, cero errores, advertencias y sugerencias.
- 286 páginas, 12687 enlaces/recursos internos y 669 resultados de búsqueda verificados en `/` y `/academia-andina/`.
- Revisión visual, móvil e interacción real pendientes por la restricción de navegador previamente observada.

## Continuidad

Se propone cerrar esta versión local en tres etapas adicionales (30–32), detalladas en CIERRE.md. El cierre académico completo tiene alcance distinto y todavía no dispone de una estimación fiable.

Entrega ZIP con código, contenido, pruebas e informes; sin dependencias, compilados ni datos personales del navegador.
