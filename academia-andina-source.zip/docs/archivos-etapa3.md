# Archivos de Etapa 3

Rutas relativas a `academia/`. Nuevos/modificados respecto de la entrega de Etapa 2, no respecto de git (la academia aún no tiene commit).

## Creados

- `src/content/lecciones/gestion-del-riesgo.md`
- `src/content/lecciones/sistema-3x3.md`
- `src/content/lecciones/planificacion-salida.md`
- `src/content/lecciones/meteorologia-montana.md`
- `src/content/lecciones/nubes-reconocimiento.md`
- `src/content/lecciones/cartografia-orientacion.md`
- `src/content/lecciones/equipamiento.md`
- `src/content/lecciones/nudos-fundamentales.md`
- `src/content/lecciones/cuerdas-anclajes.md`
- `src/content/lecciones/comunicaciones-emergencia.md`
- `src/pages/fundamentales.astro`
- `src/pages/practicas.astro`
- `src/lib/practices.ts`
- `src/lib/practice-client.ts`
- `tests/pilot.test.ts`
- `docs/etapa3.md`
- `docs/verificacion-etapa3.md`
- `docs/archivos-etapa3.md`
- `docs/etapa3-responsive.jpg`

## Modificados

- `README.md`
- `CONTRIBUTING.md`
- `package.json`
- `package-lock.json`
- `scripts/validate.ts`
- `scripts/check-build.mjs`
- `src/lib/schemas.ts`
- `src/lib/state.ts`
- `src/lib/client.ts`
- `src/data/sources.json`
- `src/pages/index.astro`
- `src/pages/lecciones/[id].astro`
- `src/pages/learning-data.json.ts`
- `src/pages/cuaderno.astro`
- `src/pages/fuentes.astro`
- `src/pages/modulos/index.astro`
- `src/pages/modulos/[id].astro`
- `src/layouts/Layout.astro`
- `src/components/LessonCard.astro`
- `src/styles/global.css`
- `tests/core.test.ts`

## Conservados

`data/curriculum.json`, las tres muestras anteriores y los archivos originales del manual. No se activó el workflow de ejemplo. `dist/` se regeneró y se excluye del repositorio; no debe editarse a mano. No se añadieron dependencias.
