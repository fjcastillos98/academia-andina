# QA de navegador · 23-10-2026

Preview local mediante Sites; sin publicación. Datos de prueba ficticios, sin datos personales.

| Comprobación | Resultado observado |
| --- | --- |
| Navegación | Portada → invierno → planificación/laboratorio; búsqueda → DVA → lección siguiente; diario y cuaderno accesibles. |
| Búsqueda | DVA devuelve 17 resultados entre lecciones, ficha educativa, caso y temario. Término inexistente devuelve 0 y explicación. |
| Quiz DVA | 2/3 muestra error y explicaciones por alternativa; 3/3 aprobado teórico con aviso de no competencia. Ambos intentos aparecen en cuaderno. |
| Persistencia | Plan y nota de DVA recuperados al recargar. Registro ficticio supervisado aparece en historial tras recarga. |
| Diario | Plantilla DVA prepara campos, no evaluación. Guardado sin supervisor rechazado. Con supervisor ficticio permite guardar sin atribuir competencia. |
| Matemáticas | Nueve respuestas correctas, incluidas comas decimales, muestran explicación. Texto abc produce error numérico. |
| Terreno | Respuesta de pendiente local muestra corrección; respuesta sobre conexión con salida muestra razonamiento y límites. |
| Importación | JSON inválido rechazado. Copia v1 vacía migrada e importada. Copia v3 de prueba recupera plan invernal. |
| Exportación | Intento bloqueado por política del navegador de pruebas: protocolo de descarga no permitido. No se eludió el bloqueo. Pendiente verificar descarga y ciclo exportar→importar en navegador local normal. Serialización y restauración verificadas por tests. |
| Teclado | Enter sobre Saltar al contenido mueve foco a contenido y hash #contenido. No es auditoría completa de accesibilidad. |
| 390 px | Página invernal y planificación renderizadas en iframe 390×844; ancho útil 375 por barra de scroll. scrollWidth=clientWidth=375 en ambas. Menú horizontal desplazable. No se simuló un dispositivo físico. |
| Fuentes | Lección DVA muestra institución, título, fecha y limitaciones. Anclas internas comprobadas automáticamente en todas las nuevas páginas. No se comprobó disponibilidad externa de cada URL durante QA. |
| Impresión | Plantilla y CSS de impresión incorporados. No se verificó PDF ni salida física de impresora. |

Capturas: screenshots/desktop.jpg y screenshots/mobile.jpg. La página temporal de QA se retiró antes del build final. Las mediciones móviles son de presentación; la navegación dentro del iframe tuvo limitaciones de automatización y se comprobó en escritorio. Inventario existente cubierto por tests de dominio, no por nueva revisión exhaustiva de navegador.
