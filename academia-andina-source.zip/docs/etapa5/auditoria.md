# Auditoría de incorporación · Etapa 5

22-10-2026. Revisión previa de arquitectura, currículo, habilidades, fuentes, lecciones, evaluaciones, casos, diario e inventario.

Base: Astro 7.4.2 + TypeScript + Markdown con frontmatter JSON + Zod. 24 módulos, 376 entradas históricas pendientes, 33 unidades, 55 lecciones y cuestionarios versionados, 52 habilidades, 5 rutas, 15 casos, 76 fuentes y 17 diagramas. M02 (montaña invernal) y M09 (nivología/avalanchas) ya existen: se amplían con unidades sin sustituir sus entradas.

Persistencia: localStorage clave existente, respaldo v3 con migraciones v1 y v2. Estado práctico separado del teórico; evaluación declarada no verifica instructor. El inventario referencia prácticas por ID; no certifica aptitud. La Etapa 5 reutiliza responses para planes, sin nuevos campos obligatorios ni cambio de versión.

Preservación: manifiesto SHA-256 de las 55 lecturas, 55 evaluaciones y 17 SVG anteriores; snapshots de currículo, habilidades, rutas, casos, fuentes y diagramas en data/archive/*.etapa45.json. Se compararán objetos históricos, además de hashes. El repositorio original no tiene cambios en archivos seguidos por Git; academia y docs son carpetas añadidas. No se hará push ni deploy.

Decisiones: una ruta invernal, unidades 5.1–5.26, búsqueda ampliada por contenido de las lecciones; 5.27–5.34 son funciones transversales, no páginas de relleno. DVA se divide en fases progresivas. Casos regionales expresamente hipotéticos. Las prácticas técnicas requieren supervisión. No se asignarán boletines, tiempos médicos o valores de compatibilidad sin documentación específica.

Límites del diagnóstico: no se realizó una auditoría clínica, certificación de seguridad ni revisión de instructor. Las fuentes se investigan por tema; el acceso a un portal no equivale a validar cobertura de boletín para Los Lagos.


## Resultado de incorporación · 23-10-2026

Se conservan 24 módulos y 376 entradas históricas; se añaden 26 unidades, 29 lecciones y habilidades, una ruta, 12 casos, 53 fuentes y 15 diagramas. Los tests de hashes y comparación de objetos históricos pasan. No se sustituyen evaluaciones anteriores.

57 tests pasan, incluidos 11 nuevos. Astro check: 61 archivos, cero errores, advertencias o hints. Build: 166 páginas. En raíz y /academia-andina/: 4546 enlaces/recursos internos y 547 resultados de búsqueda; comprobación adicional de 45 páginas nuevas y 1951 enlaces/recursos con anclas.

La revisión de navegador y sus límites constan en qa-navegador.md. No confundir los tests de software con revisión técnica de instructor. Exportación por descarga bloqueada por la política de protocolos del navegador de QA, sin intento de elusión; importación independiente verificada. Impresión PDF pendiente de comprobación manual.
