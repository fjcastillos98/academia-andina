# Fuentes de Etapa 5

Consulta documental registrada: 22-10-2026. Incorporación y comprobaciones de software: 23-10-2026. Se añaden 53 registros y se conservan íntegros los 76 anteriores. Las referencias son soporte documental; no validan una aplicación local ni la competencia del lector.

Las fuentes de fabricantes se aplican al modelo y revisión indicados. Portales e índices de documentación no equivalen a lectura del manual completo. Los casos regionales son ficticios y no describen condiciones actuales. Las fuentes anteriores enlazadas se mantienen en la biblioteca de la aplicación.

## e5-snow-material

**Institución:** WSL Institute for Snow and Avalanche Research SLF

**Título:** Snow as a material

**URL:** https://www.slf.ch/en/snow/snow-as-a-material/

**Consulta:** 2026-10-22

**Tema respaldado:** Snow as a material

**Relación curricular:** invierno-fundamentos

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Propiedades generales; no clasifica estabilidad de una ladera.

## e5-snow-science

**Institución:** National Snow and Ice Data Center, University of Colorado Boulder

**Título:** Science of Snow

**URL:** https://nsidc.org/learn/parts-cryosphere/snow/science-snow

**Consulta:** 2026-10-22

**Tema respaldado:** Science of Snow

**Relación curricular:** nieve-propiedades

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Conceptos físicos y formas de nieve; no documenta presencia local de penitentes ni condiciones actuales.

## e5-metamorphism

**Institución:** WSL Institute for Snow and Avalanche Research SLF

**Título:** Snow metamorphism

**URL:** https://www.slf.ch/en/snow/snow-as-a-material/snow-metamorphism/

**Consulta:** 2026-10-22

**Tema respaldado:** Snow metamorphism

**Relación curricular:** nieve-propiedades, nivologia

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Explicación de transformación; no permite deducir estabilidad solo desde un cristal.

## e5-round-facet

**Institución:** University of British Columbia, EOAS

**Título:** Rounding and Faceting Snow Crystals

**URL:** https://www.eoas.ubc.ca/courses/atsc113/snow/met_concepts/07-met_concepts/07de-rounding-faceting-snow-crystals/

**Consulta:** 2026-10-22

**Tema respaldado:** Rounding and Faceting Snow Crystals

**Relación curricular:** nivologia

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Recurso universitario introductorio; gradientes orientativos no se usan como umbral de seguridad.

## e5-eaws-glossary

**Institución:** European Avalanche Warning Services

**Título:** Glossary

**URL:** https://www.avalanches.org/glossary/

**Consulta:** 2026-10-22

**Tema respaldado:** Glossary

**Relación curricular:** nieve-propiedades

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Terminología multilingüe; las traducciones y clasificaciones requieren contexto.

## e5-surface-hoar

**Institución:** Avalanche.org

**Título:** Surface Hoar

**URL:** https://avalanche.org/avalanche-encyclopedia/snowpack/weak-layer/persistent-weak-layers/surface-hoar-2/

**Consulta:** 2026-10-22

**Tema respaldado:** Surface Hoar

**Relación curricular:** nivologia

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Ejemplos y procesos; no describe distribución actual en Los Lagos.

## e5-persistent

**Institución:** WSL Institute for Snow and Avalanche Research SLF

**Título:** Old snow — Persistent weak layers

**URL:** https://www.slf.ch/en/avalanche-bulletin-and-snow-situation/about-the-avalanche-bulletin/typical-avalanche-problems/old-snow/

**Consulta:** 2026-10-22

**Tema respaldado:** Old snow — Persistent weak layers

**Relación curricular:** nivologia

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Problema típico; una observación aislada o ausencia de señales no descarta el problema.

## e5-eaws-problems

**Institución:** European Avalanche Warning Services

**Título:** Avalanche Problems

**URL:** https://www.avalanches.org/standards/avalanche-problems/

**Consulta:** 2026-10-22

**Tema respaldado:** Avalanche Problems

**Relación curricular:** avalancha-tipos, boletines-avalancha

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Clasificación EAWS, distinta en algunos detalles a otras escuelas; no es boletín local.

## e5-caic-problems

**Institución:** Colorado Avalanche Information Center

**Título:** Avalanche Problems

**URL:** https://www.avalanche.state.co.us/forecasts/tutorial/avalanche-problems

**Consulta:** 2026-10-22

**Tema respaldado:** Avalanche Problems

**Relación curricular:** avalancha-tipos

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Otra clasificación técnica; no trasladar ventanas temporales generales a condiciones chilenas.

## e5-wind-slab

**Institución:** Avalanche.org

**Título:** Wind Slab

**URL:** https://avalanche.org/avalanche-encyclopedia/avalanche/avalanche-problems/avalanche-problem-type/wind-slab/

**Consulta:** 2026-10-22

**Tema respaldado:** Wind Slab

**Relación curricular:** meteo-invernal

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Conceptos y señales; no prescribe itinerario automáticamente seguro.

## e5-wet-slab

**Institución:** Avalanche.org

**Título:** Wet Slab

**URL:** https://avalanche.org/avalanche-encyclopedia/avalanche/avalanche-problems/avalanche-problem-type/wet-slab/

**Consulta:** 2026-10-22

**Tema respaldado:** Wet Slab

**Relación curricular:** meteo-invernal

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Problema de nieve húmeda; horas de estabilidad dependen del estado real del manto.

## e5-terrain-traps

**Institución:** Avalanche.org

**Título:** Terrain Trap

**URL:** https://avalanche.org/avalanche-encyclopedia/terrain/avalanche-terrain-exposure/terrain-trap/

**Consulta:** 2026-10-22

**Tema respaldado:** Terrain Trap

**Relación curricular:** avalancha-tipos, terreno-avalancha

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Ejemplos de consecuencias; no delimita terrenos locales.

## e5-exposure

**Institución:** Avalanche.org

**Título:** Avalanche Terrain Exposure

**URL:** https://avalanche.org/avalanche-encyclopedia/terrain/avalanche-terrain-exposure/

**Consulta:** 2026-10-22

**Tema respaldado:** Avalanche Terrain Exposure

**Relación curricular:** invierno-fundamentos, terreno-avalancha, matriz-riesgo-invernal

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Marco de posición y tiempo de exposición; no cuantifica riesgo individual.

## e5-ates

**Institución:** Statham y colaboradores; Natural Hazards and Earth System Sciences

**Título:** The Avalanche Terrain Exposure Scale (ATES) v.2

**URL:** https://nhess.copernicus.org/articles/25/1113/2025/

**Consulta:** 2026-10-22

**Tema respaldado:** The Avalanche Terrain Exposure Scale (ATES) v.2

**Relación curricular:** terreno-avalancha

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Clasificación especializada de terreno; no asignamos categorías ATES a montañas chilenas sin evaluación.

## e5-dmc-model

**Institución:** Dirección Meteorológica de Chile

**Título:** Modelos y satélites — Servicios Climáticos

**URL:** https://climatologia.meteochile.gob.cl/application/index/menuTematicoModeloSatelite

**Consulta:** 2026-10-22

**Tema respaldado:** Modelos y satélites — Servicios Climáticos

**Relación curricular:** meteo-invernal, boletines-avalancha, tres-por-tres-invernal

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Portal de productos; no se verificó pronóstico ni cobertura nivológica para una salida concreta.

## e5-danger-scale

**Institución:** European Avalanche Warning Services

**Título:** Avalanche Danger Scale

**URL:** https://www.avalanches.org/standards/avalanche-danger-scale/

**Consulta:** 2026-10-22

**Tema respaldado:** Avalanche Danger Scale

**Relación curricular:** boletines-avalancha, matriz-riesgo-invernal

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Escala regional y temporal; no equivale a riesgo personal ni autorización de una pendiente.

## e5-slf-bulletin

**Institución:** WSL Institute for Snow and Avalanche Research SLF

**Título:** Avalanche bulletin and snow situation

**URL:** https://www.slf.ch/en/avalanche-bulletin-and-snow-situation/

**Consulta:** 2026-10-22

**Tema respaldado:** Avalanche bulletin and snow situation

**Relación curricular:** boletines-avalancha

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Servicio suizo utilizado para aprender formatos; no informa condiciones de Chile.

## e5-kat-3x3

**Institución:** Groupe de compétence prévention des accidents d’avalanche (KAT), SLF y organizaciones participantes

**Título:** Attention avalanches! — grille 3×3

**URL:** https://www.slf.ch/fileadmin/user_upload/SLF/Lawinen/Lawinenkunde_und_Praevention/KAT/20221004_Lawinenfolder_f_web.pdf

**Consulta:** 2026-10-22

**Tema respaldado:** Attention avalanches! — grille 3×3

**Relación curricular:** tres-por-tres-invernal

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Folleto técnico francés, edición indicada en archivo 2022; adaptación educativa del 3×3, no algoritmo ni sustituto de formación.

## e5-kat-learning

**Institución:** WSL Institute for Snow and Avalanche Research SLF

**Título:** Caution avalanches!

**URL:** https://www.slf.ch/en/publications/caution-avalanches/

**Consulta:** 2026-10-22

**Tema respaldado:** Caution avalanches!

**Relación curricular:** invierno-fundamentos, factores-humanos-invierno, tres-por-tres-invernal

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** La presentación del folleto exige conocimientos y aprendizaje en un curso; no es preparación suficiente por sí sola.

## e5-human

**Institución:** Avalanche.org

**Título:** Human Factors

**URL:** https://avalanche.org/avalanche-encyclopedia/human/decision-making/human-factors/

**Consulta:** 2026-10-22

**Tema respaldado:** Human Factors

**Relación curricular:** factores-humanos-invierno, matriz-riesgo-invernal

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Marco educativo de sesgos; no permite diagnosticar retrospectivamente una causa única de accidente.

## e5-heuristics-study

**Institución:** Ian McCammon; ISSW 2002, archivo Montana State University

**Título:** Evidence of Heuristic Traps in Recreational Avalanche Accidents

**URL:** https://arc.lib.montana.edu/snow-science/item/837

**Consulta:** 2026-10-22

**Tema respaldado:** Evidence of Heuristic Traps in Recreational Avalanche Accidents

**Relación curricular:** factores-humanos-invierno

**Alcance:** Fuente primaria técnica o institucional

**Limitaciones:** Estudio de accidentes recreativos; asociación observada, no explicación universal de cada decisión.

## e5-barryvox-manual

**Institución:** Mammut

**Título:** Barryvox Extended Reference Guide — BarryHeart 3.0

**URL:** https://static.mammut.com/file/Barryvox_Extended_Reference_Guide_BarryHeart_3.0_EN.pdf

**Consulta:** 2026-10-22

**Tema respaldado:** DVA: transmisión, búsqueda y comprobaciones

**Relación curricular:** dva-fundamentos

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Manual de esta generación de Barryvox; no corresponde automáticamente a Barryvox 2/S2 ni al DVA que posea el alumno. Comprobar modelo, firmware, avisos y manual vigente.

## e5-icar-dva

**Institución:** ICAR Avalanche Rescue Commission

**Título:** Personal Avalanche Transceiver — Recommendation 0002

**URL:** https://www.alpine-rescue.org/articles/1458--avalanche-transceiver

**Consulta:** 2026-10-22

**Tema respaldado:** DVA: transmisión, búsqueda y comprobaciones; Búsqueda de señal: cobertura y lectura de escena; Múltiples señales, marcación y límites del dispositivo

**Relación curricular:** dva-fundamentos, dva-senal, dva-multiples

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Recomendación institucional publicada en2025, con criterios profesionales y formación continua. No es normativa chilena ni certifica al usuario.

## e5-bd-interferencia

**Institución:** Black Diamond

**Título:** QC Lab: Electromagnetic Interference and Avalanche Transceivers

**URL:** https://blackdiamondequipment.com/blogs/stories/qc-lab-electromagnetic-interference-and-avalanche-transceivers

**Consulta:** 2026-10-22

**Tema respaldado:** DVA: transmisión, búsqueda y comprobaciones; Búsqueda de señal: cobertura y lectura de escena

**Relación curricular:** dva-fundamentos, dva-senal

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Ensayos y explicación del fabricante; los efectos y medidas dependen de dispositivos, modos y entorno. No trasladar una distancia a todos los equipos.

## e5-senal-aaa

**Institución:** Avalanche.org / American Avalanche Association; material acreditado a Backcountry Access

**Título:** Signal search — Avalanche Encyclopedia

**URL:** https://avalanche.org/avalanche-encyclopedia/human/companion-rescue/transceiver-search/signal-search/

**Consulta:** 2026-10-22

**Tema respaldado:** Búsqueda de señal: cobertura y lectura de escena

**Relación curricular:** dva-senal

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Modelo educativo; espaciamientos de la página no se universalizan. Contrastar con manual, interferencias y formación.

## e5-coarse-aaa

**Institución:** Avalanche.org / American Avalanche Association; material acreditado a Backcountry Access

**Título:** Coarse Search — Avalanche Encyclopedia

**URL:** https://avalanche.org/avalanche-encyclopedia/human/companion-rescue/transceiver-search/coarse-search/

**Consulta:** 2026-10-22

**Tema respaldado:** Aproximación: seguir una señal sin perder el escenario

**Relación curricular:** dva-aproximacion

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Describe una fase conceptual. No es navegación ni autorización para entrar en un depósito expuesto.

## e5-fina-canada

**Institución:** Avalanche Canada

**Título:** Fine Search — AvySavvy

**URL:** https://avysavvy.avalanche.ca/en-ca/fine-search

**Consulta:** 2026-10-22

**Tema respaldado:** Búsqueda fina: precisión y transición a la sonda

**Relación curricular:** dva-fina

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Ejemplo de búsqueda fina por acotación. Algunos equipos añaden ayudas diferentes; practicar con el modelo exacto.

## e5-bca-manual

**Institución:** Backcountry Access / K2 Sports

**Título:** Tracker4 / Tracker3+ / Tracker S — Owner’s Manual

**URL:** https://k2sports.a.bigcontent.io/v1/static/2021_BCA_Tracker_Manual_T4T3%2BTS_021621

**Consulta:** 2026-10-22

**Tema respaldado:** Aproximación: seguir una señal sin perder el escenario; Múltiples señales, marcación y límites del dispositivo

**Relación curricular:** dva-aproximacion, dva-multiples

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Manual multilingüe de estos modelos y edición. Las funciones de supresión, marcación, retorno a emisión y mandos no son universales.

## e5-bca-multiples

**Institución:** Backcountry Access

**Título:** Advanced Multiple Burial Modes: Signal Suppression and Big Picture

**URL:** https://backcountryaccess.com/en-us/blog/p/tracker-advanced-multiple-burial-modes-signal-suppression-big-picture

**Consulta:** 2026-10-22

**Tema respaldado:** Múltiples señales, marcación y límites del dispositivo

**Relación curricular:** dva-multiples

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Explicación de funciones avanzadas de Tracker; requiere dominio previo de un sepultamiento y práctica específica. No equivale a triaje médico.

## e5-sonda-canada

**Institución:** Avalanche Canada

**Título:** Probing — AvySavvy

**URL:** https://avysavvy.avalanche.ca/en-ca/probing

**Consulta:** 2026-10-22

**Tema respaldado:** Búsqueda fina: precisión y transición a la sonda; Sonda: confirmación espacial y lectura del contacto

**Relación curricular:** dva-fina, sonda

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Sondaje tras búsqueda fina en rescate de compañeros; no es el mismo procedimiento que una línea organizada de sondaje.

## e5-sonda-ortovox

**Institución:** ORTOVOX

**Título:** Avalanche Probe Guide

**URL:** https://www.ortovox.com/us-en/shop/emergency-equipment/advisor/avalanche-probe-guide/

**Consulta:** 2026-10-22

**Tema respaldado:** Sonda: confirmación espacial y lectura del contacto

**Relación curricular:** sonda

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Guía comercial del fabricante sobre componentes y sistemas. No se reproducen sus estadísticas de tiempo como promesas; consultar manual exacto.

## e5-sonda-icar

**Institución:** ICAR Avalanche Rescue Commission

**Título:** Organized Avalanche Rescue Probing Strategies — updated2025

**URL:** https://www.alpine-rescue.org/articles/1682--organized-avalanche-rescue-probing-strategies-2015-updated-2025

**Consulta:** 2026-10-22

**Tema respaldado:** Sonda: confirmación espacial y lectura del contacto; Rescate en avalancha: escena, grupo y continuidad de la atención

**Relación curricular:** sonda, rescate-avalancha

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Aplicable a equipos organizados; sus longitudes y patrones no constituyen una receta para un grupo sin capacitación.

## e5-pala-canada

**Institución:** Avalanche Canada

**Título:** Shovelling — AvySavvy

**URL:** https://avysavvy.avalanche.ca/en-ca/shovelling

**Consulta:** 2026-10-22

**Tema respaldado:** Pala y excavación estratégica: acceso, transporte y relevo

**Relación curricular:** excavacion

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Modelo de transporte de nieve y relevo; adaptar con instructor al número de personas, profundidad y terreno.

## e5-pala-ortovox

**Institución:** ORTOVOX

**Título:** Avalanche Shovel Guide

**URL:** https://www.ortovox.com/us-en/shop/emergency-equipment/advisor/avalanche-shovel-guide/

**Consulta:** 2026-10-22

**Tema respaldado:** Pala y excavación estratégica: acceso, transporte y relevo

**Relación curricular:** excavacion

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Describe componentes y funciones de pala. No se adoptan tiempos de rescate o equivalencias de volumen de sus ejemplos comerciales.

## e5-wms-enterramiento

**Institución:** Wilderness Medical Society / Van Tilburg y colaboradores

**Título:** Clinical Practice Guidelines for Prevention and Management of Avalanche and Nonavalanche Snow Burial Accidents:2024 Update

**URL:** https://journals.sagepub.com/doi/full/10.1016/j.wem.2023.05.014

**Consulta:** 2026-10-22

**Tema respaldado:** Pala y excavación estratégica: acceso, transporte y relevo; Rescate en avalancha: escena, grupo y continuidad de la atención

**Relación curricular:** excavacion, rescate-avalancha

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Guía clínica: sirve de referencia para formación médica. Esta academia no reproduce algoritmos de reanimación, triaje o decisión de no reanimar. Revisión clínica local pendiente.

## e5-wms-resumen-avalancha

**Institución:** Wilderness Medical Society

**Título:** 2024 Avalanche Summary

**URL:** https://wms.org/magazine/magazine/1487/2024-Avalanche-Summary/default.aspx

**Consulta:** 2026-10-22

**Tema respaldado:** Rescate en avalancha: escena, grupo y continuidad de la atención

**Relación curricular:** rescate-avalancha

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Resumen institucional; no sustituye el artículo completo ni formación WFR o médica. No se extrapolan porcentajes ni tiempos de supervivencia.

## e5-ms-crampon

**Institución:** Mountaineering Scotland

**Título:** Crampons: which crampons are suitable for me?

**URL:** https://www.mountaineering.scot/activities/mountaineering/winter-mountaineering/getting-started/crampons

**Consulta:** 2026-10-22

**Tema respaldado:** Función, tipos y compatibilidad

**Relación curricular:** cramponaje, equipo-invernal

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Clasificación británica orientativa; no sustituye comprobación de modelo y bota ni se presenta como norma chilena.

## e5-petzl-lynx

**Institución:** Petzl

**Título:** LYNX — modular crampons

**URL:** https://www.petzl.com/LU/en/Sport/Crampons/LYNX

**Consulta:** 2026-10-22

**Tema respaldado:** Ejemplo de crampones técnicos y antiacumulación

**Relación curricular:** cramponaje

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Producto específico; no justifica su elección para una ruta. Manual exacto del equipo del usuario pendiente.

## e5-ms-winter

**Institución:** Mountaineering Scotland / Glenmore Lodge

**Título:** ThinkWINTER: Winter skills

**URL:** https://www.mountaineering.scot/safety-and-skills/thinkwinter/winter-skills

**Consulta:** 2026-10-22

**Tema respaldado:** Práctica presencial de progresión, piolet y autodetención

**Relación curricular:** cramponaje, piolet, autodetencion

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Página introductoria y material audiovisual; no acredita dominio ni valida terreno de práctica.

## e5-bmc-arrest

**Institución:** British Mountaineering Council

**Título:** Walking boots, crampons and micro spikes

**URL:** https://www.thebmc.co.uk/en/walking-boots-crampons-micro-spikes

**Consulta:** 2026-10-22

**Tema respaldado:** Limitaciones de autodetención

**Relación curricular:** autodetencion

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Extracto oficial indexado consultado; lectura directa respondió403. No se reproduce secuencia técnica ni se presenta acceso completo al manual.

## e5-grivel-gzero

**Institución:** Grivel

**Título:** G Zero — Classic ice axe

**URL:** https://grivel.com/products/g-zero

**Consulta:** 2026-10-22

**Tema respaldado:** Ejemplo de piolet de marcha

**Relación curricular:** piolet, equipo-invernal

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Página actual de producto; confirmar referencia, generación y manual del material efectivamente adquirido. No se recomienda automáticamente.

## e5-petzl-piolet

**Institución:** Petzl

**Título:** Mountaineering and walking axes — technical notice

**URL:** https://www.petzl.com/sfc/servlet.shepherd/version/download/068w0000002EOXOAA4

**Consulta:** 2026-10-22

**Tema respaldado:** Inspección de piolets

**Relación curricular:** piolet

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Extracto técnico oficial indexado. Solo se usan criterios de inspección visibles; no se extrapolan periodicidad ni capacidades a otras marcas.

## e5-msr-raquetas

**Institución:** Cascade Designs / MSR

**Título:** How do I choose the right snowshoes?

**URL:** https://support.cascadedesigns.com/hc/en-us/articles/35377000303123-How-do-I-choose-the-right-snowshoes

**Consulta:** 2026-10-22

**Tema respaldado:** Flotación, peso total y elección de raquetas

**Relación curricular:** raquetas

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Guía de fabricante para su gama. No implica que cualquier raqueta sirva para cualquier pendiente.

## e5-sac-raquetas

**Institución:** Swiss Alpine Club SAC

**Título:** Safety when snowshoeing

**URL:** https://www.sac-cas.ch/en/training-and-safety/safety/safety-when-snowshoeing/

**Consulta:** 2026-10-22

**Tema respaldado:** Planificación y formación de raquetas

**Relación curricular:** raquetas

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Contexto alpino suizo; no traslada números de emergencia ni normativa a Chile.

## e5-sac-esqui

**Institución:** Swiss Alpine Club SAC

**Título:** Safety when ski touring

**URL:** https://www.sac-cas.ch/en/training-and-safety/safety/safety-when-ski-touring/

**Consulta:** 2026-10-22

**Tema respaldado:** Preparación, capacidad del grupo y equipo en esquí de montaña

**Relación curricular:** esqui-introduccion, equipo-invernal

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Contexto suizo; recomendaciones educativas, no habilitación de guía ni reglamento chileno.

## e5-fis-conducta

**Institución:** International Ski and Snowboard Federation

**Título:** FIS Code of Conduct for Skiers and Snowboarders

**URL:** https://assets.fis-ski.com/f/252177/49280306c8/fis-code-of-conduct-for-skiers-and-snowboarders-en.pdf

**Consulta:** 2026-10-22

**Tema respaldado:** Control de velocidad y conducta en pista

**Relación curricular:** esqui-introduccion

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Código de conducta; no reemplaza reglas del centro, legislación local ni formación técnica.

## e5-frio-cdc

**Institución:** Centers for Disease Control and Prevention

**Título:** Preventing Hypothermia

**URL:** https://www.cdc.gov/winter-weather/prevention/index.html

**Consulta:** 2026-10-22

**Tema respaldado:** Reconocimiento de signos y prevención de enfriamiento

**Relación curricular:** frio-fisiologia

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Educación general; no protocolo WFR ni diagnóstico. No se incluyen dosis o algoritmos de tratamiento.

## e5-nws-cold

**Institución:** National Weather Service / NOAA

**Título:** Wind Chill Questions

**URL:** https://www.weather.gov/safety/cold-faqs

**Consulta:** 2026-10-22

**Tema respaldado:** Índice de enfriamiento y límites del modelo

**Relación curricular:** frio-fisiologia

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Índice de piel expuesta; no temperatura corporal, tiempo de supervivencia ni temperatura de objetos. Fórmula requiere unidades y dominio especificados.

## e5-heat-openstax

**Institución:** OpenStax — Anatomy and Physiology

**Título:** 24.6 Energy and Heat Balance

**URL:** https://openstax.org/books/anatomy-and-physiology/pages/24-6-energy-and-heat-balance

**Consulta:** 2026-10-22

**Tema respaldado:** Termorregulación y transferencia térmica

**Relación curricular:** frio-fisiologia

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Referencia conceptual; no se reproducen porcentajes generales de pérdidas como reglas de montaña. No se reutilizan figuras.

## e5-ms-kit

**Institución:** Mountaineering Scotland

**Título:** Mountaineering clothing and equipment

**URL:** https://www.mountaineering.scot/activities/mountaineering/winter-mountaineering/getting-started/clothing

**Consulta:** 2026-10-22

**Tema respaldado:** Funciones de ropa, protección y reservas

**Relación curricular:** equipo-invernal

**Alcance:** Fuente primaria técnica / educativa

**Limitaciones:** Lista contextual de Escocia; no inventario universal ni sustituto de evaluación del equipo real.

## e5-decision

**Institución:** Avalanche.org

**Título:** Decision Making

**URL:** https://avalanche.org/avalanche-encyclopedia/human/decision-making/

**Consulta:** 2026-10-22

**Tema respaldado:** Planificación, discusión de incertidumbre y alternativas

**Relación curricular:** planificacion-invernal, grupo-invernal, casos-invernales, casos-regionales-invierno

**Alcance:** Fuente técnica primaria

**Limitaciones:** Proceso general de decisiones; no establece exposición aceptable, normativa chilena ni una ruta.

## e5-daily

**Institución:** Avalanche Canada

**Título:** AvySavvy — The Daily Process

**URL:** https://avysavvy.avalanche.ca/en-ca/the-daily-process

**Consulta:** 2026-10-22

**Tema respaldado:** Comunicación y selección del grupo

**Relación curricular:** planificacion-invernal, grupo-invernal, casos-invernales, casos-regionales-invierno

**Alcance:** Fuente educativa institucional

**Limitaciones:** Formación canadiense; no trasladar recomendaciones de tamaño de grupo a ratios legales de guiado en Chile.

## e5-senapred-invierno

**Institución:** SENAPRED

**Título:** Invierno

**URL:** https://www.senapred.cl/invierno/

**Consulta:** 2026-10-22

**Tema respaldado:** Consulta meteorológica y prevención

**Relación curricular:** planificacion-invernal, grupo-invernal, casos-invernales, casos-regionales-invierno

**Alcance:** Recomendación oficial de prevención

**Limitaciones:** Recomendación general; no es boletín nivológico ni autorización para una salida.
