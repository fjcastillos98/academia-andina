# Etapa 5 — Montaña invernal

Entrega local de desarrollo, 23-10-2026. Versión 0.5.0. No se hizo push, deploy ni cambio al manual original. La academia continúa en desarrollo y revisión; esta entrega no acredita competencias profesionales.

## Alcance implementado

Se amplían los módulos existentes M02 y M09 y sus relaciones con meteorología, medicina introductoria, riesgo, grupo, equipo y emergencias. **No se crea ni renumera un módulo histórico.** La ruta invierno contiene 26 unidades y 29 lecciones progresivas; la búsqueda DVA se distribuye en cuatro lecciones.

| Elemento | Añadido | Total actual |
| --- | ---: | ---: |
| Módulos | 0 | 24 |
| Entradas históricas pendientes | 0 | 376 |
| Unidades | 26 | 59 |
| Lecciones y quizzes versionados | 29 | 84 |
| Habilidades | 29 | 81 |
| Rutas de aprendizaje | 1 | 6 |
| Casos | 12 | 27 |
| Fuentes | 53 | 129 |
| Diagramas SVG | 15 | 32 |

Las lecciones incorporan objetivos, prerrequisitos, desarrollo, reconocimiento y límites, errores, caso, práctica supervisada propuesta, evidencia requerida, fuentes y pendientes. Añaden 87 preguntas con explicación por alternativa y 29 respuestas abiertas con rúbrica. El laboratorio incluye nueve cálculos; la lección de terreno añade una pregunta interactiva y cinco preguntas de transferencia.

La planificación invernal incluye 21 apartados persistentes y checklist imprimible. Nueve plantillas preparan el diario sin declarar resultados. Dieciséis fichas de equipo describen función, limitaciones, inspección, compatibilidad, mantenimiento y práctica. La matriz diferencia observación contextual declarada de evaluación lograda declarada. La plataforma no autentica instructores ni certifica competencias.

## Secuencia

| Código | Unidad | Lección |
| --- | --- | --- |
| E5-01 | U5-01 | [Montaña invernal: cambia el sistema de decisiones](../../src/content/lecciones/invierno-fundamentos.md) |
| E5-02 | U5-02 | [Física de la nieve: estructura, agua y transformación](../../src/content/lecciones/nieve-propiedades.md) |
| E5-03 | U5-03 | [Nivología: leer capas, interfaces y evolución](../../src/content/lecciones/nivologia.md) |
| E5-04 | U5-04 | [Avalanchas: mecanismos, problemas y consecuencias](../../src/content/lecciones/avalancha-tipos.md) |
| E5-05 | U5-05 | [Leer terreno: pendiente, conexión y exposición](../../src/content/lecciones/terreno-avalancha.md) |
| E5-06 | U5-06 | [Meteorología invernal: procesos y decisiones encadenadas](../../src/content/lecciones/meteo-invernal.md) |
| E5-07 | U5-07 | [Boletines: leer cobertura, problema y validez](../../src/content/lecciones/boletines-avalancha.md) |
| E5-08 | U5-08 | [DVA: transmisión, búsqueda y comprobaciones](../../src/content/lecciones/dva-fundamentos.md) |
| E5-09 | U5-09 | [Búsqueda de señal: cobertura y lectura de escena](../../src/content/lecciones/dva-senal.md) |
| E5-10 | U5-09 | [Aproximación: seguir una señal sin perder el escenario](../../src/content/lecciones/dva-aproximacion.md) |
| E5-11 | U5-09 | [Búsqueda fina: precisión y transición a la sonda](../../src/content/lecciones/dva-fina.md) |
| E5-12 | U5-09 | [Múltiples señales, marcación y límites del dispositivo](../../src/content/lecciones/dva-multiples.md) |
| E5-13 | U5-10 | [Sonda: confirmación espacial y lectura del contacto](../../src/content/lecciones/sonda.md) |
| E5-14 | U5-11 | [Pala y excavación estratégica: acceso, transporte y relevo](../../src/content/lecciones/excavacion.md) |
| E5-15 | U5-12 | [Rescate en avalancha: escena, grupo y continuidad de la atención](../../src/content/lecciones/rescate-avalancha.md) |
| E5-16 | U5-13 | [Factores humanos: reconocer presión antes de decidir](../../src/content/lecciones/factores-humanos-invierno.md) |
| E5-17 | U5-14 | [Cramponaje: compatibilidad y elección de apoyos](../../src/content/lecciones/cramponaje.md) |
| E5-18 | U5-15 | [Piolet: herramienta, terreno y función](../../src/content/lecciones/piolet.md) |
| E5-19 | U5-16 | [Autodetención: reconocer límites antes de una caída](../../src/content/lecciones/autodetencion.md) |
| E5-20 | U5-17 | [Raquetas: flotación, tracción y límites de terreno](../../src/content/lecciones/raquetas.md) |
| E5-21 | U5-18 | [Esquí de pista y de montaña: una transición de responsabilidades](../../src/content/lecciones/esqui-introduccion.md) |
| E5-22 | U5-19 | [Planificación invernal: convertir información en límites](../../src/content/lecciones/planificacion-invernal.md) |
| E5-23 | U5-20 | [3×3 invernal: nueve cruces, decisiones revisables](../../src/content/lecciones/tres-por-tres-invernal.md) |
| E5-24 | U5-21 | [Matriz de riesgo: controles, incertidumbre y retirada](../../src/content/lecciones/matriz-riesgo-invernal.md) |
| E5-25 | U5-22 | [Guiado invernal: ritmo, comunicación y retirada](../../src/content/lecciones/grupo-invernal.md) |
| E5-26 | U5-23 | [Frío: balance térmico, signos y decisiones](../../src/content/lecciones/frio-fisiologia.md) |
| E5-27 | U5-24 | [Equipo invernal: sistema personal y colectivo](../../src/content/lecciones/equipo-invernal.md) |
| E5-28 | U5-25 | [Decisiones invernales: doce problemas para integrar](../../src/content/lecciones/casos-invernales.md) |
| E5-29 | U5-26 | [Los Lagos en invierno: límites de un escenario regional](../../src/content/lecciones/casos-regionales-invierno.md) |

## Verificación real

- `npm ci`: completado; registro en logs/npm-ci.log.
- `npm run check`: 61 archivos, 0 errores, 0 advertencias, 0 hints.
- `npm test`: 57 tests, 57 aprobados, 0 fallos. Once nuevos tests cubren conservación histórica, relaciones, quizzes, casos, fichas, ejercicios, planes, estados, búsquedas y migraciones. Los tests anteriores cubren inventario y persistencia.
- `npm run build`: 166 páginas, sin errores.
- `npm run test:build`: 4546 enlaces/recursos internos y 547 resultados de búsqueda verificados.
- `node scripts/check-winter-build.mjs`: 45 páginas nuevas, 1951 enlaces/recursos y sus anclas verificados.
- Los dos últimos controles pasan tanto con base `/` como `/academia-andina/`.
- Navegación, búsqueda, quiz correcto/incorrecto, nota y plan tras recarga, plantilla/registro de diario, importación v1/v3, error JSON, cálculos y terreno comprobados en navegador. Ver qa-navegador.md para evidencia y alcance.
- Diseño revisado en escritorio y contenedor de 390 px; salto por teclado comprobado.

**Límite de QA:** el navegador bloqueó la descarga de exportación JSON por política de protocolos. La lógica de serialización/restauración pasa tests, pero el ciclo completo de descarga y reimportación queda pendiente en un navegador local. La importación se comprobó con archivos de prueba independientes. La impresión PDF no se verificó.

## Fuentes y revisión pendiente

Bibliografía completa en fuentes.md, con institución, título, URL, consulta, tema y límites. Entre las organizaciones: SLF/KAT, EAWS, Avalanche Canada, Avalanche.org, ICAR, Mammut, Black Diamond, Petzl, BMC, NWS, CDC, UBC, OpenStax, DMC y SENAPRED. No se atribuye a un fabricante una compatibilidad que dependa de un modelo no identificado. Algunas páginas son índices o introducciones: su alcance limitado está declarado.

Todo el bloque requiere revisión pedagógica y de instructor. Prioridad: DVA, sondaje, excavación, rescate, cramponaje, piolet y autodetención. Fisiología del frío y relación WFR requieren revisión sanitaria; no son protocolo clínico ni sustituto de atención profesional. Los diagramas son conceptuales, no planos de montaje ni secuencias operativas completas.

Los doce casos regionales son **hipotéticos**. Permanecen pendientes cobertura/validez de boletines locales, condiciones de nieve, meteorología, accesos, permisos, itinerarios, dificultad y recursos de rescate actuales. Ningún caso verifica condiciones de Osorno, Calbuco, Casablanca, Yates, Tronador o Puntiagudo.

## Ejecutar y comprobar

Node.js 24 LTS. Desde la carpeta academia extraída:

```bash
npm ci
npm run dev
```

Abrir la dirección local que indique Astro, normalmente http://localhost:4321/invierno/.

```bash
npm run check
npm test
npm run build
npm run test:build
node scripts/check-winter-build.mjs
BASE_PATH=/academia-andina/ npm run build
BASE_PATH=/academia-andina/ npm run test:build
BASE_PATH=/academia-andina/ node scripts/check-winter-build.mjs
```

El archivo ZIP contiene fuentes y documentación, sin node_modules ni dist. Consultar ARCHIVOS.md para el listado de cambios frente a la entrega 4.5. Las entregas ZIP anteriores se conservan en el espacio de trabajo; no se anidan dentro del ZIP nuevo.

## Próximo bloque propuesto

Etapa 5.1: revisión de instructor de los siete núcleos técnicos, revisión WFR, comparación con manuales de los modelos reales y prueba local de descarga/impresión. Registrar cada observación con fecha, fuente y cambio; versionar las evaluaciones si cambian. Después, desarrollar el bloque glaciar siguiendo este modelo y sus prerrequisitos, sin anticipar competencias prácticas.
