# Archivos de la academia

Todo el trabajo de Etapa 2 está dentro de `academia/`. `data/curriculum.json` es el archivo preparado anteriormente y se conserva sin cambios. Los demás archivos de esta lista se crearon en esta etapa.

```text
academia/
  .gitignore
  CONTRIBUTING.md
  README.md
  astro.config.mjs
  data/curriculum.json
  docs/decisiones.md
  docs/github-pages.yml.example
  docs/verificacion-etapa2.md
  package-lock.json
  package.json
  public/favicon.svg
  scripts/check-build.mjs
  scripts/validate.ts
  src/components/LessonCard.astro
  src/content/lecciones/aprender-con-evidencia.md
  src/content/lecciones/leer-curvas-de-nivel.md
  src/content/lecciones/planificar-con-impacto.md
  src/content.config.ts
  src/data/glossary.json
  src/data/sources.json
  src/layouts/Layout.astro
  src/lib/catalog.ts
  src/lib/client.ts
  src/lib/learning.ts
  src/lib/schemas.ts
  src/lib/state.ts
  src/pages/404.astro
  src/pages/buscar.astro
  src/pages/cuaderno.astro
  src/pages/fuentes.astro
  src/pages/glosario.astro
  src/pages/index.astro
  src/pages/learning-data.json.ts
  src/pages/lecciones/[id].astro
  src/pages/modulos/[id].astro
  src/pages/modulos/index.astro
  src/pages/search-index.json.ts
  src/styles/global.css
  tests/core.test.ts
  tsconfig.json
  docs/arbol-archivos.md
```

Generados y excluidos del paquete: node_modules/, .astro/, dist/. La entrega no contiene datos del navegador, credenciales ni el manual original.
