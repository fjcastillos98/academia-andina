# Academia Andina Filo Austral · Etapas 5.1 y 6 — Revisión y glaciar

Plataforma estática en español para estudio personal. Astro 7.4.2, TypeScript, Markdown y Zod. Implementación independiente dentro de `academia/`: no modifica el manual de Chiloé. No se ha publicado ni hecho push.

## Requisitos y ejecución

Node.js 24 LTS y npm. Desde esta carpeta:

```bash
npm ci
npm run dev
```

Abrir http://localhost:4321/ (o el puerto que imprima Astro). No abrir `index.html` con `file://`. En el entorno de pruebas de ChatGPT se utiliza el supervisor de preview; no es un requisito del proyecto descargado.

```bash
npm run check       # TypeScript y componentes Astro
npm run validate    # Alcance curricular, frontmatter y apartados
npm test            # Pruebas automatizadas de dominio y persistencia
npm run build       # Validación + generación estática en dist/
npm run test:build  # Enlaces y recursos del build
npm run preview    # Servir el resultado, normalmente puerto 4321
```

## Qué incluye

- Portada con progreso, 24 páginas de asignatura, 376 entradas pendientes y 94 lecturas: 84 anteriores preservadas y 10 nuevas glaciares en desarrollo.
- Catálogo filtrable, navegación anterior/siguiente y búsqueda en títulos, descripción y cuerpo; normaliza tildes y mayúsculas.
- Glosario inicial de 8 términos y biblioteca de fuentes.
- Noventa y cuatro cuestionarios versionados con explicaciones, historial de hasta 10.000 intentos por lección (sin descarte automático; limitado además por los 2 MB del respaldo) y criterio teórico explícito (todas correctas).
- Notas de hasta 10.000 caracteres, favoritos y estudio local; exportación/importación JSON con validación y confirmación.
- Interfaces semánticas, foco visible, enlace para saltar al contenido, formularios etiquetados y reducción de movimiento. Diseño adaptable; no es una certificación WCAG.

Las 376 entradas son un mapa de alcance, no 376 lecciones. Algunas describen requisitos de fichas (por ejemplo, campos de montañas). Ni el piloto ni las muestras cambian los estados pendientes del mapa.

## Datos y privacidad

Se usa **localStorage**, en lugar de IndexedDB propuesto en la auditoría, porque esta etapa guarda un pequeño objeto de texto. Se encapsula en `src/lib/state.ts` para permitir migración posterior. Clave: `filo-austral:academia:v1:<ruta-base>`; queda vinculada al navegador y origen. No hay cuenta, backend, sincronización entre dispositivos ni cifrado. Evitar edición simultánea en varias pestañas: no hay resolución de conflictos.

Las notas se guardan al pulsar **Guardar nota**. No introducir datos médicos, contraseñas o información de pasajeros. Los registros no se incluyen en el build ni en el repositorio. Todos los textos importados se presentan como texto, no HTML. Los errores de lectura o cuota se avisan; no se resetea silenciosamente un estado corrupto.

Exportar antes de cambiar navegador, dirección/base o borrar almacenamiento. Importación: archivo máximo 2 MB, formato/versión estrictos, identificadores conocidos y respuestas válidas. Revisar el resumen y confirmar; reemplaza el estado anterior. El respaldo versión 3 incluye hasta 500 prácticas, 500 equipos con inspecciones y respuestas abiertas; importa y migra versiones 1 y 2 sin perder estudio. La primera escritura de datos antiguos guarda una copia local bajo la clave adicional `:before-v3`. Exporta también una copia externa. Se conserva la clave local v1 para leer los datos anteriores. Una evaluación declarada exige supervisor, evaluador, fecha, criterio y evidencia; no verifica credenciales ni certifica competencias. Es un cuaderno personal, no un registro inviolable de certificaciones.

## Estructura

- `data/curriculum.json`: currículo v2 ampliable, con las 376 entradas históricas conservadas; original exacto en `data/archive/curriculum.v1.json`.
- `src/content/lecciones/*.md`: texto y metadatos JSON en frontmatter YAML compatible.
- `src/content.config.ts`, `src/lib/schemas.ts`: colección y validación.
- `src/data/`: fuentes y glosario.
- `src/pages/`: páginas estáticas y índices JSON generados.
- `src/layouts/`, `src/components/`, `src/styles/`: interfaz.
- `src/lib/learning.ts`: búsqueda, corrección y estado teórico.
- `src/lib/state.ts`: persistencia y respaldo.
- `src/lib/client.ts`: interacciones accesibles de navegador.
- `scripts/`, `tests/`: validación y pruebas.
- `docs/`: decisiones, verificación y plantilla de publicación inactiva.

## Rutas base y GitHub Pages

Se recomienda un **repositorio independiente** llamado, por ejemplo, `academia-andina`, con el contenido de esta carpeta en su raíz. No copiar el workflow al repositorio del manual: desplegar solo `academia/dist` sobre el sitio del manual lo reemplazaría.

Comprobar localmente una base de proyecto (bash):

```bash
BASE_PATH=/academia-andina/ npm run build
BASE_PATH=/academia-andina/ npm run test:build
BASE_PATH=/academia-andina/ npm run preview
```

Abrir la ruta `/academia-andina/` del servidor de preview. Usar la misma base al compilar y servir. `BASE_PATH` debe comenzar y terminar con `/`. En PowerShell: `$env:BASE_PATH='/academia-andina/'`, ejecutar los comandos npm y luego `Remove-Item Env:BASE_PATH`. Para dominio propio o raíz, usar `/`.

`SITE_URL` configura el origen (predeterminado: `https://fjcastillos98.github.io`), **no** implica que exista publicación. Enlaces, búsqueda, índices JSON y favicon utilizan la base. Assets de Astro se prefijan automáticamente.

`docs/github-pages.yml.example` es una plantilla **inactiva** para un futuro repositorio separado. Solo tras autorización: copiarla a `.github/workflows/pages.yml` en ese nuevo repositorio, configurar Pages con GitHub Actions y ejecutarla manualmente. No contiene secretos. Revisa las versiones de acciones al activarla. Este trabajo no cambió el remoto ni activó ningún workflow.

## Contenidos y límites

Consultar `CONTRIBUTING.md`. Fuentes: SLF/KAT, OMM, USGS, NPS, NWS, Leave No Trace, UIAA, Petzl y Garmin; DMC como portal oficial de consulta, sin pronóstico local validado. Consulta documental: 21–22-10-2026. El modelo de evidencias es un criterio editorial propio. Los diez temas del piloto requieren revisión de instructor; nudos y anclajes preparan talleres supervisados, sin secuencias operativas para aplicar sin formación.

El diario guarda declaraciones personales de práctica y evaluación, con evidencia textual y una matriz de 81 habilidades. No hay verificación de instructor, matriz profesional completa, calendario, plan deportivo adaptativo, atención médica personalizada ni normativa vigente. Todo eso pertenece a etapas posteriores. Ningún cuestionario certifica una maniobra. La licencia de distribución del conjunto sigue pendiente; no se ha añadido LICENSE.

## Etapa 3: secuencia y diario

Abrir `/fundamentales/`: A riesgo → B 3×3 → C planificación → D meteorología → E nubes → F navegación → G equipo → H nudos → I cuerdas/anclajes → J comunicaciones. Los prerrequisitos orientan la secuencia, sin bloquear el acceso ni acreditar preparación práctica. `pilot.position`, `requires`, `critical`, `classifications`, `relatedModules` y `criteria` mantienen la estructura. El mapa original no se renumera.

`/practicas/` permite registrar y editar prácticas, consultar criterios y ver la matriz. Un quiz nunca actualiza una competencia. Solo las evaluaciones declaradas con todos los campos completados afectan esa columna; prevalece la evaluación más reciente y, si el mismo día hay resultados contradictorios, se muestra «En desarrollo». No hay caducidad automática ni acreditación externa. La evidencia es texto, no adjuntos.

Ver `docs/verificacion-etapa3.md` para resultados reales, `docs/etapa3.md` para alcance y pendientes, y `docs/archivos-etapa3.md` para archivos.


## Ampliación de Etapa 4

- `/programa/`: rutas, unidades, habilidades y dependencias futuras.
- `/casos/`: quince simulaciones de Calbuco, Osorno, Casablanca, Yates y cordillera de Los Lagos.
- `/planificacion/`: plantilla antes/durante/después, imprimible, sin persistencia automática ni ficha médica.
- `/equipo/`: inventario, vida útil declarada, manual, retiro e inspecciones acumulativas.
- `/practicas/`: 52 habilidades, objetivo/resultado/autonomía y vínculos con el inventario.
- `data/skills.json`, `data/learning-paths.json`: habilidades y rutas independientes del piloto.
- `src/data/assessments/`: preguntas versionadas. Nunca sobrescribir una versión usada: crear otra y conservar la anterior. Los intentos se corrigen con su versión histórica.
- `src/lib/program.ts`: integridad de referencias cruzadas; `src/lib/migrations/curriculum.ts`: migración pura v1→v2.
- `tests/etapa4.test.ts`: ampliación, migraciones, estados, equipo y referencias.
- `docs/etapa4/INFORME.md`: resultados, límites y etapa siguiente; `ARCHIVOS.md`: cambios respecto de la entrega anterior.

Los cinco estados se calculan sobre evidencia declarada. «COMPETENTE VALIDADO» exige una evaluación presencial declarada y contextualizada: no verifica identidad ni credenciales, no certifica ni habilita para guiar. Un quiz solo indica comprensión teórica. Los estados de contenido (pendiente, piloto, en desarrollo) son independientes.

Las respuestas abiertas se guardan manualmente y requieren revisión humana. El inventario no calcula caducidad ni declara material apto. No hay adjuntos de evidencia, firma de instructor ni registro inmutable. La edición de una práctica conserva su ID pero actualiza sus campos; exporta respaldos si necesitas conservar cada revisión. La importación reemplaza los datos tras mostrar un resumen: no fusiona copias.

Validación de esta entrega: `npm ci`, `npm run check`, `npm test`, build y comprobación de rutas en `/` y `/academia-andina/`. Los registros reales están en `docs/etapa4/*.log`. Las instrucciones y resultados de etapas anteriores se conservan como historia, no describen los totales actuales.

## Etapas 4.3, 4.4 y 4.5

Tres rutas nuevas, 22 unidades, 31 lecciones y 31 habilidades: fundamentos de cuerda, rescate conceptual y territorio. Incluye 10 lecciones independientes de nudos, 17 diagramas SVG, 31 respuestas abiertas con rúbricas, 6 problemas numéricos, 10 casos integradores, 7 fichas de montaña y 5 especies. `/territorio/` y `/especies/` distinguen datos documentales de información operativa pendiente.

El diario añade ejercicios, observaciones y próxima práctica; el inventario muestra fechas de uso derivadas de prácticas vinculadas. El respaldo v3 anterior admite estos campos nuevos con valores vacíos, conservando información previa.

Informe y archivos: `docs/etapa4/etapa4.3-4.4-4.5.md`. Pruebas nuevas: `tests/etapa435.test.ts`. Los datos territoriales, casos y diagramas se validan en `src/lib/territory.ts` y `src/lib/expanded.ts`. Modelos numéricos: `src/lib/mechanics.ts`. Registros de verificación en `docs/etapa4/etapa435/`.


## Etapa 5 — Montaña invernal

Ruta `/invierno/`: 26 unidades, 29 lecciones, 29 habilidades, 87 preguntas de quiz y 29 respuestas abiertas con rúbrica. Incluye 12 casos hipotéticos, 15 diagramas originales, 16 fichas educativas de equipo y 53 nuevas referencias documentales. Se amplían los módulos existentes sin eliminar las 376 entradas históricas.

- `/invierno/planificacion/`: plan de 21 apartados, guardado manual en el respaldo v3 y checklist para imprimir. Las casillas de la checklist no persisten.
- `/invierno/ejercicios/`: nueve cálculos con corrección; respuestas abiertas guardables. Los resultados numéricos no se registran como competencia.
- `/invierno/equipo/`: fichas de función, límites, inspección, compatibilidad, mantenimiento y práctica; inventario personal separado en `/equipo/`.
- `/practicas/`: nueve plantillas para preparar campos vacíos. Observación contextual y evaluación declarada aparecen por separado.

`src/lib/winter.ts` valida los nuevos datos y modelos; `src/lib/winter-client.ts` conecta la planificación al estado existente. `tests/etapa5.test.ts` comprueba integridad, conservación histórica, ejercicios y compatibilidad. Tras un build, ejecutar también `node scripts/check-winter-build.mjs`; para una base de proyecto, anteponer `BASE_PATH=/academia-andina/`.

Informe: `docs/etapa5/etapa5.md`; bibliografía y límites: `docs/etapa5/fuentes.md`; auditoría: `docs/etapa5/auditoria.md`. No hay boletín local ni rutas operativas validadas. DVA, rescate, cramponaje, piolet y autodetención requieren instrucción presencial. El contenido continúa en desarrollo y revisión.

## Etapas 5.1 y 6 · versión 0.6.0

Ocho estaciones de revisión documental en `/invierno/revision/`, acta local y suplementos visibles en las lecciones afectadas. La revisión presencial no se ha realizado. Diez unidades glaciares en `/glaciar/`, treinta preguntas nuevas, diez respuestas razonadas, cinco plantillas de práctica y tres diagramas originales. Total: 69 unidades, 91 habilidades y 7 rutas de aprendizaje.

Las fuentes y límites de cada unidad se muestran en su página. El inventario DGA no sustituye condiciones actuales; las variantes de cordada no son una configuración universal. La compatibilidad del equipo exacto, la observación de maniobras y su evaluación siguen pendientes.

Ver `docs/etapa6/INFORME.md`, `FUENTES.md` y `ARCHIVOS.md`. Prueba adicional de rutas y anclas del bloque:

```bash
node scripts/check-glacier-build.mjs
BASE_PATH=/academia-andina/ npm run build
BASE_PATH=/academia-andina/ npm run test:build
BASE_PATH=/academia-andina/ node scripts/check-glacier-build.mjs
```

No se ha publicado ni modificado el remoto.
