# Fuentes y alcance · Etapa 7

Consulta: 25 de octubre de 2026. Las referencias sustentan contenidos concretos, no certifican el currículo ni el equipo personal. Los casos y rúbricas son propuestas pedagógicas originales pendientes de revisión docente.

## Petzl / Fondation Petzl / LGGE — Waterfall ice study

https://www.petzl.com/no/en/sport/tech-tips/basic-techniques/waterfall-ice-study/glace-etude-fondation_SPO_a77w0000000KyoQAAS.html

Apoya: Variaciones térmicas generan tensiones; enfriamiento rápido favorece fracturas; agua en interfaz puede separar hielo y roca.

Límites: Síntesis de un estudio, no umbrales operativos universales. Una temperatura aislada no determina estabilidad. No extrapolar a condiciones actuales de Los Lagos.

## Petzl — AccessBook 4 — Ice climbing basics (2018)

https://s3.amazonaws.com/Petzl_home_Prod/Accessbook/ACCESSBOOK-ICE-CLIMBING-EN-2018.pdf

Apoya: Postura, economía de movimiento, puntas mono/dobles, planificación de protección y posición de reunión; dependencia del hielo.

Límites: Manual abreviado fechado 2018. Texto y páginas PDF 3, 5 y 6 inspeccionadas. No es manual completo ni reemplaza instrucciones actuales del modelo. Diferencia de cordino: libro 6–7 mm frente a página actual Abalakov mínimo 7 mm; NO mezclar dimensiones ni prescribir montaje universal.

## Petzl — Ice climbing technique — the basics

https://www.petzl.com/us/en/sport/tech-tips/basic-techniques/ice-climbing-technique---the-basics/Cascade-gestuelle_SPO_a771r000000PFoJAAW.html

Apoya: Presenta postura, progresión y golpe como destrezas que requieren formación específica y observación profesional.

Límites: Se verificó texto introductorio y advertencias. No se reprodujo ni analizó fotograma a fotograma el video; no atribuir a esta lectura detalles cinemáticos no descritos.

## Petzl — Rappelling on an abalakov

https://www.petzl.com/us/en/sport/tech-tips/basic-techniques/rappelling-on-an-abalakov/glace-descente-abalakov_SPO_a77w0000000KyoLAAS.html

Apoya: Resistencia depende de calidad del hielo y construcción; daños ocultos en anclajes existentes. Variantes con cordino y cuerda directa; esta última puede congelarse.

Límites: Ejemplo técnico específico, no receta autónoma. No universalizar diámetros, ángulos o longitudes; revisar versión y compatibilidad. La existencia de un anclaje no valida su estado.

## Petzl — Inspection of anchors on rock, ice or mixed routes

https://www.petzl.com/int/en/sport/tech-tips/basic-techniques/inspection-of-anchors-on-rock-ice-or-mixed-routes./Verification-des-ancrages-sur-rocher--glace-ou-mix_SPO_a77bK000007PH4rQAG.html

Apoya: Desgaste, aristas, corrosión y deterioro de textiles; se inspecciona también lo oculto. El entorno modifica anclajes existentes.

Límites: La inspección visual no certifica resistencia ni revela todos los defectos. No convertir un tirón manual en prueba de carga concluyente. Algunas secciones tratan roca, no hielo.

## Black Diamond — QC Lab: The risks of reboring old ice screw holes

https://eu.blackdiamondequipment.com/blogs/stories/qc-lab-the-risks-of-reboring-old-ice-screw-holes

Apoya: Diferencia de diámetro entre agujero previo y tornillo puede comprometer colocación. Recongelación puede ocultar indicios.

Límites: El propio autor señala un dato por ensayo: muestra sin significación estadística. No usar cargas medidas como capacidad de un anclaje real ni recomendar reutilizar agujeros.

## Black Diamond — Will Gadd y Matt Berry — QC Lab: Aluminum vs. Steel Ice Screws (20 December 2023)

https://eu.blackdiamondequipment.com/blogs/stories/qc-lab-aluminum-vs-steel-ice-screws-1

Apoya: Peso, ductilidad, geometría y soporte del hielo importan; el material no compensa una colocación deficiente.

Límites: Comparación de modelos BD y ensayos concretos, no todas las marcas. No trasladar porcentajes, cargas de laboratorio o certificaciones de 2023 a equipo actual sin manual/declaración vigente.

## UIAA / Norwegian Climbing Federation — Sharp edges and rope cuts (2025)

https://www.theuiaa.org/documents/safety/UIAA_NFK_SHARPEDGES_2025_ENG.pdf

Apoya: Cuerda cargada y movimiento sobre aristas pueden causar corte; la trayectoria de cuerda y riesgo de caída de objetos forman parte del aseguramiento.

Límites: Informe con recomendaciones contextualizadas; no prescribe por sí solo todo el sistema de aseguramiento en hielo. No deducir riesgo individual de sus estadísticas ni confundir marcado con resistencia universal al corte.

## Organización Meteorológica Mundial — International Cloud Atlas, Volume I — depósitos de hielo, pp. 116–118

https://cloudatlas.wmo.int/docs/wmo_407_en-v1.pdf

Apoya: Distingue escarcha por deposición de vapor y rime/cencellada por congelación de gotas subfundidas; puede haber depósitos heterogéneos.

Límites: Edición documental histórica del Atlas, usada para procesos físicos estables, no normativa vigente ni clasificación de resistencia para escalada. Las páginas web glaze/hard-rime solo devolvieron extractos: se verificó el texto del PDF oficial.

## National Snow and Ice Data Center / University of Colorado Boulder — Science of Glaciers

https://nsidc.org/learn/parts-cryosphere/glaciers/science-glaciers

Apoya: Hielo glaciar procede de transformación de nieve persistente y fluye bajo su peso; difiere de agua que se congela sobre una pared.

Límites: Síntesis glaciológica, no manual de escalada ni información actual de un glaciar específico. No convertir color, origen o edad en prueba de resistencia.

## American Alpine Institute — Pro Tips: Ice Climbing

https://www.alpineinstitute.com/pro-tips-ice-climbing/

Apoya: Diferencias de contextos de hielo de agua, glaciar y nieve transformada.

Límites: Artículo educativo de escuela. No evalúa hielo local ni autoriza una actividad.

## UIAA — Safety Standards — índice de estándares, Ice Anchors UIAA 151

https://www.theuiaa.org/safety/safety-standards/

Apoya: Existencia y ámbito de estándares de equipo, incluido anclaje de hielo.

Límites: Se consultó el índice, no se afirma haber auditado el estándar completo ni la certificación del equipo personal. No es una norma chilena de operación.

## Black Diamond — ATC-Guide — instrucciones M10798_D

https://s3.us-west-2.amazonaws.com/catsy.865/M10798_D_ATC-Guide_IS-WEB.pdf

Apoya: Funciones de aseguramiento/descenso, necesidad de formación y condiciones de uso.

Límites: Texto consultado desde enlace oficial del producto. No se inspeccionaron visualmente todos los pictogramas; no se afirma que corresponda a la generación personal ni se prescribe montaje.

## Petzl — MICRO TRAXION — ficha del fabricante

https://www.petzl.com/int/en/sport/products/progress-capture-pulleys/micro-traxion/MICRO-TRAXION_SPO_a2mw0000000HePgAAK.html

Apoya: Función de polea con captura de progreso y ámbitos declarados del producto.

Límites: Ficha funcional, no revisión completa del manual ni prueba de compatibilidad. No sustituye ATC Guide por semejanza.

## Revisión que sigue pendiente

Revisión presencial de maniobras, equipo del usuario y criterios de evaluación por instructor competente. Video técnico no revisado íntegramente; manual ATC consultado en texto sin inspección de todos los pictogramas; índice UIAA consultado sin auditoría completa del estándar. La identificación de la llamada coliflor de Calbuco requiere evidencia local. No se atribuyen condiciones actuales a una montaña.
