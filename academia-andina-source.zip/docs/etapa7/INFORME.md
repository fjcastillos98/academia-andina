# Etapa 7 · Escalada en hielo

Entrega del 25 de octubre de 2026. Versión 0.7.0. Implementación de un bloque académico en desarrollo, no certificación ni validación presencial.

## Contenido incorporado

Nueve unidades secuenciales dentro del módulo histórico M05: formación del hielo; tipos y formas; cramponaje; piolet técnico; progresión; aseguramiento; anclajes; descenso; gestión del riesgo. La ruta depende académicamente del bloque glaciar y conserva las etapas anteriores.

Cada unidad incluye objetivos, prerrequisitos, conceptos, teoría, análisis de decisiones, caso ficticio, errores, puntos de seguridad, equipo, autoevaluación, quiz y explicación de cada opción, ejercicio de escritorio, propuesta de taller, registro y criterios de revisión. Se distinguen TEORÍA, PROCEDIMIENTO, PRÁCTICA INDIVIDUAL, PRÁCTICA SUPERVISADA y COMPETENCIA. Los procedimientos se tratan como análisis de funciones y comprobaciones previas, no como un manual operativo exhaustivo.

Se incorporan 27 preguntas versionadas, nueve respuestas abiertas con rúbrica, cinco plantillas de práctica, dos diagramas originales y un laboratorio de decisiones guardable localmente. No se crean registros de práctica ni resultados por seleccionar una plantilla. El caso de la portada usa el respaldo JSON v3 existente, sin cambiar formato ni clave de almacenamiento.

Totales de la academia: 103 lecciones y cuestionarios, 78 unidades, 100 habilidades, ocho rutas, 153 registros de fuentes y 37 diagramas. Las 376 entradas históricas continúan pendientes. El número de registros bibliográficos no equivale a fuentes únicas ni a documentos íntegramente revisados.

## Fuentes y límites editoriales

Se añadieron 14 referencias de Petzl, Black Diamond, UIAA, OMM, NSIDC y American Alpine Institute. `FUENTES.md` y la sección bibliográfica de cada lección contienen URL, alcance y limitaciones. La consulta de una página no certifica cada configuración ni verifica el modelo personal.

Se explican diferencias entre origen, geometría y estado; producto, colocación y soporte; ensayo y situación real. Se evita la equivalencia «más frío = más seguro». Se documenta que el AccessBook Petzl de 2018 y la página de abalakov consultada difieren en especificaciones, sin combinar dimensiones. El ensayo de Black Diamond de agujeros reutilizados reconoce un dato por ensayo; no se adoptan sus cargas como capacidad real.

La llamada coliflor del Calbuco no se identifica automáticamente como hielo de agua ni se considera apta para tornillos. La revisión audiovisual completa, el estándar UIAA completo y los manuales del equipo personal siguen fuera del alcance verificado. No se añadieron rutas operativas, permisos, certificaciones ni afirmaciones de normativa chilena vigente.

## Verificación

- Astro/TypeScript: 0 errores, 0 advertencias, 0 sugerencias, después de corregir una posible referencia indefinida en una prueba.
- 75 pruebas aprobadas, 0 fallidas: ocho nuevas y las 67 previas.
- Build: 188 páginas tanto en `/` como bajo `/academia-andina/`.
- Comprobación general: 5.624 enlaces/recursos internos y 574 resultados del índice de búsqueda, en ambas bases.
- Comprobación específica: diez páginas nuevas y 525 enlaces/recursos, incluyendo sus anclas, en ambas bases.
- Conservación: 223 archivos académicos anteriores mantienen hash (94 lecciones, 94 evaluaciones y 35 diagramas); objetos históricos y 376 entradas pendientes preservados.
- Navegador: navegación desde portada al bloque, nueve enlaces visibles y navegación de Anclajes a Descenso; bibliografía y límites visibles.
- Cuestionario de Anclajes: respuesta incorrecta 0/3 y correcta 3/3; tras recargar se mostró evaluación teórica aprobada y estudiada. No se otorgó competencia práctica.
- Laboratorio de decisiones: respuesta guardada y recuperada tras recargar.
- Búsqueda «coliflor» con filtro de lecciones: un resultado, Tipos y formas de hielo. Búsqueda de «abalakov» cubierta también por pruebas automatizadas.
- Plantilla de Anclajes: precarga objetivos, propuesta y equipo; resultado vacío, autonomía no evaluada, evaluación pendiente y ninguna práctica guardada.
- Responsive: portada y lección de Anclajes dentro de iframe de 390 px; ancho útil 375 px y scrollWidth 375 px, sin desbordamiento horizontal del documento. Se conserva la navegación horizontal de menú prevista por el diseño.
- Dos SVG comprobados como XML. Capturas en `screenshots/`; logs en `logs/`.

Las dependencias no cambiaron; se usó la instalación existente. No se repitió `npm ci`. Para una instalación limpia se requiere Node.js 24 y el lockfile incluido.

## Limitaciones conocidas

Los talleres, revisión de instructor y evaluación práctica no han ocurrido. Tampoco se comprobaron físicamente equipos ni credenciales. Los criterios no constituyen una rúbrica profesional homologada. El bloque prepara aprendizaje supervisado; no es un curso completo de ejecución técnica ni acredita liderazgo o guiado.

La compatibilidad ATC Guide/cuerda, fijación bota/crampón, uso del piolet y sistemas de anclaje debe comprobarse con el modelo y manual correspondientes. El video de movimiento se consultó mediante su texto introductorio; no se analizó completo. Los casos locales y el uso comercial necesitan su propia información actual y validación.

La persistencia y serialización/restauración JSON están cubiertas por pruebas automatizadas. No se reintentó la descarga de exportación en navegador, bloqueada en una etapa anterior por la política de URL de ese entorno; no se afirma exportación de extremo a extremo verificada en esta entrega. Tampoco se repitió la importación por interfaz ni se verificó impresión. El ensayo a 390 px es una comprobación de diseño en iframe, no un dispositivo físico ni una auditoría WCAG completa.

Sin backend ni sincronización. No introducir datos médicos, contraseñas o información privada de pasajeros. Los registros son personales y las evaluaciones declaradas no son verificadas por la plataforma.

## Archivos y conservación

`ARCHIVOS.md` compara esta entrega con `Academia_Andina_Etapa5_1_Etapa6.zip`. La carpeta de la academia es independiente. El manual original no se modificó; no hubo push ni despliegue. El ZIP incluye código, documentación y evidencias, y excluye dependencias, build y paquetes anteriores.

## Siguiente etapa propuesta

Etapa 8: escalada alpina, con ocho unidades — planificación, anclajes, encordamiento, manejo de cuerda, grupo, progresión, autorescate y riesgo — integrando lo aprendido en estival, invierno, glaciar y hielo. Antes de convertir pautas en procedimientos evaluables, recoger observaciones reales de instructor y revisar métodos y compatibilidades. Mantener todos los logros prácticos pendientes hasta que exista evidencia.

## Ejecutar

Descomprime y entra en la carpeta `academia/`, con Node.js 24:

```bash
npm ci
npm run dev
```

Abre la URL que indique Astro, normalmente `http://localhost:4321/`.

```bash
npm run check
npm test
npm run build
npm run test:build
node scripts/check-ice-build.mjs
```

Para comprobar la base prevista de GitHub Pages, sin publicar:

```bash
BASE_PATH=/academia-andina/ npm run build
BASE_PATH=/academia-andina/ npm run test:build
BASE_PATH=/academia-andina/ node scripts/check-ice-build.mjs
```
