# Archivos de Etapa 7

Comparación con el ZIP de Etapas 5.1 y 6. Rutas relativas a `academia/`; no incluye dependencias, build ni ZIP de entrega.

## Creados (50)

- `data/archive/etapa6/curriculum.json`
- `data/archive/etapa6/diagrams.json`
- `data/archive/etapa6/learning-paths.json`
- `data/archive/etapa6/skills.json`
- `data/archive/etapa6/sources.json`
- `docs/etapa7/ARCHIVOS.md`
- `docs/etapa7/FUENTES.md`
- `docs/etapa7/INFORME.md`
- `docs/etapa7/README-anterior.md`
- `docs/etapa7/briefs.json`
- `docs/etapa7/historical-sha256.json`
- `docs/etapa7/logs/build-base.log`
- `docs/etapa7/logs/build-final.log`
- `docs/etapa7/logs/build.log`
- `docs/etapa7/logs/check.log`
- `docs/etapa7/logs/ice-base.log`
- `docs/etapa7/logs/ice-final.log`
- `docs/etapa7/logs/ice-routes.log`
- `docs/etapa7/logs/routes-base.log`
- `docs/etapa7/logs/routes-final.log`
- `docs/etapa7/logs/routes.log`
- `docs/etapa7/logs/tests-final.log`
- `docs/etapa7/logs/tests.log`
- `docs/etapa7/research.json`
- `docs/etapa7/screenshots/hielo-390.jpg`
- `docs/etapa7/screenshots/hielo-portada.jpg`
- `public/diagramas/e7-describir.svg`
- `public/diagramas/e7-sistema.svg`
- `scripts/check-ice-build.mjs`
- `src/content/lecciones/anclajes-hielo.md`
- `src/content/lecciones/aseguramiento-hielo.md`
- `src/content/lecciones/cramponaje-hielo.md`
- `src/content/lecciones/descenso-hielo.md`
- `src/content/lecciones/formacion-hielo.md`
- `src/content/lecciones/piolet-hielo.md`
- `src/content/lecciones/progresion-hielo.md`
- `src/content/lecciones/riesgo-hielo.md`
- `src/content/lecciones/tipos-hielo.md`
- `src/data/assessments/anclajes-hielo.v1.json`
- `src/data/assessments/aseguramiento-hielo.v1.json`
- `src/data/assessments/cramponaje-hielo.v1.json`
- `src/data/assessments/descenso-hielo.v1.json`
- `src/data/assessments/formacion-hielo.v1.json`
- `src/data/assessments/piolet-hielo.v1.json`
- `src/data/assessments/progresion-hielo.v1.json`
- `src/data/assessments/riesgo-hielo.v1.json`
- `src/data/assessments/tipos-hielo.v1.json`
- `src/data/ice-templates.json`
- `src/pages/hielo/index.astro`
- `tests/etapa7.test.ts`

## Modificados (15)

- `README.md`
- `data/curriculum.json`
- `data/learning-paths.json`
- `data/skills.json`
- `package-lock.json`
- `package.json`
- `scripts/validate.ts`
- `src/data/diagrams.json`
- `src/data/sources.json`
- `src/layouts/Layout.astro`
- `src/lib/expanded.ts`
- `src/lib/practice-client.ts`
- `src/lib/program.ts`
- `src/pages/lecciones/[id].astro`
- `src/pages/practicas.astro`

## Ausentes (0)

Ninguno.
