# Fuentes · Etapa 15

Consulta: 2026-10-27. Las fuentes se atribuyen sin reproducir sus documentos completos.

## Calbuco — perfil 358020

Smithsonian Institution, Global Volcanism Program — https://volcano.si.edu/volcano.cfm?vn=358020

Página consultada: tabla de altitud; para Osorno también pie fotográfico. No acredita cota topográfica, estado operativo ni alerta actual.

## Osorno — perfil 358010

Smithsonian Institution, Global Volcanism Program — https://volcano.si.edu/volcano.cfm?vn=358010

Página consultada: tabla de altitud; para Osorno también pie fotográfico. No acredita cota topográfica, estado operativo ni alerta actual.

## Catálogo de publicaciones geológicas · mapa Calbuco 1999

SERNAGEOMIN — https://portalsdnmext.sernageomin.cl/publicacionesgeologicas

Metadatos indexados consultados: M74, escala 1:75.000. Apertura directa falló (502). No se inspeccionó la lámina ni se verificó su vigencia.

## Registro de mapa de peligros del volcán Osorno, 1999

SERNAGEOMIN — https://portalgeomin.sernageomin.cl/service/60de3ded818938000000

Registro indexado: título y escala 1:75.000. Apertura directa falló (502); leyenda, datum y geometrías no revisados.

## Informe RM-2022-35 · apartado 4.1

SERNAGEOMIN — https://portalgeo.sernageomin.cl/Informes_PDF_Nac/RM-2022-35.pdf

Extracto indexado atribuye 2.002 m al Calbuco. PDF no abierto (502); dato provisional de contraste, no cota adoptada.

## Volcán Osorno · Los volcanes en la historia de Chile

Biblioteca Nacional de Chile · Memoria Chilena — https://www.memoriachilena.gob.cl/602/w3-article-98217.html

Página consultada. Síntesis histórica, no levantamiento topográfico. Publica 2.652 m para Osorno y 1.691 m para Calbuco; discrepancias no resueltas.

El catálogo y el PDF de SERNAGEOMIN se consultaron solo mediante extractos indexados por el buscador; sus aperturas devolvieron 502. La referencia IGM es una solicitud pendiente, no una fuente inspeccionada.
