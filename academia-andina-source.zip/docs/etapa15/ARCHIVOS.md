# Archivos · Etapa 15

Creados:
- src/data/territory15.json: dos expedientes, cotas atribuidas y solicitudes.
- src/lib/territory15.ts: cuatro ejercicios y corrección validada.
- src/pages/territorio/expedientes.astro: página de contraste y borrador.
- tests/etapa15.test.ts: cinco pruebas.
- docs/etapa15/: informe, fuentes, hashes y registros de validación.

Modificados:
- src/data/sources.json: cuatro referencias añadidas, registros previos conservados.
- src/pages/territorio/index.astro y [id].astro: enlaces al bloque.
- src/pages/search-index.json.ts: entrada de búsqueda.
- src/layouts/Layout.astro: versión visible.
- package.json y package-lock.json: 0.15.0, dependencias sin cambios.
- scripts/clean-build.mjs: limpieza adicional de caché Vite al compilar.
- README.md: nota de entrega.

El ZIP contiene academia/ con fuentes y documentación. Excluye node_modules, dist, .astro, archivos de control Git y entregas anteriores. No incluye el manual ajeno a academia.
