# Etapa 15 · Calbuco y Osorno

Entrega: 28 de octubre de 2026. Consulta iniciada: 27 de octubre de 2026. Versión 0.15.0. Bloque documental parcial, pendiente de revisión especializada.

## Implementación

Dos expedientes enlazados desde las fichas y el índice territorial, con seis registros de cotas atribuidas, dos registros cartográficos, cuatro ejercicios y doce alternativas explicadas. Pauta de lectura cartográfica y borrador guardable de solicitudes de revisión. Se integra en búsqueda y en el respaldo existente sin cambiar su formato. No se enviaron solicitudes.

Las discrepancias siguen abiertas. Los registros SERNAGEOMIN de mapas 1999 a escala 1:75.000 se localizaron mediante resultados indexados; la apertura directa falló con 502. No se revisaron láminas, memorias, datum, geometrías ni ediciones posteriores. El extracto RM-2022-35 tampoco equivale a lectura completa del PDF. No se adopta una cota oficial única ni se infieren cambios de altura a partir de cifras distintas.

## Verificación

- 154/154 pruebas automatizadas aprobadas, incluidas cinco nuevas: conservación histórica, referencias, corrección, entradas inválidas y restauración del borrador sin competencias.
- TypeScript/Astro: 0 errores, 0 advertencias, 0 hints.
- Build de 262 páginas en raíz y /academia-andina/; 9.575 enlaces/recursos internos y 646 resultados de búsqueda comprobados en cada base. Resultados exactos en logs/links-root.txt y logs/links-base.txt.
- La observación inicial del navegador mostró ambos expedientes, fuentes, ejercicios y formulario.
- La política del navegador bloqueó el primer intento de interacción y después la captura. No se verificaron corrección interactiva, guardado tras recargar, búsqueda mediante UI ni presentación móvil. No se intentó eludir el bloqueo.
- No se probó descarga/importación JSON de extremo a extremo ni impresión. La restauración de datos sí pasó pruebas de lógica.
- La primera validación rechazó fechas de año sin mes/día y referencias sin lección asociada: se corrigieron sin inventar fechas. Los años conocidos están en títulos/identificadores, y published queda null cuando falta fecha exacta.
- Las comprobaciones al alternar bases detectaron mezcla de rutas, incluso tras detener la vista de desarrollo. Se amplió la limpieza a node_modules/.vite. La reconstrucción aislada de cada base se verificó mediante el comprobador de enlaces; se conservan los logs finales. No se atribuye el fallo exclusivamente a la vista de desarrollo.

## Pendientes concretos

1. Obtener e inspeccionar láminas y memorias oficiales, con edición y límites de uso.
2. Contrastar cotas con cartografía IGM: punto medido, método y referencia vertical.
3. Consultar discrepancias a las instituciones; las solicitudes actuales son borradores no enviados.
4. Revisión por especialista regional e instructor y prueba local de formularios, móvil e impresión.
5. Verificar información operativa vigente antes de cualquier planificación real; este bloque no proporciona alertas actuales, permisos ni itinerarios.

## Conservación y ejecución

No se editó el manual original ni se hizo push o despliegue. Las lecciones, fichas históricas y currículo conservan sus hashes de inicio de etapa. No se modifican las competencias prácticas al resolver ejercicios o guardar texto.

Dentro de academia, con Node.js 24: npm ci; npm run dev. La ruta nueva es /territorio/expedientes/.

Siguiente trabajo recomendado: cerrar la revisión cartográfica pendiente y completar una prueba local de respaldo y formularios antes de ampliar más fichas.
