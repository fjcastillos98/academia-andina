# Etapa 10 — Entrenamiento para andinismo

26 de octubre de 2026. Versión 0.10.0. Academia en desarrollo; sin push ni despliegue.

## Alcance

16 unidades: evaluación y pruebas físicas; fuerza máxima; hipertrofia; fuerza-resistencia; resistencia aeróbica y zona 2; umbrales y VO2max; ascenso y desnivel; trekking; montañismo y carga; movilidad y estabilidad; prevención de lesiones; recuperación y sueño; nutrición deportiva; composición corporal; periodización; taper y expediciones.

Cada unidad conserva objetivos, prerrequisitos, teoría, decisiones, errores, seguridad, equipo, autoevaluación, quiz, ejercicio, práctica supervisada propuesta, registro, criterios observables, fuentes, nivel y relaciones curriculares. 48 preguntas con explicación por opción; 16 respuestas razonadas. Seis plantillas no crean evidencia automáticamente. Dos diagramas originales y laboratorio descriptivo con tres sesiones ficticias. La ruta depende de Altitud. Se conserva M22 del mapa original, sin renumerar el currículo histórico.

Total: 137 lecciones/cuestionarios, 112 unidades, 134 habilidades, 11 rutas, 182 referencias y 43 diagramas. Las 376 entradas originales siguen pendientes. Pruebas de conservación verifican 283 archivos académicos históricos y objetos de la etapa anterior.

## Verificación real

- `npm test`: 106 pruebas, 106 aprobadas, 0 fallos. Incluye validación, búsqueda, corrección, respaldo/restauración, conservación, dependencias y medidas del laboratorio.
- `npm run check`: 84 archivos; 0 errores, 0 advertencias, 0 sugerencias.
- Build: 225 páginas en raíz y con base `/academia-andina/`.
- Verificador del bloque: 17 páginas, 932 enlaces/recursos internos y sus anclas en ambas bases.
- Navegador: portada → primera lección → segunda lección; fuentes y límites visibles; búsqueda «zona 2» devuelve la lección correspondiente (13 coincidencias porque busca términos, no frase exacta).
- Quiz de evaluación inicial: 3/3, explicación por opción y aviso de no competencia; estado de aprobación conservado tras recargar. Las respuestas elegidas se limpian para un nuevo intento.
- Caso integrador: respuesta ficticia guardada y recuperada tras recargar.
- Selector B: 90 min, RPE 4, 600 m, 5 kg, 360 unidades y 400 m/h. El selector deliberadamente no persiste.
- Responsive: inspección visual en iframe de 390 × 844; contenido útil 375 px por barra vertical, scrollWidth = clientWidth = 375. Menú horizontal desplazable. No es una prueba en teléfono físico ni una auditoría WCAG.
- SVG nuevos analizados como XML. No se modificó el manual original rastreado por git.

Registros en `logs/` y captura en `screenshots/mobile.jpg`. Dependencias instaladas de la etapa anterior reutilizadas; esta continuación no cambió versiones de dependencias ni repitió instalación.

## Límites y revisión pendiente

No hay prescripción deportiva individual ni pruebas máximas autónomas, dietas, objetivo de peso o evaluación médica. Se necesita revisión por profesional del ejercicio; nutrición, disponibilidad energética y salud requieren revisión de especialistas. Las maniobras técnicas mantienen supervisión instructora. La matriz registra declaraciones y no verifica la identidad del evaluador.

Doce fuentes institucionales y científicas: ACSM, consensos IOC y sueño, y estudios originales de intensidad, carga, seguimiento, periodización y taper. Parte del acceso fue a resúmenes indexados; consultar FUENTES.md. Extrapolar estudios militares o de corredores a montaña exige cautela y no justifica dosis universales. Las pruebas automatizadas validan estructura y comportamiento, no veracidad clínica ni eficacia del programa.

El respaldo JSON fue probado por lógica de serialización/restauración. La descarga/importación del archivo desde el navegador no se volvió a verificar: en una etapa anterior la política de URL del entorno bloqueó ese flujo. No se afirma verificación integral de esa interacción en esta etapa.

## Siguiente etapa propuesta

Etapa 11: Flora, fauna y ecología de Los Lagos. Preparar un bloque progresivo de ecosistemas, bosque templado y siempreverde, ambientes altoandinos/volcánicos, identificación con incertidumbre, endemismo, amenazas e invasoras, comportamiento y seguridad, conservación, No Deje Rastro e impactos turísticos. Usar MMA, CONAF y bibliografía académica; evitar listas de especies locales sin distribución documentada. Incorporar un cuaderno de observación sin ubicaciones sensibles de especies amenazadas y revisión por especialista territorial.
