# Fuentes de Etapa 10

Consulta: 26 de octubre de 2026. Consultar un registro no equivale a revisión profesional del contenido. No se ha leído íntegramente cada artículo: se explicita el alcance de acceso. Los casos, rúbricas y su aplicación a montaña son propuestas pedagógicas, no protocolos oficiales de estas organizaciones.

## ACSM — ACSM Unveils Landmark 2026 Resistance Training Guidelines — First Update in 17 Years

https://acsm.org/resistance-training-guidelines-update-2026/

Acceso: Página institucional completa

Sustenta: Entrenamiento de fuerza regular; especificidad de fuerza, hipertrofia y potencia; individualizar según objetivo, seguridad y adherencia; el fallo muscular y una periodización compleja no son imprescindibles para todos.

Límites: Adultos sanos; no es un ensayo de andinismo ni justifica copiar una dosis universal. Resumen institucional, no revisión íntegra del position stand.

## Seiler y Kjerland — Quantifying training intensity distribution in elite endurance athletes: is there evidence for an 'optimal' distribution?

https://pubmed.ncbi.nlm.nih.gov/16430681/

Acceso: Resumen indexado; apertura directa no entregó el artículo

Sustenta: Modelo de tres zonas delimitadas por VT1 y VT2; zona 2 de ese modelo está entre umbrales. Debe declararse el modelo de zonas y el método de registro.

Límites: Muestra pequeña de deportistas de resistencia; no demuestra una distribución óptima universal ni equivalencia con cinco zonas de un reloj.

## Stöggl y Sperlich — Polarized training has greater impact on key endurance variables than threshold, high intensity, or high volume training

https://www.frontiersin.org/journals/physiology/articles/10.3389/fphys.2014.00033/full

Acceso: Resultados y discusión indexados; PMC bloqueó apertura

Sustenta: Comparación de distribuciones de intensidad en deportistas entrenados; mejoras de variables de resistencia con distribución polarizada en ese estudio; VO2peak, rendimiento y economía son variables distintas.

Límites: No convierte una proporción de intensidades en receta para principiantes ni para expediciones; resultados dependen de población, duración, modalidad y desenlace.

## Grenier y colaboradores — Energy cost and mechanical work of walking during load carriage in soldiers

https://pubmed.ncbi.nlm.nih.gov/22215177/

Acceso: Ficha y resumen indexados; apertura directa no entregó texto

Sustenta: El transporte de carga modifica las demandas energéticas y mecánicas de la marcha; la preparación específica debe considerar equipo y carga real.

Límites: Contexto militar y distribución de equipo propios del estudio; los porcentajes de masa corporal descritos no son recomendaciones de mochila para excursionistas.

## Walsh y colaboradores / BJSM — Sleep and the athlete: narrative review and 2021 expert consensus recommendations

https://bjsm.bmj.com/content/55/7/356

Acceso: Resumen y fragmentos indexados; sitio devolvió 403

Sustenta: Planificación de entrenamiento y viajes puede limitar oportunidades de sueño; horarios tempranos y sesiones nocturnas intensas pueden interferir con el descanso; considerar necesidades individuales.

Límites: No establece una cifra universal de sueño ni autoriza diagnóstico de trastornos o medicación; evidencia heterogénea.

## Comité Olímpico Internacional / Mountjoy y colaboradores — 2023 International Olympic Committee's (IOC) consensus statement on Relative Energy Deficiency in Sport (REDs)

https://bjsm.bmj.com/content/57/17/1073

Acceso: Registro PubMed y resultados indexados; publicación devolvió 403

Sustenta: Baja disponibilidad energética problemática puede afectar salud y rendimiento de mujeres y hombres; composición corporal no debe perseguirse a costa de alimentación y recuperación.

Límites: El curso no debe diagnosticar REDs, fijar umbrales universales ni almacenar historia clínica; evaluación y tratamiento requieren profesionales.

## Academy of Nutrition and Dietetics / Dietitians of Canada / ACSM — American College of Sports Medicine Joint Position Statement. Nutrition and Athletic Performance

https://pubmed.ncbi.nlm.nih.gov/26891166/

Acceso: Resumen completo en PubMed; no texto íntegro

Sustenta: Tipo, cantidad y momento de alimentos y líquidos se ajustan a entrenamiento y competición; nutrición contribuye a rendimiento y recuperación; planificación individual con nutricionista deportivo.

Límites: Documento de 2016 con erratum posterior; resumen no permite extraer dosis detalladas ni recomendaciones individuales o de suplementos.

## Shepley y colaboradores — Physiological effects of tapering in highly trained athletes

https://pubmed.ncbi.nlm.nih.gov/1559951/

Acceso: Resumen indexado; apertura directa no entregó texto

Sustenta: El taper puede estudiarse manipulando intensidad y volumen antes de un objetivo; estudio comparó tres estrategias breves en corredores entrenados.

Límites: Nueve corredores varones; no usar duración o porcentajes del experimento como calendario universal de expedición. El taper de entrenamiento no sustituye aclimatación.

## Foster y colaboradores — A new approach to monitoring exercise training

https://pubmed.ncbi.nlm.nih.gov/11708692/

Acceso: Resumen indexado; apertura directa no entregó texto

Sustenta: Método de percepción subjetiva del esfuerzo de sesión para monitorizar entrenamiento y comparar con métodos basados en frecuencia cardíaca; distinguir carga externa y respuesta interna.

Límites: No es medidor de calorías, diagnóstico ni predictor individual de lesión. Una cifra comparable no implica igual estrés mecánico entre actividades.

## ACSM / Garber y colaboradores — Quantity and quality of exercise for developing and maintaining cardiorespiratory, musculoskeletal, and neuromotor fitness in apparently healthy adults: guidance for prescribing exercise

https://pubmed.ncbi.nlm.nih.gov/21694556/

Acceso: Resumen indexado y registro de repositorio universitario

Sustenta: La preparación general incluye capacidades cardiorrespiratorias, musculares, flexibilidad y capacidades neuromotoras como equilibrio y coordinación.

Límites: Documento general antiguo: usar solamente marco de componentes; recomendaciones de fuerza actualizadas en ACSM 2026. No demuestra que movilidad aislada prevenga todas las lesiones.

## Comité Olímpico Internacional / Soligard y colaboradores — How much is too much? (Part 1) International Olympic Committee consensus statement on load in sport and risk of injury

https://bjsm.bmj.com/content/50/17/1030

Acceso: Resumen y fragmentos indexados; ficha PubMed 27535989

Sustenta: Carga comprende factores deportivos y no deportivos, mecánicos, fisiológicos y psicológicos; seguimiento de entrenamiento, bienestar y recuperación informa ajustes.

Límites: No adoptar cocientes de carga como zona segura, regla de aumento del 10% ni garantía de prevención; riesgo multifactorial y consenso de 2016.

## Rhea y colaboradores — A comparison of linear and daily undulating periodized programs with equated volume and intensity for strength

https://pubmed.ncbi.nlm.nih.gov/11991778/

Acceso: Resumen completo de PubMed

Sustenta: La periodización organiza variaciones de estímulo a lo largo del tiempo; comparación experimental de organización lineal y ondulante de fuerza.

Límites: Veinte hombres jóvenes, doce semanas y ejercicios concretos. No demuestra que un modelo sea el mejor para todo montañista ni autoriza extrapolar un programa.
