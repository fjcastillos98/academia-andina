# Etapa 12 · Geología y vulcanología de Los Lagos

Entrega local: 27 de octubre de 2026. Versión 0.12.0. Academia en desarrollo; no publicada ni certificadora.

## Implementación

Diez unidades progresivas: tectónica y subducción; entidades volcánicas y topónimos; magma, lava y domos; tefra y ceniza; corrientes piroclásticas; lahares y cuencas; relieve volcánico/glaciar; monitoreo; mapas de peligros; síntesis territorial. Cada unidad incluye objetivos, prerrequisitos, teoría, análisis documental, errores, seguridad, equipo, autoevaluación, quiz, práctica, registro, criterios y fuentes. Todas permanecen en desarrollo.

Se añadieron 30 preguntas con explicaciones por opción, diez habilidades, seis plantillas de taller supervisado, dos diagramas originales y una ruta dependiente del bloque territorial. Los cuatro suplementos documentales de Sarnoso, Casablanca, Tronador y Puntiagudo diferencian nombre popular, entidad geológica y límites de la evidencia. No se completaron por suposición coordenadas, cotas, accesos ni rutas.

El laboratorio distingue estudio, reporte, mapa y aviso de acceso mediante cuatro ejemplos ficticios. Sus respuestas no generan competencia. El caso integrador guarda una respuesta local e integra el respaldo JSON v3 existente. Los suplementos tienen esquema estricto y validación de referencias; se integran a la búsqueda.

Totales: 157 lecciones y cuestionarios, 132 unidades, 154 habilidades, 13 rutas, 207 registros bibliográficos y 47 diagramas. Las 376 entradas históricas siguen pendientes. Las 147 lecciones, 147 cuestionarios y 45 diagramas anteriores se conservan por hashes (339 archivos), además de comparación de datos históricos. Las siete fichas territoriales originales no se modifican en sus datos.

## Fuentes

Quince registros documentales nuevos: USGS, BGS/UKRI, SERNAGEOMIN (balance histórico 2021), SENAPRED, Smithsonian Global Volcanism Program y estudios de Lara y colaboradores y Mella y colaboradores. Incluyen una reconsulta de referencia histórica. GVP es una síntesis institucional; no se presenta como investigación primaria. La consulta del visor SENAPRED acredita su descripción, no una comprobación interactiva de cada mapa. El balance 2021 no describe la alerta vigente. Acceso, afirmaciones respaldadas y límites detallados en FUENTES.md y research.json.

## Verificaciones reales

| Comprobación | Resultado |
|---|---|
| TypeScript/Astro | 93 archivos, 0 errores, 0 advertencias, 0 sugerencias |
| Tests | 132 aprobados; 0 fallos |
| Build final raíz | 247 páginas, correcto |
| Build base /academia-andina/ | 247 páginas, correcto |
| Enlaces globales en ambas bases | 8794 enlaces/recursos; 632 entradas de búsqueda; correcto |
| Anclas y recursos Etapa 12 | 15 páginas, 774 enlaces/recursos; correcto en ambas bases |
| Navegador | Navegación siguiente, búsqueda Sarnoso y suplemento con fuentes visibles |
| Quiz | 2/3 y 3/3 con explicaciones; aprobación teórica persiste al recargar |
| Respuesta del caso | Guardado y recarga comprobados con texto ficticio |
| Laboratorio | Respuesta incorrecta y correcta con límites explícitos |
| Responsive | Iframe 390 × 844; ancho interior y scrollWidth 375 px; controles operables |
| Respaldo JSON | Roundtrip y rechazo de datos inválidos en pruebas automatizadas |
| Manual original | git diff vacío en archivos versionados |

La descarga/importación del respaldo por interfaz no se repitió: había un bloqueo de política del navegador observado en una etapa anterior. No se afirma una nueva comprobación de ese flujo completo. La evidencia visual y registro manual están en screenshots/ y logs/browser-qa.txt. No se reinstalaron dependencias porque las versiones no cambiaron y la instalación existente ejecutó los controles.

Durante QA se corrigió M16 → M18 en la etiqueta de los suplementos. Al alternar bases se detectó reutilización de contenido transformado por Astro: scripts/clean-build.mjs limpia exclusivamente dist/, .astro/ y node_modules/.astro/ antes del build. La secuencia base de proyecto → raíz se ejecutó nuevamente y pasó. El build final conservado es para raíz.

## Límites y revisión pendiente

Revisión académica por especialista en geología/vulcanología y revisión de aplicaciones prácticas por instructor competente. No se verificaron alertas actuales, restricciones ni condiciones operativas. No hay pronóstico, recomendación de itinerario, procedimiento de evacuación local ni acreditación de guía. La bibliografía consultada no sustituye revisión profesional de las adaptaciones didácticas.

La prueba responsive corresponde a una muestra local mediante iframe, no a una batería de dispositivos físicos o auditoría WCAG. La plataforma sigue siendo estática, local y sin verificación de identidad del evaluador. No guarda datos clínicos ni contraseñas por diseño; los campos libres requieren cuidado del usuario.

## Siguiente propuesta · Etapa 13

Historia de la montaña y patrimonio: bloque piloto progresivo sobre historia mundial, Andes y Chile, evolución de técnicas/equipo, exploración de Los Lagos y relaciones culturales con las montañas. Preparar primero una cronología documentada que distinga ascensión deportiva, exploración escrita y presencia indígena anterior; contrastar primeras ascensiones y nombres con fuentes primarias, bibliotecas y publicaciones académicas. Añadir actividades de comparación de testimonios, quiz y un caso de interpretación patrimonial, manteniendo incertidumbres explícitas. No ampliar aún a cientos de páginas.

## Ejecución local

Desde la carpeta academia descomprimida, con Node.js 24:

```bash
npm ci
npm run dev
```

Abrir http://localhost:4321/ o el puerto informado. Para comprobar:

```bash
npm run check
npm test
npm run build
npm run test:build
node scripts/check-geology-build.mjs
```

No se hizo push, deploy ni publicación. El proyecto continúa en desarrollo.
