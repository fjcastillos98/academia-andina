# Fuentes de la Etapa 12

Consulta documental: 26 de octubre de 2026. No equivale a validación profesional ni a información operativa vigente. Hay fuentes institucionales, estudios académicos y síntesis bibliográficas; no todas son investigación primaria. Quince registros nuevos incluyen reconsultas de obras ya presentes.


## e12-subduction

USGS — Using the Diagram to Discuss How Plate Tectonics Works

[Using the Diagram to Discuss How Plate Tectonics Works](https://volcanoes.usgs.gov/about/edu/dynamicplanet/nutshell.php)

**Acceso:** Página completa; puntos 11–14 sobre subducción y generación de magma

**Afirmaciones respaldadas:**

- La litosfera está dividida en placas que se mueven relativamente entre sí.
- Fluidos liberados desde la placa que subduce favorecen fusión parcial del manto suprayacente; el modelo no es simplemente fusión por roce.
- Parte del magma asciende, pero parte se enfría y solidifica en profundidad.

**Límites:** Modelo didáctico general, no sección medida de Los Lagos ni explicación exhaustiva de todas las variantes de arco. No usar velocidades ni profundidades universales. La transferencia al marco regional requiere fuente chilena específica.


## e12-glossary

USGS Volcano Hazards Program — Volcano Hazards Program Glossary

[Volcano Hazards Program Glossary](https://www.usgs.gov/glossary/volcano-hazards-program-glossary)

**Acceso:** Página completa; entradas magma, lava, dome, tephra, shield volcano y stratovolcano

**Afirmaciones respaldadas:**

- Magma designa material rocoso fundido bajo la superficie; lava corresponde a material emitido en superficie manteniendo una masa fluida o viscosa.
- Un domo de lava es una acumulación de lava viscosa, frecuentemente bloqueada, extruida desde un conducto.
- Tefra agrupa fragmentos expulsados que siguen una trayectoria aérea, incluyendo ceniza y fragmentos mayores.
- Estratovolcanes y volcanes escudo difieren en construcción y geometría; la forma no identifica por sí sola un volcán particular.
- La entrada silica relaciona cadenas poliméricas con mayor viscosidad y mayor dificultad de escape de gases; son tendencias generales y no una predicción de estilo eruptivo.

**Límites:** No copiar como clave de identificación de campo. La entrada ceniza muestra un intervalo ambiguo menor de 2–4 mm: para granulometría preferir la página especializada e12-ash. No aplicar intervalos químicos como identificaciones visuales ni usar el glosario como criterio de actividad actual.


## e12-ash

USGS Volcanic Ash Impacts & Mitigation — Volcanic Ash

[Volcanic Ash](https://volcanoes.usgs.gov/volcanic_ash/ash.html)

**Acceso:** Página completa; definición, propiedades, formación y dispersión de ceniza

**Afirmaciones respaldadas:**

- La ceniza volcánica está formada por fragmentos de roca, minerales y vidrio volcánico; no es producto de combustión como la ceniza de madera.
- La página especializada describe tamaños desde aproximadamente 2 mm hasta partículas muy finas.
- Es abrasiva, no se disuelve en agua y puede ser dispersada ampliamente por viento.
- Expansión de gases y/o interacción con agua participan en la fragmentación explosiva.

**Límites:** Propiedades generales; no predice dirección o alcance de una pluma concreta. No prescribe tratamiento médico ni equipo respiratorio individual. Fecha tomada del índice de búsqueda; la página abierta no muestra un historial editorial completo.


## e12-lahar

USGS Volcano Hazards Program — Lahars move rapidly down valleys like rivers of concrete

[Lahars move rapidly down valleys like rivers of concrete](https://www.usgs.gov/programs/VHP/lahars-move-rapidly-down-valleys-rivers-concrete)

**Acceso:** Página completa; mecanismos y ocurrencia con o sin erupción

**Afirmaciones respaldadas:**

- Los lahares transportan agua y material sólido por valles y cauces; pueden incorporar más material y cambiar de volumen durante el recorrido.
- Pueden ocurrir con o sin erupción; la fusión de nieve/hielo y la removilización de depósitos son mecanismos relevantes.
- No son equivalentes a coladas de lava ni a corrientes piroclásticas.

**Límites:** No trasladar velocidades máximas o multiplicadores de volumen a un escenario local. No establece perímetros seguros ni puntos de evacuación para Chile. Las respuestas de emergencia deben seguir planificación y autoridad local, no una maniobra universal extraída de esta página.


## e12-pdc

USGS Volcano Hazards Program — Pyroclastic flows move fast and destroy everything in their path

[Pyroclastic flows move fast and destroy everything in their path](https://www.usgs.gov/programs/VHP/pyroclastic-flows-move-fast-and-destroy-everything-their-path)

**Acceso:** Página completa; composición y mecanismos de generación

**Afirmaciones respaldadas:**

- Los flujos piroclásticos son mezclas calientes de fragmentos y gas que se desplazan rápidamente.
- Pueden originarse por colapso de columna eruptiva, emisión sin columna alta o colapso de domos/frentes de lava.
- La nube asociada no debe confundirse con una simple nube meteorológica o con caída de ceniza aislada.

**Límites:** Explicación general, no predicción local de alcance. No convertir una recomendación breve de la página en protocolo de escape ni sugerir que se puede observar de cerca o superar un flujo corriendo. No equivale a una zonificación de seguridad.


## e12-monitoring

SERNAGEOMIN — Ministerio de Minería, publicado por DIPRES — Balance de Gestión Integral, año 2021 — Servicio Nacional de Geología y Minería

[Balance de Gestión Integral, año 2021 — Servicio Nacional de Geología y Minería](https://www.dipres.gob.cl/597/articles-279892_doc_pdf.pdf)

**Acceso:** PDF de 144 páginas; secciones RNVV/OVDAS, reportes y cartografía consultadas mediante texto extraído

**Afirmaciones respaldadas:**

- Documenta que la RNVV comunica actividad mediante Reportes de Actividad Volcánica (RAV), Reportes Especiales (REAV) y Minutas Excepcionales (MEV).
- Distingue vigilancia instrumental y análisis de actividad de la elaboración de mapas de peligro volcánico regulares.
- Describe áreas de sismología y geovolcanología y trabajo complementario de instrumentación y sistemas.

**Límites:** Balance del año 2021: usar como antecedente institucional y vocabulario, no como norma vigente, frecuencia actual de reportes, número actual de volcanes vigilados ni ranking actual. El portal de alertas SERNAGEOMIN fue indexado pero su apertura falló por timeout dos veces; no se verificó alerta vigente. Los colores o reportes históricos no autorizan acceso.


## e12-visor

SENAPRED — Visor Chile Preparado

[Visor Chile Preparado](https://senapred.cl/visor-chile-preparado/)

**Acceso:** Página institucional completa; objetivos y capas del visor. No se operó el mapa interactivo

**Afirmaciones respaldadas:**

- La herramienta presenta exposición frente a amenazas volcánicas, incendios forestales y tsunami para preparación comunitaria.
- Describe capas de red vial, topografía y elementos de planos de evacuación, incluyendo áreas, puntos de encuentro y vías.
- Sirve para estudiar la diferencia entre cartografía de exposición y planificación de evacuación.

**Límites:** Se verificó la descripción, no cada capa o localidad del visor. No extraer de aquí rutas seguras, cobertura completa ni vigencia de un punto de encuentro particular. Un visor no sustituye instrucciones de autoridad ni una revisión operativa actual.


## e12-sensors

USGS — California Volcano Observatory — Volcano Monitoring — Clear Lake Volcanic Field

[Volcano Monitoring — Clear Lake Volcanic Field](https://www.usgs.gov/volcanoes/clear-lake-volcanic-field/science/volcano-monitoring)

**Acceso:** Página completa con resúmenes de monitoreo de gases, deformación y sismicidad

**Afirmaciones respaldadas:**

- Presenta monitoreo sísmico, de deformación y de gases como líneas complementarias.
- El desplazamiento superficial puede acompañar movimiento de magma y requiere medición e interpretación.
- La vigilancia de gases y aguas puede realizarse mediante campañas y no necesariamente como señal continua en todo volcán.

**Límites:** Ejemplo estadounidense: no demuestra qué instrumentos operan hoy en un volcán de Los Lagos. La fecha corresponde a las tres entradas enlazadas. No fija umbrales universales ni permite pronosticar una erupción a partir de un solo indicador.


## e12-hazard-maps

USGS Volcano Hazards Program — California volcano locations, threat rank and hazard zones

[California volcano locations, threat rank and hazard zones](https://www.usgs.gov/data/california-volcano-locations-threat-rank-and-hazard-zones)

**Acceso:** Página completa; fundamentos y limitaciones de zonificación

**Afirmaciones respaldadas:**

- Los mapas de peligro representan fenómenos potenciales y áreas que podrían ser afectadas, apoyándose en geología, depósitos y cronología eruptiva.
- Los límites representados pueden ser graduales e inciertos; escala y resolución influyen en la representación.
- La vigilancia en tiempo real aporta información adicional sobre sectores potencialmente afectados; el peligro concreto depende también del estilo, volumen, localización, duración y condiciones meteorológicas e hidrológicas.

**Límites:** Ejemplo de California, no cartografía de Los Lagos. No transferir polígonos, probabilidades ni escalas a Chile. No convertir un límite de mapa en garantía de seguridad fuera de él. No equivale a alerta vigente ni autorización de acceso.


## e12-viscosity

British Geological Survey — UKRI — Volcanic hazards

[Volcanic hazards](https://www.bgs.ac.uk/discovering-geology/earth-hazards/volcanoes/volcanic-hazards/)

**Acceso:** Página completa; apartado Lava flows and lava domes, líneas 69–81

**Afirmaciones respaldadas:**

- La viscosidad de las lavas depende de composición, temperatura y contenido de agua: la página describe tendencias generales, no una regla única para toda erupción.
- Los domos se forman por extrusión de lava muy viscosa y pueden colapsar produciendo corrientes piroclásticas.
- La página distingue caída de tefra/ceniza, flujos de lava, corrientes piroclásticas y lahares.

**Límites:** No trasladar intervalos de temperatura, velocidades o descripciones genéricas a un volcán concreto. Agua disuelta y gas separado no son intercambiables; evitar afirmar que más gas siempre aumenta o disminuye viscosidad. Para cristalinidad o modelos cuantitativos se requiere fuente adicional. No usar frases de evacuación genéricas como protocolo operativo chileno.


## e12-name-lara

Lara, Rodríguez, Moreno y Pérez de Arce — Revista Geológica de Chile / SERNAGEOMIN — Geocronología K-Ar y geoquímica del volcanismo plioceno superior-pleistoceno de los Andes del sur (39–42°S), 2001 — reconsulta

[Geocronología K-Ar y geoquímica del volcanismo plioceno superior-pleistoceno de los Andes del sur (39–42°S), 2001 — reconsulta](https://www.scielo.cl/scielo.php?pid=S0716-02082001000100004&script=sci_arttext)

**Acceso:** Texto HTML abierto; pasaje específico Sarnoso recuperado además mediante búsqueda indexada. PDF de Andean Geology sin texto extraíble en la herramienta.

**Afirmaciones respaldadas:**

- El Complejo Sarnoso al suroeste de Casablanca incluye un aparato central erosionado y conos piroclásticos superpuestos, algunos postglaciales.
- La descripción documenta estructura volcánica pese al uso del topónimo cerro; no identifica por sí sola una cumbre deportiva o itinerario.

**Límites:** Reconsulta de referencia ya existente lara-sarnoso. No asignar una edad única a todas las unidades ni calificar todo el conjunto de extinto. Identidad entre punto turístico, cota y entidad geológica requiere contraste cartográfico.


## e12-name-antillanca

Smithsonian Institution — Global Volcanism Program — Antillanca Volcanic Complex — Geological Summary y Subfeatures

[Antillanca Volcanic Complex — Geological Summary y Subfeatures](https://volcano.si.edu/volcano.cfm?vn=357153)

**Acceso:** Página HTML completa, especialmente resumen geológico y subestructuras.

**Afirmaciones respaldadas:**

- Diferencia el complejo Antillanca de sus centros; clasifica Casablanca como estratovolcán.
- Describe Sarnoso y Fiuchá como estratovolcanes antiguos fuertemente disectados por glaciares.

**Límites:** Síntesis institucional, no estudio primario de cada unidad. No tratar el reporte fechado de marzo de 2020 como alerta actual. No extrapolar la actividad o edad de un centro a todo el complejo. No resolver cotas deportivas con este registro.


## e12-name-tronador

Smithsonian Institution — Global Volcanism Program — Tronador — Geological Summary y Eruptive History

[Tronador — Geological Summary y Eruptive History](https://volcano.si.edu/volcano.cfm?vn=358011)

**Acceso:** Página HTML completa; distingue Monte Tronador, grupo volcánico y cono Fonck.

**Afirmaciones respaldadas:**

- El Monte Tronador forma parte de un grupo volcánico transfronterizo con historia pleistocena.
- La posible actividad holocena del grupo se refiere al cono Fonck; su edad se expresa con incertidumbre.

**Límites:** No trasladar actividad posible de Fonck a la cumbre principal. Origen volcánico no equivale a actividad eruptiva actual. El catálogo presenta incertidumbre de última erupción; no inventar una fecha ni homologar alturas discrepantes entre fuentes.


## e12-name-mella

Mella, Muñoz, Vergara, Klohn, Farmer y Stern — Revista Geológica de Chile — Petrogenesis of the Pleistocene Tronador Volcanic Group, Andean Southern Volcanic Zone, 2005

[Petrogenesis of the Pleistocene Tronador Volcanic Group, Andean Southern Volcanic Zone, 2005](https://www.andeangeology.cl/index.php/revista1/article/view/V32n1-a09/html)

**Acceso:** Texto HTML completo; resumen y apartado Volcanic Complexes and Units.

**Afirmaciones respaldadas:**

- Distingue unidades Garganta del Diablo, Steffen, complejo Tronador y cono Fonck dentro del grupo.
- Relaciona unidades volcánicas con erosión e interacción glaciar; una montaña visible puede reunir episodios distintos.

**Límites:** No reutilizar edades o altitudes como una fecha o cota única del topónimo. La fecha 2010 de algunos metadatos de repositorio no es el año del artículo: volumen32 número1 es de 2005. No ofrece una evaluación de ruta actual.


## e12-name-puntiagudo

Smithsonian Institution — Global Volcanism Program — Puntiagudo-Cordón Cenizos — Geological Summary y Eruptive History

[Puntiagudo-Cordón Cenizos — Geological Summary y Eruptive History](https://volcano.si.edu/volcano.cfm?vn=357160&vtab=Eruptions)

**Acceso:** Página HTML completa; resumen, historial y sinónimos.

**Afirmaciones respaldadas:**

- Puntiagudo se describe como estratovolcán andesítico cuya aguja resulta de disección glaciar.
- El sistema catalogado incluye Cordón Cenizos; el evento histórico de 1850 se atribuye a ese cordón y el de 1930 figura incierto.

**Límites:** No atribuir todos los eventos del sistema a la aguja de Puntiagudo. No confundir con el cerro homónimo de la Región Metropolitana. No deducir estabilidad de roca, actividad actual ni dificultad por la clasificación.
