# Archivos de la Etapa 12

Comparación con la entrega ZIP de Etapa 11; excluye dependencias, build y entregas. El manual está fuera de academia/.

## Creados

- `data/archive/etapa11/README.md`
- `data/archive/etapa11/curriculum.json`
- `data/archive/etapa11/diagrams.json`
- `data/archive/etapa11/learning-paths.json`
- `data/archive/etapa11/mountains.json`
- `data/archive/etapa11/skills.json`
- `data/archive/etapa11/sources.json`
- `docs/etapa12/FUENTES.md`
- `docs/etapa12/INFORME.md`
- `docs/etapa12/briefs.json`
- `docs/etapa12/historical-sha256.json`
- `docs/etapa12/logs/browser-qa.txt`
- `docs/etapa12/logs/build-base.txt`
- `docs/etapa12/logs/build-links-base.txt`
- `docs/etapa12/logs/build-links.txt`
- `docs/etapa12/logs/build.txt`
- `docs/etapa12/logs/check.txt`
- `docs/etapa12/logs/git-status.txt`
- `docs/etapa12/logs/manual-tracked-diff.txt`
- `docs/etapa12/logs/routes-base.txt`
- `docs/etapa12/logs/routes-root.txt`
- `docs/etapa12/logs/tests.txt`
- `docs/etapa12/regional-research.json`
- `docs/etapa12/research.json`
- `docs/etapa12/screenshots/geologia-390px.jpg`
- `public/diagramas/e12-documentos.svg`
- `public/diagramas/e12-procesos.svg`
- `scripts/check-geology-build.mjs`
- `scripts/clean-build.mjs`
- `src/content/lecciones/corrientes-piroclasticas.md`
- `src/content/lecciones/edificios-volcanicos.md`
- `src/content/lecciones/lahares-cuencas.md`
- `src/content/lecciones/magma-lava-domos.md`
- `src/content/lecciones/mapas-peligro-volcanico.md`
- `src/content/lecciones/monitoreo-volcanico.md`
- `src/content/lecciones/relieve-volcanico-glaciar.md`
- `src/content/lecciones/sintesis-geologica.md`
- `src/content/lecciones/tectonica-subduccion.md`
- `src/content/lecciones/tefra-ceniza.md`
- `src/data/assessments/corrientes-piroclasticas.v1.json`
- `src/data/assessments/edificios-volcanicos.v1.json`
- `src/data/assessments/lahares-cuencas.v1.json`
- `src/data/assessments/magma-lava-domos.v1.json`
- `src/data/assessments/mapas-peligro-volcanico.v1.json`
- `src/data/assessments/monitoreo-volcanico.v1.json`
- `src/data/assessments/relieve-volcanico-glaciar.v1.json`
- `src/data/assessments/sintesis-geologica.v1.json`
- `src/data/assessments/tectonica-subduccion.v1.json`
- `src/data/assessments/tefra-ceniza.v1.json`
- `src/data/geology-cases.json`
- `src/data/geology-templates.json`
- `src/lib/geology-client.ts`
- `src/lib/geology.ts`
- `src/pages/geologia/index.astro`
- `tests/etapa12.test.ts`
- `docs/etapa12/ARCHIVOS.md`

## Modificados

- `README.md`
- `data/curriculum.json`
- `data/learning-paths.json`
- `data/skills.json`
- `package-lock.json`
- `package.json`
- `scripts/validate.ts`
- `src/data/diagrams.json`
- `src/data/sources.json`
- `src/layouts/Layout.astro`
- `src/lib/expanded.ts`
- `src/lib/practice-client.ts`
- `src/lib/program.ts`
- `src/pages/lecciones/[id].astro`
- `src/pages/practicas.astro`
- `src/pages/search-index.json.ts`
- `src/pages/territorio/[id].astro`
- `src/pages/territorio/index.astro`

## Eliminados

Ninguno.
