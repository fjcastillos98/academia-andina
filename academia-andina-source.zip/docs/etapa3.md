# Etapa 3 — Bloque piloto Fundamentales

Estado: implementación funcional del piloto; revisión pedagógica y técnica externa pendiente. No es una academia terminada ni una certificación. Fecha: 22-10-2026.

## Alcance académico

Diez temas nuevos (A–J), unas 30–35 min de estudio orientativo por tema más ejercicios. Los tiempos no miden competencia. Cada uno tiene objetivos, prerrequisitos, conceptos, teoría, análisis/procedimientos de preparación, errores, seguridad, equipo, recuperación activa, quiz con explicación, ejercicios, vínculo al diario, criterios, fuentes, nivel y continuidad curricular. Casos y ejercicios son elaboración didáctica original y ficticia; los conceptos técnicos citan fuentes primarias.

| Tema | Trabajo real incorporado |
| --- | --- |
| A. Riesgo | Peligro/exposición/consecuencia/incertidumbre; alternativas y presión social. |
| B. 3×3 | Nueve preguntas y revisiones en tres momentos; origen nivológico y adaptación estival explícita. |
| C. Planificación | Ficha de itinerario, supuestos de tiempo, alternativas, roles y aviso. |
| D. Meteorología | Observación/pronóstico/clima, representatividad, relieve, información faltante y decisiones. |
| E. Nubes | Diez géneros introductorios, lenticularis, registro de observación e incertidumbre. |
| F. Navegación | Escala, curvas, equidistancia, referencias de coordenadas y contraste mapa/terreno. |
| G. Equipo | Funciones, dependencias compartidas e inventario del equipo de Filo Austral. |
| H. Nudos | Funciones de ocho, ballestrinque y dinámico; referencia técnica, variantes y preparación de taller. |
| I. Cuerdas/anclajes | Denominaciones, identificación documental, recorrido conceptual de carga, fallos comunes y límites de evaluación. |
| J. Comunicaciones | Mensaje simulado, confirmación, contingencias, límites de inReach y verificación pendiente de VHF. |

Los veinte ítems nuevos de quiz comprueban conceptos y decisiones. Se conservan las tres muestras anteriores y sus preguntas/IDs. El piloto P1-A…P1-J tiene orden propio; no reemplaza M01 del currículo anterior ni reduce las 376 entradas pendientes.

## Evidencias

Diario local con todos los campos solicitados, edición y respaldo JSON v2. Migración de v1 sin pérdida de notas, favoritos e intentos. Máximo 500 prácticas y 2 MB por importación; hasta 100 intentos por lección. Evidencia textual, sin adjuntos. Los campos libres no deben contener datos médicos, contraseñas ni datos privados de terceros; no hay cifrado ni clasificación automática de texto sensible.

La matriz separa seis columnas. Una evaluación requiere práctica supervisada, supervisor, evaluador, fecha, criterio y evidencia; es una declaración del usuario, no verificación de credenciales. Confianza y repeticiones nunca conceden competencia. La evaluación más reciente prevalece; un conflicto de resultados del mismo día se presenta como «En desarrollo». No hay firma digital, acreditación ni vigencia automática.

## Revisión de instructor

Todos los temas necesitan revisión pedagógica y contextual. Prioridad: H e I, incluyendo variantes, selección de material, demostración, inspección, criterios observables y evaluación presencial. También requieren supervisión situada las prácticas de orientación y la futura gestión real de comunicaciones de grupo. No hay secuencias operativas de rescate, rápel, aseguramiento ni sistemas de izado en este piloto.

## Fuentes

El registro completo y sus enlaces están en `src/data/sources.json` y `/fuentes/`; cada lección enlaza sus referencias desde el cuerpo y muestra fecha y límites. Nuevas consultas: SLF/KAT (3×3 y riesgo), OMM (guía y lenticularis), USGS (mapa y brújula), NPS (funciones de equipo), NWS (orografía y rayos), Petzl (nudos e inspección de anclajes), UIAA (terminología de cuerdas, artículo histórico de 2021), Garmin (SOS inReach Mini 2). Leave No Trace se reutiliza desde la etapa anterior. DMC figura como portal oficial localizado, no como pronóstico o alerta local verificados.

Requieren verificación: manuales y versiones de las piezas concretas del usuario, compatibilidades, canales/autorizaciones VHF, accesos, cierres, normativa y condiciones locales. No se inventan frecuencias, cifras de resistencia, alertas ni rutas.

## Etapa 4 propuesta

1. Revisión del piloto con instructor: devolver observaciones por criterio y fuente; corregir antes de ampliar técnicas.
2. Probar tres sesiones: planificación/3×3, mapa y comunicación simulada, identificación de equipo y taller supervisado de nudos. Registrar evidencia real y revisar la utilidad del diario.
3. Construir solo el siguiente bloque de montaña estival: marcha, progresión no técnica y decisiones de grupo; después técnicas de cuerda con material docente validado.
4. Preparar una ficha territorial piloto de Los Lagos con fuentes oficiales verificadas, sin publicar rutas o dificultades no contrastadas.

Altitud, medicina, entrenamiento científico, invierno, glaciar, hielo, ecología, geología e historia permanecen en el alcance futuro solicitado. No se han generado cientos de páginas ni investigado aún Cerro Sarnoso u otras fichas territoriales como hechos establecidos.
