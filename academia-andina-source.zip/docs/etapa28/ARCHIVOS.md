# Estados iniciales revisados

- src/pages/historia.astro
- src/pages/liderazgo.astro
- src/pages/invierno/index.astro
- src/pages/ecologia/index.astro
- src/pages/entrenamiento/index.astro
- src/pages/hielo/index.astro
- src/pages/lecciones/[id].astro
- src/pages/geologia/index.astro
- src/pages/glaciar/index.astro
- src/pages/altitud/index.astro
- src/pages/alpina/index.astro
- src/components/LessonCard.astro
