# Etapa 28 · Coherencia de orientación y estados

Fecha: 30 de octubre de 2026. Versión 0.28.0.

## Cambios

- Fundamentales ya no afirma que los bloques posteriores están sin desarrollar. Aclara su condición de piloto y enlaza al catálogo disponible. El rótulo distingue diez lecciones de las 24 asignaturas históricas.
- El mapa y las fichas de asignatura distinguen las entradas del temario histórico, las lecturas disponibles y el cierre editorial pendiente. Enlazan a la matriz de correspondencias sin convertir propuestas parciales en cobertura completa.
- Los prerrequisitos de cada asignatura muestran el título correspondiente, en lugar del texto fijo «Fundamentos» para todos.
- Las tarjetas, páginas de lección y secuencias temáticas muestran «Estado local sin cargar» antes de leer datos, en lugar de «No estudiada». Se conserva «No estudiada» como estado real una vez leídos los registros.
- La portada muestra «Sin cargar» inicialmente y oculta la barra de progreso hasta disponer de datos legibles. No presenta un cero como resultado antes de cargar los registros.
- Los fallos de carga de los catálogos de lecciones o evaluaciones presentan datos no disponibles y ocultan la sugerencia de continuar. Los errores de lectura del almacenamiento también mantienen oculta la barra.

La revisión se limita a la orientación y presentación de estados identificadas en estas páginas; no constituye auditoría completa del contenido académico. No cambia el criterio de aprobación, el formato de respaldo, las 175 lecciones, las rutas ni la matriz curricular. No se modificó el manual original ni se publicó o realizó push.

## Verificación

- 188 pruebas existentes aprobadas, cero fallos.
- Astro: 139 archivos, cero errores, advertencias y sugerencias.
- 286 páginas, 12338 enlaces/recursos internos y 669 resultados de búsqueda verificados en `/` y `/academia-andina/`.
- Inspección de código de los estados iniciales, fallo de carga y lectura no disponible.
- Revisión visual, móvil e interacción real pendiente por la restricción de navegador previamente observada. Los fallos de carga y almacenamiento no se simularon en navegador; no se declara verificación integral de esas interacciones.

## Continuidad

Siguiente mejora propuesta: dar acceso directo desde cada lección a las rutas que la incluyen, respetando las lecciones compartidas y el orden del programa.

Entrega ZIP con código, contenido, pruebas e informe; sin dependencias, compilados ni registros personales del navegador.
