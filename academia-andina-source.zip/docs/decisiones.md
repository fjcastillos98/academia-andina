# Decisiones de la Etapa 2

- Carpeta independiente `academia/`; manual y auditoría originales intactos.
- Astro 7.4.2, Node 24 y dependencias fijadas con lockfile. No se requiere servidor de producción.
- Markdown compilado a HTML: lectura disponible sin parser remoto. JavaScript para interacciones; sin CDN, fonts remotas ni imágenes de geografía supuesta.
- Identidad bosque/crema, marca tipográfica propia y dibujo topográfico decorativo, no cartografía navegable.
- `localStorage` encapsulado para texto pequeño. Decisión distinta del IndexedDB preliminar; migración futura al crecer registros. No se presume sincronización.
- Los cuestionarios y claves son públicos en una web estática: son herramientas de autoestudio, no exámenes acreditables ni resistentes a manipulación.
- Publicación desactivada. Plantilla para futuro repositorio independiente, evitando sustituir el manual.
- Servidor de desarrollo escucha en 0.0.0.0; se admite específicamente terminal.local para QA gestionada. No hay comodín de hosts. No exponer el servidor de desarrollo como producción.
- Tres muestras; 376 entradas conservadas pendientes. No hay descenso de clientes, dosis, rescate o normativa publicados como procedimiento vigente.

Documentación técnica consultada (21-10-2026):
- https://docs.astro.build/en/guides/content-collections/
- https://docs.astro.build/en/guides/deploy/github/

Referencias formativas y límites están en `src/data/sources.json` y en las páginas de lección/fuentes.
