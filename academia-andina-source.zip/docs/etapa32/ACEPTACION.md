# Acta de entrega y aceptación pendiente

30 de octubre de 2026 · 0.32.0.

El ciclo de entrega local de etapas 1–32 termina con código y documentación. No declara validación integral del producto ni cierre del currículo. Los informes antiguos describen su etapa, no sustituyen este estado de entrega.

## Comprobado

Pruebas automatizadas de lógica, validación curricular, tipos Astro, compilaciones en raíz y subruta, enlaces/recursos y reglas parciales de accesibilidad estática. Ver registros de etapa32 y de etapas30–31. Las tres incidencias de la revisión30 tienen corrección en código en etapa31.

## Pendiente de aceptación en navegador

La restricción de acceso observada impidió estas comprobaciones. No se intentó eludirla.

| Prueba | Criterio observable | Estado |
| --- | --- | --- |
| Móvil y escritorio | A 390 px y en escritorio: textos y controles legibles, índice disponible, sin desbordamiento de página | Pendiente |
| Teclado | Tab y Shift+Tab, foco visible, enlace saltar contenido, índice, formularios y tablas alcanzables | Pendiente |
| Búsqueda | Buscar con tildes, filtrar Ruta de estudio, abrir resultado correcto | Pendiente |
| Quiz y notas | Guardar, recargar y recuperar exactamente resultado y texto | Pendiente |
| Taller y diario | Guardar respuestas y práctica ficticia identificada como prueba; comprobar edición y recarga | Pendiente |
| Respaldo | Exportar, cancelar una importación sin cambios, confirmar en un perfil de prueba y comparar registros | Pendiente |
| Fallos | Error de JSON/red y almacenamiento bloqueado: aviso explícito, sin falso vacío ni sobrescritura | Pendiente |
| Sin JavaScript | Lectura y enlaces disponibles, estados sin cargar claramente indicados | Pendiente |

Ejecutar las pruebas con datos ficticios en un perfil separado; exportar primero cualquier registro real. Anotar fecha, versión, navegador, pantalla, pasos, resultado y evidencia. Si algo falla, registrar y corregir antes de marcarlo conforme. No reutilizar resultados visuales de etapas anteriores para cerrar esta lista.

## Límites de entrega

No es una app móvil instalable, no hay sincronización de cuentas, no se publicaron servicios y no hay acreditación profesional. El manual original no forma parte de los cambios. Las competencias prácticas y el contenido especializado mantienen sus revisiones pendientes.

No quedan etapas numeradas del ciclo de entrega propuesto. Sí quedan las verificaciones de esta acta y el desarrollo académico futuro; deben tratarse como trabajo pendiente, no como resuelto por el cierre documental.
