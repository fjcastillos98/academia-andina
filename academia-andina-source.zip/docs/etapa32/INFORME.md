# Etapa 32 · Entrega documental de la versión local

30 de octubre de 2026 · Versión 0.32.0.

El paquete cierra el ciclo propuesto de 32 etapas para la plataforma disponible. Incluye guía de inicio, instalación local, uso y respaldos; mantenimiento; y acta de aceptación con pendientes. No se añadieron funciones ni contenidos académicos en esta etapa. Se actualizaron la versión y la presentación general del README, que conservaba cifras de etapas anteriores.

## Documentos de entrada

- INICIO.md, en la raíz: instalación, primera sesión, respaldo y solución de problemas.
- MANTENIMIENTO.md, en esta carpeta: compilación, bases y conservación del historial.
- ACEPTACION.md, en esta carpeta: evidencia disponible, pruebas pendientes y criterios de aceptación.
- README.md: mapa del proyecto y antecedentes históricos.

## Verificación de entrega

190 pruebas aprobadas. Astro: 142 archivos, cero errores, advertencias y sugerencias. Compilaciones en raíz y /academia-andina/: 286 páginas, 12687 enlaces/recursos internos y 669 resultados de búsqueda comprobados. Inspección estática parcial: 1974 controles y 4180 enlaces con fragmento, sin hallazgos en las reglas aplicadas en ambas bases.

La instalación desde cero con npm ci en otro computador no se ejecutó; se usaron las dependencias ya instaladas. Las instrucciones se contrastaron con package.json y la configuración local. La revisión visual e interactiva permanece pendiente por la restricción de navegador, como especifica ACEPTACION.md. No se declara conformidad WCAG ni validación integral.

El paquete contiene 175 lecciones y 16 rutas. La matriz conserva 46 propuestas parciales y 330 entradas sin revisar de 376 entradas históricas. El currículo académico no está terminado ni validado presencialmente.

## Alcance del cierre

No quedan etapas numeradas del plan de entrega local. Sí quedan aceptación visual/interactiva y desarrollo académico. No se publicó, no se hizo push ni se modificó el manual original. La versión se entrega como fuente reproducible con dependencias bloqueadas, no como ejecutable de escritorio o app móvil.

El ZIP excluye dependencias, compilados, metadatos Git, entregas anteriores y datos del navegador. MANIFIESTO.sha256 enumera hashes de los archivos incluidos, salvo el propio manifiesto.
