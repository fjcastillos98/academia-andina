# Mantenimiento de la entrega 0.32.0

## Verificar cambios

Desde academia, con las dependencias instaladas:

```text
npm run check
npm test
npm run build
npm run test:build
python3 scripts/audit-accessibility.py
```

Python 3 se utiliza solo para la inspección estática opcional, no para ejecutar la plataforma. El script de accesibilidad emite JSON con hallazgos; revisar su lista `issues`, pues no falla automáticamente al detectar problemas. No sustituye pruebas visuales ni certifica WCAG.

`build` limpia compilados y ejecuta auditoría curricular y validación antes de generar `dist`. `npm run preview -- --host 127.0.0.1` sirve ese resultado. No ejecutar compilaciones simultáneas en esta carpeta.

## Base alternativa

La base debe empezar y terminar con `/`. Mantén el mismo valor al compilar, comprobar enlaces y previsualizar. Ejemplo en PowerShell:

```powershell
$env:BASE_PATH='/academia-andina/'
npm run build
npm run test:build
npm run preview -- --host 127.0.0.1
```

Abre la dirección indicada con `/academia-andina/` al final. Para volver a raíz, detén el servidor y elimina la variable antes de recompilar:

```powershell
Remove-Item Env:BASE_PATH
npm run build
```

En bash, antepone `BASE_PATH=/academia-andina/` a cada comando correspondiente. Cambiar base, host o puerto cambia el ámbito del almacenamiento; exporta antes. SITE_URL es configuración de compilación, no una operación de publicación. No se realizó publicación ni push en esta entrega.

## Editar contenido

- Lecciones: src/content/lecciones; conservar identificadores, referencias y estados editoriales.
- Evaluaciones versionadas: src/data/assessments. Conservar versiones usadas por respaldos e historial.
- Rutas, habilidades y currículo: data/. No convertir entradas históricas pendientes en completadas por añadir enlaces.
- Fuentes: src/data/sources.json. Registrar alcance real de consulta y revisión; no atribuir revisión especializada sin evidencia.
- Presentación: src/pages, src/components y src/styles. Estado local: src/lib/state.ts y clientes asociados.

Antes de actualizar, conservar carpeta anterior y exportar respaldo. Trabajar en una copia, ejecutar verificaciones y documentar las diferencias. Para volver atrás, servir la versión anterior por separado y comprobar compatibilidad del respaldo antes de importarlo. No borrar registros ni retirar versiones de evaluación para simplificar una actualización.

## Alcance académico

La matriz mantiene 46 propuestas parciales y 330 entradas sin revisar, de 376 entradas históricas. No son porcentajes de competencia o de contenido terminado. Quedan revisión especializada, ampliación y evaluación presencial según cada materia. Las fuentes operativas, permisos y condiciones de terreno requieren comprobación independiente antes de actividades reales.
