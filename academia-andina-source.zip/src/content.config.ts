import { defineCollection } from 'astro:content';
import { glob } from 'astro/loaders';
import { lessonSchema } from './lib/schemas';
export const collections={lecciones:defineCollection({loader:glob({pattern:'**/*.md',base:'./src/content/lecciones'}),schema:lessonSchema})};
