import {getCollection} from 'astro:content';
import {url} from '../lib/catalog';
export async function GET(){const lessons=(await getCollection('lecciones')).sort((a,b)=>a.data.order-b.data.order);return new Response(JSON.stringify(lessons.map(l=>({id:l.id,title:l.data.title,href:url(`lecciones/${l.id}/`),quiz:l.data.quiz,pilot:l.data.pilot}))));}
