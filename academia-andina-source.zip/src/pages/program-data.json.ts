import skills from '../../data/skills.json';
const assessments=Object.values(import.meta.glob('../data/assessments/*.json',{eager:true,import:'default'}));
export function GET(){return new Response(JSON.stringify({skills,assessments}));}
