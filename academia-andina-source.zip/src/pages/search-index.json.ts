import expeditionCases from '../data/expedition-cases17.json';
import geologyCases from '../data/geology-cases.json';
import {getCollection} from 'astro:content';
import {curriculum,url,shortTitle} from '../lib/catalog';
import mountains from '../lib/mountains';
import species from '../data/species.json';
import cases from '../data/cases.json';
import glossary from '../data/glossary.json';
import reviewStations from '../data/review51.json';
import winterEquipment from '../data/winter-equipment.json';
export async function GET(){const lessons=await getCollection('lecciones');const items=[
 {title:"Elegir qué estudiar",description:"Seis objetivos para recorrer las rutas del programa",content:"Fundamentos, cuerdas, ambientes técnicos, preparación personal, territorio y guiado",href:url("estudiar/"),kind:"Ruta de estudio",module:""},
 {title:"Ruta de guiado y servicio",description:"Diez lecciones en cuatro bloques y un caso integrador",content:"Ética, pedagogía, comunicación, interpretación, atención y revisión",href:url("ruta-guiado/"),kind:"Ruta de estudio",module:"M19"},
 {title:"Integración de guiado y servicio",description:"Seis momentos y cuatro contrastes de coherencia",content:"Briefing, adaptación, decisiones, interpretación, quejas y debriefing",href:url("integracion-guiado/"),kind:"Caso",module:"M19"},
 {title:"Quejas e incidentes de servicio",description:"Taller de recepción, respuesta y seguimiento",content:"Hechos, versiones, prioridades, derivación y cierre",href:url("atencion/"),kind:"Taller documental",module:"M19"},
 {title:"Comunicación intercultural e interpretación",description:"Taller de guion con evidencia y revisión",content:"Observación, fuente, inferencia, comunidades y comprensión",href:url("interpretacion/"),kind:"Taller documental",module:"M19"},
 {title:"Taller de ética y responsabilidad",description:"Cuatro casos originales de decisión profesional",content:"Credenciales, presión comercial, trato digno y comunidades",href:url("etica/"),kind:"Taller documental",module:"M00"},
 {title:"Matriz de trazabilidad curricular",description:"376 entradas históricas: fundamentos, riesgo, planificación y liderazgo",content:"Evidencia textual, alcance, vacíos y revisión pendiente",href:url("trazabilidad/"),kind:"Taller documental",module:"M19"},
 {title:"Auditoría curricular",description:"Inventario, cobertura y prioridades editoriales",content:"Módulos, vacíos, duplicidades, revisión y trazabilidad",href:url("auditoria/"),kind:"Taller documental",module:"M00"},
 ...expeditionCases.map(c=>({title:c.title,description:c.context,content:c.events.map(e=>e.information+" "+e.prompt).join(" "),href:url(`expediciones/${c.id}/`),kind:"Caso",module:"M23"})),
 {title:"Pedagogía, guiado y liderazgo",description:"Seis unidades: objetivos, briefing, enseñanza, comunicación, decisiones y debriefing",content:"Plan de taller y revisión humana",href:url("liderazgo/"),kind:"Taller documental",module:"M19"},
 {title:"Seleccionar cartografía · Calbuco y Osorno",description:"Etapa 15.1: hojas IGM, cobertura y pendientes",content:"Correntoso H-052 Calbuco H-069 Las Cascadas H-043 Puerto Montt datum vertical",href:url("territorio/cartografia/"),kind:"Taller documental",module:"M18"},
 {title:"Calbuco y Osorno · expedientes documentales",description:"Etapa 15: discrepancias de altitud y cartografía oficial",content:"SERNAGEOMIN, IGM, escala, datum, cota, solicitud de revisión y consulta parcial",href:url("territorio/expedientes/"),kind:"Taller documental",module:"M18"},
 {title:"Comparar evidencia territorial",description:"Taller de Hornopirén, Michinmahuida, Chaitén y Corcovado",content:"Cota, datum, reportes inciertos, permisos y solicitudes de verificación",href:url("territorio/comparar/"),kind:"Taller documental",module:"M18"},
 ...geologyCases.map(c=>({title:`Ampliación geológica: ${c.name}`,description:c.conclusion,content:[c.evidence,c.uncertainties].join(" "),href:url(`territorio/${c.id}/#geologia-etapa12`),kind:"Ficha territorial",module:"M18"})),
 ...reviewStations.map(s=>({title:s.title,description:s.goal,content:[s.finding,...s.checks,...s.criteria,s.practice].join(" "),href:url(`invierno/revision/#${s.id}`),kind:"Pauta de revisión",module:""})),
 ...winterEquipment.map(c=>({title:c.title,description:c.function,content:Object.values(c).join(" "),href:url(`invierno/equipo/#${c.id}`),kind:"Equipo educativo",module:"M21"})),
 ...mountains.map(m=>({title:m.name,description:m.geologicalClassification,content:Object.values(m).flat().join(" "),href:url(`territorio/${m.id}/`),kind:"Ficha territorial",module:"M18"})),
 ...species.map(s=>({title:s.commonName,description:s.scientificName,content:Object.values(s).flat().join(" "),href:url(`especies/${s.id}/`),kind:"Especie",module:"M15"})),
 ...cases.map(c=>({title:c.title,description:c.intro,content:c.sections.map(s=>s.body).join(" "),href:url(`casos/${c.id}/`),kind:"Caso",module:""})),
 ...lessons.map(l=>({title:l.data.title,description:l.data.description,content:l.body||'',href:url(`lecciones/${l.id}/`),kind:'Lección',module:l.data.module})),
 ...curriculum.modules.flatMap(m=>[{title:shortTitle(m.title),description:`${m.topics.length} entradas pendientes`,content:m.topics.join(' '),href:url(`modulos/${m.id.toLowerCase()}/`),kind:'Asignatura',module:m.id},...m.topics.map((t,i)=>({title:t,description:'Pendiente de desarrollo y validación. No es una lección finalizada.',content:'',href:url(`modulos/${m.id.toLowerCase()}/#tema-${i+1}`),kind:'Tema pendiente',module:m.id}))]),
 ...glossary.map(t=>({title:t.term,description:t.definition,content:t.definition,href:url(`glosario/#${t.id}`),kind:'Glosario',module:''}))];return new Response(JSON.stringify(items));}
