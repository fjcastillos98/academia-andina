---
{
  "title": "Rescate con pasajeros y coordinación de apoyo",
  "description": "Distinguir necesidades de un pasajero y capacidad real del grupo.",
  "module": "M19",
  "code": "E44-24",
  "order": 323,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U44-06",
  "skills": [
    "s44-rescate-pasajeros"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir necesidades de un pasajero y capacidad real del grupo.",
    "Organizar un mensaje de apoyo externo sin prometer tiempos de rescate.",
    "Justificar alternativas y límites de actuación de un guía aislado."
  ],
  "prerequisites": [
    "s44-autorrescate-escenarios"
  ],
  "sources": [
    "nps-emergencia",
    "petzl-rescate-principios"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "rescate-decision"
  ],
  "preparation": [
    "Explicar los conceptos sin confundir un modelo con una maniobra.",
    "Reconocer al menos dos errores del caso y justificar una alternativa.",
    "Identificar la documentación y las competencias prácticas que faltan."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "nps-emergencia",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un pasajero asustado no avanza. ¿Qué respuesta es defendible?",
        "options": [
          "Prometer seguridad absoluta.",
          "Escuchar, verificar comprensión y reevaluar alternativas.",
          "Forzarlo para cumplir horario."
        ],
        "answer": 1,
        "explanation": "El problema requiere información y trato responsable.",
        "rationales": [
          "No se puede prometer ausencia de riesgo.",
          "El problema requiere información y trato responsable.",
          "La presión puede empeorar la situación."
        ],
        "source": "nps-emergencia",
        "kind": "caso",
        "difficulty": "intermedia"
      },
      {
        "prompt": "El guía aislado necesita funciones simultáneas incompatibles.",
        "options": [
          "Debe reconocer el límite y coordinar apoyo.",
          "Basta escribir todos los roles a su nombre.",
          "Puede asignarlos a cualquiera."
        ],
        "answer": 0,
        "explanation": "La organización debe ser viable con capacidades reales.",
        "rationales": [
          "La organización debe ser viable con capacidades reales.",
          "Un papel no crea capacidad ni atención.",
          "Cada rol crítico exige competencia."
        ],
        "source": "petzl-rescate-principios",
        "kind": "decisiones",
        "difficulty": "intermedia"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

El grupo es parte de la escena, no un recurso técnico ilimitado. Lesión, incapacidad, miedo y agotamiento no son diagnósticos intercambiables. La respuesta del guía debe respetar formación, información y recursos, y mantener comunicación comprensible con pasajeros y apoyo.

## Teoría y decisiones

**Pasajero lesionado:** hechos observables, peligros inmediatos y posibilidades de contacto son información prioritaria. La atención sanitaria corresponde al nivel de formación y protocolos apropiados. No registrar detalles médicos en esta academia; usar un caso ficticio o un aprendizaje anonimizado.

**Pasajero incapacitado:** no suponer cooperación para conexiones, desplazamiento o instrucciones. La incapacidad puede transformar una propuesta que dependía de participación activa. Requiere revisar recursos y apoyo organizado; la existencia de una cuerda no sustituye esa capacidad.

**Pasajero con miedo:** escuchar, explicar opciones y comprobar comprensión sin coerción. No diagnosticar la causa ni forzar el movimiento para cumplir un horario. Puede ser necesario cambiar objetivo o pedir apoyo; no prometer seguridad absoluta para tranquilizar.

**Persona que no puede continuar:** distinguir la decisión de detener progresión de la elección del medio de evacuación. Reunir información y revisar alternativas verificadas. Descenso asistido no es automáticamente la alternativa más sencilla: exige terreno, soporte, competencias y control de todos los participantes.

**Evacuación y apoyo externo:** coordinar localización, referencia, hechos, recursos, restricciones y cambios. Acordar cómo confirmar recepción y qué hacer si falla el medio. No inventar frecuencias VHF, números o tiempos de respuesta. Los medios deben verificarse en el plan real. Un SOS satelital no garantiza rescate inmediato ni elimina la obligación de mantener control.

El guía aislado tiene límites de atención y actuación: no puede convertirse simultáneamente en rescatista técnico, asegurador, sanitario y responsable del resto por declararlo en un plan. El rescate organizado puede aportar capacidades, pero su disponibilidad debe confirmarse. La preparación es establecer una organización viable antes del problema, no improvisar roles imposibles.

## Caso práctico y aplicación al guiado

Filo Austral tiene un pasajero inmovilizado por una causa no determinada, dos personas con frío y comunicación intermitente. Propón prioridades y funciones realizables sin añadir diagnósticos. Si para atender al afectado debes perder control de los demás, identifica el conflicto y qué apoyo necesita resolverse. Redacta un mensaje simulado sin nombres.

## Errores frecuentes y señales de alerta

Convertir miedo en desobediencia; presionar para ahorrar tiempo; usar a un pasajero como operador técnico sin formación; prometer evacuación aérea; ocultar límites al apoyo; registrar información médica innecesaria en el diario de estudio.

## Autoevaluación y respuestas explicadas

¿Puede considerarse a todos los pasajeros ayudantes técnicos? **No: capacidad y función deben verificarse.** ¿Qué aporta un mensaje factual? **Permite a quienes apoyan interpretar la situación sin mezclar observaciones con diagnósticos supuestos.**

## Ejercicios y práctica presencial

Escenificación de briefing y comunicación en aula, con cambio de condiciones y un canal simulado. Evaluación de decisiones y trato al pasajero por instructor. Formación presencial separada para evacuación, primeros auxilios y descenso asistido.

## Evidencia requerida

Mensaje, reparto de roles viable, alternativas y criterios de solicitud de apoyo. Registrar aprendizaje anonimizado, observaciones y próxima práctica.

## Relaciones con otras habilidades

Revisa los prerrequisitos y el contrato de habilidad de esta unidad en el programa. Contrasta la explicación con las fuentes indicadas: las cifras de un ejercicio no son límites de uso de un equipo. Toda transferencia a una situación con personas requiere formación y revisión presencial.
