---
{
  "title": "Montaña invernal: cambia el sistema de decisiones",
  "description": "Comparar una actividad estival con su versión invernal sin asumir equivalencia.",
  "module": "M02",
  "code": "E5-01",
  "order": 500,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-01",
  "skills": [
    "s5-invierno-fundamentos"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Comparar una actividad estival con su versión invernal sin asumir equivalencia.",
    "Relacionar terreno, condiciones y capacidades del grupo.",
    "Identificar información que falta antes de conservar una ruta conocida."
  ],
  "prerequisites": [
    "gestion-del-riesgo",
    "cartografia-orientacion",
    "equipamiento",
    "meteorologia-montana",
    "comunicaciones-emergencia"
  ],
  "sources": [
    "e5-snow-material",
    "e5-exposure",
    "e5-kat-learning"
  ],
  "pending": [
    "Revisión pedagógica y de instructor. Condiciones, cobertura de boletines y aplicación territorial real: PENDIENTE DE VERIFICACIÓN."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una ruta tiene el mismo nombre en ambas estaciones. ¿Qué se conserva automáticamente?",
        "options": [
          "Su dificultad.",
          "La identificación nominal, no sus condiciones.",
          "Su tiempo de recorrido."
        ],
        "answer": 1,
        "explanation": "El nombre no describe el estado actual.",
        "rationales": [
          "La dificultad puede cambiar.",
          "Distingue identidad y condiciones.",
          "La superficie y el grupo alteran el tiempo."
        ],
        "source": "e5-snow-material",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "El sector donde estás es suave pero recibe una ladera superior. ¿Qué falta analizar?",
        "options": [
          "Solo el calzado.",
          "Solo tu pendiente local.",
          "La conexión y exposición desde arriba."
        ],
        "answer": 2,
        "explanation": "Exposición incluye posición respecto de terreno conectado.",
        "rationales": [
          "Es un recurso, no evaluación del terreno.",
          "Omite la fuente superior.",
          "Considera trayectoria y ubicación."
        ],
        "source": "e5-exposure",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "Un folleto técnico fue leído y entendido. ¿Qué demuestra?",
        "options": [
          "Preparación teórica que requiere práctica y revisión.",
          "Competencia invernal validada.",
          "Capacidad de rescatar a un cliente."
        ],
        "answer": 0,
        "explanation": "SLF vincula esos materiales con formación.",
        "rationales": [
          "Respeta el alcance.",
          "No hubo evaluación práctica.",
          "No hubo demostración de rescate."
        ],
        "source": "e5-kat-learning",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Distingue conocimiento previo de condición actual.",
    "Relaciona cambio con consecuencia y capacidad necesaria.",
    "Formula una alternativa y explicita qué falta verificar."
  ],
  "openAssessment": {
    "prompt": "Explica tres cambios que invalidarían un plan estival y propone qué verificar o qué objetivo reducir.",
    "rubric": [
      "Distingue conocimiento previo de condición actual.",
      "Relaciona cambio con consecuencia y capacidad necesaria.",
      "Formula una alternativa y explicita qué falta verificar."
    ],
    "source": "e5-snow-material",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-retirada"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Identifica cambios de superficie, referencias, exposición y funcionamiento del grupo; registra hora y lugar de observación.

## Teoría y toma de decisiones

El invierno modifica la relación entre desplazamiento, terreno y consecuencias. El nombre de una ruta puede permanecer, mientras cambian la superficie, las referencias y las capacidades necesarias. Una huella visible en verano puede quedar cubierta; un tramo con apoyo firme puede exigir desplazamiento sobre nieve o hielo; un sector de paso puede recibir nieve desde una ladera situada más arriba. La experiencia anterior sigue siendo información útil, pero debe fecharse y delimitarse: conocer la geometría general no equivale a conocer las condiciones presentes.

La nieve es un material cuya estructura y propiedades cambian; no es una cubierta homogénea [SLF](#fuente-e5-snow-material). Esto importa al comparar capacidad de apoyo, esfuerzo y observación. El hielo o una superficie endurecida pueden cambiar las consecuencias de un resbalón, mientras nieve profunda puede alterar el tiempo y el consumo de recursos. No basta con agregar crampones al listado: hay que comprobar compatibilidad y capacidad práctica para usar el material en ese contexto. La posesión de equipo no completa esa evaluación.

El frío y el viento afectan protección, destreza y comunicación. La visibilidad condiciona qué referencias pueden reconocerse y con qué anticipación se detecta un cambio de terreno. Las horas de luz se consultan para fecha y lugar, no se deducen de una temporada en abstracto. Un plan que dependía de señales visuales distantes necesita contingencias cuando esas señales desaparecen. Retirada, demora y asistencia deben analizarse junto al ascenso, porque el grupo conserva exposición durante el regreso.

En avalanchas, exposición describe dónde y durante cuánto tiempo se interactúa con el terreno capaz de afectar al grupo [Avalanche.org](#fuente-e5-exposure). Caminar por un sector poco inclinado no responde por sí solo a lo que puede ocurrir sobre él. Un análisis inicial pregunta por salidas, trayectorias y depósitos posibles, por trampas de terreno y por las capacidades de las personas que se desplazan allí. Ese análisis se profundiza en las unidades de nieve, terreno y boletines.

La distinción tradicional entre riesgo objetivo y subjetivo puede ayudar a ordenar preguntas: fenómenos y características del entorno por una parte, decisiones, preparación y conducta por otra. No debe crear dos compartimentos independientes. Una decisión de horario modifica la exposición a un proceso; una limitación del grupo modifica qué alternativa es ejecutable. En esta academia se pide describir peligro, exposición, consecuencias y controles concretos antes de usar una etiqueta.

Para practicar la comparación, construye dos columnas para un mismo recorrido hipotético. En la primera escribe qué evidencia estival tienes; en la segunda, qué debe verificarse para invierno. Añade una tercera con la decisión que impide tomar cada vacío. Si falta información decisiva, reducir o cancelar el objetivo es una conclusión válida. La síntesis escrita prepara un taller; los materiales de prevención de SLF se conciben vinculados a cursos y conocimientos previos [fuente](#fuente-e5-kat-learning).

## Qué observo, qué significa y qué no puedo concluir

Una comparación documental no reconoce una ruta ni demuestra capacidad de progresión.

## Caso práctico y aplicación al guiado

Un tramo conocido de verano ahora está cubierto de nieve y sin referencias visuales. ¿Qué parte de tu conocimiento sigue siendo útil y qué no?

## Errores frecuentes y señales de alerta

Asumir misma dificultad por igual nombre; convertir equipo comprado en habilidad; calcular solo el ascenso.

## Autoevaluación y respuesta razonada

Explica tres cambios que invalidarían un plan estival y propone qué verificar o qué objetivo reducir.

## Ejercicios y práctica supervisada

Comparación de escritorio de dos escenarios sin salir a terreno expuesto. Prácticas de marcha y equipo con instructor.

## Evidencia requerida

- Distingue conocimiento previo de condición actual.
- Relaciona cambio con consecuencia y capacidad necesaria.
- Formula una alternativa y explicita qué falta verificar.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-invierno-fundamentos).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
