---
{
  "title": "Prusik",
  "description": "Identificar nombre, variante y función de prusik.",
  "module": "M07",
  "code": "E43-10",
  "order": 309,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U43-03",
  "skills": [
    "s43-prusik"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Identificar nombre, variante y función de prusik.",
    "Distinguir límites de uso, errores y compatibilidades pendientes.",
    "Preparar una revisión presencial con evidencia."
  ],
  "prerequisites": [
    "s43-nudo-dinamico"
  ],
  "sources": [
    "petzl-friccion"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "revision-visual"
  ],
  "preparation": [
    "Función: nudo de fricción que la fuente describe con bloqueo en ambas direcciones.",
    "Error: intercambiar cordinos distintos sin reevaluar.",
    "Compatibilidad: tipo y diámetro se seleccionan respecto de la cuerda."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "petzl-friccion",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "En el estudio de prusik, ¿qué afirmación es defendible?",
        "options": [
          "Su nombre garantiza agarre con cualquier material.",
          "Función: nudo de fricción que la fuente describe con bloqueo en ambas direcciones.",
          "El diámetro por sí solo prueba compatibilidad."
        ],
        "answer": 1,
        "explanation": "La función debe identificarse dentro del alcance descrito; no implica aptitud del conjunto.",
        "rationales": [
          "La afirmación omite contexto o atribuye una función no demostrada.",
          "Función: nudo de fricción que la fuente describe con bloqueo en ambas direcciones. Se mantiene su alcance específico.",
          "No permite evaluar el sistema completo ni sus límites."
        ],
        "source": "petzl-friccion",
        "difficulty": "básica",
        "kind": "conocimiento"
      },
      {
        "prompt": "El nudo parece correcto, pero no se ve su conexión. ¿Qué concluyes?",
        "options": [
          "El sistema ya está revisado.",
          "La conexión es necesariamente incorrecta.",
          "Falta información; no aprobar el conjunto por una sola parte."
        ],
        "answer": 2,
        "explanation": "La revisión debe distinguir lo observado de lo que aún no se puede comprobar.",
        "rationales": [
          "Extrapola una parte al conjunto.",
          "La falta de imagen no prueba un defecto.",
          "Conserva incertidumbre y pide una comprobación concreta."
        ],
        "source": "petzl-friccion",
        "difficulty": "intermedia",
        "kind": "errores"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

Nombre: Prusik, variante exacta de la fuente. Característica: anillo, cuerda soporte y disposición forman un conjunto.

## Teoría: función, aplicación y límites

- Función: nudo de fricción que la fuente describe con bloqueo en ambas direcciones.

- Uso: estudiar interacción entre cordino y cuerda.

- No uso: no asumir agarre por el nombre o por número memorizado de vueltas.

- Ventaja didáctica: revela que la compatibilidad es funcional.

- Limitación: la configuración debe probarse en un entorno controlado con instructor.

- Característica: anillo, cuerda soporte y disposición forman un conjunto.

La pregunta de estudio no termina al reconocer el nombre. Explica qué se pretende conectar, cuál es el recorrido de la carga y qué información falta para evaluar el conjunto. Distingue la observación directa de una suposición: no ver un defecto en una imagen no equivale a revisar todas las caras. En una sesión de guiado, pide al alumno describir la función con sus palabras antes de discutir rapidez o destreza.

[Referencia técnica: petzl-friccion](#fuente-petzl-friccion). Consulta los diagramas del fabricante para la configuración exacta; las láminas de esta academia analizan funciones y errores, no sustituyen esos diagramas ni el taller.

## Caso práctico y aplicación al guiado

Ejercicio: dos anillos tienen igual diámetro declarado y distinta construcción. ¿Son intercambiables? No se concluye: falta documentación y evaluación de interacción.

- Montaña: introducción al respaldo y captura, sin procedimiento de rescate.

- Guiado: registrar combinación concreta practicada.

## Errores frecuentes y señales de alerta

Error: intercambiar cordinos distintos sin reevaluar.

## Inspección y compatibilidades

Inspección: montaje, continuidad, compatibilidad y funcionamiento según fuente/instructor.

Compatibilidad: tipo y diámetro se seleccionan respecto de la cuerda.

Se debe detener la propuesta si no se identifica la variante o el lugar de conexión. La revisión de extremos se hace según referencia aplicable; no se añade una cifra universal. La condición del material también necesita documentación e inspección, incluso cuando el recorrido del nudo parece correcto.

## Autoevaluación y respuestas explicadas

¿Reconocer una forma demuestra ejecución en terreno? **No: faltan selección, conexión, inspección, comunicación y desempeño bajo las condiciones evaluadas.**

¿Qué debes registrar si dos personas no coinciden en la variante? **Los nombres y diagramas utilizados, la fuente de cada uno y la discrepancia; resolverla con instructor antes de una aplicación.**

## Ejercicios y práctica presencial

Práctica: presencial; no cargar personas en pruebas individuales.

Prepara una ficha de comparación entre la función prevista y una función que este estudio no autoriza. Explica un error posible sin introducirlo en material en uso. En taller, el instructor observa identificación, confección, vestido, ajuste y revisión cruzada con material didáctico y condiciones controladas. No se carga una persona ni se improvisa una maniobra durante el estudio individual.

## Evidencia requerida

Nombre y variante, fuente, combinación de material, observación del instructor, error detectado, corrección y nueva práctica. La evaluación presencial debe declarar contexto y límites; un cuestionario solo registra comprensión.

## Relaciones con otras habilidades

Este tema precede a revisión de nudos y encordamiento. No se utiliza el resultado del quiz como habilitación para asegurar, descender o rescatar.
