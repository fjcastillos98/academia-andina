---
{
  "title": "Fuerza máxima: capacidad, técnica y progresión",
  "description": "Distinguir el objetivo de fuerza del esfuerzo indiscriminado.",
  "module": "M22",
  "code": "E10-02",
  "order": 1002,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U10-02",
  "skills": [
    "s10-fuerza-maxima"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Distinguir el objetivo de fuerza del esfuerzo indiscriminado.",
    "Aplicar el concepto a una decisión de preparación de montaña y reconocer sus límites."
  ],
  "prerequisites": [
    "s10-evaluacion-entrenamiento"
  ],
  "sources": [
    "e10-strength"
  ],
  "pending": [
    "Revisión por profesional del ejercicio e instructor de montaña pendiente. Nutrición y salud requieren revisión profesional específica; no se ha evaluado aptitud personal.",
    "Los casos y rúbricas son propuestas pedagógicas originales. La aplicación individual requiere evaluación, técnica y seguimiento.",
    "No se atribuyen requisitos de certificación, umbrales universales ni preparación técnica a los resultados físicos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una repetición máxima describe…",
        "options": [
          "Un ejercicio y condiciones concretas.",
          "Toda la competencia en montaña.",
          "La capacidad de aclimatar."
        ],
        "answer": 0,
        "explanation": "La medición es específica.",
        "rationales": [
          "La medición es específica.",
          "Faltan muchas capacidades.",
          "Son procesos diferentes."
        ],
        "source": "e10-strength",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Si se acorta el recorrido al subir peso…",
        "options": [
          "La mejora está demostrada.",
          "Cambió la tarea y debe registrarse.",
          "No importa para comparar."
        ],
        "answer": 1,
        "explanation": "La comparación necesita ese dato.",
        "rationales": [
          "No se conserva el protocolo.",
          "La comparación necesita ese dato.",
          "La técnica influye en el resultado."
        ],
        "source": "e10-strength",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Para aprender esta unidad…",
        "options": [
          "Es obligatorio probar un máximo.",
          "Hay que copiar kilos de otro.",
          "Puede trabajarse con cargas submáximas supervisadas."
        ],
        "answer": 2,
        "explanation": "Permite aprender técnica y registro.",
        "rationales": [
          "No es un requisito docente.",
          "No individualiza la carga.",
          "Permite aprender técnica y registro."
        ],
        "source": "e10-strength",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue carga y capacidad.",
    "Registra técnica además de peso.",
    "Justifica una progresión sin imponer un máximo."
  ],
  "openAssessment": {
    "prompt": "Compara dos fichas con igual carga y distinto recorrido. Redacta qué tendría que estandarizarse.",
    "rubric": [
      "Distingue carga y capacidad.",
      "Registra técnica además de peso.",
      "Justifica una progresión sin imponer un máximo."
    ],
    "source": "e10-strength",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN PROFESIONAL PENDIENTE.** Este contenido no prescribe un programa individual ni acredita competencia técnica. Los ejercicios numéricos y casos son ficticios. No introduzcas datos médicos, mediciones corporales privadas ni antecedentes de terceros.

## Conceptos clave y propósito

Fuerza máxima, carga externa, repetición, serie, descanso y técnica.

## Teoría y toma de decisiones

La fuerza máxima es la mayor fuerza que puede expresarse en una tarea y contexto determinados. Un test de una repetición máxima pertenece a un ejercicio concreto; no representa toda la fuerza de una persona. En entrenamiento, carga, volumen, frecuencia y ejecución interactúan. ACSM 2026 distingue objetivos de fuerza, hipertrofia y potencia, y destaca la adaptación a la persona. [ACSM](#fuente-e10-strength).

Preparación general: aprender patrones como sentarse y levantarse, bisagra de cadera, empujar y traccionar con control. Preparación específica: relacionar esa capacidad con escalones, carga o apoyos de montaña. La transferencia no es automática: levantar más en una máquina no demuestra control en terreno irregular.

En el caso original, una persona aumenta peso y reduce el recorrido para completar la serie. El número externo sube, pero la tarea cambió. Para registrar progreso se conserva la técnica acordada y se distingue una repetición lograda de una ejecución alterada.

No es necesario realizar un máximo para estudiar esta unidad. Un profesional puede elegir una progresión con cargas submáximas y criterios técnicos. Las cargas de otra persona, incluso con talla parecida, no son una prescripción individual.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación del aprendizaje:** Con instructor, selecciona ejercicio y variante, acuerda rango de movimiento y control, y registra carga y repeticiones realmente realizadas. Ajusta una variable de forma deliberada cuando la ejecución y recuperación lo permitan. Detén la serie si se pierde el criterio técnico; no intentes rescatar una repetición peligrosa para cumplir el registro.

La selección real de ejercicios, cargas, pruebas y progresión corresponde a una evaluación individual con profesionales. Las técnicas críticas de montaña requieren formación práctica y supervisión de instructor competente. El acondicionamiento físico no autoriza una maniobra.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una serie ficticia pasa de 30 a 40 kg, pero el movimiento se acorta. Explica qué datos impiden atribuir la diferencia a una mejora de fuerza.

Distingue dato, interpretación y decisión. Explica qué incertidumbre permanece. Los casos no representan un protocolo del organismo citado ni un criterio oficial de habilitación para guía.

## Errores frecuentes y puntos críticos de seguridad

Usar más peso como único criterio; confundir esfuerzo con calidad; probar máximos sin supervisión; omitir descansos.

## Material y equipo relacionado

Resistencia ajustable y entorno estable. Bancos, máquinas o pesos libres requieren preparación y uso según instrucciones.

[Consultar inventario](../../equipo/). Ajustar o poseer el equipo no demuestra dominarlo. Las prácticas técnicas se registran por separado del acondicionamiento.

## Autoevaluación y recuperación activa

- Explica la diferencia entre la capacidad que estudias y una tarea técnica de montaña.
- ¿Qué información falta en el caso y qué decisión modificaría?
- ¿Qué parte puede analizarse en escritorio y cuál necesita observación profesional?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Compara dos fichas con igual carga y distinto recorrido. Redacta qué tendría que estandarizarse.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Taller de patrones básicos con profesional del ejercicio, cargas seleccionadas individualmente y feedback de ejecución.

## Evidencia requerida y criterios de competencia

- Distingue carga y capacidad.
- Registra técnica además de peso.
- Justifica una progresión sin imponer un máximo.

**COMPETENCIA:** estos criterios describen aprendizaje que debe observar un profesional en contexto. No acreditan aptitud médica, entrenamiento personal, guiado ni maniobra técnica. Una lectura, prueba física o quiz no otorga certificación. Marca pendiente lo que no se haya evaluado.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s10-fuerza-maxima). Registra fecha, actividad, escenario, equipo, objetivo, errores, correcciones, supervisor y evidencia de aprendizaje. No guardes datos médicos ni contraseñas. No inventes sesiones, evaluaciones o repeticiones para completar la matriz.

## Relaciones con otros módulos

[Entrenamiento](../../entrenamiento/) · [Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Programa](../../programa/). Entrenamiento general, preparación específica, aclimatación y competencia técnica se relacionan, pero no son equivalentes.
