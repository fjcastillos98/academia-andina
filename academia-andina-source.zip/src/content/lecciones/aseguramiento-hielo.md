---
{
  "title": "Aseguramiento en hielo: funciones y comprobación del sistema",
  "description": "Diferenciar dispositivo, acción del asegurador y protección.",
  "module": "M05",
  "code": "E7-06",
  "order": 706,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U7-06",
  "skills": [
    "s7-aseguramiento-hielo"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Diferenciar dispositivo, acción del asegurador y protección.",
    "Analizar consecuencias de caída sin transferir hábitos de escalada deportiva."
  ],
  "prerequisites": [
    "s7-progresion-hielo"
  ],
  "sources": [
    "e7-atc",
    "e7-micro",
    "e7-rope-cuts"
  ],
  "pending": [
    "Revisión de instructor de hielo pendiente; no se ha observado ni aprobado ninguna práctica.",
    "Compatibilidad y manual de los modelos personales pendientes de verificación; ninguna pieza se considera apta por aparecer en el inventario."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Micro Traxion reemplaza automáticamente a ATC Guide…",
        "options": [
          "Sí, porque bloquea.",
          "No: función y condiciones deben analizarse por separado.",
          "Sí, con la misma marca de cuerda."
        ],
        "answer": 1,
        "explanation": "Los dispositivos no son intercambiables por apariencia. Diferenciar dispositivo, acción del asegurador y protección.",
        "rationales": [
          "Capturar progreso no iguala todas las funciones.",
          "Los dispositivos no son intercambiables por apariencia.",
          "Una marca común no prueba compatibilidad."
        ],
        "source": "e7-micro",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Falta el manual de la generación exacta. ¿Qué hacer?",
        "options": [
          "Resolver la comprobación antes del taller.",
          "Copiar el de una pieza parecida.",
          "Confiar en el color."
        ],
        "answer": 0,
        "explanation": "El vacío documental es relevante. Diferenciar dispositivo, acción del asegurador y protección.",
        "rationales": [
          "El vacío documental es relevante.",
          "La semejanza no garantiza mismas instrucciones.",
          "El color no identifica condiciones de uso."
        ],
        "source": "e7-atc",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una comprobación mutua útil incluye…",
        "options": [
          "Solo decir listo.",
          "Solo mirar el casco.",
          "Función, configuración y dudas explicitadas."
        ],
        "answer": 2,
        "explanation": "Permite detectar discrepancias. Diferenciar dispositivo, acción del asegurador y protección.",
        "rationales": [
          "No identifica qué se verificó.",
          "No cubre la cadena de aseguramiento.",
          "Permite detectar discrepancias."
        ],
        "source": "e7-atc",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Diferencia las funciones de todos los componentes.",
    "Realiza comprobaciones y comunicación observables según método enseñado.",
    "Detiene el uso ante incompatibilidad o configuración no comprendida."
  ],
  "openAssessment": {
    "prompt": "Haz una matriz de componentes y funciones. Para cada fila escribe documento, condición por comprobar y quién puede verificarla. No dibujes un montaje listo para usar.",
    "rubric": [
      "Diferencia las funciones de todos los componentes.",
      "Realiza comprobaciones y comunicación observables según método enseñado.",
      "Detiene el uso ante incompatibilidad o configuración no comprendida."
    ],
    "source": "e7-atc",
    "difficulty": "integración"
  },
  "diagrams": [
    "e7-sistema"
  ]
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. El estudio y el quiz no acreditan una maniobra ni capacidad de guiado.**

## Conceptos clave y propósito

Cadena de aseguramiento, gestión de cuerda, posición, compatibilidad y comunicación.

## Teoría y toma de decisiones

Un sistema de aseguramiento reúne persona, arnés, cuerda, conectores, dispositivo, protecciones y soporte. El nombre comercial de una pieza no describe el conjunto. La documentación del dispositivo fija condiciones de uso, pero no evalúa automáticamente la calidad del hielo ni la colocación de protecciones. [Fuente de contraste](#fuente-e7-atc).

En hielo, las consecuencias de caída incluyen interacción con herramientas y crampones, además del terreno y las protecciones. No se adopta la caída como ejercicio rutinario por analogía con una sesión deportiva. Esta unidad prepara análisis de funciones; la técnica manual debe aprenderse y comprobarse con instructor.

ATC Guide y Micro Traxion tienen funciones distintas. No se intercambian por compartir cuerda y mosquetones. Para estudiar el ATC Guide hay que identificar generación, modo, cuerdas admitidas y exigencias del manual. Micro Traxion es una polea con captura de progreso con usos y límites propios; no se propone aquí como sustituto del dispositivo de aseguramiento. [Fuente de contraste](#fuente-e7-micro).

Una comprobación mutua debe ser específica y comunicada: qué función se espera, qué configuración está presente y qué dato sigue desconocido. Repetir «todo bien» no deja saber qué se revisó. La ubicación del asegurador y la comunicación forman parte del plan porque caída de hielo, ruido o falta de visibilidad pueden alterar la tarea.

El ejercicio documental termina cuando falta una instrucción esencial del modelo. Resolver la incertidumbre por semejanza con otro dispositivo no es una comprobación. La revisión presencial y el manual correspondiente son dependencias de la práctica, no casillas que se completan por leer.

El informe UIAA sobre cortes recuerda que una cuerda cargada puede dañarse al interactuar con una arista. Su marcado no elimina ese problema. Identificar trayectorias y posibles contactos es parte del análisis del sistema, no un detalle posterior. [Informe técnico](#fuente-e7-rope-cuts).

## Procedimiento: función, comprobaciones y límites

**PROCEDIMIENTO — marco de análisis previo al taller.** Objetivo: Diferenciar dispositivo, acción del asegurador y protección. Se utiliza para preparar el aprendizaje y detectar vacíos antes de una tarea real. Identifica la función, los componentes, la información que falta y las consecuencias de un error. Contrasta la versión de la fuente con el modelo de equipo y el método del instructor. No hay una configuración universal derivada de esta página.

Las comprobaciones relevantes se desarrollan en la teoría, el equipo y la rúbrica de esta unidad. Si el uso previsto o la protección del taller no están claros, la práctica no se inicia. Las variantes de una fuente se conservan dentro de su contexto; no se mezclan pasos de métodos distintos por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario ficticio para análisis:** Hay un ATC Guide disponible, pero no se conoce la generación ni se ha revisado la combinación de cuerdas. Otro integrante propone Micro Traxion porque «bloquea». Describe los problemas funcionales de esa sustitución.

Antes de responder, enumera los hechos dados y los datos que has supuesto. Propón una decisión provisional y una condición que te haría revisarla. El caso, los ejercicios y las rúbricas son propuestas pedagógicas originales de la academia, pendientes de revisión docente; no son un protocolo de un organismo citado.

## Errores frecuentes y puntos críticos de seguridad

Dar por compatible el diámetro nominal; mezclar modos de uso; equiparar captura de progreso con aseguramiento; omitir la acción del asegurador; trasladar el hábito de caída deportiva.

No uses la ausencia de incidentes como prueba de seguridad. Las tareas con carga, herramientas o exposición necesitan control presencial competente. Ninguna respuesta escrita autoriza a escalar, montar un anclaje ni asistir a un pasajero.

## Material y equipo relacionado

Casco, arnés, cuerda adecuada, dispositivo de aseguramiento y conectores compatibles, protecciones y manuales exactos. Micro Traxion se estudia por su función documentada, no como reemplazo.

[Consultar inventario](../../equipo/). Registra documento y revisión, sin inventar inspecciones realizadas. Tener material no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con tus palabras: Diferenciar dispositivo, acción del asegurador y protección.
- ¿Qué observación del caso apoya tu decisión y qué dato sigue faltando?
- ¿Qué error de esta unidad podrías reconocer documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Haz una matriz de componentes y funciones. Para cada fila escribe documento, condición por comprobar y quién puede verificarla. No dibujes un montaje listo para usar.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Con instructor: identificación del equipo, comprobaciones mutuas y comunicación en sistema preparado y protegido por él. Las transiciones y el manejo manual requieren demostración y evaluación presencial. Sin ensayo de caída improvisado.

## Evidencia requerida y criterios de competencia

- Diferencia las funciones de todos los componentes.
- Realiza comprobaciones y comunicación observables según método enseñado.
- Detiene el uso ante incompatibilidad o configuración no comprendida.

**COMPETENCIA:** estos criterios orientan la revisión. Cuando implican ejecución, el instructor debe observarla en un contexto definido, registrar resultado y lo que no se evaluó. No hay umbral automático de repeticiones, confianza o aciertos. La plataforma conserva una declaración personal y no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s7-aseguramiento-hielo). Registra solo tareas realmente realizadas: fecha, lugar, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Mantén separados resultado observado, confianza y evaluación. No incluyas datos médicos ni datos privados de terceros.

## Relaciones con otros módulos

[Ruta invernal](../../invierno/), [formación glaciar](../../glaciar/), [encordamiento según contexto](../encordamiento-contexto/) y [anclajes y reuniones](../anclajes-reuniones/) aportan prerrequisitos. La aplicación alpina y el guiado requieren su propia formación y evaluación. [Volver a la secuencia de hielo](../../hielo/).
