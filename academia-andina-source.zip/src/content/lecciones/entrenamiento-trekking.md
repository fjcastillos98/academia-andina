---
{
  "title": "Entrenamiento específico para trekking",
  "description": "Relacionar duración, terreno, equipamiento y repetición de jornadas.",
  "module": "M22",
  "code": "E10-08",
  "order": 1008,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U10-08",
  "skills": [
    "s10-entrenamiento-trekking"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Relacionar duración, terreno, equipamiento y repetición de jornadas.",
    "Aplicar el concepto a una decisión de preparación de montaña y reconocer sus límites."
  ],
  "prerequisites": [
    "s10-ascenso-desnivel"
  ],
  "sources": [
    "e10-load"
  ],
  "pending": [
    "Revisión por profesional del ejercicio e instructor de montaña pendiente. Nutrición y salud requieren revisión profesional específica; no se ha evaluado aptitud personal.",
    "Los casos y rúbricas son propuestas pedagógicas originales. La aplicación individual requiere evaluación, técnica y seguimiento.",
    "No se atribuyen requisitos de certificación, umbrales universales ni preparación técnica a los resultados físicos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "La preparación específica aproxima…",
        "options": [
          "Demandas relevantes de la actividad.",
          "Todos los peligros posibles.",
          "Una marca de otro deportista."
        ],
        "answer": 0,
        "explanation": "Se seleccionan tareas pertinentes.",
        "rationales": [
          "Se seleccionan tareas pertinentes.",
          "No se necesita recrear riesgo.",
          "No es una individualización."
        ],
        "source": "e10-load",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Cambiar todo simultáneamente…",
        "options": [
          "Aclara qué factor influyó.",
          "Dificulta interpretar la respuesta.",
          "Garantiza progreso más rápido."
        ],
        "answer": 1,
        "explanation": "Impide atribuir cambios.",
        "rationales": [
          "Mezcla factores.",
          "Impide atribuir cambios.",
          "No existe esa garantía."
        ],
        "source": "e10-load",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un trekking de varios días exige considerar…",
        "options": [
          "Solo el primer kilómetro.",
          "Solo la subida.",
          "La repetición de jornadas y recuperación."
        ],
        "answer": 2,
        "explanation": "La tarea se extiende en el tiempo.",
        "rationales": [
          "No representa el objetivo.",
          "Falta regreso y continuidad.",
          "La tarea se extiende en el tiempo."
        ],
        "source": "e10-load",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Define demandas más allá de distancia.",
    "Separa preparación y exposición.",
    "Incluye recuperación entre jornadas."
  ],
  "openAssessment": {
    "prompt": "Escribe una matriz de demandas de trekking con general, específico y pendiente de practicar.",
    "rubric": [
      "Define demandas más allá de distancia.",
      "Separa preparación y exposición.",
      "Incluye recuperación entre jornadas."
    ],
    "source": "e10-load",
    "difficulty": "integración"
  },
  "diagrams": [
    "e10-general-especifico"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN PROFESIONAL PENDIENTE.** Este contenido no prescribe un programa individual ni acredita competencia técnica. Los ejercicios numéricos y casos son ficticios. No introduzcas datos médicos, mediciones corporales privadas ni antecedentes de terceros.

## Conceptos clave y propósito

Especificidad, duración, pies, terreno, descenso, pausas y días consecutivos.

## Teoría y toma de decisiones

Preparación general y específica se complementan. La general trabaja capacidades transferibles; la específica aproxima gradualmente las demandas del objetivo. Para trekking, duración, terreno, mochila y repetición de jornadas importan además de la distancia.

Una caminata corta en llano no reproduce una jornada prolongada con bajada. Tampoco hace falta reproducir todos los riesgos de montaña para entrenar: la exposición técnica no es una variable de acondicionamiento que deba aumentarse. La progresión física se realiza en escenarios controlados y compatibles con la formación.

El caso original propone un objetivo de dos días y descubre que solo se ha ensayado una sesión aislada. El estudiante identifica datos que faltan: tolerancia del equipamiento, comida accesible, recuperación entre días y logística del retorno. No se prescribe una cantidad fija de kilómetros semanales.

La literatura de transporte de carga aporta mecanismos de coste y demanda, pero gran parte procede de población militar; no permite importar pesos o ritmos como norma turística. [Ámbito de la investigación](#fuente-e10-load). La aplicación a trekking se explicita como diseño pedagógico a revisar con entrenador.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación del aprendizaje:** Describe las demandas del objetivo sin usar una ruta peligrosa como entrenamiento. Selecciona una sesión de familiarización con profesional, controla duración y terreno y revisa cómo se toleró antes de progresar. Cambiar varias variables a la vez impide saber qué produjo la dificultad.

La selección real de ejercicios, cargas, pruebas y progresión corresponde a una evaluación individual con profesionales. Las técnicas críticas de montaña requieren formación práctica y supervisión de instructor competente. El acondicionamiento físico no autoriza una maniobra.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un plan ficticio acumula kilómetros en llano, pero no considera el descenso ni caminar al día siguiente. Añade preguntas para completar el diseño.

Distingue dato, interpretación y decisión. Explica qué incertidumbre permanece. Los casos no representan un protocolo del organismo citado ni un criterio oficial de habilitación para guía.

## Errores frecuentes y puntos críticos de seguridad

Entrenar solo distancia; estrenar calzado en salida larga; convertir cada marcha en prueba máxima; aumentar simultáneamente carga, velocidad y desnivel.

## Material y equipo relacionado

Calzado probado, mochila ajustada, bastones si se conocen y logística de comida/agua. No se validan modelos de equipo por completar la lección.

[Consultar inventario](../../equipo/). Ajustar o poseer el equipo no demuestra dominarlo. Las prácticas técnicas se registran por separado del acondicionamiento.

## Autoevaluación y recuperación activa

- Explica la diferencia entre la capacidad que estudias y una tarea técnica de montaña.
- ¿Qué información falta en el caso y qué decisión modificaría?
- ¿Qué parte puede analizarse en escritorio y cuál necesita observación profesional?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Escribe una matriz de demandas de trekking con general, específico y pendiente de practicar.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Observación de marcha y ajustes de equipo en circuito protegido con instructor y entrenador cuando corresponda.

## Evidencia requerida y criterios de competencia

- Define demandas más allá de distancia.
- Separa preparación y exposición.
- Incluye recuperación entre jornadas.

**COMPETENCIA:** estos criterios describen aprendizaje que debe observar un profesional en contexto. No acreditan aptitud médica, entrenamiento personal, guiado ni maniobra técnica. Una lectura, prueba física o quiz no otorga certificación. Marca pendiente lo que no se haya evaluado.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s10-entrenamiento-trekking). Registra fecha, actividad, escenario, equipo, objetivo, errores, correcciones, supervisor y evidencia de aprendizaje. No guardes datos médicos ni contraseñas. No inventes sesiones, evaluaciones o repeticiones para completar la matriz.

## Relaciones con otros módulos

[Entrenamiento](../../entrenamiento/) · [Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Programa](../../programa/). Entrenamiento general, preparación específica, aclimatación y competencia técnica se relacionan, pero no son equivalentes.
