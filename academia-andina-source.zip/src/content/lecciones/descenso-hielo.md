---
{
  "title": "Descenso en hielo: transición, recuperación y retirada",
  "description": "Tratar el descenso como parte del plan desde el inicio.",
  "module": "M05",
  "code": "E7-08",
  "order": 708,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U7-08",
  "skills": [
    "s7-descenso-hielo"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Tratar el descenso como parte del plan desde el inicio.",
    "Diferenciar control del descenso, anclaje y recuperación de cuerda."
  ],
  "prerequisites": [
    "s7-anclajes-hielo"
  ],
  "sources": [
    "e7-abalakov",
    "e7-inspection",
    "e7-atc",
    "e7-accessbook"
  ],
  "pending": [
    "Revisión de instructor de hielo pendiente; no se ha observado ni aprobado ninguna práctica.",
    "Compatibilidad y manual de los modelos personales pendientes de verificación; ninguna pieza se considera apta por aparecer en el inventario."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un puente antiguo con cordino…",
        "options": [
          "Requiere evaluación actual, no aprobación por existencia.",
          "Está aprobado por usuarios anteriores.",
          "Sirve para cualquier número de personas."
        ],
        "answer": 0,
        "explanation": "Su estado y soporte pueden haber cambiado. Tratar el descenso como parte del plan desde el inicio.",
        "rationales": [
          "Su estado y soporte pueden haber cambiado.",
          "El uso previo no valida el presente.",
          "No se infiere capacidad ni configuración."
        ],
        "source": "e7-abalakov",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Planificar descenso corresponde…",
        "options": [
          "Solo al llegar arriba.",
          "Desde la preparación y con reevaluación durante la salida.",
          "Únicamente al último de la cordada."
        ],
        "answer": 1,
        "explanation": "Es una parte del plan que cambia con las condiciones. Tratar el descenso como parte del plan desde el inicio.",
        "rationales": [
          "La retirada condiciona la propuesta inicial.",
          "Es una parte del plan que cambia con las condiciones.",
          "La responsabilidad no se reduce a ese momento."
        ],
        "source": "e7-abalakov",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un descenso individual dominado…",
        "options": [
          "Acredita rescate de pasajero.",
          "Permite improvisar toda asistencia.",
          "No demuestra las capacidades adicionales de asistencia."
        ],
        "answer": 2,
        "explanation": "Las responsabilidades nuevas requieren aprendizaje específico. Tratar el descenso como parte del plan desde el inicio.",
        "rationales": [
          "Las tareas y evaluación son distintas.",
          "La formación tiene un ámbito.",
          "Las responsabilidades nuevas requieren aprendizaje específico."
        ],
        "source": "e7-abalakov",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Explica continuidad de protección, control y recuperación como funciones distintas.",
    "Realiza transiciones enseñadas bajo observación y comunica dudas.",
    "Identifica cambios que requieren detener y revisar el plan."
  ],
  "openAssessment": {
    "prompt": "Redacta un plan de retorno ficticio con punto de decisión, datos faltantes, funciones y alternativa. Marca qué aspectos requieren evaluación presencial y cuáles puedes investigar documentalmente.",
    "rubric": [
      "Explica continuidad de protección, control y recuperación como funciones distintas.",
      "Realiza transiciones enseñadas bajo observación y comunica dudas.",
      "Identifica cambios que requieren detener y revisar el plan."
    ],
    "source": "e7-abalakov",
    "difficulty": "integración"
  },
  "diagrams": [
    "e7-sistema"
  ]
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. El estudio y el quiz no acreditan una maniobra ni capacidad de guiado.**

## Conceptos clave y propósito

Retirada, transición, continuidad de protección, recuperación y reevaluación.

## Teoría y toma de decisiones

El descenso no empieza cuando se llega al final del largo. Antes de escalar se necesita una propuesta de retorno que considere anclajes, cuerda disponible, condiciones y capacidades. Una alternativa de retirada no queda validada por llamarse plan B; requiere su propio análisis.

Petzl describe el rápel sobre abalakov como una técnica específica. Esa explicación no autoriza cualquier puente ya existente ni todo tipo de hielo. La revisión del soporte y el método de enseñanza siguen siendo necesarios. El estado de una instalación puede haber cambiado desde que otra cordada la utilizó. [Fuente de contraste](#fuente-e7-abalakov).

Hay tres problemas distintos: permanecer protegido durante la transición, controlar el desplazamiento y recuperar el material sin crear otra exposición. Resolver uno no demuestra que los otros estén resueltos. La cuerda puede interactuar con hielo, bordes o herramientas; el plan debe incluir cómo se detecta y comunica una dificultad, sin suponer que siempre podrá recuperarse.

No se introduce aquí el descenso asistido de un pasajero como variación trivial de rápel individual. Cambia la tarea, las responsabilidades y las capacidades que deben evaluarse. Si una persona no puede colaborar, el grupo necesita reconocer los límites de su formación y del apoyo disponible.

La práctica supervisada debe registrar transiciones, comprobaciones y comunicación, no solo tiempo hasta el suelo. Ante un cambio del hielo o dificultad de recuperación, el criterio no es terminar a cualquier precio: se reevalúa el sistema y la exposición con quien dirige la actividad.

Existe una diferencia entre las especificaciones de cordino del AccessBook de 2018 y la página actual de Petzl sobre abalakov. Esta lección conserva ambas referencias con su fecha y no combina sus medidas. El instructor debe resolver versión, método y equipo aplicables. [Manual histórico](#fuente-e7-accessbook) y [página consultada](#fuente-e7-abalakov).

## Procedimiento: función, comprobaciones y límites

**PROCEDIMIENTO — marco de análisis previo al taller.** Objetivo: Tratar el descenso como parte del plan desde el inicio. Se utiliza para preparar el aprendizaje y detectar vacíos antes de una tarea real. Identifica la función, los componentes, la información que falta y las consecuencias de un error. Contrasta la versión de la fuente con el modelo de equipo y el método del instructor. No hay una configuración universal derivada de esta página.

Las comprobaciones relevantes se desarrollan en la teoría, el equipo y la rúbrica de esta unidad. Si el uso previsto o la protección del taller no están claros, la práctica no se inicia. Las variantes de una fuente se conservan dentro de su contexto; no se mezclan pasos de métodos distintos por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario ficticio para análisis:** La cordada encuentra un puente antiguo y deduce que puede bajar porque tiene cordino. La temperatura y el agua cambiaron desde la mañana. Identifica supuestos y las tres funciones que se deben revisar antes de hablar de ejecución.

Antes de responder, enumera los hechos dados y los datos que has supuesto. Propón una decisión provisional y una condición que te haría revisarla. El caso, los ejercicios y las rúbricas son propuestas pedagógicas originales de la academia, pendientes de revisión docente; no son un protocolo de un organismo citado.

## Errores frecuentes y puntos críticos de seguridad

Confundir existencia con validez; planificar solo la subida; desconectar protección antes de resolver transición; insistir en recuperar material sin reevaluar exposición; improvisar descenso de un cliente.

No uses la ausencia de incidentes como prueba de seguridad. Las tareas con carga, herramientas o exposición necesitan control presencial competente. Ninguna respuesta escrita autoriza a escalar, montar un anclaje ni asistir a un pasajero.

## Material y equipo relacionado

Sistema de descenso, cuerda, conectores y anclajes del método enseñado, protección de bordes cuando proceda y comunicación. ATC Guide no habilita por sí solo para descenso asistido.

[Consultar inventario](../../equipo/). Registra documento y revisión, sin inventar inspecciones realizadas. Tener material no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con tus palabras: Tratar el descenso como parte del plan desde el inicio.
- ¿Qué observación del caso apoya tu decisión y qué dato sigue faltando?
- ¿Qué error de esta unidad podrías reconocer documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Redacta un plan de retorno ficticio con punto de decisión, datos faltantes, funciones y alternativa. Marca qué aspectos requieren evaluación presencial y cuáles puedes investigar documentalmente.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** El instructor prepara un taller protegido de transiciones, comprobaciones y comunicación, con anclajes que él evalúa. La construcción y uso de abalakov requieren demostración y supervisión; no se improvisan desde la ficha.

## Evidencia requerida y criterios de competencia

- Explica continuidad de protección, control y recuperación como funciones distintas.
- Realiza transiciones enseñadas bajo observación y comunica dudas.
- Identifica cambios que requieren detener y revisar el plan.

**COMPETENCIA:** estos criterios orientan la revisión. Cuando implican ejecución, el instructor debe observarla en un contexto definido, registrar resultado y lo que no se evaluó. No hay umbral automático de repeticiones, confianza o aciertos. La plataforma conserva una declaración personal y no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s7-descenso-hielo). Registra solo tareas realmente realizadas: fecha, lugar, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Mantén separados resultado observado, confianza y evaluación. No incluyas datos médicos ni datos privados de terceros.

## Relaciones con otros módulos

[Ruta invernal](../../invierno/), [formación glaciar](../../glaciar/), [encordamiento según contexto](../encordamiento-contexto/) y [anclajes y reuniones](../anclajes-reuniones/) aportan prerrequisitos. La aplicación alpina y el guiado requieren su propia formación y evaluación. [Volver a la secuencia de hielo](../../hielo/).
