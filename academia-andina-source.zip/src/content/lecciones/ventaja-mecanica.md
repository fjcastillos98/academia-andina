---
{
  "title": "Ventaja mecánica: modelos, fuerzas y trabajo",
  "description": "Calcular fuerza y desplazamiento en modelos ideales de 2:1 a 5:1.",
  "module": "M07",
  "code": "E44-19",
  "order": 318,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U44-01",
  "skills": [
    "s44-ventaja-mecanica"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Calcular fuerza y desplazamiento en modelos ideales de 2:1 a 5:1.",
    "Comparar ventaja ideal, ventaja real y eficiencia conservando las unidades.",
    "Explicar por qué un cálculo correcto no dimensiona un sistema de rescate."
  ],
  "prerequisites": [
    "s43-rapel-descenso"
  ],
  "sources": [
    "openstax-ma",
    "petzl-ma"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "ventaja-ideal",
    "trabajo-conservado"
  ],
  "preparation": [
    "Explicar los conceptos sin confundir un modelo con una maniobra.",
    "Reconocer al menos dos errores del caso y justificar una alternativa.",
    "Identificar la documentación y las competencias prácticas que faltan."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "openstax-ma",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una carga ideal de 200 N en 4:1 requiere…",
        "options": [
          "50 N de esfuerzo ideal.",
          "800 N de esfuerzo ideal.",
          "50 kg de esfuerzo."
        ],
        "answer": 0,
        "explanation": "200/4=50 N; no incluye pérdidas.",
        "rationales": [
          "200/4=50 N; no incluye pérdidas.",
          "Se multiplicó en lugar de dividir.",
          "Se confunde masa y fuerza."
        ],
        "source": "openstax-ma",
        "kind": "aplicación",
        "difficulty": "intermedia"
      },
      {
        "prompt": "Para elevar 0,4 m con 3:1 ideal se toma…",
        "options": [
          "0,4 m.",
          "1,2 m.",
          "0,133 m."
        ],
        "answer": 1,
        "explanation": "3×0,4=1,2 m; fuerza menor exige más recorrido.",
        "rationales": [
          "Ignora la relación de desplazamientos.",
          "3×0,4=1,2 m; fuerza menor exige más recorrido.",
          "Invierte la relación de distancia."
        ],
        "source": "petzl-ma",
        "kind": "aplicación",
        "difficulty": "intermedia"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

Fuerza se expresa aquí en newtons, masa en kilogramos y trabajo en joules. Ventaja mecánica es fuerza útil de salida dividida por fuerza de entrada. En un modelo ideal sin pérdidas, reducir la fuerza exige recorrer más distancia; no se crea energía [Referencia: openstax-ma](#fuente-openstax-ma).

## Teoría y decisiones

Para una carga ideal de fuerza W y ventaja n, F=W/n. Para elevarla una altura h, la longitud de entrada ideal es n·h. En régimen cuasiestático, F·(n·h)=W·h. La ventaja real es W/F medida bajo condiciones concretas; si es menor que la ideal, se requiere más esfuerzo. La eficiencia del conjunto relaciona trabajo útil y trabajo de entrada, no el simple número de poleas.

Una polea fija ideal que solo cambia dirección no multiplica la fuerza sobre la carga; además, su soporte recibe la resultante de ambos ramales. Una polea móvil puede sumar contribuciones de tensión. Petzl propone seguir las fuerzas por el esquema y sumar las que actúan sobre la carga; contar poleas no basta [Referencia: petzl-ma](#fuente-petzl-ma).

En los diagramas 2:1, 3:1, 4:1 y 5:1 se representan **contribuciones ideales a la carga**, no recorridos de cuerda listos para montaje. Para un sistema compuesto 2:1 que acciona un 3:1 ideal, la ventaja puede ser 6:1 si las etapas están conectadas de esa manera. No se multiplican relaciones solo porque hay dos aparatos: primero hay que demostrar la relación entre etapas y sus desplazamientos.

Problemas originales: A) W=120 N, n=2, h=0,5 m: F=60 N, entrada=1 m, trabajo=60 J. B) W=150 N, n=3, h=0,4 m: F=50 N, entrada=1,2 m, trabajo=60 J. C) W=200 N, n=4, h=0,25 m: F=50 N, entrada=1 m, trabajo=50 J. D) W=250 N, n=5, h=0,2 m: F=50 N, entrada=1 m, trabajo=50 J.

E) En una simulación 3:1 se mide F=80 N al mover W=150 N: ventaja real=1,875. Con una entrada medida de 1,2 m y elevación de 0,4 m, eficiencia de trabajo=60/96=62,5 %. No atribuyas esa cifra a Micro Traxion: es un ejemplo inventado. F) Un compuesto ideal 2×3 mueve W=180 N: F=30 N; para h=0,1 m se requieren 0,6 m de entrada. En todos los casos faltan condiciones para dimensionar un rescate real.

## Caso práctico y aplicación al guiado

Un guía observa que un sistema requiere menos esfuerzo y concluye que ya no hay riesgo de sobrecargar un componente. Explica la diferencia entre esfuerzo del operador y fuerzas internas. Más ventaja puede facilitar que el equipo aplique fuerzas elevadas sin percibirlas directamente.

## Errores frecuentes y señales de alerta

Usar kg como fuerza sin aclaración; contar poleas; omitir desplazamiento; asignar eficiencia de una polea a todo el sistema; ignorar rozamiento, elasticidad y reinicios. Una respuesta numérica correcta no verifica compatibilidad ni soporte.

## Autoevaluación y respuestas explicadas

¿Una redirección fija ideal es 2:1 por tener dos ramales visibles? **No: hay que sumar los que actúan sobre la carga móvil.** ¿Un 5:1 crea trabajo? **No; intercambia fuerza por desplazamiento, con pérdidas en la realidad.**

## Ejercicios y práctica presencial

Resolver los seis problemas mostrando unidades e hipótesis; comparar dos esquemas de fuerzas. Taller de mesa con instructor y masas didácticas pequeñas, sin suspensión de personas. Medir fuerza y desplazamiento solo con equipamiento de ensayo apropiado.

## Evidencia requerida

Hoja de cálculo razonada, esquema de contribuciones y explicación de por qué el resultado no selecciona material. Evaluación matemática separada de la evaluación de izado.

## Relaciones con otras habilidades

Revisa los prerrequisitos y el contrato de habilidad de esta unidad en el programa. Contrasta la explicación con las fuentes indicadas: las cifras de un ejercicio no son límites de uso de un equipo. Toda transferencia a una situación con personas requiere formación y revisión presencial.
