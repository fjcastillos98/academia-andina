---
{
  "title": "Meteorología de montaña",
  "description": "Leer la validez y las limitaciones de la información meteorológica antes de decidir.",
  "module": "M01",
  "code": "P1-D",
  "order": 104,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "pilot",
  "reviewDate": "2026-10-22",
  "objectives": [
    "Diferenciar tiempo observado, pronóstico y clima.",
    "Explicar el efecto orográfico sin extrapolar una estación al itinerario.",
    "Redactar una decisión vinculada a la incertidumbre meteorológica."
  ],
  "prerequisites": [
    "Estudiar Planificación de una salida y explicar sus límites."
  ],
  "sources": [
    "nws-orografia",
    "nws-rayos",
    "dmc"
  ],
  "pending": [
    "Revisión pedagógica y validación de criterios por instructor competente.",
    "Aplicación territorial en Los Lagos: requiere verificación situada."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una previsión no muestra información de visibilidad. ¿Qué puedes concluir?",
        "options": [
          "Que será excelente.",
          "Que ese dato falta y debe investigarse si es decisivo.",
          "Que la visibilidad coincide con la temperatura."
        ],
        "answer": 1,
        "explanation": "Un campo ausente no permite inferir condiciones favorables."
      },
      {
        "prompt": "¿Qué describe el ascenso orográfico del aire húmedo?",
        "options": [
          "Una posible causa de nube y precipitación al ascender sobre relieve.",
          "Una garantía de cielo despejado a sotavento.",
          "Una regla que sustituye toda previsión."
        ],
        "answer": 0,
        "explanation": "El mecanismo ayuda a comprender el relieve, pero no predice por sí solo cada ladera."
      }
    ]
  },
  "pilot": {
    "position": 4,
    "requires": [
      "planificacion-salida"
    ],
    "critical": false,
    "classifications": [
      "TEORÍA",
      "PROCEDIMIENTO",
      "PRÁCTICA INDIVIDUAL",
      "PRÁCTICA SUPERVISADA",
      "COMPETENCIA"
    ],
    "relatedModules": [
      "M01",
      "M00"
    ],
    "criteria": [
      "Identifica emisión, validez y área; distingue observación de previsión; relaciona una incertidumbre con una alternativa y evita declarar seguridad a partir de un icono."
    ]
  }
}
---
## Conceptos

**TEORÍA.** El tiempo describe el estado de la atmósfera en un momento; el pronóstico estima su evolución; el clima resume patrones de un periodo largo. Una media climática no es el pronóstico de una salida.

El NWS explica que el aire húmedo forzado a ascender sobre relieve puede enfriarse, condensar y producir nube y precipitación; el sotavento puede recibir menos precipitación [National Weather Service](#fuente-nws-orografia). Esto no convierte cada ladera en una predicción exacta. Importan la situación atmosférica y la escala del dato.

Una previsión para una ciudad no describe automáticamente una cumbre. Para Chile, el portal de la Dirección Meteorológica de Chile es un punto de consulta oficial [Dirección Meteorológica de Chile](#fuente-dmc). Aquí no se reproduce ningún aviso vigente ni se ha validado un pronóstico para una ruta.

## Desarrollo teórico y toma de decisiones

**PROCEDIMIENTO · análisis y preparación.** Lee cada producto con cinco preguntas: quién lo emite, cuándo se emitió, para qué periodo vale, qué área o altitud representa y qué incertidumbres declara. Anota viento, precipitación, temperatura, visibilidad y posibilidad de tormenta cuando el producto los incluya; un campo ausente es un dato faltante, no un valor cero.

Después traduce la información a consecuencias del itinerario: ¿qué referencia dejaría de ser visible?, ¿qué tramo dificultaría el retorno?, ¿qué exposición no puede evitarse? Define una alternativa antes de salir. En terreno compara lo previsto con lo observado sin sustituir información regional por una impresión aislada.

El NWS recuerda que durante una tormenta eléctrica no existe un lugar exterior completamente seguro [National Weather Service](#fuente-nws-rayos). El objetivo es evitar la exposición; este texto no propone refugios improvisados ni garantiza protección.

## Ejemplo

Actividad didáctica original, no descripción de una ruta operativa.

## Caso de estudio

Caso ficticio: una captura muestra un icono de sol, pero no conserva hora de emisión, sector ni elevación. El grupo la interpreta como garantía de visibilidad. Identifica tres datos ausentes y redacta qué consultarías antes de decidir.

Respuesta orientativa: recuperar el producto original y su periodo de validez; verificar cobertura espacial y variables pertinentes. La confianza en la decisión debe disminuir cuando no puede comprobarse qué representa la captura.

## Errores frecuentes

Confundir icono con boletín completo; extrapolar temperatura del valle; creer que un día sin lluvia elimina viento o baja visibilidad; usar una captura antigua.

## Límites y puntos críticos de seguridad

Los umbrales operativos dependen de actividad, exposición y grupo: requieren revisión competente. No se dan aquí cifras universales de viento o temperatura aceptables.

## Material y equipo relacionado

Capas de abrigo, protección de lluvia, mapa y respaldo de orientación. InReach y VHF no sustituyen un plan meteorológico.

## Recuperación activa

- ¿Qué hace que un dato sea poco representativo de tu ruta?
- ¿Por qué la ausencia de lluvia no basta para decidir?

Responde antes de consultar el texto. Luego anota qué cambiaste y por qué; el recuerdo sin justificación no basta.

## Ejercicio y práctica

**PRÁCTICA INDIVIDUAL** limitada a análisis en mesa u observación segura. En casa, guarda fecha y enlace de un producto oficial y escribe su alcance. Compara dos momentos de emisión sin salir para “comprobar” un fenómeno adverso.

**PRÁCTICA SUPERVISADA.** Un instructor competente selecciona el contexto y observa la ejecución pertinente; este texto no autoriza a realizar maniobras técnicas sin esa formación. Antes de la sesión, acuerda objetivo, límites y cómo se interrumpirá el ejercicio.

## Registro de práctica

Abre el Diario de prácticas desde la navegación y selecciona esta habilidad. Registra fecha, lugar, condiciones, actividad, equipo, repeticiones, errores, correcciones y evidencia. Identifica al supervisor solo cuando estuvo presente. La confianza es una percepción, no un resultado de competencia. No incluyas datos médicos, contraseñas ni información privada de terceros.

## Criterios de revisión y competencia

**COMPETENCIA · evaluación pendiente.** Identifica emisión, validez y área; distingue observación de previsión; relaciona una incertidumbre con una alternativa y evita declarar seguridad a partir de un icono.

La evaluación debe indicar quién observó, qué contexto y evidencia revisó, qué criterio aplicó y cuál fue el resultado. El diario conserva una declaración del usuario: no verifica identidad ni credenciales del evaluador y no emite certificaciones. Una lectura o quiz nunca demuestra ejecución técnica.

## Próximos pasos y relación con otros módulos

Continúa con **Nubes y reconocimiento atmosférico**.

Relación con el currículo original: M01. Esta secuencia pertenece al bloque piloto **Módulo 1 — Fundamentales**; no renumera las 376 entradas pendientes del mapa original. Meteorología, navegación y decisiones se revisitan en montaña estival, invernal y glaciar; no son prerrequisitos prácticos ya acreditados.
