---
{
  "title": "Taper y preparación final de expediciones",
  "description": "Distinguir reducción de carga, descanso y preparación específica antes del viaje.",
  "module": "M22",
  "code": "E10-16",
  "order": 1016,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U10-16",
  "skills": [
    "s10-taper-expediciones"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Distinguir reducción de carga, descanso y preparación específica antes del viaje.",
    "Aplicar el concepto a una decisión de preparación de montaña y reconocer sus límites."
  ],
  "prerequisites": [
    "s10-periodizacion"
  ],
  "sources": [
    "e10-taper"
  ],
  "pending": [
    "Revisión por profesional del ejercicio e instructor de montaña pendiente. Nutrición y salud requieren revisión profesional específica; no se ha evaluado aptitud personal.",
    "Los casos y rúbricas son propuestas pedagógicas originales. La aplicación individual requiere evaluación, técnica y seguimiento.",
    "No se atribuyen requisitos de certificación, umbrales universales ni preparación técnica a los resultados físicos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "El taper busca…",
        "options": [
          "Gestionar carga antes del objetivo.",
          "Recuperar todas las sesiones perdidas.",
          "Garantizar cumbre."
        ],
        "answer": 0,
        "explanation": "Se ajusta al proceso y la persona.",
        "rationales": [
          "Se ajusta al proceso y la persona.",
          "No es una deuda acumulable.",
          "No controla todos los factores."
        ],
        "source": "e10-taper",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Llegar descansado…",
        "options": [
          "Elimina enfermedad de altitud.",
          "No sustituye aclimatación.",
          "Acredita rescate."
        ],
        "answer": 1,
        "explanation": "El perfil de exposición sigue importando.",
        "rationales": [
          "Son procesos distintos.",
          "El perfil de exposición sigue importando.",
          "No evalúa maniobras."
        ],
        "source": "e10-taper",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La revisión final debe…",
        "options": [
          "Ocultar pendientes.",
          "Usar la fecha como aprobación.",
          "Identificar evidencia y limitaciones."
        ],
        "answer": 2,
        "explanation": "Permite ajustar el objetivo.",
        "rationales": [
          "Impide decisiones informadas.",
          "No demuestra capacidades.",
          "Permite ajustar el objetivo."
        ],
        "source": "e10-taper",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Explica taper sin imponer porcentaje universal.",
    "Separa descanso y aclimatación.",
    "Declara pendientes en vez de certificar."
  ],
  "openAssessment": {
    "prompt": "Prepara una revisión ficticia con tres columnas: demostrado en contexto, pendiente y decisión antes del viaje.",
    "rubric": [
      "Explica taper sin imponer porcentaje universal.",
      "Separa descanso y aclimatación.",
      "Declara pendientes en vez de certificar."
    ],
    "source": "e10-taper",
    "difficulty": "integración"
  },
  "diagrams": [
    "e10-general-especifico"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN PROFESIONAL PENDIENTE.** Este contenido no prescribe un programa individual ni acredita competencia técnica. Los ejercicios numéricos y casos son ficticios. No introduzcas datos médicos, mediciones corporales privadas ni antecedentes de terceros.

## Conceptos clave y propósito

Taper, fatiga residual, mantenimiento, viaje, aclimatación y logística final.

## Teoría y toma de decisiones

El taper reduce carga antes de una competición u objetivo para favorecer la expresión del rendimiento. No es necesariamente reposo absoluto ni una fase para recuperar entrenamiento omitido. La respuesta depende de historia, deporte y estrategia.

La investigación de taper compara poblaciones y protocolos concretos; sus resultados no determinan un porcentaje único para una expedición de montaña. Se conserva la distinción entre evidencia deportiva y aplicación pedagógica. [Investigación de taper](#fuente-e10-taper).

Antes de una expedición se revisan entrenamiento, viaje, alimentación, equipo y práctica técnica. La aclimatación sigue siendo un problema propio: llegar descansado no elimina la susceptibilidad a enfermedad de altitud. [Bloque de Altitud](../../altitud/).

En el caso original falta una semana y se propone una última marcha extrema con mochila nueva. El análisis identifica fatiga, falta de familiarización y escaso tiempo para corregir. Una decisión razonable requiere revisar el objetivo con profesionales; la fecha de salida no obliga a declararse preparado.

La evaluación final debe nombrar lo pendiente: un elemento no ensayado, una técnica no observada o una contingencia sin verificar. El curso termina con una propuesta de revisión, no con una certificación de expedicionario.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación del aprendizaje:** Revisa con entrenador la carga final según el proceso real y coordina con instructor las habilidades pendientes. Separa ensayos ligeros de equipo y sesiones de acondicionamiento. No introduzcas un esfuerzo extremo para compensar carencias ni confundas taper con aclimatación.

La selección real de ejercicios, cargas, pruebas y progresión corresponde a una evaluación individual con profesionales. Las técnicas críticas de montaña requieren formación práctica y supervisión de instructor competente. El acondicionamiento físico no autoriza una maniobra.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una semana antes del viaje, el plan agrega una salida máxima para demostrar preparación. Redacta preguntas que permitan decidir si ajustar o posponer el objetivo.

Distingue dato, interpretación y decisión. Explica qué incertidumbre permanece. Los casos no representan un protocolo del organismo citado ni un criterio oficial de habilitación para guía.

## Errores frecuentes y puntos críticos de seguridad

Copiar un porcentaje de otro deporte; estrenar carga alta al final; tratar descanso como aclimatación; certificar preparación por completar el calendario.

## Material y equipo relacionado

Equipo ya familiarizado, lista logística, agenda y plan de viaje. Casco, arnés, cuerda, piolet y crampones requieren competencias específicas verificadas por instructor.

[Consultar inventario](../../equipo/). Ajustar o poseer el equipo no demuestra dominarlo. Las prácticas técnicas se registran por separado del acondicionamiento.

## Autoevaluación y recuperación activa

- Explica la diferencia entre la capacidad que estudias y una tarea técnica de montaña.
- ¿Qué información falta en el caso y qué decisión modificaría?
- ¿Qué parte puede analizarse en escritorio y cuál necesita observación profesional?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Prepara una revisión ficticia con tres columnas: demostrado en contexto, pendiente y decisión antes del viaje.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Revisión conjunta con entrenador e instructor; decisiones clínicas o de aclimatación se consultan con profesional sanitario.

## Evidencia requerida y criterios de competencia

- Explica taper sin imponer porcentaje universal.
- Separa descanso y aclimatación.
- Declara pendientes en vez de certificar.

**COMPETENCIA:** estos criterios describen aprendizaje que debe observar un profesional en contexto. No acreditan aptitud médica, entrenamiento personal, guiado ni maniobra técnica. Una lectura, prueba física o quiz no otorga certificación. Marca pendiente lo que no se haya evaluado.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s10-taper-expediciones). Registra fecha, actividad, escenario, equipo, objetivo, errores, correcciones, supervisor y evidencia de aprendizaje. No guardes datos médicos ni contraseñas. No inventes sesiones, evaluaciones o repeticiones para completar la matriz.

## Relaciones con otros módulos

[Entrenamiento](../../entrenamiento/) · [Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Programa](../../programa/). Entrenamiento general, preparación específica, aclimatación y competencia técnica se relacionan, pero no son equivalentes.
