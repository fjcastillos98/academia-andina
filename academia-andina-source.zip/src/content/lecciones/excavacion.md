---
{
  "title": "Pala y excavación estratégica: acceso, transporte y relevo",
  "description": "Distinguir una pala destinada a rescate de una herramienta recreativa.",
  "module": "M09",
  "code": "E5-14",
  "order": 513,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-11",
  "skills": [
    "s5-excavacion"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir una pala destinada a rescate de una herramienta recreativa.",
    "Explicar por qué excavar incluye retirar nieve y conservar espacio de trabajo.",
    "Relacionar estrategia con profundidad, participantes y seguridad."
  ],
  "prerequisites": [
    "s5-sonda"
  ],
  "sources": [
    "e5-pala-ortovox",
    "e5-pala-canada",
    "e5-wms-enterramiento"
  ],
  "pending": [
    "Estrategia presencial, material y criterios específicos de instructor pendientes."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Excavación estratégica busca…",
        "options": [
          "Solo sacar la mayor cantidad por palada.",
          "Crear acceso y transportar nieve de forma coordinada.",
          "Reemplazar la sonda."
        ],
        "answer": 1,
        "explanation": "El objetivo incluye acceso utilizable y organización.",
        "rationales": [
          "Cantidad por palada no describe todo el sistema.",
          "Considera progreso y flujo.",
          "La referencia espacial mantiene su función."
        ],
        "source": "e5-pala-canada",
        "difficulty": "intermedia",
        "kind": "conocimiento"
      },
      {
        "prompt": "¿Por qué relevar posiciones?",
        "options": [
          "Porque el esfuerzo y fatiga se distribuyen de forma desigual.",
          "Porque cualquier orden fijo es universal.",
          "Porque la pala pierde señal."
        ],
        "answer": 0,
        "explanation": "La coordinación atiende a la capacidad de trabajo.",
        "rationales": [
          "Explica el principio.",
          "El contexto modifica la organización.",
          "La pala no emite señal DVA."
        ],
        "source": "e5-pala-canada",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Llegar al cuerpo significa…",
        "options": [
          "Que puede abandonarse la atención.",
          "Que el quiz queda validado como rescate.",
          "Que aún se requiere acceso adecuado, evaluación y coordinación."
        ],
        "answer": 2,
        "explanation": "Localización, extracción y atención son resultados distintos.",
        "rationales": [
          "Omite riesgos clínicos.",
          "No existe esa equivalencia.",
          "Mantiene continuidad del cuidado."
        ],
        "source": "e5-wms-enterramiento",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Explica el flujo de nieve y dos posibles obstrucciones.",
    "Relaciona organización con recursos y profundidad sin fórmula universal.",
    "Distingue extracción y evaluación clínica."
  ],
  "openAssessment": {
    "prompt": "Analiza un esquema con nieve acumulada en el acceso: explica el error, qué alternativa probarías en taller y qué evidencia observarías.",
    "rubric": [
      "Explica el flujo de nieve y dos posibles obstrucciones.",
      "Relaciona organización con recursos y profundidad sin fórmula universal.",
      "Distingue extracción y evaluación clínica."
    ],
    "source": "e5-pala-ortovox",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-excavacion"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Distinguir penetración, transporte de nieve, espacio de acceso y relevo; reconocer montaje y daños.

## Teoría y toma de decisiones

Excavar no es únicamente abrir un agujero sobre una señal. Hay que desplazar nieve, mantener un acceso, llegar a la persona y crear espacio para atención. La pala de rescate es un sistema de hoja, mango, empuñadura y uniones que debe poder trabajar en nieve compactada. ORTOVOX distingue estos componentes y funciones de transporte. [Guía del fabricante](#fuente-e5-pala-ortovox). Una pala recreativa destinada a juego o limpieza ligera no se presume equivalente; tampoco se decide solo por color, volumen o peso.

Antes de la práctica se identifican fijaciones, extensión del mango si existe, grietas, deformaciones y cierre de ensamblaje. La configuración correcta se obtiene del manual, no se improvisa al primer esfuerzo. Una pala desmontada dentro de una mochila es material disponible, pero el tiempo y las dificultades para acceder y montarla forman parte del desempeño. La inspección del inventario registra observaciones y mantenimiento sin declarar automáticamente «apta» por tener una ficha completa.

La excavación estratégica organiza dos problemas simultáneos: avanzar hacia el objetivo y sacar del área la nieve removida. Si el material vuelve al agujero o se acumula donde necesitan trabajar otras personas, esfuerzo y progreso se separan. Avalanche Canada propone transporte coordinado y relevo porque la tarea frontal demanda esfuerzo. [Principios de equipo](#fuente-e5-pala-canada). El dibujo de una fila sirve para entender funciones, no fija una geometría universal. Número de rescatistas, pendiente, profundidad, consistencia y amenazas pueden exigir otra organización enseñada por instructor.

La referencia de la sonda informa posición y profundidad; no proporciona por sí sola una excavación completa. Un diseño de acceso considera también espacio para maniobrar y retirar material. Las guías WMS incluyen la excavación dentro de una respuesta que continúa con atención. [Guía clínica y de rescate](#fuente-e5-wms-enterramiento). Acercarse a una persona exige control y reconocer el cambio de objetivo: no se trata de mantener máxima agresividad con la herramienta en el contacto. El acceso a la vía aérea y evaluación primaria pertenecen a una formación presencial de rescate y primeros auxilios, no a una deducción basada en un esquema.

Ejercicio original: una cuadrícula representa una zona de excavación, otra de acumulación temporal y una vía de salida. Tres participantes solo pueden ocupar determinadas casillas. Prueba dos distribuciones dibujadas y señala dónde la nieve bloquea al siguiente trabajador. No se puntúa la configuración como una receta real: se evalúa si el alumno detecta el cuello de botella y explica cómo verificar una alternativa con instructor. Introduce después un trabajador fatigado y razona qué información necesita quien coordina para reorganizar el esfuerzo.

Un cronómetro aislado puede premiar una mala práctica. En un ensayo, una excavación rápida termina con una cavidad estrecha que no permite atención; otra exige más coordinación inicial, pero deja un espacio utilizable. El debriefing debe revisar acceso logrado, control de herramientas, transferencia de nieve y comunicación, además del tiempo. Las dimensiones concretas y los criterios de logro se acuerdan para ese taller y no se convierten en umbrales universales de supervivencia.

La aplicación al guiado exige pensar en recursos reales: pasajeros asustados, destreza desigual y una persona que además debe comunicarse. No se asigna esfuerzo físico ilimitado ni se considera seguro acumular gente en una zona expuesta. El alumno prepara una distribución conceptual y reconoce cuándo necesita rescate organizado. En práctica se usan blancos inertes y terreno seleccionado por instructor. La habilidad que se busca demostrar es organización observable bajo condiciones definidas; contestar cómo funciona una pala no demuestra excavación eficaz en una emergencia.

## Qué observo, qué significa y qué no puedo concluir

No hay distribución universal para toda profundidad y cantidad de rescatistas; la pala no sustituye atención clínica.

## Caso práctico y aplicación al guiado

Un equipo mueve mucha nieve pero la deposita en el acceso. Analiza el cuello de botella y qué medirías en un taller.

## Errores frecuentes y señales de alerta

Excavar sin salida de nieve; no relevar fatiga; crear cavidad inutilizable; golpear sin control cerca del objetivo.

## Autoevaluación y respuesta razonada

Analiza un esquema con nieve acumulada en el acceso: explica el error, qué alternativa probarías en taller y qué evidencia observarías.

## Ejercicios y práctica supervisada

Taller presencial con nieve y blanco inerte protegido, control de herramientas y tiempos parciales, sin personas enterradas.

## Evidencia requerida

- Explica el flujo de nieve y dos posibles obstrucciones.
- Relaciona organización con recursos y profundidad sin fórmula universal.
- Distingue extracción y evaluación clínica.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-excavacion).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
