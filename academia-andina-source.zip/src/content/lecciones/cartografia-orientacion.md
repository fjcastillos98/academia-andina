---
{
  "title": "Cartografía, orientación y navegación",
  "description": "Construir una interpretación del mapa y contrastarla con referencias sin depender de un único dispositivo.",
  "module": "M14",
  "code": "P1-F",
  "order": 106,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "pilot",
  "reviewDate": "2026-10-22",
  "objectives": [
    "Interpretar escala y equidistancia.",
    "Distinguir posición, orientación y elección de ruta.",
    "Detectar una inconsistencia entre mapa, registro y terreno."
  ],
  "prerequisites": [
    "Estudiar Nubes y reconocimiento atmosférico y explicar sus límites."
  ],
  "sources": [
    "usgs-navegacion"
  ],
  "pending": [
    "Revisión pedagógica y validación de criterios por instructor competente.",
    "Aplicación territorial en Los Lagos: requiere verificación situada."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "En escala 1:25 000, 4 cm representan…",
        "options": [
          "100 m horizontales.",
          "1 km horizontal.",
          "Una hora de marcha."
        ],
        "answer": 1,
        "explanation": "4 × 25 000 cm = 100 000 cm = 1 000 m. La escala no determina duración ni transitabilidad."
      },
      {
        "prompt": "Una traza GPS atraviesa un tramo desconocido. ¿Qué acredita?",
        "options": [
          "Que el terreno es seguro.",
          "Que puedes omitir la lectura del mapa.",
          "Una representación de posiciones que necesita contexto y verificación."
        ],
        "answer": 2,
        "explanation": "La traza no verifica por sí sola condiciones actuales, exposición ni capacidad del grupo."
      }
    ]
  },
  "pilot": {
    "position": 6,
    "requires": [
      "nubes-reconocimiento"
    ],
    "critical": false,
    "classifications": [
      "TEORÍA",
      "PROCEDIMIENTO",
      "PRÁCTICA INDIVIDUAL",
      "PRÁCTICA SUPERVISADA",
      "COMPETENCIA"
    ],
    "relatedModules": [
      "M14",
      "M00"
    ],
    "criteria": [
      "Interpreta correctamente escala y equidistancia, declara referencias de coordenadas, compara al menos dos evidencias y reconoce qué información no determina la transitabilidad."
    ]
  }
}
---
## Conceptos

**TEORÍA.** La cartografía representa el terreno mediante una selección de información. La orientación relaciona esa representación con direcciones y referencias; navegar incluye decidir y comprobar el desplazamiento. Un punto GPS no decide qué terreno es transitable.

USGS explica que las curvas unen puntos de igual elevación y que su separación ayuda a interpretar la pendiente; la equidistancia se consulta en el mapa [US Geological Survey](#fuente-usgs-navegacion). La leyenda y la escala forman parte de la lectura. No interpretes un color o símbolo usando la memoria de otro mapa.

## Desarrollo teórico y toma de decisiones

**PROCEDIMIENTO · análisis y preparación.** Empieza en mesa: identifica título, fecha, escala, sistema de coordenadas, datum, leyenda y equidistancia. Distingue norte geográfico, norte de cuadrícula y norte magnético como referencias diferentes: cualquier conversión requiere el dato pertinente y vigente del mapa o fuente. Este piloto no enseña un ajuste universal de brújula.

En un ejemplo de escala 1:25 000, 1 cm representa 250 m horizontales. Un segmento de 4 cm equivale a 1 km horizontal en esa representación; no es la distancia real de marcha ni incorpora desnivel. Para describir una posición comparte también el formato y referencia de las coordenadas. Copiar números sin ese contexto puede volver ambiguo el mensaje.

Planifica tramos entre referencias identificables y puntos donde comprobarás tu interpretación. Si dos datos se contradicen, reconoce la discrepancia antes de continuar; no conviertas la precisión aparente de la pantalla en certeza sobre el terreno.

## Ejemplo

Actividad didáctica original, no descripción de una ruta operativa.

## Caso de estudio

Caso ficticio: una persona interpreta curvas muy próximas como un atajo y otra compara un punto del teléfono con una cuadrícula distinta. Hay dos problemas independientes: lectura de relieve y referencia de posición.

Respuesta orientativa: revisar leyenda y equidistancia para interpretar el terreno; confirmar sistemas antes de comparar coordenadas. Ninguno de esos pasos demuestra que el tramo pueda recorrerse. Se necesita información de terreno y evaluación situada.

## Errores frecuentes

Confundir distancia horizontal con esfuerzo; no leer leyenda; seguir una línea descargada como si fuera una ruta validada; omitir datum y formato.

## Límites y puntos críticos de seguridad

La práctica inicial debe hacerse en entorno conocido, no expuesto y con supervisión acordada. No se propone perderse voluntariamente ni navegar con visibilidad adversa para aprender.

## Material y equipo relacionado

Mapa físico, brújula, teléfono o GPS con cartografía disponible y energía de respaldo. Distinguir cartografía descargada de conectividad.

## Recuperación activa

- ¿Qué diferencia hay entre un kilómetro en planta y uno de marcha?
- ¿Qué información falta si solo comunicas dos números como coordenadas?

Responde antes de consultar el texto. Luego anota qué cambiaste y por qué; el recuerdo sin justificación no basta.

## Ejercicio y práctica

**PRÁCTICA INDIVIDUAL** limitada a análisis en mesa u observación segura. Mide tres segmentos en un mapa de escala conocida y explica las unidades. Después, en un lugar conocido y seguro, contrasta dos referencias visibles con el mapa junto a un acompañante competente.

**PRÁCTICA SUPERVISADA.** Un instructor competente selecciona el contexto y observa la ejecución pertinente; este texto no autoriza a realizar maniobras técnicas sin esa formación. Antes de la sesión, acuerda objetivo, límites y cómo se interrumpirá el ejercicio.

## Registro de práctica

Abre el Diario de prácticas desde la navegación y selecciona esta habilidad. Registra fecha, lugar, condiciones, actividad, equipo, repeticiones, errores, correcciones y evidencia. Identifica al supervisor solo cuando estuvo presente. La confianza es una percepción, no un resultado de competencia. No incluyas datos médicos, contraseñas ni información privada de terceros.

## Criterios de revisión y competencia

**COMPETENCIA · evaluación pendiente.** Interpreta correctamente escala y equidistancia, declara referencias de coordenadas, compara al menos dos evidencias y reconoce qué información no determina la transitabilidad.

La evaluación debe indicar quién observó, qué contexto y evidencia revisó, qué criterio aplicó y cuál fue el resultado. El diario conserva una declaración del usuario: no verifica identidad ni credenciales del evaluador y no emite certificaciones. Una lectura o quiz nunca demuestra ejecución técnica.

## Próximos pasos y relación con otros módulos

Continúa con **Equipamiento personal y colectivo**.

Relación con el currículo original: M14. Esta secuencia pertenece al bloque piloto **Módulo 1 — Fundamentales**; no renumera las 376 entradas pendientes del mapa original. Meteorología, navegación y decisiones se revisitan en montaña estival, invernal y glaciar; no son prerrequisitos prácticos ya acreditados.
