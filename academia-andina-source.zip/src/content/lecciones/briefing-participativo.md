---
{
  "title": "Briefing y comprobación de comprensión",
  "description": "Explica propósito y funciones sin ambigüedad.",
  "module": "M19",
  "code": "E16-02",
  "order": 1602,
  "minutes": 30,
  "level": "Intermedio",
  "status": "development",
  "unit": "U16-02",
  "skills": [
    "s16-briefing-participativo"
  ],
  "critical": false,
  "reviewDate": "2026-10-28",
  "objectives": [
    "Explica propósito y funciones sin ambigüedad.",
    "Comprueba comprensión con reformulación."
  ],
  "prerequisites": [
    "s16-objetivos-aprendizaje"
  ],
  "sources": [
    "e16-mt"
  ],
  "pending": [
    "Revisión por docente e instructor competente pendiente.",
    "Casos y rúbricas originales; no certifican guiado ni sustituyen formación técnica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "El grupo asiente sin preguntas. ¿Qué falta?",
        "options": [
          "Dar por entendido todo.",
          "Acortar siempre la explicación.",
          "Observar una reformulación del acuerdo."
        ],
        "answer": 2,
        "explanation": "Permite detectar interpretaciones distintas.",
        "rationales": [
          "Asentir no prueba comprensión.",
          "La brevedad no resuelve la duda por sí sola.",
          "Permite detectar interpretaciones distintas."
        ],
        "source": "e16-mt",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una persona no quiere preguntar delante de todos. ¿Qué harías en el taller?",
        "options": [
          "Ofrecer una vía privada y aclarar sin ridiculizar.",
          "Exigir que hable públicamente.",
          "Ignorar su duda."
        ],
        "answer": 0,
        "explanation": "Permite participación respetuosa.",
        "rationales": [
          "Permite participación respetuosa.",
          "Puede impedir que la duda aparezca.",
          "Deja la comprensión sin comprobar."
        ],
        "source": "e16-mt",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué evidencia corresponde al ejercicio propuesto en esta unidad?",
        "options": [
          "Un registro de la tarea, errores y correcciones observados.",
          "Una declaración automática de competencia por leer.",
          "Una valoración del carácter de la persona."
        ],
        "answer": 0,
        "explanation": "La rúbrica pide observaciones de una tarea concreta; su evaluación sigue siendo humana.",
        "rationales": [
          "Es evidencia contextual del taller.",
          "Leer no demuestra ejecución.",
          "Se evalúan actuaciones, no etiquetas personales."
        ],
        "source": "e16-mt",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Explica propósito y funciones sin ambigüedad.",
    "Comprueba comprensión con reformulación.",
    "Ofrece un canal de dudas accesible."
  ],
  "openAssessment": {
    "prompt": "Prepara un briefing de tres minutos para una actividad de aula. Incluye dos preguntas de reformulación y una forma de plantear dudas sin exposición pública.",
    "rubric": [
      "Explica propósito y funciones sin ambigüedad.",
      "Comprueba comprensión con reformulación.",
      "Ofrece un canal de dudas accesible."
    ],
    "source": "e16-mt",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**BLOQUE EN DESARROLLO · REVISIÓN DOCENTE E INSTRUCTORA PENDIENTE.** Talleres de mesa con personajes ficticios, sin exposición en terreno ni datos personales.

## Conceptos clave y propósito

Un briefing es una conversación de preparación: propósito, organización, límites y comprobación de lo entendido. La propuesta siguiente es una pauta educativa, no una lista operativa universal.

## Teoría y alcance de la fuente

Mountain Training presenta un liderazgo centrado en las personas que equilibra propósito compartido, apoyo y desafío. Ese marco orienta la reflexión; no fija aquí una proporción guía-pasajeros ni requisitos legales chilenos.

[Fuente conceptual y límites](#fuente-e16-mt). El diseño de tareas, preguntas y criterios siguiente es una propuesta original de la academia; no se atribuye a la organización citada ni constituye un estándar de acreditación.

## Aplicación docente propuesta

En una simulación, explica el objetivo de la actividad, cómo se comunicarán las dudas y quién coordina cada tarea. Pide a alguien que reformule el acuerdo con sus palabras; «¿entendieron?» suele dejar pocas evidencias para revisar. Si la reformulación difiere, aclara el mensaje y comprueba de nuevo.

Adapta vocabulario y ritmo al grupo. Una persona puede preferir preguntar en privado o necesitar una explicación visual. No interpretes silencio como acuerdo ni entusiasmo como comprensión. La ficha del briefing debe separar hechos confirmados de supuestos. Un cambio relevante requiere comunicar qué acuerdo cambia y comprobar que la nueva instrucción llegó a sus destinatarios.

## Caso práctico

**Escenario ficticio:** En un taller ficticio, dos participantes interpretan de forma diferente cuándo deben avisar al coordinador.

Explica qué observación necesitas antes de concluir y qué parte de tu respuesta es todavía una hipótesis.

## Errores frecuentes

Confundir confianza con evidencia, registrar como realizada una práctica solo preparada y trasladar el resultado de una simulación a terreno real. Revisa también si describiste un hecho o una interpretación.

## Material y equipo

Cuaderno, tarjetas con roles ficticios y una ficha territorial de la academia. No se requieren cuerdas, anclajes ni exposición al terreno para estos ejercicios.

## Autoevaluación

- Explica propósito y funciones sin ambigüedad.
- Comprueba comprensión con reformulación.
- Ofrece un canal de dudas accesible.

## Ejercicios y práctica supervisada

Prepara un briefing de tres minutos para una actividad de aula. Incluye dos preguntas de reformulación y una forma de plantear dudas sin exposición pública.

En un taller con docente o instructor, alterna participante, facilitador y observador. Define antes el criterio y recoge después una corrección. El instructor decide si corresponde otra práctica; no aumentes exposición para producir evidencia.

## Evidencia requerida

Conserva objetivo, tarea, observación, error, corrección y próxima práctica. La revisión humana debe indicar contexto y límites; no basta una etiqueta de «logrado». El quiz registra conocimiento teórico y no cambia competencias prácticas.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s16-briefing-participativo). Solo registra el taller después de realizarlo. No inventes supervisor, evaluación ni repeticiones.

## Relaciones con otros módulos

[Pedagogía y liderazgo](../../liderazgo/) · [Fundamentos de grupo](../../lecciones/grupo-liderazgo/) · [Programa](../../programa/). Las maniobras y decisiones técnicas requieren sus propias competencias y supervisión.
