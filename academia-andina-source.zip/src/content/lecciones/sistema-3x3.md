---
{
  "title": "Sistema 3×3",
  "description": "Revisar condiciones, terreno y grupo en tres momentos de una salida.",
  "module": "M00",
  "code": "P1-B",
  "order": 102,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "pilot",
  "reviewDate": "2026-10-22",
  "objectives": [
    "Construir una matriz de nueve preguntas.",
    "Diferenciar planificación, observación local y decisión en un tramo.",
    "Reconocer el origen nivológico y los límites de esta adaptación."
  ],
  "prerequisites": [
    "Estudiar Gestión del riesgo en montaña y explicar sus límites."
  ],
  "sources": [
    "slf-3x3"
  ],
  "pending": [
    "Revisión pedagógica y validación de criterios por instructor competente.",
    "Aplicación territorial en Los Lagos: requiere verificación situada."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿Qué representa el 3×3 de este piloto?",
        "options": [
          "Una fórmula que certifica rutas.",
          "Una estructura de preguntas adaptada pedagógicamente.",
          "Un sustituto del instructor para avalanchas."
        ],
        "answer": 1,
        "explanation": "La adaptación organiza observaciones y decisiones; no certifica rutas ni enseña evaluación nivológica."
      },
      {
        "prompt": "La observación local contradice el plan. ¿Qué corresponde?",
        "options": [
          "Mantener el plan para no perder consistencia.",
          "Ignorar la observación porque es puntual.",
          "Revisar los supuestos y las alternativas."
        ],
        "answer": 2,
        "explanation": "La utilidad del sistema está en actualizar el juicio cuando cambia la evidencia."
      }
    ]
  },
  "pilot": {
    "position": 2,
    "requires": [
      "gestion-del-riesgo"
    ],
    "critical": false,
    "classifications": [
      "TEORÍA",
      "PROCEDIMIENTO",
      "PRÁCTICA INDIVIDUAL",
      "PRÁCTICA SUPERVISADA",
      "COMPETENCIA"
    ],
    "relatedModules": [
      "M00"
    ],
    "criteria": [
      "Formula nueve preguntas útiles, distingue datos y supuestos y documenta una revisión razonada sin transformar la tabla en puntuación de seguridad."
    ]
  }
}
---
## Conceptos

**TEORÍA.** El 3×3 organiza tres factores —condiciones, terreno y personas— en tres escalas de decisión: preparación, evaluación en el terreno y valoración del punto concreto. El folleto SLF/KAT lo presenta en prevención de avalanchas [SLF / KAT](#fuente-slf-3x3). Un boletín regional no determina por sí solo la estabilidad de una pendiente individual.

Aquí se ofrece una **adaptación pedagógica para una salida estival no técnica**. No es el método de reducción de avalanchas ni una validación de seguridad para Los Lagos. Aprender esta tabla no habilita para elegir pendientes nevadas.

## Desarrollo teórico y toma de decisiones

**PROCEDIMIENTO · análisis y preparación.** | Momento | Condiciones | Terreno | Personas |
| --- | --- | --- | --- |
| En casa | ¿Qué información es válida para la fecha y zona? | ¿Dónde están las dificultades y alternativas? | ¿Qué experiencia y limitaciones declara el grupo? |
| Al inicio | ¿Lo observado coincide con lo previsto? | ¿El acceso y la ruta coinciden con el plan? | ¿Equipo, disposición y ritmo permiten el plan? |
| Ante un tramo | ¿Qué ha cambiado aquí? | ¿Qué exposición y salida ofrece este punto? | ¿Todos comprenden y aceptan la decisión? |

No completes las nueve casillas una sola vez y archives la hoja. En cada transición registra un cambio, su implicación y la decisión. Si no hay información suficiente, escribe «desconocido» y define qué alternativa evita depender de ese dato. La tabla ordena preguntas; no genera automáticamente un sí.

## Ejemplo

Actividad didáctica original, no descripción de una ruta operativa.

## Caso de estudio

Caso ficticio: en casa se esperaba buena visibilidad. Al inicio el grupo camina más lento de lo previsto. Ante una bifurcación la nube oculta la referencia que pensabas usar. Distribuye esos datos en la tabla sin forzarlos a una única casilla: un cambio en condiciones puede modificar la lectura del terreno y la carga de trabajo del grupo.

Respuesta orientativa: revisar tiempos y orientación conjuntamente, explicitar la pérdida de la referencia y reconsiderar el plan antes de entrar en terreno desconocido. «El plan decía continuar» no es una justificación.

## Errores frecuentes

Usar nueve casillas como nueve permisos; dejar fuera a la persona menos experimentada; confundir una previsión regional con una observación local.

## Límites y puntos críticos de seguridad

La aplicación nivológica necesita formación específica, boletín pertinente y evaluación del terreno. Este piloto no enseña a aprobar pendientes de avalancha.

## Material y equipo relacionado

Mapa, previsión fechada, libreta y medios de observación. El dispositivo electrónico no completa las casillas por ti.

## Recuperación activa

- ¿Qué diferencia existe entre escala regional y punto concreto?
- ¿Por qué un cambio de ritmo afecta más de una casilla?

Responde antes de consultar el texto. Luego anota qué cambiaste y por qué; el recuerdo sin justificación no basta.

## Ejercicio y práctica

**PRÁCTICA INDIVIDUAL** limitada a análisis en mesa u observación segura. Realiza una simulación en mesa con tres tarjetas de cambios. Reescribe solo las casillas afectadas y explica las conexiones con las demás.

**PRÁCTICA SUPERVISADA.** Un instructor competente selecciona el contexto y observa la ejecución pertinente; este texto no autoriza a realizar maniobras técnicas sin esa formación. Antes de la sesión, acuerda objetivo, límites y cómo se interrumpirá el ejercicio.

## Registro de práctica

Abre el Diario de prácticas desde la navegación y selecciona esta habilidad. Registra fecha, lugar, condiciones, actividad, equipo, repeticiones, errores, correcciones y evidencia. Identifica al supervisor solo cuando estuvo presente. La confianza es una percepción, no un resultado de competencia. No incluyas datos médicos, contraseñas ni información privada de terceros.

## Criterios de revisión y competencia

**COMPETENCIA · evaluación pendiente.** Formula nueve preguntas útiles, distingue datos y supuestos y documenta una revisión razonada sin transformar la tabla en puntuación de seguridad.

La evaluación debe indicar quién observó, qué contexto y evidencia revisó, qué criterio aplicó y cuál fue el resultado. El diario conserva una declaración del usuario: no verifica identidad ni credenciales del evaluador y no emite certificaciones. Una lectura o quiz nunca demuestra ejecución técnica.

## Próximos pasos y relación con otros módulos

Continúa con **Planificación de una salida**.

Relación con el currículo original: M00. Esta secuencia pertenece al bloque piloto **Módulo 1 — Fundamentales**; no renumera las 376 entradas pendientes del mapa original. Meteorología, navegación y decisiones se revisitan en montaña estival, invernal y glaciar; no son prerrequisitos prácticos ya acreditados.
