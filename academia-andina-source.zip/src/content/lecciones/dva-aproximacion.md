---
{
  "title": "Aproximación: seguir una señal sin perder el escenario",
  "description": "Explicar la transición desde adquirir señal a aproximarse.",
  "module": "M09",
  "code": "E5-10",
  "order": 509,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-09",
  "skills": [
    "s5-dva-aproximacion"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Explicar la transición desde adquirir señal a aproximarse.",
    "Interpretar tendencias de distancia y dirección sin confundirlas con navegación.",
    "Reconocer pérdida de coherencia y necesidad de revisión."
  ],
  "prerequisites": [
    "s5-dva-senal"
  ],
  "sources": [
    "e5-coarse-aaa",
    "e5-bca-manual"
  ],
  "pending": [
    "Transiciones de interfaz y técnica del modelo personal: revisión presencial pendiente."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "La flecha del DVA indica…",
        "options": [
          "Una ruta libre de peligros.",
          "Información de búsqueda que aún exige evaluar el terreno.",
          "La posición exacta de la cabeza."
        ],
        "answer": 1,
        "explanation": "La señal no es un mapa de seguridad.",
        "rationales": [
          "Atribuye una función inexistente.",
          "Separa señal y terreno.",
          "No identifica anatomía."
        ],
        "source": "e5-coarse-aaa",
        "difficulty": "intermedia",
        "kind": "conocimiento"
      },
      {
        "prompt": "Cambiar orientación y altura continuamente dificulta…",
        "options": [
          "Comparar lecturas de forma controlada.",
          "Que la nieve se transforme.",
          "Que el instructor vea la marca comercial."
        ],
        "answer": 0,
        "explanation": "Se alteran varias condiciones a la vez.",
        "rationales": [
          "Afecta interpretación de una secuencia.",
          "No explica el problema de lectura.",
          "No es el objetivo académico."
        ],
        "source": "e5-coarse-aaa",
        "difficulty": "intermedia",
        "kind": "errores"
      },
      {
        "prompt": "Al terminar aproximación, ¿qué se ha demostrado?",
        "options": [
          "Rescate completo.",
          "Competencia profesional.",
          "Una fase de búsqueda, pendiente de localización y atención."
        ],
        "answer": 2,
        "explanation": "Cada fase tiene un objetivo limitado.",
        "rationales": [
          "Faltan fases y resultados.",
          "Exige formación y evaluación contextual.",
          "Describe correctamente el alcance."
        ],
        "source": "e5-bca-manual",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "Describe la finalidad de aproximación frente a búsqueda fina.",
    "Interpreta secuencias sin adjudicar exactitud no demostrada.",
    "Mantiene separadas decisiones de terreno e indicaciones del dispositivo."
  ],
  "openAssessment": {
    "prompt": "Compara dos registros de aproximación: uno documenta posición y lectura, otro solo el tiempo final. ¿Qué puedes evaluar con cada uno?",
    "rubric": [
      "Describe la finalidad de aproximación frente a búsqueda fina.",
      "Interpreta secuencias sin adjudicar exactitud no demostrada.",
      "Mantiene separadas decisiones de terreno e indicaciones del dispositivo."
    ],
    "source": "e5-coarse-aaa",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-dva-flujo"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Reconocer señal consistente, tendencia y transición de interfaz conforme al manual.

## Teoría y toma de decisiones

La fase de aproximación comienza cuando hay una señal consistente que puede orientar el acercamiento. En algunas escuelas se llama búsqueda secundaria o gruesa. Su finalidad es reducir el área de incertidumbre hasta poder trabajar con precisión, no confirmar todavía el cuerpo de una persona. Avalanche.org describe seguir las indicaciones del receptor y ajustar el ritmo; el comportamiento de la lectura importa más que una cifra aislada. [Aproximación](#fuente-e5-coarse-aaa). El usuario debe entender qué fase realiza para no trasladar el movimiento amplio de la búsqueda de señal al trabajo fino.

El DVA recibe un campo electromagnético y procesa la señal; no muestra un mapa topográfico ni la ruta más transitable. La dirección indicada no evalúa una grieta, un cortado o un canal. Su lectura de distancia no debe confundirse con una medida exacta de enterramiento desde cualquier posición. En un modelo de papel, coloca un receptor y un emisor sin relieve; después añade un obstáculo. La información de la pantalla puede ser idéntica mientras la decisión de desplazamiento cambia. Esa comparación demuestra por qué quien busca debe conservar atención al terreno.

Un manual ofrece instrucciones concretas para la presentación de flechas, sonidos y números de su modelo. El manual BCA consultado muestra indicadores de dirección, distancia, batería y múltiples señales. [Ejemplo de interfaz](#fuente-e5-bca-manual). Identificarlos no significa que otro DVA responda igual. La práctica prepara a leer una tendencia y a reconocer la transición indicada por el equipo, incluyendo cambios de pantalla que pueden ser normales. Memorizar «siempre aparece una flecha» sería un aprendizaje frágil ante otra interfaz.

La coherencia se observa en una secuencia: qué lectura había, qué movimiento ocurrió y qué apareció después. Un número que aumenta después de cierto desplazamiento exige interpretar la evolución y contrastar orientación conforme al manual; seguir acelerando sin mirar destruye información útil. Tampoco se trata de convertir cada variación en avería: hay que distinguir un cambio esperado de un resultado que no encaja. El instructor enseña esta lectura con el aparato real; la academia puede evaluar si el alumno formula la pregunta correcta.

Ejercicio original: una tarjeta presenta una serie ficticia de lecturas y dos relatos. En el primero, el buscador conserva control del aparato y describe su recorrido. En el segundo, lo agita, gira continuamente y omite el lugar de cada lectura. Aunque ambos muestran un número pequeño al final, sus registros no permiten la misma interpretación. Explica por qué cambiar varias condiciones simultáneamente dificulta saber qué produjo la variación. No se pretende reproducir en una tabla el campo real de un emisor; se evalúa el manejo de evidencia.

Aplicación al guiado: durante un entrenamiento, otra persona debe poder comprender qué está ocurriendo sin interrumpir al buscador con órdenes contradictorias. Acordar vocabulario como «señal adquirida», «aproximación» y «paso a búsqueda fina» ayuda a preparar sonda y pala según el ejercicio. Son comunicaciones de estado, no anuncios de éxito. «Estoy cerca» deja sin aclarar qué se observó; «iniciamos búsqueda fina según el equipo» describe una transición. El registro final debe separar la fase lograda del resultado global: aproximarse no equivale a localizar, y localizar no equivale a excavar o atender. Esa separación permite diseñar la siguiente práctica sin atribuir una competencia que no fue observada.

## Qué observo, qué significa y qué no puedo concluir

El DVA no indica transitabilidad ni profundidad exacta desde cualquier punto.

## Caso práctico y aplicación al guiado

En un ejercicio la flecha apunta hacia un obstáculo representado en el croquis. Explica por qué dirección de señal y decisión de desplazamiento son problemas distintos.

## Errores frecuentes y señales de alerta

Correr sin interpretar; agitar el aparato; confundir distancia de pantalla con cota; ignorar terreno.

## Autoevaluación y respuesta razonada

Compara dos registros de aproximación: uno documenta posición y lectura, otro solo el tiempo final. ¿Qué puedes evaluar con cada uno?

## Ejercicios y práctica supervisada

Aproximaciones a un emisor de entrenamiento, una variable por vez, bajo instructor y en área segura.

## Evidencia requerida

- Describe la finalidad de aproximación frente a búsqueda fina.
- Interpreta secuencias sin adjudicar exactitud no demostrada.
- Mantiene separadas decisiones de terreno e indicaciones del dispositivo.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-dva-aproximacion).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
