---
{
  "title": "Meteorología invernal: procesos y decisiones encadenadas",
  "description": "Relacionar precipitación, viento y energía con cambios del manto.",
  "module": "M10",
  "code": "E5-06",
  "order": 505,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-06",
  "skills": [
    "s5-meteo-invernal"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Relacionar precipitación, viento y energía con cambios del manto.",
    "Distinguir datos de modelo, observación y pronóstico.",
    "Revisar una decisión cuando cambian visibilidad o condiciones."
  ],
  "prerequisites": [
    "s5-terreno-avalancha"
  ],
  "sources": [
    "e5-wind-slab",
    "e5-wet-slab",
    "e5-dmc-model"
  ],
  "pending": [
    "Revisión pedagógica y de instructor. Condiciones, cobertura de boletines y aplicación territorial real: PENDIENTE DE VERIFICACIÓN."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Dejó de nevar, pero el viento mueve nieve. ¿Qué cambia?",
        "options": [
          "Toda placa desaparece.",
          "Puede continuar redistribución y carga.",
          "Solo cambia sensación térmica."
        ],
        "answer": 1,
        "explanation": "El transporte no exige precipitación simultánea.",
        "rationales": [
          "No hay ese mecanismo automático.",
          "Identifica un proceso activo.",
          "Omite transporte."
        ],
        "source": "e5-wind-slab",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "Un meteograma DMC es…",
        "options": [
          "Información modelada que debe leerse con alcance y validez.",
          "Un test de estabilidad.",
          "Una autorización de ruta."
        ],
        "answer": 0,
        "explanation": "Producto meteorológico no equivale a evaluación nivológica local.",
        "rationales": [
          "Alcance correcto.",
          "Mide otra cosa.",
          "No otorga autorización."
        ],
        "source": "e5-dmc-model",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "Hubo rehielo superficial. ¿Puede fijarse estabilidad de todo el manto?",
        "options": [
          "Sí.",
          "Solo por la hora.",
          "No, faltan estado interno y evolución."
        ],
        "answer": 2,
        "explanation": "El proceso es espacial y temporalmente variable.",
        "rationales": [
          "Extrapola una superficie.",
          "No basta el reloj.",
          "Reconoce estructura y cambio."
        ],
        "source": "e5-wet-slab",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Explica la cadena meteorología-manto-terreno-exposición.",
    "Diferencia modelo y observación.",
    "Revisa la decisión ante pérdida de información."
  ],
  "openAssessment": {
    "prompt": "Construye una cadena de seis eslabones desde lluvia sobre nieve o viento hasta decisión de retirada, indicando incertidumbres.",
    "rubric": [
      "Explica la cadena meteorología-manto-terreno-exposición.",
      "Diferencia modelo y observación.",
      "Revisa la decisión ante pérdida de información."
    ],
    "source": "e5-wind-slab",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-retirada"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Anota transporte visible, cambios de superficie, visibilidad y hora; no conviertas una señal en pronóstico completo.

## Teoría y toma de decisiones

La meteorología invernal se interpreta como una secuencia de procesos que afecta un terreno y un grupo. La nieve nueva puede añadir carga; el viento puede redistribuir nieve incluso cuando deja de nevar; lluvia y calentamiento pueden introducir agua o cambiar el balance energético. La temperatura del aire es un dato necesario, pero no explica por sí sola la temperatura interna, la unión entre capas ni la continuidad de un problema. Las unidades anteriores de atmósfera y pronósticos aportan vocabulario que aquí se aplica al manto.

El transporte por viento puede formar depósitos cohesionados. Señales de nieve en movimiento, acumulaciones y cambios de textura merecen evaluación, pero no permiten fijar automáticamente edad ni estabilidad del depósito. Si una placa se forma sobre una capa débil persistente, el problema no se resuelve con una regla de espera simple [fuente](#fuente-e5-wind-slab). La dirección de viento observada ahora puede no describir todos los episodios que construyeron el depósito.

El calentamiento prolongado y la lluvia sobre nieve pueden favorecer entrada de agua y debilitar uniones, con variación espacial y temporal. Un rehielo nocturno superficial no demuestra que todo el manto haya recuperado resistencia; una costra que se rompe cambia también el esfuerzo del grupo. Las placas húmedas pueden ser difíciles de anticipar [fuente](#fuente-e5-wet-slab). No se prescribe una hora universal de retorno: se necesita una hipótesis local y criterios observables de cambio.

Radiación solar, nubosidad y enfriamiento nocturno influyen en el intercambio de energía. Orientación y sombra hacen que dos sectores próximos no evolucionen igual. Congelación y descongelación son procesos, no etiquetas de seguridad. La lluvia puede modificar además ropa, destreza, visibilidad y comunicaciones, de modo que una misma variable afecta tanto al manto como a la capacidad del grupo para cambiar de plan.

La DMC ofrece productos basados en modelos, como meteogramas con información horaria de temperatura, precipitación, humedad y viento [fuente](#fuente-e5-dmc-model). Registra producto, emisión, validez y localización. No atribuyas precisión de una estación a una cumbre distinta. Un pronóstico organiza hipótesis; una observación contrasta lo que ocurre en un punto; la decisión incorpora también terreno y personas. Ninguno de esos documentos es un boletín de avalanchas por el solo hecho de mencionar nieve.

Whiteout describe pérdida de contraste y referencias visuales que dificulta reconocer relieve. La tormenta puede ocultar cambios precisamente cuando más importan. En el ejercicio, dibuja una cadena: meteorología → cambio posible del manto → terreno afectado → exposición → decisión. Introduce después dos cambios ficticios: viento distinto al previsto y reducción de visibilidad. Explica qué información se pierde y cuándo ya no puedes sostener el plan. No basta añadir un margen de tiempo si tampoco puedes reconocer dónde te encuentras; la alternativa requiere navegación, comunicaciones y capacidad de retirada.

## Qué observo, qué significa y qué no puedo concluir

No se publican condiciones actuales, isoterma local ni boletines inventados.

## Caso práctico y aplicación al guiado

Cesa la nevada pero continúa el viento. ¿Qué procesos pueden seguir activos y qué información del pronóstico caducó?

## Errores frecuentes y señales de alerta

Suponer fin de nevada igual a fin de problema; usar temperatura del valle para toda la montaña; regresar por una ruta no reconocible en whiteout.

## Autoevaluación y respuesta razonada

Construye una cadena de seis eslabones desde lluvia sobre nieve o viento hasta decisión de retirada, indicando incertidumbres.

## Ejercicios y práctica supervisada

Comparar un producto meteorológico archivado con observaciones ficticias etiquetadas; taller de navegación con instructor.

## Evidencia requerida

- Explica la cadena meteorología-manto-terreno-exposición.
- Diferencia modelo y observación.
- Revisa la decisión ante pérdida de información.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-meteo-invernal).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
