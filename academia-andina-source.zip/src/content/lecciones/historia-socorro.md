---
{
  "title": "Rescate organizado: memoria institucional y servicio",
  "description": "Distingue propuesta, operación y constitución institucional.",
  "module": "M17",
  "code": "E13-06",
  "order": 1306,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U13-06",
  "skills": [
    "s13-historia-socorro"
  ],
  "critical": false,
  "reviewDate": "2026-10-27",
  "objectives": [
    "Distingue propuesta, operación y constitución institucional.",
    "Atribuye el episodio regional sin inferir cobertura presente."
  ],
  "prerequisites": [
    "s13-historia-esqui-escalada"
  ],
  "sources": [
    "e13-csa"
  ],
  "pending": [
    "Revisión por historiador o especialista de patrimonio e instructor de montaña pendiente.",
    "Primeras ascensiones de Los Lagos, historia completa de escuelas técnicas y testimonios comunitarios requieren investigación y revisión adicionales.",
    "Casos y rúbricas son propuestas pedagógicas originales; no certifican guiado ni competencia práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "1949 y 1969 en la reseña CSA…",
        "options": [
          "Pueden referirse a hitos diferentes.",
          "Prueban necesariamente un error.",
          "Definen tiempos actuales de rescate."
        ],
        "answer": 0,
        "explanation": "La fuente distingue propuesta y corporación.",
        "rationales": [
          "La fuente distingue propuesta y corporación.",
          "Hay que revisar qué evento se fecha.",
          "No son datos operativos."
        ],
        "source": "e13-csa",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un rescate pasado en Puerto Montt permite…",
        "options": [
          "Garantizar respuesta inmediata hoy.",
          "Describir un episodio atribuido a la memoria institucional.",
          "Calcular recursos disponibles."
        ],
        "answer": 1,
        "explanation": "Mantiene alcance y atribución.",
        "rationales": [
          "No informa disponibilidad actual.",
          "Mantiene alcance y atribución.",
          "Faltan datos presentes."
        ],
        "source": "e13-csa",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una maniobra narrada históricamente…",
        "options": [
          "Se debe imitar para aprenderla.",
          "Reemplaza formación de rescate.",
          "Se estudia sin asumir que sea una instrucción actual."
        ],
        "answer": 2,
        "explanation": "Conserva la distinción de contextos.",
        "rationales": [
          "Imitarla sin formación puede ser peligroso.",
          "La historia no acredita técnica.",
          "Conserva la distinción de contextos."
        ],
        "source": "e13-csa",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue propuesta, operación y constitución institucional.",
    "Atribuye el episodio regional sin inferir cobertura presente.",
    "Separa homenaje, análisis histórico y procedimiento técnico."
  ],
  "openAssessment": {
    "prompt": "Elabora una ficha del episodio de Puerto Montt con hecho atribuido, fuente retrospectiva y tres límites. No incluyas datos privados ni un protocolo de rescate.",
    "rubric": [
      "Distingue propuesta, operación y constitución institucional.",
      "Atribuye el episodio regional sin inferir cobertura presente.",
      "Separa homenaje, análisis histórico y procedimiento técnico."
    ],
    "source": "e13-csa",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ACADÉMICA PENDIENTE.** Historia documental e interpretación: no es formación para ejecutar maniobras. No guardes datos médicos, contraseñas, datos privados de terceros ni conocimientos de acceso restringido.

## Conceptos clave y propósito

Voluntariado, propuesta de creación, operación, institucionalización y memoria. Una cronología del rescate no constituye un protocolo operativo.

## Teoría y toma de decisiones

La reseña del Cuerpo de Socorro Andino distingue una propuesta de creación en 1949, un primer rescate a nombre de la institución en 1951 y su constitución como corporación en 1969. Esas fechas corresponden a eventos diferentes; escoger una como «fundación» sin explicar el criterio oculta parte del proceso.

La misma reseña recuerda su ayuda a Puerto Montt tras el terremoto de 1960. Es un vínculo concreto entre la historia del socorro y Los Lagos, atribuido a la memoria institucional. No se usa para calcular cobertura, tiempos de respuesta o recursos actuales. Tampoco permite concluir quién realizó todos los rescates anteriores a la creación del cuerpo.

Al estudiar un episodio de rescate distingue la memoria del servicio, la documentación contemporánea y la revisión técnica posterior. Una narración heroica puede reconocer trabajo y solidaridad, pero no basta para analizar causas o decisiones. Evita juzgar un accidente con información que quienes participaron no tenían; evita también convertir el homenaje en un argumento para repetir una exposición. La formación actual en comunicaciones, primeros auxilios y evacuación requiere sus propias fuentes y práctica competente.

Fuentes de esta unidad: [Referencia 1](#fuente-e13-csa). Los ejercicios y criterios siguientes son diseño educativo original, no protocolos de las organizaciones citadas.

## Procedimiento: lectura, comprobaciones y variantes

**PROCEDIMIENTO — análisis documental:** Construye tres columnas: propuesta, actuación y forma institucional. Añade el episodio de Puerto Montt como operación relatada y formula qué documento contemporáneo permitiría contrastarlo.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Dos textos dan 1949 y 1969 como fecha del CSA. Antes de declarar que uno está equivocado, identifica si hablan de propuesta organizativa o constitución jurídica.

## Errores frecuentes y puntos críticos de seguridad

Confundir hitos distintos; deducir disponibilidad actual desde un rescate antiguo; reproducir maniobras históricas; divulgar datos personales de víctimas en el cuaderno.

Las maniobras críticas requieren formación práctica y supervisión de instructor competente. Estudiar cómo se actuaba antiguamente no habilita a reproducirlo. Este taller no requiere exposición en terreno.

## Material y equipo relacionado

Cronología y documentos públicos. VHF e inReach se relacionan con el módulo actual de comunicaciones, no con una reconstrucción operativa de rescates antiguos.

[Inventario educativo](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con una evidencia y un límite: Distingue propuesta, operación y constitución institucional.
- Explica con una evidencia y un límite: Atribuye el episodio regional sin inferir cobertura presente.
- Explica con una evidencia y un límite: Separa homenaje, análisis histórico y procedimiento técnico.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Elabora una ficha del episodio de Puerto Montt con hecho atribuido, fuente retrospectiva y tres límites. No incluyas datos privados ni un protocolo de rescate.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Revisión por docente e instructor de rescate sobre límites del relato histórico; toda maniobra práctica se reserva a formación específica supervisada.

## Evidencia requerida y criterios de competencia

- Distingue propuesta, operación y constitución institucional.
- Atribuye el episodio regional sin inferir cobertura presente.
- Separa homenaje, análisis histórico y procedimiento técnico.

**COMPETENCIA:** se requiere revisión humana contextual del trabajo. Una lectura, quiz o guion no certifica guiado, interpretación profesional ni maniobras técnicas. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s13-historia-socorro). Registra fecha, lugar de estudio, documentos, habilidad, repeticiones, errores, correcciones, supervisor y evidencia textual no sensible. Diferencia taller ficticio y actividad real; no inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Historia y patrimonio](../../historia/) · [Territorio](../../territorio/) · [Geología](../../geologia/) · [Ecología](../../ecologia/) · [Programa](../../programa/). La interpretación histórica complementa la formación técnica; no sustituye condiciones ni permisos actuales.
