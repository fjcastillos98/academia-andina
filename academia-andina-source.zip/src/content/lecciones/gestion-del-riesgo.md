---
{
  "title": "Gestión del riesgo en montaña",
  "description": "Separar peligro, exposición y consecuencias para justificar una decisión revisable.",
  "module": "M00",
  "code": "P1-A",
  "order": 101,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "pilot",
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir un peligro de la exposición del grupo.",
    "Explicar una alternativa y el dato que obligaría a detenerse.",
    "Identificar una presión social que distorsiona la decisión."
  ],
  "prerequisites": [
    "Leer la introducción: Aprender con evidencia."
  ],
  "sources": [
    "slf-3x3"
  ],
  "pending": [
    "Revisión pedagógica y validación de criterios por instructor competente.",
    "Aplicación territorial en Los Lagos: requiere verificación situada."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "El grupo ya pagó el traslado. ¿Qué cambia eso en el peligro del terreno?",
        "options": [
          "Nada por sí mismo; puede introducir presión en la decisión.",
          "Reduce el peligro porque aumenta el compromiso.",
          "Permite sustituir la evaluación por experiencia."
        ],
        "answer": 0,
        "explanation": "El coste ya asumido no modifica las condiciones físicas. Identificar la presión ayuda a revisar el juicio."
      },
      {
        "prompt": "Falta un dato decisivo para evaluar un tramo. ¿Qué respuesta muestra mejor criterio?",
        "options": [
          "Asignar una probabilidad baja sin justificarla.",
          "Declarar la incertidumbre y mantener alternativas que eviten la exposición.",
          "Promediar opiniones para obtener una certeza."
        ],
        "answer": 1,
        "explanation": "La incertidumbre debe quedar visible. El consenso no reemplaza información ni hace aceptable una exposición."
      }
    ]
  },
  "pilot": {
    "position": 1,
    "requires": [],
    "critical": false,
    "classifications": [
      "TEORÍA",
      "PROCEDIMIENTO",
      "PRÁCTICA INDIVIDUAL",
      "PRÁCTICA SUPERVISADA",
      "COMPETENCIA"
    ],
    "relatedModules": [
      "M00"
    ],
    "criteria": [
      "Identifica al menos un peligro, una exposición y una incertidumbre distintos; compara dos alternativas y explica cuándo revisaría la decisión."
    ]
  }
}
---
## Conceptos

**TEORÍA.** Un peligro es una fuente posible de daño; la exposición describe quién puede verse afectado, dónde y durante cuánto tiempo. El riesgo reúne la posibilidad de un resultado adverso y sus consecuencias. No es una cifra que podamos deducir con precisión a partir de intuiciones. **Incertidumbre** significa que faltan datos o que estos no describen bien el lugar y momento de la decisión.

El folleto SLF/KAT recuerda que valorar un riesgo exige considerar también las consecuencias [SLF / KAT](#fuente-slf-3x3). En este curso usamos una ficha cualitativa original: peligro → exposición → consecuencia plausible → información faltante → acción. No es una escala profesional validada ni permite sumar puntos para declarar una ruta segura.

## Desarrollo teórico y toma de decisiones

**PROCEDIMIENTO · análisis y preparación.** Para decidir, escribe primero qué quieres conseguir y qué alternativas aceptas. Después identifica el tramo donde el grupo estaría expuesto, la evidencia disponible y qué no puedes comprobar. Propón una acción que reduzca la exposición: cambiar el itinerario, retrasar, acortar o no salir. Finalmente fija un punto de revisión y quién puede expresar una objeción.

Una medida tiene límites: llevar casco no demuestra que un corredor con caída de piedras sea aceptable. Pregunta qué peligro queda después de la medida. Si no puedes explicar cómo salir del escenario, la ficha está incompleta. No uses una ausencia de incidentes anteriores como prueba de seguridad.

## Ejemplo

Actividad didáctica original, no descripción de una ruta operativa.

## Caso de estudio

Caso ficticio: cuatro personas quieren llegar a un mirador sin pasos técnicos. El acceso final pasa bajo una ladera con piedras recientes; hay un recorrido más bajo. Una persona dice «ya pagamos el traslado». Separa la evidencia física de la presión económica. El objetivo de aprendizaje es comparar alternativas, no seleccionar una ruta real.

Respuesta orientativa: la inversión ya realizada no cambia el terreno; faltan observaciones y contexto para aceptar la exposición. El recorrido bajo también necesita evaluación. Una buena respuesta expresa incertidumbre y conserva la opción de regresar.

## Errores frecuentes

Confundir familiaridad con control; buscar solo datos favorables; asignar a la persona más entusiasta la decisión sin escuchar al resto.

## Límites y puntos críticos de seguridad

No convertir esta ficha en autorización para nieve, roca expuesta o rescate. Los riesgos locales y las capacidades reales requieren evaluación situada.

## Material y equipo relacionado

Mapa, previsión, reloj y ficha de decisiones. Casco o cuerda no compensan una decisión injustificada.

## Recuperación activa

- ¿Qué diferencia hay entre peligro y exposición?
- ¿Qué dato podría hacerte abandonar tu alternativa preferida?

Responde antes de consultar el texto. Luego anota qué cambiaste y por qué; el recuerdo sin justificación no basta.

## Ejercicio y práctica

**PRÁCTICA INDIVIDUAL** limitada a análisis en mesa u observación segura. En una mesa, redacta dos fichas para el caso: continuar y regresar. Un compañero debe encontrar un supuesto no comprobado en cada una.

**PRÁCTICA SUPERVISADA.** Un instructor competente selecciona el contexto y observa la ejecución pertinente; este texto no autoriza a realizar maniobras técnicas sin esa formación. Antes de la sesión, acuerda objetivo, límites y cómo se interrumpirá el ejercicio.

## Registro de práctica

Abre el Diario de prácticas desde la navegación y selecciona esta habilidad. Registra fecha, lugar, condiciones, actividad, equipo, repeticiones, errores, correcciones y evidencia. Identifica al supervisor solo cuando estuvo presente. La confianza es una percepción, no un resultado de competencia. No incluyas datos médicos, contraseñas ni información privada de terceros.

## Criterios de revisión y competencia

**COMPETENCIA · evaluación pendiente.** Identifica al menos un peligro, una exposición y una incertidumbre distintos; compara dos alternativas y explica cuándo revisaría la decisión.

La evaluación debe indicar quién observó, qué contexto y evidencia revisó, qué criterio aplicó y cuál fue el resultado. El diario conserva una declaración del usuario: no verifica identidad ni credenciales del evaluador y no emite certificaciones. Una lectura o quiz nunca demuestra ejecución técnica.

## Próximos pasos y relación con otros módulos

Continúa con **Sistema 3×3**.

Relación con el currículo original: M00. Esta secuencia pertenece al bloque piloto **Módulo 1 — Fundamentales**; no renumera las 376 entradas pendientes del mapa original. Meteorología, navegación y decisiones se revisitan en montaña estival, invernal y glaciar; no son prerrequisitos prácticos ya acreditados.
