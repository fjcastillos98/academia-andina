---
{
  "title": "Encordamiento alpino: elegir una función, no una apariencia",
  "description": "Distinguir largos, movimiento simultáneo y cuerda corta.",
  "module": "M06",
  "code": "E8-03",
  "order": 803,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U8-03",
  "skills": [
    "s8-encordamiento-alpino"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Distinguir largos, movimiento simultáneo y cuerda corta.",
    "Reconocer que estar conectados no garantiza protección ante una caída."
  ],
  "prerequisites": [
    "s8-anclajes-alpinos"
  ],
  "sources": [
    "e8-radline",
    "e8-simul",
    "e8-anchor"
  ],
  "pending": [
    "Revisión docente y práctica presencial por instructor alpino competente pendientes. No se ha observado ni aprobado una maniobra.",
    "Compatibilidad y manual del equipo personal pendientes de verificación; no se extrapolan ejemplos GRIGRI/REVERSO/RAD LINE a ATC Guide u otras cuerdas."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Estar unidos por cuerda demuestra…",
        "options": [
          "Que toda caída se detendrá.",
          "Solo una conexión; hay que analizar su función de protección.",
          "Competencia del responsable."
        ],
        "answer": 1,
        "explanation": "Conexión y aseguramiento no son equivalentes. Distinguir largos, movimiento simultáneo y cuerda corta.",
        "rationales": [
          "La detención depende del sistema completo.",
          "Conexión y aseguramiento no son equivalentes.",
          "El equipo no evalúa capacidades."
        ],
        "source": "e8-simul",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Cuerda corta significa…",
        "options": [
          "Cualquier cuerda recogida.",
          "Un atajo universal para ahorrar tiempo.",
          "Una técnica especializada que exige formación específica."
        ],
        "answer": 2,
        "explanation": "La técnica no se reduce a una distancia. Distinguir largos, movimiento simultáneo y cuerda corta.",
        "rationales": [
          "La apariencia no define el método.",
          "La rapidez no valida su uso.",
          "La técnica no se reduce a una distancia."
        ],
        "source": "e8-radline",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Cambia nieve por un resalte rocoso. Conviene…",
        "options": [
          "Reevaluar método y protección antes de exponerse.",
          "Mantener todo porque ya está montado.",
          "Acortar sin otro análisis."
        ],
        "answer": 0,
        "explanation": "La función debe responder al nuevo tramo. Distinguir largos, movimiento simultáneo y cuerda corta.",
        "rationales": [
          "La función debe responder al nuevo tramo.",
          "La configuración previa no es prueba de pertinencia.",
          "Longitud no sustituye evaluación."
        ],
        "source": "e8-radline",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Explica diferencias funcionales sin reducirlas a longitud.",
    "Reconoce cuándo una caída puede comprometer a otro integrante.",
    "Propone detener y revisar el método antes de una transición no resuelta."
  ],
  "openAssessment": {
    "prompt": "Construye una tabla de los tres métodos: función, capacidades que exige, información necesaria y límite. Donde falte evidencia escribe «requiere formación presencial», no una configuración supuesta.",
    "rubric": [
      "Explica diferencias funcionales sin reducirlas a longitud.",
      "Reconoce cuándo una caída puede comprometer a otro integrante.",
      "Propone detener y revisar el método antes de una transición no resuelta."
    ],
    "source": "e8-radline",
    "difficulty": "integración"
  },
  "diagrams": [
    "e8-funciones"
  ]
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. Lecturas y cuestionarios no acreditan ejecución técnica ni guiado.**

## Conceptos clave y propósito

Conexión, aseguramiento, largos, simultáneo, cuerda corta, consecuencia de caída y capacidad técnica.

## Teoría y toma de decisiones

Encordarse conecta integrantes, pero la función de esa conexión depende del sistema y del terreno. La misma cuerda puede formar parte de una escalada por largos, de desplazamiento simultáneo o de técnicas especializadas de cuerda corta. Son métodos diferentes; no se distinguen solamente por la distancia visible entre personas.

En una organización por largos se alternan funciones de progresión y aseguramiento desde posiciones preparadas. El movimiento simultáneo cambia la relación entre integrantes y protecciones porque varias personas se desplazan al mismo tiempo. La cuerda corta exige habilidades especializadas de prevención y control; no equivale a recoger cuerda para que moleste menos. Su uso no se aprende de una fotografía ni se prescribe aquí. [Fuente de contraste](#fuente-e8-radline).

Una caída puede afectar a más de un miembro cuando la conexión transmite el problema sin una protección apropiada. Por eso la pregunta inicial no es «¿cuánta cuerda dejamos?», sino «¿qué función debe cumplir y qué ocurriría si alguien cae?». La respuesta necesita terreno, posibilidades de protección y capacidades observadas. La longitud por sí sola no resuelve ese análisis. [Fuente de contraste](#fuente-e8-simul).

Una transición de terreno exige volver a elegir el método, no mantenerlo por inercia. Una cordada que usó una configuración sobre nieve no tiene por ello una solución para un resalte rocoso. El lugar para detenerse y reorganizarse también forma parte de la propuesta: improvisar el cambio ya expuestos añade otro problema.

Para guiado, la competencia del responsable no se deduce de saber atar un nudo. Hay que considerar la capacidad del participante, cómo se detecta una dificultad, qué control existe y qué opciones quedan. Esta unidad no asigna proporciones guía/pasajeros ni afirma autorización normativa; esas condiciones deben comprobarse por separado.

La advertencia Petzl sobre RAD LINE trata una cuerda hiperstática concreta e incompatibilidades con ciertas situaciones de caída. No demuestra que cualquier cuerda sirva para cuerda corta ni que este producto sea apropiado para la actividad del usuario. La formación avanzada busca prevenir el desarrollo de una caída, no confiar en detener una caída ya formada. [Documento específico](#fuente-e8-radline).

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — análisis previo al taller.** Distinguir largos, movimiento simultáneo y cuerda corta. Se utiliza al preparar una tarea o revisar un cambio de contexto. Las comprobaciones se organizan por función, soporte, equipo, capacidades y continuidad de protección. La teoría y la rúbrica especifican qué observar en esta unidad.

El instructor selecciona método, protección y condiciones de parada. Si falta una condición esencial o el grupo no comprende una función, no se inicia la maniobra. Las variantes se mantienen dentro del contexto de su fuente: una página sobre vía equipada, un producto o senderismo no constituye un procedimiento universal alpino.

## Caso práctico y aplicación al guiado

**Escenario de aula:** Después de una sesión de glaciar, el grupo llega a un tramo rocoso ficticio y propone mantener el encordamiento porque ya está hecho. Explica qué objetivo de protección debe reconsiderarse y por qué acortar la cuerda no demuestra una solución.

Distingue hechos, suposiciones y preguntas antes de proponer una decisión. Los ejercicios, casos y rúbricas son propuestas pedagógicas originales de la academia pendientes de revisión docente. No se presentan como protocolos de los organismos citados.

## Errores frecuentes y puntos críticos de seguridad

Confundir conexión con aseguramiento; llamar cuerda corta a cualquier distancia pequeña; trasladar configuraciones entre terrenos; usar el número de integrantes como único criterio; improvisar movimiento simultáneo.

Una práctica protegida tiene un alcance limitado; no valida todas las condiciones futuras. No se aprende una técnica crítica mediante una caída deliberada ni copiando una imagen en terreno expuesto.

## Material y equipo relacionado

Arnés, cuerda, casco, conectores y protecciones adecuados a la actividad y manuales. La cuerda de 9,7 mm del inventario aporta un dato nominal; no decide por sí sola el método.

[Consultar inventario](../../equipo/). Identifica modelo, documentación y datos pendientes. No inventes inspecciones ni atribuyas competencia a la compra de un dispositivo.

## Autoevaluación y recuperación activa

- Explica con un ejemplo: Distinguir largos, movimiento simultáneo y cuerda corta.
- ¿Qué información falta en el caso y qué decisión depende de ella?
- ¿Qué parte puedes revisar documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Construye una tabla de los tres métodos: función, capacidades que exige, información necesaria y límite. Donde falte evidencia escribe «requiere formación presencial», no una configuración supuesta.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Instructor con competencia en técnicas alpinas explica y demuestra diferencias en un entorno protegido. La cuerda corta y el movimiento simultáneo necesitan formación específica; no se ensayan de forma autónoma a partir de la tabla.

## Evidencia requerida y criterios de competencia

- Explica diferencias funcionales sin reducirlas a longitud.
- Reconoce cuándo una caída puede comprometer a otro integrante.
- Propone detener y revisar el método antes de una transición no resuelta.

**COMPETENCIA:** la ejecución debe evaluarse presencialmente en un contexto explícito por instructor competente. Las respuestas escritas no sustituyen esa observación. Se registra qué ocurrió, qué no se evaluó y qué debe corregirse. No hay un número de repeticiones que otorgue competencia automáticamente.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s8-encordamiento-alpino). Registra solo lo realizado: fecha, lugar, actividad, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Confianza, resultado y evaluación son datos diferentes. No guardar datos médicos, contraseñas ni datos privados de terceros.

## Relaciones con otros módulos

Integra [hielo](../../hielo/), [glaciar](../../glaciar/), [planificación invernal](../planificacion-invernal/) y [anclajes y reuniones](../anclajes-reuniones/). El [programa](../../programa/) muestra prerrequisitos; son académicos, no habilitaciones. [Volver al bloque alpino](../../alpina/).
