---
{
  "title": "Detener una caída: objetivo y límites",
  "description": "Separar prevención, detención, estabilización y transferencia.",
  "module": "M04",
  "code": "E6-07",
  "order": 607,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U6-07",
  "skills": [
    "s6-detencion-grieta"
  ],
  "critical": true,
  "reviewDate": "2026-10-23",
  "objectives": [
    "Separar prevención, detención, estabilización y transferencia.",
    "Reconocer que sostener inicialmente no resuelve el rescate."
  ],
  "prerequisites": [
    "s6-encordamiento-glaciar"
  ],
  "sources": [
    "e6-petzl-team",
    "e6-petzl-transfer"
  ],
  "pending": [
    "Práctica dirigida con sistema de respaldo diseñado por instructor; no provocar caídas reales en grietas. PENDIENTE DE VERIFICACIÓN.",
    "Revisión presencial por instructor competente pendiente. No se ha realizado ni aprobado ninguna práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Caída retenida equivale a…",
        "options": [
          "Rescate terminado.",
          "Un objetivo inicial; faltan otros por resolver.",
          "Anclaje verificado."
        ],
        "answer": 1,
        "explanation": "Detención y estabilización son objetivos distintos.",
        "rationales": [
          "No se justifica: Detención y estabilización son objetivos distintos.",
          "Correcta: Detención y estabilización son objetivos distintos.",
          "No se justifica: Detención y estabilización son objetivos distintos."
        ],
        "source": "e6-petzl-team",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una transferencia requiere…",
        "options": [
          "Solo una pieza de marca.",
          "Soltar primero.",
          "Evaluación del soporte, sistema y técnica entrenada."
        ],
        "answer": 2,
        "explanation": "El material reconocible no valida un anclaje.",
        "rationales": [
          "No se justifica: El material reconocible no valida un anclaje.",
          "No se justifica: El material reconocible no valida un anclaje.",
          "Correcta: El material reconocible no valida un anclaje."
        ],
        "source": "e6-petzl-team",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Cómo preparar la práctica?",
        "options": [
          "Instructor define protección, respaldo y criterios.",
          "Provocar caída real en una grieta.",
          "Copiar un dibujo en terreno."
        ],
        "answer": 0,
        "explanation": "El aprendizaje debe realizarse bajo control competente.",
        "rationales": [
          "Correcta: El aprendizaje debe realizarse bajo control competente.",
          "No se justifica: El aprendizaje debe realizarse bajo control competente.",
          "No se justifica: El aprendizaje debe realizarse bajo control competente."
        ],
        "source": "e6-petzl-team",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "No confunde caída detenida con persona recuperada.",
    "Evita improvisar carga sobre soporte no evaluado.",
    "Identifica la necesidad de formación de todo el equipo."
  ],
  "openAssessment": {
    "prompt": "Ordena tarjetas conceptuales de reconocimiento de escena, caída detenida, sistema estabilizado y valoración de la persona; añade incertidumbres y acciones fuera de tu competencia.",
    "rubric": [
      "No confunde caída detenida con persona recuperada.",
      "Evita improvisar carga sobre soporte no evaluado.",
      "Identifica la necesidad de formación de todo el equipo."
    ],
    "source": "e6-petzl-team",
    "difficulty": "integración"
  },
  "diagrams": [
    "e6-objetivos"
  ]
}
---

**CONTENIDO TEÓRICO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Carga dinámica, Contrapeso, Labio, Transferencia al anclaje. La respuesta inicial y la fase de descarga a un anclaje tienen problemas distintos.

## Teoría y toma de decisiones

Detener la caída de un compañero en una grieta no es lo mismo que intentar frenar un deslizamiento propio. La carga llega a través del sistema de cuerda y afecta al equipo. La coordinación, la holgura, el soporte y el borde condicionan la respuesta; un piolet no garantiza el resultado. [Contexto de cordada](#fuente-e6-petzl-team). Esta materia exige entrenamiento presencial con protección y respaldo definidos por instructor.

Detención, estabilización y transferencia nombran objetivos distintos. Sostener inicialmente una carga no significa poder abandonar esa función para organizar otra. Petzl trata la transferencia a un anclaje como fase propia y advierte sobre la necesidad de evitar acciones bruscas. [Transferencia](#fuente-e6-petzl-transfer). El anclaje necesita evaluación del soporte, dirección y sistema; no queda validado por emplear una estaca, tornillo o piolet reconocible.

El análisis de escritorio puede preguntar qué sigue sin resolverse tras detener: estado de la persona, estabilidad del conjunto, exposición del resto, comunicación y apoyo. No prescribe el orden operativo de todas las acciones en cualquier emergencia. Si una opción requiere capacidades que el grupo no tiene, debe declararse antes de la actividad, en lugar de descubrirlo bajo carga. La planificación de rescate forma parte de la decisión previa de entrar.

Para un taller, pide al instructor que defina qué se simula, qué cargas y protecciones controla y qué criterio detiene el ejercicio. Los participantes no provocan caídas reales a grietas ni prueban un anclaje suspendiendo a una persona por su cuenta. La evidencia posterior distingue respuesta observada, errores, corrección y tareas que no se evaluaron. Un resultado logrado en un escenario protegido no puede anotarse como capacidad universal de detención y rescate.

## Procedimiento conceptual: objetivo, uso y límites

Separar prevención, detención, estabilización y transferencia. Esta unidad se utiliza para preparar el análisis y un taller, no para ejecutar una maniobra sin entrenamiento. La condición de nieve/hielo y la geometría pueden cambiar la dificultad de detener; no atribuir garantía al piolet.

Las variantes técnicas mantienen el ámbito de la fuente citada. Antes de cambiar una configuración se deben revisar sus funciones, comprobaciones y límites con instructor; no se combinan pasos de escuelas distintas por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario hipotético de aula.** El ejercicio declara «caída retenida» y otro participante propone soltar la posición para buscar material. Explica qué objetivo aún falta demostrar y qué información impide aceptar esa transición.

## Errores frecuentes y puntos críticos

Confundir retención con estabilización; transferir a soporte no evaluado; sumar personas al borde; provocar una caída para aprender.

No se atribuye una garantía de seguridad al equipo, al quiz ni a una práctica en condiciones diferentes. Si falta un dato esencial para justificar el objetivo, declarar ese vacío es parte del aprendizaje.

## Material y equipo relacionado

Sistema completo de cordada y rescate, soporte y material de anclaje definidos por instructor; no asumir que comprar una estaca valida la transferencia.

[Inventario personal](../../equipo/): conserva referencia del manual y observaciones de inspección. El registro no declara aptitud de una pieza ni competencia de quien la porta.

## Autoevaluación y recuperación activa

- ¿Qué sigue sin resolverse al detener una caída?
- ¿Por qué transferir una carga es una habilidad distinta de sostenerla?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL de escritorio:** Ordena tarjetas conceptuales de reconocimiento de escena, caída detenida, sistema estabilizado y valoración de la persona; añade incertidumbres y acciones fuera de tu competencia.

**PRÁCTICA SUPERVISADA:** el instructor adapta un taller con objetivos observables, protección y criterios de parada. No provocar caídas reales ni entrar a terreno expuesto para comprobar esta página. La evaluación presencial es independiente de la respuesta teórica.

## Evidencia requerida y criterios de competencia

- No confunde caída detenida con persona recuperada.
- Evita improvisar carga sobre soporte no evaluado.
- Identifica la necesidad de formación de todo el equipo.

Estos criterios valoran razonamiento; para una competencia práctica, el instructor debe definir y observar la ejecución en un contexto explícito. No se preasigna una evaluación por estudiar.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s6-detencion-grieta). Registrar únicamente lo realizado: fecha, lugar, condiciones, objetivo, equipo, supervisor, resultado, errores, correcciones, evidencia, autonomía observada y próxima práctica. No guardar datos médicos ni información privada de pasajeros.

## Relaciones con etapas anteriores

[Glaciología introductoria](../glaciologia-intro/), [planificación invernal](../planificacion-invernal/), [encordamiento según contexto](../encordamiento-contexto/), [anclajes](../anclajes-reuniones/) y [ventaja mecánica](../ventaja-mecanica/). Estas dependencias orientan el estudio; no autorizan la aplicación técnica. [Ruta glaciar](../../glaciar/).
