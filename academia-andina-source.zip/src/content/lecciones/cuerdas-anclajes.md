---
{
  "title": "Cuerdas y conceptos básicos de anclaje",
  "description": "Comprender un sistema de conexión y sus incertidumbres antes de aprender montajes con instructor.",
  "module": "M01",
  "code": "P1-I",
  "order": 109,
  "minutes": 35,
  "level": "Fundamentos",
  "status": "pilot",
  "reviewDate": "2026-10-22",
  "objectives": [
    "Identificar componentes y direcciones de carga en un esquema conceptual.",
    "Distinguir presencia de un anclaje y evaluación de su estado.",
    "Preparar preguntas sobre compatibilidad y redundancia."
  ],
  "prerequisites": [
    "Estudiar Nudos fundamentales y explicar sus límites."
  ],
  "sources": [
    "petzl-anclajes",
    "uiaa-cuerdas"
  ],
  "pending": [
    "Revisión pedagógica y validación de criterios por instructor competente.",
    "Aplicación territorial en Los Lagos: requiere verificación situada.",
    "Demostración, variantes, comprobaciones y evaluación práctica por instructor."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un anclaje instalado en una ruta…",
        "options": [
          "Es apto por definición.",
          "Necesita evaluación; estar instalado no demuestra su estado.",
          "No puede deteriorarse."
        ],
        "answer": 1,
        "explanation": "La fuente advierte desgaste y otros deterioros. La presencia no equivale a aptitud."
      },
      {
        "prompt": "Dos ramas dependen de un mismo soporte desconocido. ¿Qué debes registrar?",
        "options": [
          "Redundancia garantizada.",
          "Una carga máxima inventada.",
          "El fallo común y la incertidumbre del soporte."
        ],
        "answer": 2,
        "explanation": "La evaluación considera el sistema y sus dependencias, no solo el número de piezas."
      }
    ]
  },
  "pilot": {
    "position": 9,
    "requires": [
      "nudos-fundamentales"
    ],
    "critical": true,
    "classifications": [
      "TEORÍA",
      "PROCEDIMIENTO",
      "PRÁCTICA INDIVIDUAL",
      "PRÁCTICA SUPERVISADA",
      "COMPETENCIA"
    ],
    "relatedModules": [
      "M01",
      "M00"
    ],
    "criteria": [
      "Explica el recorrido conceptual de la carga y una incertidumbre; identifica fallos comunes y límites del análisis. La competencia de montaje requiere una evaluación práctica separada y específica."
    ]
  }
}
---
## Conceptos

**TEORÍA.** Un sistema conecta personas y terreno mediante componentes con funciones y limitaciones. En este piloto llamamos anclaje al elemento de conexión con el medio y reunión a una organización de puntos y conexiones para una tarea; el uso de estos términos puede variar entre escuelas. La terminología se acuerda con el instructor antes de practicar.

Petzl advierte que anclajes instalados pueden estar desgastados, corroídos, debilitados o sueltos y requieren comprobación antes de uso [Petzl](#fuente-petzl-anclajes). Encontrar material fijo no demuestra que sea apto. La ausencia de daño visible tampoco es una prueba completa de resistencia.

### Identificar una cuerda antes de hablar de un sistema

La [UIAA Safety Commission](#fuente-uiaa-cuerdas) distingue en su explicación de 2021 cuerdas dinámicas, cordinos accesorios y cuerdas de baja elongación. Advierte que llamar «estática» o «semiestática» a una cuerda de baja elongación puede generar confusión. Por eso el nombre coloquial no sustituye la identificación y las instrucciones del fabricante. Aquí no se reproducen límites de ensayo ni se afirma que el listado de estándares de aquel artículo siga siendo exhaustivo hoy.

Para estudiar tu cuerda, prepara una ficha con designación, uso previsto, documentación, historial conocido y dudas. Compara dos fichas sin intercambiar físicamente las cuerdas en un sistema. El ejercicio termina cuando puedes explicar qué información falta para decidir; no cuando has encontrado dos diámetros parecidos.

## Desarrollo teórico y toma de decisiones

**PROCEDIMIENTO · preparación para taller, no instrucciones de ejecución.** **Objetivo:** comprender cómo se transmite una acción entre persona, cuerda, conexiones y terreno. **Cuándo se utiliza:** como base de futuras prácticas de aseguramiento, reunión y rescate, cada una con requisitos propios. **Principios:** evaluar componentes y conjunto, dirección de carga, consecuencias de fallo y límites de información. **Componentes:** cuerda identificada, conectores, elementos de unión y puntos en el terreno según sistema enseñado.

**Comprobaciones conceptuales:** ¿de dónde viene la carga?, ¿qué elemento depende de otro?, ¿hay un fallo común?, ¿qué dato del fabricante falta?, ¿qué parte del sustrato no podemos evaluar? **Variantes:** reuniones en roca, hielo o nieve no son intercambiables; materiales y métodos necesitan enseñanza específica. **Limitaciones:** no se infieren resistencias, ángulos aceptables ni configuraciones seguras con esta lectura. **Supervisión:** seleccionar, montar, cargar o evaluar anclajes para personas exige instructor competente y entorno formativo controlado.

Para la cuerda, identifica la designación exacta, el uso previsto y el manual. No deduzcas compatibilidad solo por diámetro o aspecto ni extrapoles las prestaciones de una cuerda a otra. Los datos de las unidades que adquieras requieren verificación.

## Ejemplo

Actividad didáctica original, no descripción de una ruta operativa.

## Caso de estudio

Caso ficticio: dos conexiones aparentemente independientes terminan en un mismo elemento cuya condición se desconoce. Dibuja un diagrama de dependencias sin construirlo físicamente. ¿Qué información aporta contar dos conexiones?

Respuesta orientativa: el conteo describe piezas, no elimina el fallo compartido. Debe quedar visible la dependencia y la incertidumbre del soporte. Este análisis no constituye una aprobación del sistema.

## Errores frecuentes

Contar puntos sin evaluar dependencia; suponer que material fijo está mantenido; sustituir un componente sin revisar compatibilidad; ensayar resistencia con tirones improvisados.

## Límites y puntos críticos de seguridad

No cargar un montaje ni suspender personas durante el ejercicio individual. La evaluación de soporte y sistema no se resuelve por fotografía ni por quiz.

## Material y equipo relacionado

Cuerdas, mosquetones, cintas, estacas y tornillos de hielo como objetos de identificación; ATC Guide y poleas como conexiones futuras a estudiar, sin prescribir montajes.

## Recuperación activa

- ¿Por qué dos conexiones no garantizan independencia?
- ¿Qué no puedes determinar de un anclaje solo mirando una foto?

Responde antes de consultar el texto. Luego anota qué cambiaste y por qué; el recuerdo sin justificación no basta.

## Ejercicio y práctica

**PRÁCTICA INDIVIDUAL** limitada a análisis en mesa u observación segura. Dibuja dos sistemas abstractos y marca dependencias comunes. Lleva el dibujo y las fichas de tus piezas a una sesión con instructor; el montaje real queda fuera del ejercicio individual.

**PRÁCTICA SUPERVISADA.** Un instructor competente selecciona el contexto y observa la ejecución pertinente; este texto no autoriza a realizar maniobras técnicas sin esa formación. Antes de la sesión, acuerda objetivo, límites y cómo se interrumpirá el ejercicio.

## Registro de práctica

Abre el Diario de prácticas desde la navegación y selecciona esta habilidad. Registra fecha, lugar, condiciones, actividad, equipo, repeticiones, errores, correcciones y evidencia. Identifica al supervisor solo cuando estuvo presente. La confianza es una percepción, no un resultado de competencia. No incluyas datos médicos, contraseñas ni información privada de terceros.

## Criterios de revisión y competencia

**COMPETENCIA · evaluación pendiente.** Explica el recorrido conceptual de la carga y una incertidumbre; identifica fallos comunes y límites del análisis. La competencia de montaje requiere una evaluación práctica separada y específica.

La evaluación debe indicar quién observó, qué contexto y evidencia revisó, qué criterio aplicó y cuál fue el resultado. El diario conserva una declaración del usuario: no verifica identidad ni credenciales del evaluador y no emite certificaciones. Una lectura o quiz nunca demuestra ejecución técnica.

## Próximos pasos y relación con otros módulos

Continúa con **Comunicaciones y emergencia**.

Relación con el currículo original: M01. Esta secuencia pertenece al bloque piloto **Módulo 1 — Fundamentales**; no renumera las 376 entradas pendientes del mapa original. Meteorología, navegación y decisiones se revisitan en montaña estival, invernal y glaciar; no son prerrequisitos prácticos ya acreditados.
