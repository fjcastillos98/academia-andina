---
{
  "title": "Patrimonio vivo: construir un guion responsable",
  "description": "Distingue registro administrativo y voz comunitaria.",
  "module": "M17",
  "code": "E13-08",
  "order": 1308,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U13-08",
  "skills": [
    "s13-historia-patrimonio-vivo"
  ],
  "critical": false,
  "reviewDate": "2026-10-27",
  "objectives": [
    "Distingue registro administrativo y voz comunitaria.",
    "Atribuye información y reconoce límites de consentimiento."
  ],
  "prerequisites": [
    "s13-historia-llanquihue"
  ],
  "sources": [
    "e13-futahuillimapu",
    "e13-etica"
  ],
  "pending": [
    "Revisión por historiador o especialista de patrimonio e instructor de montaña pendiente.",
    "Primeras ascensiones de Los Lagos, historia completa de escuelas técnicas y testimonios comunitarios requieren investigación y revisión adicionales.",
    "Casos y rúbricas son propuestas pedagógicas originales; no certifican guiado ni competencia práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un censo administrativo histórico es…",
        "options": [
          "La voz completa y neutral de cada comunidad.",
          "Una fuente producida con un propósito que debe analizarse.",
          "Un permiso turístico actual."
        ],
        "answer": 1,
        "explanation": "Permite crítica documental situada.",
        "rationales": [
          "Su producción y contexto importan.",
          "Permite crítica documental situada.",
          "No concede permisos presentes."
        ],
        "source": "e13-futahuillimapu",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un relato encontrado en internet…",
        "options": [
          "Puede difundirse como voz de toda comunidad.",
          "Obliga a inventar detalles faltantes.",
          "Requiere comprobar contexto y condiciones de uso."
        ],
        "answer": 2,
        "explanation": "Respeta procedencia y acuerdos.",
        "rationales": [
          "Homogeneiza y omite atribución.",
          "La falta de datos exige límites.",
          "Respeta procedencia y acuerdos."
        ],
        "source": "e13-etica",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Si no hay evidencia sobre una creencia local…",
        "options": [
          "Reconoce el límite y evita atribuirla.",
          "Adapta una leyenda de otra región.",
          "Presenta una hipótesis como tradición."
        ],
        "answer": 0,
        "explanation": "Mantiene rigor y respeto.",
        "rationales": [
          "Mantiene rigor y respeto.",
          "Traslada una identidad sin respaldo.",
          "Oculta la incertidumbre."
        ],
        "source": "e13-etica",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue registro administrativo y voz comunitaria.",
    "Atribuye información y reconoce límites de consentimiento.",
    "Entrega un guion trazable sin inventar relatos ni permisos."
  ],
  "openAssessment": {
    "prompt": "Redacta un guion de 250 palabras con tres referencias o remisiones precisas, dos incertidumbres y una decisión de omitir contenido no autorizado. Revisa que no contenga promesas de seguridad.",
    "rubric": [
      "Distingue registro administrativo y voz comunitaria.",
      "Atribuye información y reconoce límites de consentimiento.",
      "Entrega un guion trazable sin inventar relatos ni permisos."
    ],
    "source": "e13-futahuillimapu",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ACADÉMICA PENDIENTE.** Historia documental e interpretación: no es formación para ejecutar maniobras. No guardes datos médicos, contraseñas, datos privados de terceros ni conocimientos de acceso restringido.

## Conceptos clave y propósito

Patrimonio vivo, portadores, consentimiento, atribución y contexto. Un archivo administrativo no es una descripción neutral ni la voz de toda una comunidad.

## Teoría y toma de decisiones

El resumen del estudio de Cristián Perucci publicado por el Servicio Nacional del Patrimonio Cultural en 2024 presenta fichas del censo de 1907–1908 en Futahuillimapu, entre el río Bueno y el seno de Reloncaví. El autor las relaciona con procesos de desposesión y transformación social de la población mapuche-huilliche. Se consulta aquí el resumen institucional, no el conjunto de fichas ni el artículo completo. El ejemplo muestra por qué preguntar quién produjo un registro y con qué propósito importa tanto como su fecha.

Los principios éticos de UNESCO reconocen el papel principal de las comunidades en la salvaguardia y proponen diálogo, colaboración y consentimiento libre, previo, sostenido e informado. Esto no es un permiso automático para usar relatos locales ni una explicación completa de obligaciones legales chilenas. La información públicamente accesible tampoco sustituye los acuerdos sobre reproducción de conocimientos, imágenes o testimonios.

El proyecto final de este bloque es un guion breve para un visitante de Los Lagos. Integra una observación del paisaje, un hecho histórico atribuido, una perspectiva territorial y una incertidumbre. Cuando no exista colaboración acordada, no hables como representante comunitario ni inventes ceremonias, traducciones o una creencia común a todos los pueblos. El aprendizaje consiste también en reconocer cuándo corresponde callar, reformular o solicitar revisión antes de difundir.

Fuentes de esta unidad: [Referencia 1](#fuente-e13-futahuillimapu) · [Referencia 2](#fuente-e13-etica). Los ejercicios y criterios siguientes son diseño educativo original, no protocolos de las organizaciones citadas.

## Procedimiento: lectura, comprobaciones y variantes

**PROCEDIMIENTO — análisis documental:** Prepara el guion en cuatro partes: observación, documento, interpretación y pendiente. Marca todo contenido que requeriría acuerdo con sus portadores. Variante: trabajar exclusivamente con un documento público sin incluir testimonios ni conocimientos restringidos. La revisión no se reemplaza por una casilla de consentimiento inventada.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un visitante pide una leyenda sagrada específica de una cumbre y solo tienes una web genérica. Propón una respuesta respetuosa que explique el límite y ofrezca información documentada sin inventar una voz comunitaria.

## Errores frecuentes y puntos críticos de seguridad

Homogeneizar identidades; atribuir una creencia a todos; confundir archivo administrativo con voz propia; divulgar ubicaciones sensibles; inventar consentimiento para completar el ejercicio.

Las maniobras críticas requieren formación práctica y supervisión de instructor competente. Estudiar cómo se actuaba antiguamente no habilita a reproducirlo. Este taller no requiere exposición en terreno.

## Material y equipo relacionado

Fichas públicas, guion y lista de preguntas. No grabar entrevistas ni adjuntar datos personales o conocimientos restringidos al cuaderno de la academia.

[Inventario educativo](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con una evidencia y un límite: Distingue registro administrativo y voz comunitaria.
- Explica con una evidencia y un límite: Atribuye información y reconoce límites de consentimiento.
- Explica con una evidencia y un límite: Entrega un guion trazable sin inventar relatos ni permisos.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Redacta un guion de 250 palabras con tres referencias o remisiones precisas, dos incertidumbres y una decisión de omitir contenido no autorizado. Revisa que no contenga promesas de seguridad.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Revisión académica y de interpretación por docente/instructor. Si se incorporan conocimientos comunitarios, revisión y colaboración acordadas con sus portadores antes de cualquier difusión; aún pendientes.

## Evidencia requerida y criterios de competencia

- Distingue registro administrativo y voz comunitaria.
- Atribuye información y reconoce límites de consentimiento.
- Entrega un guion trazable sin inventar relatos ni permisos.

**COMPETENCIA:** se requiere revisión humana contextual del trabajo. Una lectura, quiz o guion no certifica guiado, interpretación profesional ni maniobras técnicas. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s13-historia-patrimonio-vivo). Registra fecha, lugar de estudio, documentos, habilidad, repeticiones, errores, correcciones, supervisor y evidencia textual no sensible. Diferencia taller ficticio y actividad real; no inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Historia y patrimonio](../../historia/) · [Territorio](../../territorio/) · [Geología](../../geologia/) · [Ecología](../../ecologia/) · [Programa](../../programa/). La interpretación histórica complementa la formación técnica; no sustituye condiciones ni permisos actuales.
