---
{
  "title": "Progresión en hielo: secuencia, ritmo y exposición",
  "description": "Analizar movimiento y exposición como problemas relacionados.",
  "module": "M05",
  "code": "E7-05",
  "order": 705,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U7-05",
  "skills": [
    "s7-progresion-hielo"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Analizar movimiento y exposición como problemas relacionados.",
    "Definir criterios de progresión del aprendizaje sin pasar directamente al liderazgo."
  ],
  "prerequisites": [
    "s7-piolet-hielo"
  ],
  "sources": [
    "e7-movement",
    "e7-accessbook",
    "e7-rope-cuts"
  ],
  "pending": [
    "Revisión de instructor de hielo pendiente; no se ha observado ni aprobado ninguna práctica.",
    "Compatibilidad y manual de los modelos personales pendientes de verificación; ninguna pieza se considera apta por aparecer en el inventario.",
    "El video técnico se verificó solo por su texto introductorio; revisión audiovisual completa con instructor pendiente."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Completar un recorrido como segundo acredita…",
        "options": [
          "Liderazgo en cualquier hielo.",
          "Solo lo observado en ese contexto.",
          "Capacidad de montar reuniones."
        ],
        "answer": 1,
        "explanation": "La evidencia tiene un alcance concreto. Analizar movimiento y exposición como problemas relacionados.",
        "rationales": [
          "Son responsabilidades diferentes.",
          "La evidencia tiene un alcance concreto.",
          "Esa habilidad requiere su propia observación."
        ],
        "source": "e7-movement",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La zona de espera del grupo…",
        "options": [
          "Forma parte del diseño de exposición.",
          "Es irrelevante si todos llevan casco.",
          "Debe estar siempre bajo el escalador."
        ],
        "answer": 0,
        "explanation": "También puede recibir hielo desprendido. Analizar movimiento y exposición como problemas relacionados.",
        "rationales": [
          "También puede recibir hielo desprendido.",
          "El casco no elimina la exposición.",
          "No existe esa ubicación universal."
        ],
        "source": "e7-movement",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Para comprender un error conviene…",
        "options": [
          "Cambiar todas las variables.",
          "Medir solo altura alcanzada.",
          "Registrar situación, acción y efecto observado."
        ],
        "answer": 2,
        "explanation": "Permite una corrección contrastable. Analizar movimiento y exposición como problemas relacionados.",
        "rationales": [
          "Dificulta atribuir causas.",
          "Omite calidad de ejecución.",
          "Permite una corrección contrastable."
        ],
        "source": "e7-movement",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Mantiene control observable durante la tarea indicada.",
    "Comunica dificultad antes de perder capacidad de seguir instrucciones.",
    "Distingue qué se evaluó y qué quedó fuera, especialmente liderazgo."
  ],
  "openAssessment": {
    "prompt": "Analiza un relato ficticio de seis movimientos: identifica qué observarías en apoyos, herramientas, pausa y comunicación. Escribe criterios para detener el ejercicio sin inventar umbrales universales.",
    "rubric": [
      "Mantiene control observable durante la tarea indicada.",
      "Comunica dificultad antes de perder capacidad de seguir instrucciones.",
      "Distingue qué se evaluó y qué quedó fuera, especialmente liderazgo."
    ],
    "source": "e7-movement",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. El estudio y el quiz no acreditan una maniobra ni capacidad de guiado.**

## Conceptos clave y propósito

Secuencia de movimiento, descanso, línea de caída, comunicación y margen de retorno.

## Teoría y toma de decisiones

La progresión combina apoyos, herramientas, desplazamiento del cuerpo y momentos de pausa. El aprendizaje protegido permite observar qué componente explica un error. Si se aumenta a la vez inclinación, duración y autonomía, resulta difícil distinguir una carencia técnica de una fatiga excesiva. [Fuente de contraste](#fuente-e7-movement).

La técnica individual no resuelve por sí sola dónde se sitúan asegurador, instructor y otras cordadas. El hielo desprendido puede afectar a quien no está escalando. El diseño del taller incluye exposición al pie, comunicaciones y reglas para detener la actividad; un casco no elimina la necesidad de seleccionar ubicaciones.

Escalar como segundo o en un sistema de protección preparado no equivale a liderar. Liderar incorpora decisiones de protección, gestión de cuerda y consecuencias de caída mientras se progresa. La ausencia de caídas en una sesión no demuestra preparación para asumir ese conjunto de responsabilidades. La progresión académica conserva esas funciones separadas.

Un debriefing útil identifica una secuencia concreta: situación, acción, efecto y corrección. «Me cansé» es un comienzo; «perdí precisión en apoyos cuando aceleré para alcanzar el descanso» permite una hipótesis que el instructor puede contrastar. No se atribuye toda dificultad a fuerza insuficiente ni se prescribe un entrenamiento físico individual a partir de esa frase.

## Procedimiento: función, comprobaciones y límites

**PROCEDIMIENTO — marco de análisis previo al taller.** Objetivo: Analizar movimiento y exposición como problemas relacionados. Se utiliza para preparar el aprendizaje y detectar vacíos antes de una tarea real. Identifica la función, los componentes, la información que falta y las consecuencias de un error. Contrasta la versión de la fuente con el modelo de equipo y el método del instructor. No hay una configuración universal derivada de esta página.

Las comprobaciones relevantes se desarrollan en la teoría, el equipo y la rúbrica de esta unidad. Si el uso previsto o la protección del taller no están claros, la práctica no se inicia. Las variantes de una fuente se conservan dentro de su contexto; no se mezclan pasos de métodos distintos por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario ficticio para análisis:** Una sesión protegida termina sin incidentes. El alumno quiere liderar la siguiente vía porque completó el recorrido. Explica qué capacidades no fueron observadas y cómo pedir una evaluación pertinente.

Antes de responder, enumera los hechos dados y los datos que has supuesto. Propón una decisión provisional y una condición que te haría revisarla. El caso, los ejercicios y las rúbricas son propuestas pedagógicas originales de la academia, pendientes de revisión docente; no son un protocolo de un organismo citado.

## Errores frecuentes y puntos críticos de seguridad

Confundir llegar arriba con ejecución controlada; acelerar cuando se pierde precisión; situar al grupo bajo la línea de caída; trasladar resultados de segundo a liderazgo.

No uses la ausencia de incidentes como prueba de seguridad. Las tareas con carga, herramientas o exposición necesitan control presencial competente. Ninguna respuesta escrita autoriza a escalar, montar un anclaje ni asistir a un pasajero.

## Material y equipo relacionado

Sistema técnico definido por instructor, casco, cuerda y comunicaciones verificadas. Llevar más material no sustituye organización de participantes y zona de espera.

[Consultar inventario](../../equipo/). Registra documento y revisión, sin inventar inspecciones realizadas. Tener material no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con tus palabras: Analizar movimiento y exposición como problemas relacionados.
- ¿Qué observación del caso apoya tu decisión y qué dato sigue faltando?
- ¿Qué error de esta unidad podrías reconocer documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Analiza un relato ficticio de seis movimientos: identifica qué observarías en apoyos, herramientas, pausa y comunicación. Escribe criterios para detener el ejercicio sin inventar umbrales universales.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Instructor diseña una progresión protegida y cambia una variable cada vez. Observa control, pausas y avisos; mantiene separada la evaluación de liderazgo. La sesión no incluye caídas voluntarias para aprender a confiar.

## Evidencia requerida y criterios de competencia

- Mantiene control observable durante la tarea indicada.
- Comunica dificultad antes de perder capacidad de seguir instrucciones.
- Distingue qué se evaluó y qué quedó fuera, especialmente liderazgo.

**COMPETENCIA:** estos criterios orientan la revisión. Cuando implican ejecución, el instructor debe observarla en un contexto definido, registrar resultado y lo que no se evaluó. No hay umbral automático de repeticiones, confianza o aciertos. La plataforma conserva una declaración personal y no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s7-progresion-hielo). Registra solo tareas realmente realizadas: fecha, lugar, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Mantén separados resultado observado, confianza y evaluación. No incluyas datos médicos ni datos privados de terceros.

## Relaciones con otros módulos

[Ruta invernal](../../invierno/), [formación glaciar](../../glaciar/), [encordamiento según contexto](../encordamiento-contexto/) y [anclajes y reuniones](../anclajes-reuniones/) aportan prerrequisitos. La aplicación alpina y el guiado requieren su propia formación y evaluación. [Volver a la secuencia de hielo](../../hielo/).
