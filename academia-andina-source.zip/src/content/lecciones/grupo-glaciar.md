---
{
  "title": "Grupo glaciar: decisiones compartidas",
  "description": "Integrar terreno, personas, equipo y límites en un briefing.",
  "module": "M04",
  "code": "E6-10",
  "order": 610,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U6-10",
  "skills": [
    "s6-grupo-glaciar"
  ],
  "critical": true,
  "reviewDate": "2026-10-23",
  "objectives": [
    "Integrar terreno, personas, equipo y límites en un briefing.",
    "Explicar criterios de retirada sin depender de presión de cumbre."
  ],
  "prerequisites": [
    "s6-izado-glaciar"
  ],
  "sources": [
    "e6-acc-team",
    "e6-petzl-edge",
    "e6-dga-inventory"
  ],
  "pending": [
    "Condiciones, acceso, rescate disponible y cobertura de comunicación local: PENDIENTE DE VERIFICACIÓN. PENDIENTE DE VERIFICACIÓN.",
    "Revisión presencial por instructor competente pendiente. No se ha realizado ni aprobado ninguna práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "El plan B no tiene reconocimiento. ¿Qué estado tiene?",
        "options": [
          "Seguro por ser alternativo.",
          "Pendiente de verificar por sí mismo.",
          "Aprobado por acortar."
        ],
        "answer": 1,
        "explanation": "La etiqueta alternativa no valida sus condiciones.",
        "rationales": [
          "No se justifica: La etiqueta alternativa no valida sus condiciones.",
          "Correcta: La etiqueta alternativa no valida sus condiciones.",
          "No se justifica: La etiqueta alternativa no valida sus condiciones."
        ],
        "source": "e6-acc-team",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Cómo comprobar comprensión del briefing?",
        "options": [
          "Suponerla si nadie pregunta.",
          "Mostrar el material.",
          "Pedir que expliquen tareas, límites y avisos."
        ],
        "answer": 2,
        "explanation": "La explicación ayuda a descubrir vacíos; no sustituye práctica.",
        "rationales": [
          "No se justifica: La explicación ayuda a descubrir vacíos; no sustituye práctica.",
          "No se justifica: La explicación ayuda a descubrir vacíos; no sustituye práctica.",
          "Correcta: La explicación ayuda a descubrir vacíos; no sustituye práctica."
        ],
        "source": "e6-acc-team",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "El inventario DGA permite…",
        "options": [
          "Consultar geometrías y metadatos según versión.",
          "Garantizar recursos de rescate.",
          "Confirmar puentes hoy."
        ],
        "answer": 0,
        "explanation": "El inventario tiene alcance distinto al operativo.",
        "rationales": [
          "Correcta: El inventario tiene alcance distinto al operativo.",
          "No se justifica: El inventario tiene alcance distinto al operativo.",
          "No se justifica: El inventario tiene alcance distinto al operativo."
        ],
        "source": "e6-dga-inventory",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "Distingue hechos e hipótesis.",
    "Permite detener el plan.",
    "No supone acceso ni recursos externos disponibles."
  ],
  "openAssessment": {
    "prompt": "Caso hipotético de Los Lagos: visibilidad disminuye y una persona no domina las comunicaciones acordadas. Justifica una decisión conservadora, la información faltante y un plan alternativo también sujeto a verificación.",
    "rubric": [
      "Distingue hechos e hipótesis.",
      "Permite detener el plan.",
      "No supone acceso ni recursos externos disponibles."
    ],
    "source": "e6-acc-team",
    "difficulty": "integración"
  },
  "diagrams": [
    "e6-decision"
  ]
}
---

**CONTENIDO TEÓRICO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Capacidades observadas, Plan de comunicación, Reevaluación, Evidencia territorial. Una lista de piezas no demuestra que el grupo pueda responder a una caída.

## Teoría y toma de decisiones

Guiar un grupo en glaciar requiere integrar capacidad observada, exposición y recursos. Una lista de equipo completo no prueba que el grupo pueda responder a una caída. La discusión de ACC sobre cordadas de dos muestra cómo las decisiones previas condicionan la respuesta; no establece una proporción legal de pasajeros para Chile. [Contexto técnico](#fuente-e6-acc-team). Esta unidad no certifica guiado ni fija capacidades comerciales.

El briefing debe permitir comprobar comprensión. En una propuesta pedagógica, cada participante explica con sus palabras cómo comunicar dificultad, qué cambios obligan a reevaluar y qué tareas no sabe hacer. Repetir instrucciones sin confirmar comprensión puede ocultar una dependencia importante. La información del integrante menos entrenado forma parte de la decisión; no se neutraliza entregándole más material.

La información territorial se organiza por fuente y fecha. La DGA aporta inventario, no condición operativa de un recorrido. [Ámbito del inventario](#fuente-e6-dga-inventory). Accesos, permisos, meteorología, nieve, comunicación y recursos de rescate necesitan verificación específica. Ninguna disponibilidad se da por supuesta porque existió en una salida anterior. Los escenarios de esta academia sobre Los Lagos son ejercicios hipotéticos, no reportes de terreno.

En un incidente también hay que proteger al grupo restante. Una tarea de valoración cerca del borde requiere protección y capacidad propias, como muestra Petzl. [Exposición durante la evaluación](#fuente-e6-petzl-edge). La persona que coordina no puede contar dos veces al mismo participante como buscador de información, operador de cuerda y responsable de comunicación si las funciones se solapan.

El ejercicio final es un briefing y debriefing de mesa. Presenta objetivo limitado, datos confirmados, vacíos, criterios de no inicio y alternativa. Otra persona introduce un cambio de visibilidad y una pérdida de capacidad del equipo. Revisa el plan y explica qué abandonas, qué mantienes y qué debes verificar antes de cualquier movimiento. Evalúa la calidad de la justificación, no que el relato llegue a la cumbre.

## Procedimiento conceptual: objetivo, uso y límites

Integrar terreno, personas, equipo y límites en un briefing. Esta unidad se utiliza para preparar el análisis y un taller, no para ejecutar una maniobra sin entrenamiento. Preparar roles y decisiones de escritorio es elaboración pedagógica; no se presenta como estándar profesional ni proporción legal.

Las variantes técnicas mantienen el ámbito de la fuente citada. Antes de cambiar una configuración se deben revisar sus funciones, comprobaciones y límites con instructor; no se combinan pasos de escuelas distintas por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario hipotético de aula.** Caso ficticio de Los Lagos, sin ruta real: disminuye la visibilidad y un integrante no entiende los avisos acordados. La alternativa propuesta tampoco tiene reconocimiento actualizado. Justifica por qué puede ser necesario abandonar el objetivo.

## Errores frecuentes y puntos críticos

Confundir plan B con ruta segura; ocultar límites para mantener autoridad; asignar tareas incompatibles simultáneamente; inventar tiempos de rescate.

No se atribuye una garantía de seguridad al equipo, al quiz ni a una práctica en condiciones diferentes. Si falta un dato esencial para justificar el objetivo, declarar ese vacío es parte del aprendizaje.

## Material y equipo relacionado

Conjunto técnico verificado, comunicaciones, navegación y plan de apoyo. InReach y VHF no garantizan cobertura o rescate disponible.

[Inventario personal](../../equipo/): conserva referencia del manual y observaciones de inspección. El registro no declara aptitud de una pieza ni competencia de quien la porta.

## Autoevaluación y recuperación activa

- ¿Cómo comprobar comprensión sin una pregunta que solo admita sí?
- ¿Qué debe verificarse también en una alternativa?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL de escritorio:** Caso hipotético de Los Lagos: visibilidad disminuye y una persona no domina las comunicaciones acordadas. Justifica una decisión conservadora, la información faltante y un plan alternativo también sujeto a verificación.

**PRÁCTICA SUPERVISADA:** el instructor adapta un taller con objetivos observables, protección y criterios de parada. No provocar caídas reales ni entrar a terreno expuesto para comprobar esta página. La evaluación presencial es independiente de la respuesta teórica.

## Evidencia requerida y criterios de competencia

- Distingue hechos e hipótesis.
- Permite detener el plan.
- No supone acceso ni recursos externos disponibles.

Estos criterios valoran razonamiento; para una competencia práctica, el instructor debe definir y observar la ejecución en un contexto explícito. No se preasigna una evaluación por estudiar.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s6-grupo-glaciar). Registrar únicamente lo realizado: fecha, lugar, condiciones, objetivo, equipo, supervisor, resultado, errores, correcciones, evidencia, autonomía observada y próxima práctica. No guardar datos médicos ni información privada de pasajeros.

## Relaciones con etapas anteriores

[Glaciología introductoria](../glaciologia-intro/), [planificación invernal](../planificacion-invernal/), [encordamiento según contexto](../encordamiento-contexto/), [anclajes](../anclajes-reuniones/) y [ventaja mecánica](../ventaja-mecanica/). Estas dependencias orientan el estudio; no autorizan la aplicación técnica. [Ruta glaciar](../../glaciar/).
