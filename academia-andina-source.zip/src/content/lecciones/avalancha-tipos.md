---
{
  "title": "Avalanchas: mecanismos, problemas y consecuencias",
  "description": "Distinguir forma de rotura, humedad, desencadenante y problema.",
  "module": "M09",
  "code": "E5-04",
  "order": 503,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-04",
  "skills": [
    "s5-avalancha-tipos"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir forma de rotura, humedad, desencadenante y problema.",
    "Reconocer salida, trayectoria y depósito.",
    "Relacionar tamaño con consecuencias y terreno de trampa."
  ],
  "prerequisites": [
    "s5-nivologia"
  ],
  "sources": [
    "e5-caic-problems",
    "e5-eaws-problems",
    "e5-terrain-traps"
  ],
  "pending": [
    "Revisión pedagógica y de instructor. Condiciones, cobertura de boletines y aplicación territorial real: PENDIENTE DE VERIFICACIÓN."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "«Húmeda» y «de placa» son…",
        "options": [
          "Siempre incompatibles.",
          "Descriptores que pueden combinarse.",
          "Dos tamaños oficiales."
        ],
        "answer": 1,
        "explanation": "Humedad y forma de rotura describen ejes diferentes.",
        "rationales": [
          "Confunde ejes.",
          "Clasificación coherente.",
          "No describen tamaño."
        ],
        "source": "e5-caic-problems",
        "difficulty": "intermedia",
        "kind": "conocimiento"
      },
      {
        "prompt": "Un canal bajo una ladera puede…",
        "options": [
          "Concentrar movimiento y consecuencias.",
          "Eliminar exposición.",
          "Estabilizar toda nieve superior."
        ],
        "answer": 0,
        "explanation": "Es una posible trampa o trayectoria.",
        "rationales": [
          "Relaciona forma y consecuencia.",
          "Puede recibir nieve.",
          "No cambia automáticamente capas superiores."
        ],
        "source": "e5-terrain-traps",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "Dos boletines usan diferentes categorías. ¿Qué haces?",
        "options": [
          "Fusionas nombres libremente.",
          "Usas solo colores.",
          "Revisas la leyenda de cada sistema."
        ],
        "answer": 2,
        "explanation": "Las clasificaciones no son idénticas.",
        "rationales": [
          "Puede cambiar significado.",
          "Pierde detalles.",
          "Conserva alcance y terminología."
        ],
        "source": "e5-eaws-problems",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Usa más de un eje de clasificación.",
    "Identifica terreno conectado y depósito.",
    "Justifica consecuencias sin inventar probabilidades."
  ],
  "openAssessment": {
    "prompt": "Clasifica un escenario por inicio, humedad y desencadenante; dibuja recorrido y compara consecuencias en dos posiciones.",
    "rubric": [
      "Usa más de un eje de clasificación.",
      "Identifica terreno conectado y depósito.",
      "Justifica consecuencias sin inventar probabilidades."
    ],
    "source": "e5-caic-problems",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-tipos",
    "e5-recorrido"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

En imágenes, separa punto o frente de inicio, zonas recorridas y depósito; etiqueta lo que no puede verse.

## Teoría y toma de decisiones

Una avalancha es un movimiento de nieve pendiente abajo; para describirla no basta una sola etiqueta. Conviene separar forma de inicio, humedad, material involucrado y desencadenante. Una avalancha de placa implica una capa cohesionada que se separa; una de nieve suelta comienza de forma localizada y puede ensancharse al incorporar nieve. Ambas pueden relacionarse con condiciones secas o húmedas. «Natural» y «desencadenada por personas» indican cómo se inició el movimiento, no categorías excluyentes de tamaño [CAIC](#fuente-e5-caic-problems).

Los problemas de avalancha describen situaciones que ayudan a anticipar dónde y cómo puede producirse inestabilidad. EAWS utiliza problemas de nieve reciente, placa de viento, capas débiles persistentes, nieve húmeda y deslizamiento basal, además de categorías opcionales. Otras escuelas separan más tipos; CAIC distingue, por ejemplo, nieve suelta seca y húmeda y diferentes placas. Se debe conservar la terminología del boletín consultado, evitando mezclar leyendas como si fueran idénticas [EAWS](#fuente-e5-eaws-problems).

El terreno puede organizarse conceptualmente en zona de salida, trayectoria y depósito. La primera no es el único lugar relevante para una persona: se puede estar expuesto abajo o lateralmente en terreno conectado. Canales y quebradas pueden concentrar movimiento; depresiones pueden acumular depósito; obstáculos y cortados pueden agravar las consecuencias. Una avalancha relativamente pequeña puede ser grave donde existe una trampa de terreno [fuente](#fuente-e5-terrain-traps). Las cornisas añaden otro problema que requiere analizar carga, posible caída y lo que hay debajo; no se deduce un margen universal desde una fotografía.

Tamaño y frecuencia responden preguntas diferentes. «Poco frecuente» no significa «poca consecuencia», y «pequeña» no significa «inofensiva». Para un ejercicio, describe por separado la posibilidad de desencadenamiento, el área afectada y el resultado para personas situadas en distintos puntos. La propagación de una rotura exige pensar más allá del lugar donde aparece la primera señal; el problema persistente se desarrolla en su unidad específica. No se asignan aquí probabilidades numéricas inventadas.

En el diagrama de salida-trayectoria-depósito marca tres posiciones de un grupo ficticio. Para cada una explica de dónde podría llegar nieve y dónde terminaría acumulada. Después cambia el escenario: la misma cantidad de nieve se canaliza hacia una depresión con obstáculos. Revisa las consecuencias sin cambiar automáticamente la etiqueta de inicio. Esta comparación ayuda a evitar que una clasificación técnica reemplace el análisis del recorrido completo.

Para el guiado, el lenguaje debe ser comprensible y trazable. No basta decir «hay avalanchas»; la comunicación debe mostrar qué problema se considera, qué terreno podría afectar y qué decisión limita la exposición. Si la evidencia no permite identificar el problema, registra esa incertidumbre. La prevención, el reconocimiento y la decisión de no entrar se estudian antes de las técnicas de rescate. Aprender a nombrar una avalancha no demuestra capacidad para gestionarla en terreno.

## Qué observo, qué significa y qué no puedo concluir

Una imagen no confirma estabilidad presente, desencadenante ni alcance futuro.

## Caso práctico y aplicación al guiado

Dos eventos del mismo tamaño relativo llegan a una explanada o a una quebrada. Explica por qué las consecuencias pueden diferir.

## Errores frecuentes y señales de alerta

Usar húmeda como sinónimo de lenta e inofensiva; confundir problema con tipo de rotura; ignorar exposición por debajo.

## Autoevaluación y respuesta razonada

Clasifica un escenario por inicio, humedad y desencadenante; dibuja recorrido y compara consecuencias en dos posiciones.

## Ejercicios y práctica supervisada

Clasificar diagramas y fotografías con fuente y contexto; práctica de reconocimiento con instructor fuera de exposición.

## Evidencia requerida

- Usa más de un eje de clasificación.
- Identifica terreno conectado y depósito.
- Justifica consecuencias sin inventar probabilidades.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-avalancha-tipos).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
