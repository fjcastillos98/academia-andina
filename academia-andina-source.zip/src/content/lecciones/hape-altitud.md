---
{
  "title": "HAPE: deterioro respiratorio en altitud",
  "description": "Reconocer deterioro respiratorio que exige suspender la actividad.",
  "module": "M03",
  "code": "E9-05",
  "order": 905,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U9-05",
  "skills": [
    "s9-hape-altitud"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Reconocer deterioro respiratorio que exige suspender la actividad.",
    "Distinguir HAPE de MAM sin exigir que aparezcan juntos."
  ],
  "prerequisites": [
    "s9-hace-altitud"
  ],
  "sources": [
    "e9-cdc",
    "e9-wms"
  ],
  "pending": [
    "Revisión médica por profesional de medicina de montaña y revisión docente por instructor pendientes. No se ha evaluado atención clínica ni rescate.",
    "Casos, ejercicios y criterios son propuestas pedagógicas originales; no autorizan decisiones clínicas individuales.",
    "Condiciones de rutas, comunicaciones y recursos de atención locales requieren verificación antes de cada salida."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿HAPE requiere que antes haya MAM?",
        "options": [
          "No necesariamente.",
          "Siempre.",
          "Solo si la persona tiene buen entrenamiento."
        ],
        "answer": 0,
        "explanation": "Puede presentarse sin MAM.",
        "rationales": [
          "Puede presentarse sin MAM.",
          "No son una secuencia obligatoria.",
          "La condición física no establece esa secuencia."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Dificultad respiratoria en reposo en el caso…",
        "options": [
          "Se resuelve exigiendo más ritmo.",
          "Requiere atención urgente y cambio del plan.",
          "Puede ignorarse si no hay cefalea."
        ],
        "answer": 1,
        "explanation": "Es una alarma, aunque falte diagnóstico definitivo.",
        "rationales": [
          "Aumentar esfuerzo no es una respuesta adecuada.",
          "Es una alarma, aunque falte diagnóstico definitivo.",
          "La ausencia de cefalea no descarta HAPE."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Durante la evacuación se busca…",
        "options": [
          "Que corra para bajar antes.",
          "Esperar a que aparezca esputo rosado.",
          "Reducir esfuerzo y obtener apoyo."
        ],
        "answer": 2,
        "explanation": "La logística debe limitar el esfuerzo de la persona.",
        "rationales": [
          "Puede agravar la situación.",
          "No debe esperarse esa manifestación.",
          "La logística debe limitar el esfuerzo de la persona."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Reconoce disnea en reposo como alarma.",
    "No exige MAM previo para considerar HAPE.",
    "Incluye reducción de esfuerzo y asistencia urgente."
  ],
  "openAssessment": {
    "prompt": "Escribe dos mensajes: uno con hechos del caso y otro con una interpretación precipitada. Señala por qué el primero ayuda más a coordinar asistencia.",
    "rubric": [
      "Reconoce disnea en reposo como alarma.",
      "No exige MAM previo para considerar HAPE.",
      "Incluye reducción de esfuerzo y asistencia urgente."
    ],
    "source": "e9-cdc",
    "difficulty": "integración"
  },
  "diagrams": [
    "e9-observar"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN MÉDICA Y DE INSTRUCTOR PENDIENTES.** No es una herramienta de diagnóstico ni prescripción. Los casos son ficticios; no introduzcas datos médicos personales. Una emergencia real requiere asistencia urgente, no completar esta lección.

## Conceptos clave y propósito

HAPE, edema pulmonar de altitud, disnea de esfuerzo, disnea de reposo y evacuación.

## Teoría y toma de decisiones

HAPE significa edema pulmonar de altitud. Puede aparecer sin MAM previo. El deterioro del rendimiento y la falta de aire desproporcionada con el esfuerzo pueden preceder a la disnea en reposo. No se debe esperar esputo rosado para reaccionar. [CDC, HAPE](#fuente-e9-cdc).

La respuesta en terreno remoto prioriza descenso urgente, ayuda y minimizar el esfuerzo de la persona. El oxígeno, cuando está disponible y se sabe administrar, forma parte del tratamiento; la decisión y los recursos se preparan con profesionales. Una lista de medicamentos no resuelve la necesidad de evacuar.

En un grupo es fácil normalizar que el más lento vaya quedando atrás. El ejercicio compara ritmo habitual, cambio reciente y contexto: se describe lo observado sin atribuirlo a desentrenamiento. La ausencia de dolor de cabeza no es una autorización para continuar.

No toda dificultad respiratoria es HAPE. Esa incertidumbre exige valoración, no tranquilidad artificial. El mensaje útil comunica situación y evolución, mientras el equipo gestiona abrigo, terreno, acompañamiento y acceso a atención. Aquí no se enseña a auscultar ni a seleccionar tratamientos; esas habilidades tienen una formación clínica propia.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación y análisis de aula.** En el caso, detén la progresión y solicita asistencia ante dificultad respiratoria en reposo. Prepara evacuación reduciendo el esfuerzo y evitando que la persona baje sola. Comprueba qué apoyo real existe y qué impide moverla. No retrasar por buscar una lectura instrumental perfecta ni exigir que coincidan todos los síntomas de una lista.

Las indicaciones clínicas dependen del paciente y los recursos. Las maniobras de movilización, oxigenoterapia y rescate requieren formación práctica y supervisión competente. No extrapolar un caso de escritorio a una actuación real ni elegir fármacos a partir de un quiz.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un personaje sin cefalea cae progresivamente detrás del grupo; en el campamento le cuesta respirar estando sentado. Un compañero dice que sin dolor de cabeza no es altitud. Analiza la decisión, no emitas un diagnóstico definitivo.

Identifica hechos, incertidumbres y decisiones. Explica qué información podría modificar tu propuesta. La rúbrica es docente, no un protocolo avalado por las instituciones citadas.

## Errores frecuentes y puntos críticos de seguridad

Esperar secreciones llamativas; exigir cefalea previa; obligar a descender corriendo; diagnosticar solo por saturación; atribuir el cambio a falta de entrenamiento.

## Material y equipo relacionado

Comunicación, protección térmica y sistema de evacuación revisado. Equipo médico solo dentro del entrenamiento y plan de atención correspondientes.

[Inventario educativo](../../equipo/). Tener el recurso no demuestra saber utilizarlo. El diario no es una ficha clínica.

## Autoevaluación y recuperación activa

- ¿Puedes explicar el concepto central sin confundirlo con una autorización de salida?
- ¿Qué dato falta en el escenario y qué decisión depende de él?
- ¿Qué tarea exige formación sanitaria o técnica y no se evalúa aquí?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Escribe dos mensajes: uno con hechos del caso y otro con una interpretación precipitada. Señala por qué el primero ayuda más a coordinar asistencia.

**PRÁCTICA SUPERVISADA — propuesta:** Simulación de comunicación y evacuación con instructor; estudiar cómo reducir el esfuerzo sin improvisar técnicas de transporte en terreno expuesto.

## Evidencia requerida y criterios de competencia

- Reconoce disnea en reposo como alarma.
- No exige MAM previo para considerar HAPE.
- Incluye reducción de esfuerzo y asistencia urgente.

**COMPETENCIA:** requiere observación contextual por instructor competente y revisión sanitaria cuando corresponda. Estos criterios evalúan preparación, comunicación y límites de actuación; no habilitan como profesional sanitario ni guía. La plataforma no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de la habilidad](../../practicas/?habilidad=s9-hape-altitud). Registra fecha, actividad, escenario ficticio, equipo, errores, correcciones, supervisor y evidencia del aprendizaje. No incluyas diagnósticos, recetas, mediciones personales ni datos de pacientes. Marca pendiente toda evaluación no realizada.

## Relaciones con otros módulos

[Volver a Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Escalada alpina](../../alpina/) · [Programa](../../programa/). La secuencia académica conecta planificación, comunicación y riesgo; no acredita aptitud clínica ni práctica.
