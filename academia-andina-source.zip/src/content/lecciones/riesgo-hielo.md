---
{
  "title": "Gestión del riesgo en hielo: decisión y aprendizaje",
  "description": "Integrar hielo, terreno, personas y recursos en una decisión revisable.",
  "module": "M05",
  "code": "E7-09",
  "order": 709,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U7-09",
  "skills": [
    "s7-riesgo-hielo"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Integrar hielo, terreno, personas y recursos en una decisión revisable.",
    "Separar éxito del objetivo y calidad del proceso de decisión."
  ],
  "prerequisites": [
    "s7-descenso-hielo"
  ],
  "sources": [
    "e7-waterfall",
    "e7-accessbook",
    "e7-rope-cuts"
  ],
  "pending": [
    "Revisión de instructor de hielo pendiente; no se ha observado ni aprobado ninguna práctica.",
    "Compatibilidad y manual de los modelos personales pendientes de verificación; ninguna pieza se considera apta por aparecer en el inventario."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una vía corta implica…",
        "options": [
          "Riesgo bajo garantizado.",
          "Que deben evaluarse igualmente exposición y consecuencias.",
          "Que no hace falta plan de retorno."
        ],
        "answer": 1,
        "explanation": "El análisis incluye todas las fases. Integrar hielo, terreno, personas y recursos en una decisión revisable.",
        "rationales": [
          "La longitud no resume el riesgo.",
          "El análisis incluye todas las fases.",
          "La retirada sigue siendo parte de la propuesta."
        ],
        "source": "e7-waterfall",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Volver sin accidente demuestra…",
        "options": [
          "Que todas las decisiones fueron correctas.",
          "Que el equipo basta para guiar.",
          "Un resultado, que debe analizarse separado del proceso."
        ],
        "answer": 2,
        "explanation": "Permite aprender sin sesgo de resultado. Integrar hielo, terreno, personas y recursos en una decisión revisable.",
        "rationales": [
          "Un buen resultado no valida todo el razonamiento.",
          "No constituye evaluación de guiado.",
          "Permite aprender sin sesgo de resultado."
        ],
        "source": "e7-waterfall",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La alternativa carece de datos. Se registra como…",
        "options": [
          "Pendiente de verificar, no solución garantizada.",
          "Segura porque es plan B.",
          "Aprobada si ahorra tiempo."
        ],
        "answer": 0,
        "explanation": "Mantiene la incertidumbre explícita. Integrar hielo, terreno, personas y recursos en una decisión revisable.",
        "rationales": [
          "Mantiene la incertidumbre explícita.",
          "La etiqueta no modifica condiciones.",
          "El ahorro no verifica exposición."
        ],
        "source": "e7-waterfall",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Integra aproximación, actividad y retorno en el análisis.",
    "Distingue observaciones de presión social y suposiciones.",
    "Justifica una decisión y sus condiciones de revisión sin afirmar riesgo cero."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso en cuatro columnas: dato, incertidumbre, consecuencia y decisión. Añade dos cambios que obliguen a revisarla y redacta un debriefing de una retirada.",
    "rubric": [
      "Integra aproximación, actividad y retorno en el análisis.",
      "Distingue observaciones de presión social y suposiciones.",
      "Justifica una decisión y sus condiciones de revisión sin afirmar riesgo cero."
    ],
    "source": "e7-waterfall",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. El estudio y el quiz no acreditan una maniobra ni capacidad de guiado.**

## Conceptos clave y propósito

Exposición, consecuencias, incertidumbre, cambios, factores humanos y retirada.

## Teoría y toma de decisiones

La decisión de escalar incluye aproximación, zona al pie, itinerario, otras cordadas y descenso. La dificultad técnica no resume esas exposiciones. Una escalada corta puede concentrar consecuencias importantes; una vía conocida puede presentar condiciones diferentes.

El contraste documental de Petzl sobre hielo y su enseñanza básica insiste en interpretar el entorno y su evolución. Para este currículo se traduce en una herramienta original de análisis: qué sabemos, qué no sabemos, qué ha cambiado y qué opciones permanecen. Es una pauta de razonamiento, no un método validado para calcular probabilidad ni una escala universal de riesgo. [Fuente de contraste](#fuente-e7-waterfall).

Los factores humanos pueden ocultar datos: haber viajado, llevar equipo nuevo o esperar una fotografía de cumbre no modifica el hielo. Conviene asignar antes quién puede plantear una duda, cómo se comunica y cómo se reconsidera el objetivo. La decisión debe poder cambiar cuando cambia la información, sin exigir que alguien demuestre primero que ocurrirá un accidente.

Para Filo Austral, separar práctica personal y operación con pasajeros es esencial. Las capacidades observadas en un taller no se extienden automáticamente al guiado. Las condiciones legales, ambientales y de acceso de una actividad concreta se verifican por separado; este bloque no afirma autorización comercial ni normativa vigente.

El debriefing compara el razonamiento con los datos disponibles en cada momento. Llegar sin incidentes no demuestra que la decisión fuera correcta. Retirarse puede ofrecer evidencia de reconocimiento de límites. Registra qué señal se reconoció, qué opción se descartó y qué dato permitiría estudiar mejor el siguiente caso, sin reconstruir una certeza que no existía.

## Procedimiento: función, comprobaciones y límites

**PROCEDIMIENTO — marco de análisis previo al taller.** Objetivo: Integrar hielo, terreno, personas y recursos en una decisión revisable. Se utiliza para preparar el aprendizaje y detectar vacíos antes de una tarea real. Identifica la función, los componentes, la información que falta y las consecuencias de un error. Contrasta la versión de la fuente con el modelo de equipo y el método del instructor. No hay una configuración universal derivada de esta página.

Las comprobaciones relevantes se desarrollan en la teoría, el equipo y la rúbrica de esta unidad. Si el uso previsto o la protección del taller no están claros, la práctica no se inicia. Las variantes de una fuente se conservan dentro de su contexto; no se mezclan pasos de métodos distintos por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario ficticio para análisis:** Caso ficticio: el grupo viajó varias horas, una cordada está arriba, aparece agua en un sector y el retorno alternativo no está documentado. Redacta un briefing que haga visibles los vacíos y una decisión justificable sin inventar un pronóstico local.

Antes de responder, enumera los hechos dados y los datos que has supuesto. Propón una decisión provisional y una condición que te haría revisarla. El caso, los ejercicios y las rúbricas son propuestas pedagógicas originales de la academia, pendientes de revisión docente; no son un protocolo de un organismo citado.

## Errores frecuentes y puntos críticos de seguridad

Confundir dificultad con riesgo; usar el dinero invertido como argumento técnico; considerar ausencia de accidente una validación; trasladar una práctica personal a pasajeros; llamar segura a una alternativa sin datos.

No uses la ausencia de incidentes como prueba de seguridad. Las tareas con carga, herramientas o exposición necesitan control presencial competente. Ninguna respuesta escrita autoriza a escalar, montar un anclaje ni asistir a un pasajero.

## Material y equipo relacionado

Información meteorológica y de acceso actual, navegación, equipo técnico compatible, comunicaciones y plan de apoyo. InReach Mini 2 y VHF requieren condiciones de funcionamiento y no garantizan respuesta de rescate.

[Consultar inventario](../../equipo/). Registra documento y revisión, sin inventar inspecciones realizadas. Tener material no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con tus palabras: Integrar hielo, terreno, personas y recursos en una decisión revisable.
- ¿Qué observación del caso apoya tu decisión y qué dato sigue faltando?
- ¿Qué error de esta unidad podrías reconocer documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Resuelve el caso en cuatro columnas: dato, incertidumbre, consecuencia y decisión. Añade dos cambios que obliguen a revisarla y redacta un debriefing de una retirada.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Simulación de mesa dirigida por instructor con información escalonada y reparto de roles. No necesita exposición real. El supervisor evalúa si las decisiones cambian por evidencia y cómo se comunica la retirada.

## Evidencia requerida y criterios de competencia

- Integra aproximación, actividad y retorno en el análisis.
- Distingue observaciones de presión social y suposiciones.
- Justifica una decisión y sus condiciones de revisión sin afirmar riesgo cero.

**COMPETENCIA:** estos criterios orientan la revisión. Cuando implican ejecución, el instructor debe observarla en un contexto definido, registrar resultado y lo que no se evaluó. No hay umbral automático de repeticiones, confianza o aciertos. La plataforma conserva una declaración personal y no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s7-riesgo-hielo). Registra solo tareas realmente realizadas: fecha, lugar, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Mantén separados resultado observado, confianza y evaluación. No incluyas datos médicos ni datos privados de terceros.

## Relaciones con otros módulos

[Ruta invernal](../../invierno/), [formación glaciar](../../glaciar/), [encordamiento según contexto](../encordamiento-contexto/) y [anclajes y reuniones](../anclajes-reuniones/) aportan prerrequisitos. La aplicación alpina y el guiado requieren su propia formación y evaluación. [Volver a la secuencia de hielo](../../hielo/).
