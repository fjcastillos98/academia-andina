---
{
  "title": "Flora regional: identificar con rasgos y evidencia",
  "description": "Registra rasgos antes de nombrar una especie.",
  "module": "M15",
  "code": "E11-04",
  "order": 1104,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U11-04",
  "skills": [
    "s11-flora-identificacion"
  ],
  "critical": false,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Registra rasgos antes de nombrar una especie.",
    "Distingue hipótesis de identificación revisada."
  ],
  "prerequisites": [
    "s11-ambientes-altoandinos"
  ],
  "sources": [
    "e11-alerce"
  ],
  "pending": [
    "Revisión por especialista en ecología e instructor territorial pendiente. Los ejercicios no autorizan acceso, colecta o manejo de fauna.",
    "Categorías legales vigentes, protocolos de encuentro específicos y claves taxonómicas completas: requieren verificación.",
    "Casos, rúbricas y propuestas de práctica originales; no constituyen un protocolo oficial ni una certificación."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una copa lejana sugerida por una app…",
        "options": [
          "Es prueba definitiva.",
          "Autoriza extraer una rama.",
          "Puede mantenerse como hipótesis pendiente."
        ],
        "answer": 2,
        "explanation": "Expresa la incertidumbre.",
        "rationales": [
          "La sugerencia no verifica caracteres.",
          "La identificación no habilita extracción.",
          "Expresa la incertidumbre."
        ],
        "source": "e11-alerce",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un nombre común…",
        "options": [
          "Puede requerir aclaración mediante nombre científico y fuente.",
          "Siempre identifica una sola especie.",
          "Es una prueba de endemismo."
        ],
        "answer": 0,
        "explanation": "Reduce ambigüedad.",
        "rationales": [
          "Reduce ambigüedad.",
          "No necesariamente es unívoco.",
          "No describe distribución."
        ],
        "source": "e11-alerce",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Si faltan caracteres diagnósticos…",
        "options": [
          "Completa por imaginación.",
          "Registra el nivel de identificación que la evidencia permite.",
          "Borra la observación."
        ],
        "answer": 1,
        "explanation": "Una observación incompleta puede ser útil.",
        "rationales": [
          "Fabricaría información.",
          "Una observación incompleta puede ser útil.",
          "Puede conservarse con límites."
        ],
        "source": "e11-alerce",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Registra rasgos antes de nombrar una especie.",
    "Distingue hipótesis de identificación revisada.",
    "Reconoce límites de una foto y de una ficha histórica."
  ],
  "openAssessment": {
    "prompt": "Completa una ficha ficticia de árbol con rasgos visibles, rasgos ausentes, hipótesis y referencia pendiente, sin asignar certeza artificial.",
    "rubric": [
      "Registra rasgos antes de nombrar una especie.",
      "Distingue hipótesis de identificación revisada.",
      "Reconoce límites de una foto y de una ficha histórica."
    ],
    "source": "e11-alerce",
    "difficulty": "integración"
  },
  "diagrams": [
    "e11-evidencia"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ECOLÓGICA PENDIENTE.** Observación responsable para estudio personal. No acredita identificación taxonómica, competencia profesional ni autorización de acceso. No guardes datos médicos ni localizaciones precisas de especies sensibles.

## Conceptos clave y propósito

Nombre común, nombre científico, carácter diagnóstico, semejanza, variación y nivel taxonómico. Una fotografía puede permitir identificar un grupo sin permitir llegar a especie.

## Teoría y toma de decisiones

La ficha oficial de alerce (Fitzroya cupressoides) describe hojas pequeñas dispuestas en grupos de tres. Ese rasgo sirve para aprender a observar disposición foliar, pero no constituye por sí solo una clave completa. No debe reemplazar la revisión de otros caracteres ni justificar manipular ramas. Las fichas antiguas pueden conservar divisiones regionales históricas: no copies sus límites administrativos como si fueran actuales.

Un registro útil documenta porte, disposición y forma de hojas, corteza visible y estructuras reproductivas si están presentes. Si no hay detalle suficiente, utiliza una hipótesis amplia como “árbol por identificar”. El nombre común puede variar o referirse a más de un taxón. Conserva la grafía científica de la fuente y su fecha; una revisión taxonómica posterior puede cambiar la interpretación.

Identificar es comparar evidencias con alternativas, no buscar una imagen parecida y detenerse. Escribe al menos un rasgo compatible, uno que falta y una posible confusión. No se enseña comestibilidad, medicina ni colecta. La decisión responsable puede ser dejar el registro sin identificar y pedir revisión a una persona competente.

Referencias de esta unidad: [Fuente 1](#fuente-e11-alerce). Los casos y las aplicaciones pedagógicas que siguen son elaboración original; no se atribuyen como protocolos de las fuentes.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — observación y decisión:** Observa sin retirar material; describe rasgos antes de proponer nombre; contrasta una ficha; registra alternativa y duda; solicita revisión cuando corresponda. Variante: revisión de foto frente a planta visible desde sendero. Límite: la ficha no permite identificar todas las especies similares.

No manipules fauna, no recolectes material y no salgas del itinerario autorizado para completar el ejercicio. La conducción real y las maniobras técnicas requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una aplicación propone alerce a partir de una copa lejana. No se ven hojas. Decide qué puede guardarse en el cuaderno y qué no puede afirmarse al grupo.

## Errores frecuentes y puntos críticos de seguridad

Convertir una sugerencia automática en certeza; usar tamaño o antigüedad aparente como único criterio; arrancar una rama; inferir comestibilidad por parecido.

## Material y equipo relacionado

Cámara con zoom, cuaderno y ficha botánica atribuida. No se requieren cuchillos ni herramientas de colecta para este ejercicio.

[Revisar inventario](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica cómo comprobarías este criterio: Registra rasgos antes de nombrar una especie.
- Explica cómo comprobarías este criterio: Distingue hipótesis de identificación revisada.
- Explica cómo comprobarías este criterio: Reconoce límites de una foto y de una ficha histórica.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Completa una ficha ficticia de árbol con rasgos visibles, rasgos ausentes, hipótesis y referencia pendiente, sin asignar certeza artificial.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Comparación no extractiva de rasgos con botánico o intérprete competente; revisión del nivel de identificación alcanzable.

## Evidencia requerida y criterios de competencia

- Registra rasgos antes de nombrar una especie.
- Distingue hipótesis de identificación revisada.
- Reconoce límites de una foto y de una ficha histórica.

**COMPETENCIA:** requiere observación y revisión humana en contexto. Una lectura, registro o quiz no certifica guiado, identificación experta ni maniobras. La plataforma no verifica credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s11-flora-identificacion) y [cuaderno de observación](../../ecologia/#observaciones). Separa ejercicio ficticio, observación real y práctica evaluada. Registra errores, correcciones, supervisor y evidencia sin inventar resultados. Mantén áreas generales; el texto libre no filtra automáticamente ubicaciones sensibles.

## Relaciones con otros módulos

[Ecología](../../ecologia/) · [Fichas de especies](../../especies/) · [Territorio](../../territorio/) · [Planificación](../../planificacion/) · [Programa](../../programa/). La interpretación ambiental se relaciona con geología, cartografía, gestión de grupos y patrimonio, sin sustituir su formación específica.
