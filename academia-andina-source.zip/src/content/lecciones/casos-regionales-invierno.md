---
{
  "title": "Los Lagos en invierno: límites de un escenario regional",
  "description": "Separar hechos, hipótesis y vacíos del escenario.",
  "module": "M23",
  "code": "E5-29",
  "order": 528,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-26",
  "skills": [
    "s5-casos-regionales-invierno"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Separar hechos, hipótesis y vacíos del escenario.",
    "Defender una decisión con alternativa y criterios de revisión.",
    "Explicar qué datos territoriales no proporciona un caso."
  ],
  "prerequisites": [
    "s5-casos-invernales"
  ],
  "sources": [
    "e5-decision",
    "e5-daily",
    "e5-senapred-invierno"
  ],
  "pending": [
    "Revisión del plan y rúbrica por instructor; fuentes territoriales y condiciones de cualquier salida real pendientes de verificación."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "El caso dice «Osorno». ¿Qué queda verificado?",
        "options": [
          "Ruta y temporada.",
          "Solo el nombre usado como marco del ejercicio.",
          "Peligro de avalancha actual."
        ],
        "answer": 1,
        "explanation": "El escenario está etiquetado como hipotético.",
        "rationales": [
          "No hay itinerario validado.",
          "Respeta el alcance del caso.",
          "No se entrega boletín actual."
        ],
        "source": "e5-decision",
        "difficulty": "integración",
        "kind": "decisiones"
      },
      {
        "prompt": "Tu plan requiere un anclaje que no se menciona. ¿Qué haces?",
        "options": [
          "Lo das por existente.",
          "Lo sustituyes por cualquier roca.",
          "Declaras la dependencia y reconsideras la opción."
        ],
        "answer": 2,
        "explanation": "Una alternativa depende de recursos reales.",
        "rationales": [
          "Inventa un recurso.",
          "No verifica resistencia ni diseño.",
          "Hace visible la incertidumbre."
        ],
        "source": "e5-decision",
        "difficulty": "integración",
        "kind": "decisiones"
      },
      {
        "prompt": "El grupo llegó bien pese a ignorar una señal. ¿Cómo evaluar?",
        "options": [
          "Revisar el proceso y la señal ignorada.",
          "Aprobar la decisión por el resultado.",
          "Eliminar el incidente del diario."
        ],
        "answer": 0,
        "explanation": "Resultado y calidad de decisión son distintos.",
        "rationales": [
          "Permite aprender del proceso.",
          "Normaliza exposición no razonada.",
          "Oculta aprendizaje útil."
        ],
        "source": "e5-decision",
        "difficulty": "integración",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Separa hechos y supuestos.",
    "Relaciona exposición, recursos y alternativas.",
    "Declara criterios de revisión y datos territoriales pendientes."
  ],
  "openAssessment": {
    "prompt": "Resuelve un caso antes de leer su orientación; después registra qué cambió y qué evidencia exigirías para sostener tu decisión.",
    "rubric": [
      "Separa hechos y supuestos.",
      "Relaciona exposición, recursos y alternativas.",
      "Declara criterios de revisión y datos territoriales pendientes."
    ],
    "source": "e5-decision",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

La expresión «escenario hipotético» y el campo de información faltante delimitan el ejercicio. No completar vacíos con conocimiento supuesto.

## Teoría y toma de decisiones

Los casos de esta unidad son ejercicios hipotéticos: los nombres Osorno, Calbuco, Casablanca, Yates, Tronador y Puntiagudo sirven para conectar el aprendizaje con la región, sin afirmar que haya ocurrido un episodio ni describir un itinerario. Una ficha geológica no proporciona estabilidad de nieve. Un nombre popular, una fotografía o un track histórico no establecen acceso, dificultad ni transitabilidad. La primera tarea es separar el dato territorial respaldado de la condición inventada para discutir una decisión.

Cada caso distingue contexto, información disponible, información faltante, peligros, terreno, personas, condiciones, opciones, decisión, justificación, plan B y debriefing. Antes de leer la orientación propuesta, escribe una respuesta propia. Subraya los hechos del escenario y marca con otro símbolo cualquier supuesto añadido. Si tu respuesta depende de una pendiente, un acceso o un diagnóstico que el caso no entrega, esa dependencia es parte de la discusión y no debe ocultarse.

La comparación de alternativas considera quién queda expuesto, durante cuánto tiempo y con qué recursos. Continuar, esperar, cambiar objetivo y retirarse no son sinónimos de seguridad ni de fracaso. Cada opción necesita un lugar, una capacidad y una contingencia. La ausencia de señales evidentes no demuestra estabilidad; un relato de paso anterior no verifica el estado presente. El marco general de decisiones de Avalanche.org destaca la incertidumbre y las alternativas [fuente](#fuente-e5-decision); nuestras preguntas y soluciones razonadas son ejercicios editoriales, no recomendaciones territoriales oficiales.

Trabaja en dos rondas. En la primera solo usa lo disponible. En la segunda incorpora un cambio ficticio entregado por el instructor: empeora visibilidad, falla una comunicación o un integrante ya no puede continuar. Revisa qué parte de tu decisión se mantiene y cuál se modifica. Una respuesta robusta explica el cambio; no defiende por orgullo la elección inicial. El debriefing debe registrar también qué evidencia habría sido necesaria para sostener la alternativa descartada.

Para los casos de avalancha, pérdida de señal o personas lesionadas, el ejercicio se limita a prioridades, límites y coordinación. No se simulan enterramientos de personas ni maniobras con carga humana a partir de esta página. El rescate técnico y la atención pertenecen a entrenamiento presencial apropiado. Si no puedes demostrar capacidad para ejecutar una alternativa, no la cuentes como recurso disponible.

La rúbrica valora cinco acciones: discriminar información, reconocer exposición, formular opciones viables, justificar una decisión condicionada y revisar el resultado. Un caso bien escrito puede evidenciar comprensión, pero no habilidad de manejo de DVA, crampones o piolet. Guarda tu argumento como respuesta abierta y utiliza el diario solo para prácticas realmente realizadas. En una salida futura, el dossier deberá actualizar condiciones y fuentes; el caso ficticio no se reutiliza como plan operativo.

## Qué observo, qué significa y qué no puedo concluir

Ningún caso identifica una ruta o situación real ni habilita rescate.

## Caso práctico y aplicación al guiado

Selecciona dos casos: uno de nieve/terreno y otro de grupo. Explica cómo una misma presión de horario afecta ambas decisiones.

## Errores frecuentes y señales de alerta

Inventar datos para justificar continuar; presentar retirada como viable sin revisar descenso; confundir resultado favorable con buena decisión.

## Autoevaluación y respuesta razonada

Resuelve un caso antes de leer su orientación; después registra qué cambió y qué evidencia exigirías para sostener tu decisión.

## Ejercicios y práctica supervisada

Debate de escritorio con un compañero y revisión de instructor. Registra cambios de razonamiento antes y después de leer la orientación.

## Evidencia requerida

- Separa hechos y supuestos.
- Relaciona exposición, recursos y alternativas.
- Declara criterios de revisión y datos territoriales pendientes.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-casos-regionales-invierno).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).

[Plantilla de planificación](../../invierno/planificacion/) · [Casos de esta etapa](../../invierno/#casos) · [Laboratorio de cálculos](../../invierno/ejercicios/).
