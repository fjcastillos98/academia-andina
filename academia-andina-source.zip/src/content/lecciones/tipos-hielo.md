---
{
  "title": "Tipos y formas de hielo: describir antes de decidir",
  "description": "Separar origen, forma y estado del hielo.",
  "module": "M05",
  "code": "E7-02",
  "order": 702,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U7-02",
  "skills": [
    "s7-tipos-hielo"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Separar origen, forma y estado del hielo.",
    "Reconocer los límites de etiquetas como compacto, aireado o coliflor."
  ],
  "prerequisites": [
    "s7-formacion-hielo"
  ],
  "sources": [
    "e7-aai",
    "e7-wmo-deposits",
    "e7-nsidc"
  ],
  "pending": [
    "Revisión de instructor de hielo pendiente; no se ha observado ni aprobado ninguna práctica.",
    "Compatibilidad y manual de los modelos personales pendientes de verificación; ninguna pieza se considera apta por aparecer en el inventario.",
    "Origen y estado de la llamada coliflor del Calbuco: requiere verificación local; no se deduce aptitud para tornillos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "«Glaciar» y «columna» describen…",
        "options": [
          "La misma propiedad.",
          "Origen y forma, respectivamente.",
          "Una resistencia normativa."
        ],
        "answer": 1,
        "explanation": "La clasificación evita confundir origen y geometría. Separar origen, forma y estado del hielo.",
        "rationales": [
          "Las palabras responden a preguntas distintas.",
          "La clasificación evita confundir origen y geometría.",
          "No expresan resistencia ensayada."
        ],
        "source": "e7-aai",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "«Coliflor» en una foto de Calbuco permite…",
        "options": [
          "Asegurar que es hielo de agua.",
          "Recomendar automáticamente un crampón.",
          "Registrar el término local y verificar qué material describe."
        ],
        "answer": 2,
        "explanation": "La identificación local exige evidencia adicional. Separar origen, forma y estado del hielo.",
        "rationales": [
          "El apodo no identifica el proceso.",
          "El equipo no se decide por una etiqueta.",
          "La identificación local exige evidencia adicional."
        ],
        "source": "e7-aai",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una zona parece compacta. ¿Cómo anotarla?",
        "options": [
          "Observación localizada, sin resistencia asignada.",
          "Anclaje certificado.",
          "Ruta aprobada."
        ],
        "answer": 0,
        "explanation": "Mantiene el alcance de lo observado. Separar origen, forma y estado del hielo.",
        "rationales": [
          "Mantiene el alcance de lo observado.",
          "No hubo ensayo ni evaluación de anclaje.",
          "Una observación no evalúa la ruta completa."
        ],
        "source": "e7-aai",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Separa correctamente los tres ejes de descripción.",
    "Conserva incertidumbre sobre zonas ocultas y origen no documentado.",
    "No asigna resistencia, dificultad ni equipo solo por color o nombre."
  ],
  "openAssessment": {
    "prompt": "Clasifica cuatro fotografías de una fuente identificada en tres columnas: origen propuesto, forma observada y estado. Usa «no determinable» cuando corresponda.",
    "rubric": [
      "Separa correctamente los tres ejes de descripción.",
      "Conserva incertidumbre sobre zonas ocultas y origen no documentado.",
      "No asigna resistencia, dificultad ni equipo solo por color o nombre."
    ],
    "source": "e7-aai",
    "difficulty": "integración"
  },
  "diagrams": [
    "e7-describir"
  ]
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. El estudio y el quiz no acreditan una maniobra ni capacidad de guiado.**

## Conceptos clave y propósito

Hielo de agua, hielo glaciar, nieve transformada, escarcha o cencellada; textura, continuidad y vínculo con el soporte.

## Teoría y toma de decisiones

Una clasificación útil tiene varios ejes. El origen describe cómo se formó el material; la forma describe su geometría; el estado describe características observables en un momento. «Glaciar», «columna» y «fracturado» responden a preguntas diferentes. Reunirlos en una sola escala de bueno a malo oculta información importante.

El American Alpine Institute compara contextos de escalada en hielo de agua, glaciar y nieve transformada. La terminología de campo puede variar entre regiones y escuelas. Antes de adoptar una palabra registra qué describe la fuente y qué observas realmente. Una etiqueta coloquial no reemplaza propiedades documentadas ni entrenamiento para interpretarlas. [Fuente de contraste](#fuente-e7-aai).

El color, los huecos visibles, las fracturas, el agua y la continuidad pueden registrarse como observaciones. Ninguno, aislado, proporciona una resistencia numérica del lugar. «Compacto» debe tratarse como descripción limitada, no como una certificación de anclaje. Lo visible tampoco revela toda la conexión entre hielo y roca.

En Los Lagos se usa a veces «coliflor» para formas de nieve o hielo adherido. Esta academia no identifica el proceso de una formación concreta del Calbuco a partir de ese nombre. Cencellada, nieve endurecida y hielo de agua no deben intercambiarse sin evidencia meteorológica y observación competente. Ese caso local queda expresamente pendiente de verificación.

Organiza una ficha con origen propuesto, forma, observaciones, evidencia faltante y consecuencias para el objetivo. Evita convertir una descripción en recomendación de equipo o ruta. Dos superficies que reciben el mismo nombre pueden exigir decisiones distintas.

El Atlas de la OMM diferencia escarcha por deposición de vapor y cencellada por congelación de gotas subfundidas. Es una distinción de proceso físico, no una clasificación de resistencia para escalar. [Definiciones documentales](#fuente-e7-wmo-deposits).

## Procedimiento: función, comprobaciones y límites

**PROCEDIMIENTO — marco de análisis previo al taller.** Objetivo: Separar origen, forma y estado del hielo. Se utiliza para preparar el aprendizaje y detectar vacíos antes de una tarea real. Identifica la función, los componentes, la información que falta y las consecuencias de un error. Contrasta la versión de la fuente con el modelo de equipo y el método del instructor. No hay una configuración universal derivada de esta página.

Las comprobaciones relevantes se desarrollan en la teoría, el equipo y la rúbrica de esta unidad. Si el uso previsto o la protección del taller no están claros, la práctica no se inicia. Las variantes de una fuente se conservan dentro de su contexto; no se mezclan pasos de métodos distintos por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario ficticio para análisis:** Dos fotografías llevan la etiqueta «hielo bueno»: una muestra una lámina sobre roca y otra una columna. Solo conoces la fecha de una. Explica por qué el adjetivo no permite comparar su estabilidad ni elegir un anclaje.

Antes de responder, enumera los hechos dados y los datos que has supuesto. Propón una decisión provisional y una condición que te haría revisarla. El caso, los ejercicios y las rúbricas son propuestas pedagógicas originales de la academia, pendientes de revisión docente; no son un protocolo de un organismo citado.

## Errores frecuentes y puntos críticos de seguridad

Equiparar hielo azul a seguro; confundir cencellada con hielo compacto; atribuir un origen geológico o meteorológico por un apodo; deducir equipo suficiente a partir del nombre del volcán.

No uses la ausencia de incidentes como prueba de seguridad. Las tareas con carga, herramientas o exposición necesitan control presencial competente. Ninguna respuesta escrita autoriza a escalar, montar un anclaje ni asistir a un pasajero.

## Material y equipo relacionado

Fichas de observación, fotografías con escala conocida y bibliografía. La elección de crampones, piolets o tornillos exige revisar función y contexto, además de la etiqueta del material.

[Consultar inventario](../../equipo/). Registra documento y revisión, sin inventar inspecciones realizadas. Tener material no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con tus palabras: Separar origen, forma y estado del hielo.
- ¿Qué observación del caso apoya tu decisión y qué dato sigue faltando?
- ¿Qué error de esta unidad podrías reconocer documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Clasifica cuatro fotografías de una fuente identificada en tres columnas: origen propuesto, forma observada y estado. Usa «no determinable» cuando corresponda.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** El instructor revisa descripciones y selecciona muestras o imágenes. Una posterior observación de terreno necesita ubicación y protección definidas por él; no se autoriza acceso por haber completado la clasificación.

## Evidencia requerida y criterios de competencia

- Separa correctamente los tres ejes de descripción.
- Conserva incertidumbre sobre zonas ocultas y origen no documentado.
- No asigna resistencia, dificultad ni equipo solo por color o nombre.

**COMPETENCIA:** estos criterios orientan la revisión. Cuando implican ejecución, el instructor debe observarla en un contexto definido, registrar resultado y lo que no se evaluó. No hay umbral automático de repeticiones, confianza o aciertos. La plataforma conserva una declaración personal y no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s7-tipos-hielo). Registra solo tareas realmente realizadas: fecha, lugar, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Mantén separados resultado observado, confianza y evaluación. No incluyas datos médicos ni datos privados de terceros.

## Relaciones con otros módulos

[Ruta invernal](../../invierno/), [formación glaciar](../../glaciar/), [encordamiento según contexto](../encordamiento-contexto/) y [anclajes y reuniones](../anclajes-reuniones/) aportan prerrequisitos. La aplicación alpina y el guiado requieren su propia formación y evaluación. [Volver a la secuencia de hielo](../../hielo/).
