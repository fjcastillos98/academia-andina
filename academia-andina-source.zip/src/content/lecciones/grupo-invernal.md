---
{
  "title": "Guiado invernal: ritmo, comunicación y retirada",
  "description": "Diseñar un briefing que permita comprobar comprensión.",
  "module": "M19",
  "code": "E5-25",
  "order": 524,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-22",
  "skills": [
    "s5-grupo-invernal"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Diseñar un briefing que permita comprobar comprensión.",
    "Reconocer deterioro del funcionamiento del grupo antes de agotar opciones.",
    "Justificar una retirada que incluya a pasajeros inexpertos."
  ],
  "prerequisites": [
    "s5-matriz-riesgo-invernal"
  ],
  "sources": [
    "e5-decision",
    "e5-daily",
    "e5-senapred-invierno"
  ],
  "pending": [
    "Revisión del plan y rúbrica por instructor; fuentes territoriales y condiciones de cualquier salida real pendientes de verificación."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Nadie pregunta durante el briefing. ¿Qué concluyes?",
        "options": [
          "Todos comprendieron.",
          "Hay que comprobar comprensión con una situación concreta.",
          "Solo importa la persona con experiencia."
        ],
        "answer": 1,
        "explanation": "El silencio no muestra comprensión.",
        "rationales": [
          "Confunde ausencia de preguntas con aprendizaje.",
          "Permite observar comprensión.",
          "Excluye a quienes necesitan apoyo."
        ],
        "source": "e5-daily",
        "difficulty": "integración",
        "kind": "decisiones"
      },
      {
        "prompt": "El transporte obliga a bajar rápido. ¿Qué cambia?",
        "options": [
          "Desaparecen límites técnicos.",
          "Puede omitirse el control del grupo.",
          "Debe revisarse el plan y comunicar el retraso."
        ],
        "answer": 2,
        "explanation": "La presión logística no reduce exposición.",
        "rationales": [
          "No cambia las capacidades.",
          "Omite información relevante.",
          "Aborda la causa sin acelerar a ciegas."
        ],
        "source": "e5-decision",
        "difficulty": "integración",
        "kind": "decisiones"
      },
      {
        "prompt": "Un pasajero pierde destreza y coherencia. ¿Qué procede?",
        "options": [
          "Reevaluar de inmediato y activar apoyo según formación y situación.",
          "Esperar hasta la cumbre.",
          "Guardar un diagnóstico en el diario."
        ],
        "answer": 0,
        "explanation": "Son cambios relevantes para protección y atención.",
        "rationales": [
          "Prioriza evaluación y recursos.",
          "Retrasa una respuesta necesaria.",
          "El diario no es una ficha clínica."
        ],
        "source": "e5-daily",
        "difficulty": "integración",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Solicita y confirma información del pasajero.",
    "Explica límites y alternativas sin presión de cumbre.",
    "Comprueba si la retirada propuesta es ejecutable por todo el grupo."
  ],
  "openAssessment": {
    "prompt": "Diseña un briefing breve y una conversación de retirada. Explica cómo comprobarás comprensión y cómo evitarás que la presión comercial decida por el grupo.",
    "rubric": [
      "Solicita y confirma información del pasajero.",
      "Explica límites y alternativas sin presión de cumbre.",
      "Comprueba si la retirada propuesta es ejecutable por todo el grupo."
    ],
    "source": "e5-decision",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Comprobar comprensión exige que otra persona explique el acuerdo. Un cambio de capacidad respecto del inicio merece reevaluación, aunque no haya un diagnóstico.

## Teoría y toma de decisiones

En invierno, gestionar el grupo significa sostener capacidad de observar, comunicar y decidir mientras cambian condiciones y recursos. El guía no debe inferir comprensión a partir del silencio. Una persona puede aceptar una propuesta por vergüenza, autoridad o deseo de no retrasar al resto. Avalanche Canada enfatiza comunicación abierta desde la planificación y participación de miembros con distinta experiencia [fuente](#fuente-e5-daily). Esto no establece una proporción legal de pasajeros por guía; esa cuestión requiere una revisión normativa independiente.

Un briefing útil describe el objetivo condicionado, el terreno que se evitará, quién toma decisiones, las señales acordadas, el ritmo previsto y cómo comunicar frío, dificultad o inseguridad. En vez de preguntar únicamente «¿entendido?», plantea una situación: «Si pierdes contacto visual, ¿qué acuerdo revisamos antes de movernos?». La respuesta revela comprensión y permite corregir ambigüedades antes de salir. Las reglas concretas de desplazamiento, separación y reagrupamiento dependen del terreno, las condiciones y la instrucción técnica; no se fija aquí una distancia universal.

La gestión del ritmo debe considerar al grupo completo. Un promedio puede ocultar a alguien que ya no puede manipular sus guantes o fijaciones. Observa cambios respecto del funcionamiento previo: tropiezos, lentitud en tareas simples, dificultad para mantener comunicación, apatía o insistencia en continuar sin poder justificarlo. Son señales que requieren detener la evaluación del objetivo y comprobar la situación; no se convierten automáticamente en un diagnóstico. Las señales médicas y la respuesta inicial se estudian en la unidad de frío y en formación WFR.

Frío, fatiga, alimentación, hidratación y ansiedad pueden interactuar. En el ejercicio de planificación se prevén oportunidades de pausa y acceso al equipo, de forma que beber, comer o añadir protección no dependan de alcanzar la cumbre. No se prescribe una ingesta universal ni se almacena información médica. Un pasajero inexperto puede necesitar ayuda para explicar qué le ocurre; utiliza preguntas concretas y comprueba la tarea, evitando ridiculizar o minimizar su preocupación. No asignes una técnica nueva como solución improvisada a un retraso.

En Filo Austral, la promesa comercial debe permitir cambiar el objetivo. Que el transporte tenga una hora, que alguien haya viajado mucho o que el grupo quiera una foto no disminuye exposición. Antes de la salida se ensaya cómo comunicar una retirada: observación concreta, consecuencia posible, límite del plan y alternativa. «Nos retiramos porque ya no podemos sostener las condiciones acordadas» debe poder acompañarse de evidencia, no de una puntuación opaca.

Cerrar una decisión incluye comprobar que el grupo puede ejecutarla. Retirar no significa acelerar sin control ni dividir al grupo por presión. Revisa orientación, condiciones de descenso, recursos de apoyo y comunicaciones. En debriefing separa decisiones buenas con resultado adverso de decisiones pobres que tuvieron suerte. El aprendizaje debe conservar también desacuerdos y señales ignoradas, sin identificar pasajeros. La práctica de liderazgo se evalúa en escenarios supervisados con observación de conducta, no solo mediante un texto persuasivo.

## Qué observo, qué significa y qué no puedo concluir

Esta unidad no fija ratios legales, separación estándar, ritmo obligatorio ni tratamiento médico. Requiere habilidades de comunicación y atención presencial.

## Caso práctico y aplicación al guiado

Un pasajero calla mientras pierde el ritmo; otro propone separarlo con la persona más rápida para recuperar el horario. Formula preguntas y alternativas sin asumir que dividir mejora la seguridad.

## Errores frecuentes y señales de alerta

Interpretar silencio como consentimiento informado; culpar a quien informa fatiga; esperar signos graves para discutir retirada; mantener un horario por promesa comercial.

## Autoevaluación y respuesta razonada

Diseña un briefing breve y una conversación de retirada. Explica cómo comprobarás comprensión y cómo evitarás que la presión comercial decida por el grupo.

## Ejercicios y práctica supervisada

Role-play de briefing y retirada con tres roles: guía, pasajero con incertidumbre y observador. El observador registra preguntas, confirmaciones y señales ignoradas; no inventa una evaluación de competencia real.

## Evidencia requerida

- Solicita y confirma información del pasajero.
- Explica límites y alternativas sin presión de cumbre.
- Comprueba si la retirada propuesta es ejecutable por todo el grupo.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-grupo-invernal).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
