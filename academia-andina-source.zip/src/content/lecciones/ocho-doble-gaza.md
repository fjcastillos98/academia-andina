---
{
  "title": "Ocho doble",
  "description": "Identificar nombre, variante y función de ocho doble.",
  "module": "M07",
  "code": "E43-05",
  "order": 304,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U43-03",
  "skills": [
    "s43-ocho-doble-gaza"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Identificar nombre, variante y función de ocho doble.",
    "Distinguir límites de uso, errores y compatibilidades pendientes.",
    "Preparar una revisión presencial con evidencia."
  ],
  "prerequisites": [
    "s43-ocho-seno"
  ],
  "sources": [
    "petzl-nudos-435"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "familias-ocho"
  ],
  "preparation": [
    "Función: analizar dos gazas en una configuración de conexión.",
    "Error: confundir cantidad de gazas con redundancia.",
    "Compatibilidad: revisar soporte, cuerda y conexiones."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "petzl-nudos-435",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "En el estudio de ocho doble, ¿qué afirmación es defendible?",
        "options": [
          "Dos gazas garantizan independencia.",
          "Función: analizar dos gazas en una configuración de conexión.",
          "El nombre es inequívoco en toda escuela."
        ],
        "answer": 1,
        "explanation": "La función debe identificarse dentro del alcance descrito; no implica aptitud del conjunto.",
        "rationales": [
          "La afirmación omite contexto o atribuye una función no demostrada.",
          "Función: analizar dos gazas en una configuración de conexión. Se mantiene su alcance específico.",
          "No permite evaluar el sistema completo ni sus límites."
        ],
        "source": "petzl-nudos-435",
        "difficulty": "básica",
        "kind": "conocimiento"
      },
      {
        "prompt": "El nudo parece correcto, pero no se ve su conexión. ¿Qué concluyes?",
        "options": [
          "El sistema ya está revisado.",
          "La conexión es necesariamente incorrecta.",
          "Falta información; no aprobar el conjunto por una sola parte."
        ],
        "answer": 2,
        "explanation": "La revisión debe distinguir lo observado de lo que aún no se puede comprobar.",
        "rationales": [
          "Extrapola una parte al conjunto.",
          "La falta de imagen no prueba un defecto.",
          "Conserva incertidumbre y pide una comprobación concreta."
        ],
        "source": "petzl-nudos-435",
        "difficulty": "intermedia",
        "kind": "errores"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

Nombre: en este curso «ocho doble de dos gazas» se refiere a la variante Bunny de la fuente; otras escuelas llaman ocho doble al ocho por seno. Característica: dos gazas no convierten un nudo en un sistema automáticamente ecualizado.

## Teoría: función, aplicación y límites

- Función: analizar dos gazas en una configuración de conexión.

- Uso: reconocer la variante exacta antes de discutir un sistema.

- No uso: no decidir que dos gazas equivalen a dos anclajes independientes.

- Ventaja didáctica: visualizar dos ramales.

- Limitación: comparten componentes y origen.

- Característica: dos gazas no convierten un nudo en un sistema automáticamente ecualizado.

La pregunta de estudio no termina al reconocer el nombre. Explica qué se pretende conectar, cuál es el recorrido de la carga y qué información falta para evaluar el conjunto. Distingue la observación directa de una suposición: no ver un defecto en una imagen no equivale a revisar todas las caras. En una sesión de guiado, pide al alumno describir la función con sus palabras antes de discutir rapidez o destreza.

[Referencia técnica: petzl-nudos-435](#fuente-petzl-nudos-435). Consulta los diagramas del fabricante para la configuración exacta; las láminas de esta academia analizan funciones y errores, no sustituyen esos diagramas ni el taller.

## Caso práctico y aplicación al guiado

Ejercicio: dos conexiones al mismo bloque. ¿Son independientes? No se concluye por la apariencia; falta evaluar el soporte común.

- Montaña: estudio de alternativas de conexión.

- Guiado: acordar vocabulario y diagrama con el instructor.

## Errores frecuentes y señales de alerta

Error: confundir cantidad de gazas con redundancia.

## Inspección y compatibilidades

Inspección: correspondencia exacta con la variante y carga previstas.

Compatibilidad: revisar soporte, cuerda y conexiones.

Se debe detener la propuesta si no se identifica la variante o el lugar de conexión. La revisión de extremos se hace según referencia aplicable; no se añade una cifra universal. La condición del material también necesita documentación e inspección, incluso cuando el recorrido del nudo parece correcto.

## Autoevaluación y respuestas explicadas

¿Reconocer una forma demuestra ejecución en terreno? **No: faltan selección, conexión, inspección, comunicación y desempeño bajo las condiciones evaluadas.**

¿Qué debes registrar si dos personas no coinciden en la variante? **Los nombres y diagramas utilizados, la fuente de cada uno y la discrepancia; resolverla con instructor antes de una aplicación.**

## Ejercicios y práctica presencial

Práctica: confección y análisis solo en taller supervisado.

Prepara una ficha de comparación entre la función prevista y una función que este estudio no autoriza. Explica un error posible sin introducirlo en material en uso. En taller, el instructor observa identificación, confección, vestido, ajuste y revisión cruzada con material didáctico y condiciones controladas. No se carga una persona ni se improvisa una maniobra durante el estudio individual.

## Evidencia requerida

Nombre y variante, fuente, combinación de material, observación del instructor, error detectado, corrección y nueva práctica. La evaluación presencial debe declarar contexto y límites; un cuestionario solo registra comprensión.

## Relaciones con otras habilidades

Este tema precede a revisión de nudos y encordamiento. No se utiliza el resultado del quiz como habilitación para asegurar, descender o rescatar.
