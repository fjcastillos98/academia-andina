---
{
  "title": "Guiado de grupos, liderazgo y comunicación",
  "description": "Preparar briefing y comprobación de comprensión.",
  "module": "M19",
  "code": "E4-09",
  "order": 209,
  "minutes": 45,
  "level": "Intermedio",
  "status": "development",
  "reviewDate": "2026-10-22",
  "unit": "U4-09",
  "skills": [
    "s4-grupo-liderazgo"
  ],
  "critical": true,
  "objectives": [
    "Preparar briefing y comprobación de comprensión.",
    "Organizar comunicación, ritmo y reuniones sin ratios universales.",
    "Responder a miedo, fatiga y conflicto sin presión ni diagnóstico improvisado."
  ],
  "prerequisites": [
    "Completar estudio de Fundamentales; la práctica previa debe revisarse presencialmente.",
    "Estudiar Nubes, ondas de montaña y observación."
  ],
  "sources": [
    "nps-grupo",
    "sernatur-2026"
  ],
  "pending": [
    "Revisión pedagógica y evaluación situada por instructor competente.",
    "Condiciones, accesos, permisos y compatibilidad del equipo requieren verificación para cada actividad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una persona llega cuando termina cada pausa. ¿Qué revisar?",
        "options": [
          "Organización de pausas, ritmo y plan del grupo.",
          "Solo su motivación.",
          "Nada si nadie se queja."
        ],
        "answer": 0,
        "explanation": "La organización puede impedir recuperación y comunicación de necesidades."
      },
      {
        "prompt": "Un cliente exige seguir. ¿Eso modifica el peligro físico?",
        "options": [
          "Sí.",
          "Solo si pagó más.",
          "No; es una presión que debe gestionarse."
        ],
        "answer": 2,
        "explanation": "Escuchar y explicar alternativas no implica convertir la seguridad en votación."
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

**TEORÍA.** Guiar implica mantener una representación compartida de objetivo, límites y cambios. **Briefing** prepara una actividad; **comunicación de circuito cerrado** pide confirmación y repetición del mensaje esencial; **debriefing** revisa hechos y decisiones después. Estas son herramientas didácticas de coordinación, no sustitutos de competencia técnica.

## Teoría: el grupo como sistema

El NPS aconseja permanecer juntos durante la actividad y reconoce el riesgo de separación [Referencia: nps-grupo](#fuente-nps-grupo). En la planificación de Filo Austral, “juntos” debe traducirse a cómo se mantiene control y comunicación en cada tramo. No fijamos aquí una distancia ni una posición del guía universal: visibilidad, terreno, tamaño y capacidades modifican la organización.

Explica quién conduce, quién observa la parte posterior cuando corresponda, dónde se reúne el grupo y cómo se confirma que nadie falta. Una persona de cierre no recibe automáticamente funciones de guía por ocupar ese lugar. Si el terreno requiere una organización para la que faltan personas competentes, el problema se resuelve cambiando la actividad, no renombrando pasajeros como asistentes.

La distribución debe permitir reconocer cambios y comunicarlos. Una fila compacta puede tener limitaciones en cierto terreno y una separación excesiva puede impedir control. La distancia operativa se aprende en contexto; los requisitos de una actividad comercial se verifican en el instrumento pertinente, sin inferirlos de este curso [Referencia: sernatur-2026](#fuente-sernatur-2026).

## Briefing útil

Presenta objetivo y alternativas, recorrido por etapas, duración estimada, recursos, señales acordadas, comportamiento en puntos de decisión, cómo comunicar dificultades y criterios de retirada. Evita una charla que solo enumera prohibiciones. Pide a dos personas que expliquen con sus palabras qué harán si pierden contacto o necesitan detenerse.

El lenguaje debe ser comprensible. “Nos vemos arriba” no define lugar, condición ni control del grupo. “Nadie cambia de tramo hasta que confirmemos el recuento en el punto acordado” es más observable, pero ese punto aún debe ser apropiado al terreno. El ejemplo enseña precisión de comunicación, no una regla de conducción universal.

## Diferencias de capacidad, miedo y conflicto

La fatiga observada puede manifestarse como cambios de ritmo o atención, pero el guía no debe atribuir una causa clínica sin formación. Pregunta, observa y revisa. El miedo no se resuelve con “confía en mí”: explica opciones reales y escucha qué situación preocupa. No prometas que no ocurrirá nada.

Ante un conflicto, separa hechos, intereses y decisión. Un pasajero puede querer continuar por dinero o expectativas; esa presión no cambia el terreno. Comunica qué ha cambiado, qué opciones se evaluaron y cuál es el límite del servicio. Si se modifica o termina una actividad, define cómo se mantiene acompañamiento y control: retirar a un cliente no significa dejarlo solo.

En situaciones de síntomas o lesión, activa el marco de primeros auxilios y emergencia correspondiente a la formación real del equipo. Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica. Aquí no se enseñan tratamientos ni maniobras de evacuación.

## Caso práctico: pasajeros con ritmos distintos

Escenario ficticio de Filo Austral en Los Lagos: una persona llega tarde a cada pausa, otra se impacienta y una tercera oculta miedo a retrasar al grupo. El guía anuncia una pausa pero sale de nuevo antes de que todos puedan recuperarse.

Analiza quién tiene información y quién no puede hablar. Respuesta orientativa: revisar organización y objetivo, escuchar sin exposición pública innecesaria y comunicar una alternativa. No “solucionar” el problema mandando por delante a los rápidos sin evaluar control y competencia disponible.

## Errores frecuentes y señales de alerta

Explicar sin comprobar comprensión; delegar sin verificar capacidad; elogiar aguantar molestias; tratar preocupación como desobediencia; prometer cumbre; discutir la decisión técnica como votación. Señales: mensajes que no llegan, recuentos inconsistentes, cambios de comportamiento y repetición de las mismas dudas.

## Autoevaluación y respuestas explicadas

1. ¿Qué diferencia informar y comprobar comprensión? **La segunda exige una respuesta que muestre qué entendió el receptor y permite corregir ambigüedades.**
2. ¿Puede una buena comunicación compensar falta de capacidad técnica? **No. Ayuda a coordinar, pero no crea una habilidad que no ha sido entrenada y evaluada.**

## Ejercicios y práctica presencial

Simula un briefing de cinco minutos y pide a los participantes reconstruir el plan. Representa un cliente con miedo y otro que exige seguir; practica una respuesta respetuosa con alternativas. En una caminata formativa supervisada, observa comunicación y recuentos sin introducir riesgos deliberados.

## Evidencia requerida

Guion, preguntas de comprobación, observaciones del supervisor y correcciones. La autonomía observada debe limitarse al tipo de grupo, actividad y condiciones evaluados.

## Relaciones con otras habilidades

Esta unidad se integra en la ruta estival. Consulta la ficha de habilidad y sus prerrequisitos en el programa. Registra práctica y evaluación por separado: estudiar y responder correctamente no acredita ejecución. Los ejercicios son propuestas didácticas originales; los casos no son rutas operativas.
