---
{
  "title": "Ambientes altoandinos y volcánicos: reconocer límites",
  "description": "Distingue sustrato volcánico de formación vegetal.",
  "module": "M15",
  "code": "E11-03",
  "order": 1103,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U11-03",
  "skills": [
    "s11-ambientes-altoandinos"
  ],
  "critical": false,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Distingue sustrato volcánico de formación vegetal.",
    "Explica por qué estepa no equivale a toda ladera abierta."
  ],
  "prerequisites": [
    "s11-bosque-templado"
  ],
  "sources": [
    "e11-regional"
  ],
  "pending": [
    "Revisión por especialista en ecología e instructor territorial pendiente. Los ejercicios no autorizan acceso, colecta o manejo de fauna.",
    "Categorías legales vigentes, protocolos de encuentro específicos y claves taxonómicas completas: requieren verificación.",
    "Casos, rúbricas y propuestas de práctica originales; no constituyen un protocolo oficial ni una certificación."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Volcánico y altoandino…",
        "options": [
          "Son sinónimos exactos.",
          "Describen dimensiones diferentes del lugar.",
          "Garantizan ausencia de bosque."
        ],
        "answer": 1,
        "explanation": "Geología y ambiente no son la misma clasificación.",
        "rationales": [
          "Uno no sustituye al otro.",
          "Geología y ambiente no son la misma clasificación.",
          "No se deduce de ambos términos."
        ],
        "source": "e11-regional",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Plantas en una ladera prueban…",
        "options": [
          "Que no hay peligro volcánico.",
          "La fecha exacta de una erupción.",
          "Su presencia observada, no esas conclusiones."
        ],
        "answer": 2,
        "explanation": "Conserva el alcance del dato.",
        "rationales": [
          "La seguridad necesita información específica.",
          "La edad no se deduce así.",
          "Conserva el alcance del dato."
        ],
        "source": "e11-regional",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Para clasificar una formación debes…",
        "options": [
          "Buscar una fuente aplicable y reconocer incertidumbre.",
          "Usar solo una cota universal.",
          "Asignar el nombre más conocido."
        ],
        "answer": 0,
        "explanation": "La clasificación necesita evidencia.",
        "rationales": [
          "La clasificación necesita evidencia.",
          "La exposición e historia pueden variar.",
          "El nombre no sustituye la comprobación."
        ],
        "source": "e11-regional",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue sustrato volcánico de formación vegetal.",
    "Explica por qué estepa no equivale a toda ladera abierta.",
    "Mantiene independiente la decisión de seguridad volcánica."
  ],
  "openAssessment": {
    "prompt": "Compara dos imágenes ficticias de laderas: separa geología, vegetación y seguridad en tres columnas, con preguntas pendientes.",
    "rubric": [
      "Distingue sustrato volcánico de formación vegetal.",
      "Explica por qué estepa no equivale a toda ladera abierta.",
      "Mantiene independiente la decisión de seguridad volcánica."
    ],
    "source": "e11-regional",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ECOLÓGICA PENDIENTE.** Observación responsable para estudio personal. No acredita identificación taxonómica, competencia profesional ni autorización de acceso. No guardes datos médicos ni localizaciones precisas de especies sensibles.

## Conceptos clave y propósito

Gradiente altitudinal, exposición, cobertura discontinua, sustrato volcánico, perturbación y sucesión. Estepa altoandina es una categoría de vegetación; volcánico es una descripción del origen o proceso geológico.

## Teoría y toma de decisiones

El diagnóstico MMA/PNUD de Los Lagos (2015) diferencia matorral bajo templado andino y herbazal templado andino. No permite sustituir esos nombres por “estepa” ni llamar así a cualquier ladera abierta. Una superficie de ceniza, roca, nieve o vegetación baja necesita descripción propia y, para una clasificación formal, una fuente cartográfica o estudio aplicable.

En ambientes de altura, observa continuidad de la cobertura, tamaño de las plantas y relación con relieve y exposición. No asignes una adaptación a una especie que no identificaste. La descripción puede quedar en “vegetación baja y discontinua en un sector expuesto”; es información útil si conserva su contexto. El límite del bosque no es una línea universal aplicable a todos los volcanes de Los Lagos.

La sucesión ecológica ayuda a pensar cambios tras una perturbación, pero no constituye un reloj. Sin fecha del evento, sustrato y seguimiento no se puede datar una comunidad por la altura de sus plantas. La seguridad volcánica se estudia aparte: vegetación presente no prueba ausencia de peligros. Un ejercicio de ecología nunca autoriza entrar en una zona restringida o modificar el plan para alcanzar una muestra.

Referencias de esta unidad: [Fuente 1](#fuente-e11-regional). Los casos y las aplicaciones pedagógicas que siguen son elaboración original; no se atribuyen como protocolos de las fuentes.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — observación y decisión:** Describe cobertura y sustrato por separado. Identifica qué clasificación respalda la fuente y qué queda pendiente. Compara escenarios fotográficos; en terreno mantén el itinerario autorizado. Variante: sucesión tras perturbación documentada frente a causa desconocida; no confundirlas.

No manipules fauna, no recolectes material y no salgas del itinerario autorizado para completar el ejercicio. La conducción real y las maniobras técnicas requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una ladera volcánica tiene plantas entre rocas. Alguien propone usar esa presencia para afirmar que el lugar es seguro y que la erupción fue hace décadas. Explica ambas limitaciones.

## Errores frecuentes y puntos críticos de seguridad

Confundir todo ambiente abierto con estepa; usar una cota fija para toda la región; interpretar vegetación como semáforo volcánico. Evita pisoteo fuera de sendero para identificar plantas pequeñas.

## Material y equipo relacionado

Mapa y registros de fuente; prismáticos y cámara. Equipo de navegación y comunicación según el plan de salida, no según una ficha ecológica.

[Revisar inventario](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica cómo comprobarías este criterio: Distingue sustrato volcánico de formación vegetal.
- Explica cómo comprobarías este criterio: Explica por qué estepa no equivale a toda ladera abierta.
- Explica cómo comprobarías este criterio: Mantiene independiente la decisión de seguridad volcánica.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Compara dos imágenes ficticias de laderas: separa geología, vegetación y seguridad en tres columnas, con preguntas pendientes.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Interpretación de gradiente desde puntos habilitados con especialista, sin acceso a sectores restringidos ni extracción.

## Evidencia requerida y criterios de competencia

- Distingue sustrato volcánico de formación vegetal.
- Explica por qué estepa no equivale a toda ladera abierta.
- Mantiene independiente la decisión de seguridad volcánica.

**COMPETENCIA:** requiere observación y revisión humana en contexto. Una lectura, registro o quiz no certifica guiado, identificación experta ni maniobras. La plataforma no verifica credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s11-ambientes-altoandinos) y [cuaderno de observación](../../ecologia/#observaciones). Separa ejercicio ficticio, observación real y práctica evaluada. Registra errores, correcciones, supervisor y evidencia sin inventar resultados. Mantén áreas generales; el texto libre no filtra automáticamente ubicaciones sensibles.

## Relaciones con otros módulos

[Ecología](../../ecologia/) · [Fichas de especies](../../especies/) · [Territorio](../../territorio/) · [Planificación](../../planificacion/) · [Programa](../../programa/). La interpretación ambiental se relaciona con geología, cartografía, gestión de grupos y patrimonio, sin sustituir su formación específica.
