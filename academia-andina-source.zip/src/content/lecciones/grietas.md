---
{
  "title": "Grietas y puentes de nieve",
  "description": "Relacionar fracturas con deformación diferencial.",
  "module": "M04",
  "code": "E6-03",
  "order": 603,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U6-03",
  "skills": [
    "s6-grietas"
  ],
  "critical": true,
  "reviewDate": "2026-10-23",
  "objectives": [
    "Relacionar fracturas con deformación diferencial.",
    "Explicar por qué no ver una grieta no demuestra ausencia."
  ],
  "prerequisites": [
    "s6-terreno-glaciar"
  ],
  "sources": [
    "e6-nps-crevasses",
    "e6-acc-team"
  ],
  "pending": [
    "Toda valoración de puente requiere formación y contexto presencial; no practicar caminando hacia grietas para observar. PENDIENTE DE VERIFICACIÓN.",
    "Revisión presencial por instructor competente pendiente. No se ha realizado ni aprobado ninguna práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "No se ve una grieta. ¿Qué conclusión es correcta?",
        "options": [
          "No existe.",
          "Está cerrada definitivamente.",
          "La observación no descarta una grieta cubierta."
        ],
        "answer": 2,
        "explanation": "La nieve puede ocultar fracturas.",
        "rationales": [
          "No se justifica: La nieve puede ocultar fracturas.",
          "No se justifica: La nieve puede ocultar fracturas.",
          "Correcta: La nieve puede ocultar fracturas."
        ],
        "source": "e6-nps-crevasses",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Huellas antiguas sobre un puente demuestran…",
        "options": [
          "Capacidad actual de soporte.",
          "Solo evidencia limitada de un paso o marca anterior.",
          "Que ya no necesita evaluación."
        ],
        "answer": 1,
        "explanation": "No informan todas las condiciones presentes.",
        "rationales": [
          "No se justifica: No informan todas las condiciones presentes.",
          "Correcta: No informan todas las condiciones presentes.",
          "No se justifica: No informan todas las condiciones presentes."
        ],
        "source": "e6-nps-crevasses",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "El borde puede…",
        "options": [
          "Afectar también al rescate posterior.",
          "Ignorarse si la cuerda retuvo.",
          "Validarse por acercarse sin protección."
        ],
        "answer": 0,
        "explanation": "La geometría y la interacción cuerda/nieve forman parte del problema.",
        "rationales": [
          "Correcta: La geometría y la interacción cuerda/nieve forman parte del problema.",
          "No se justifica: La geometría y la interacción cuerda/nieve forman parte del problema.",
          "No se justifica: La geometría y la interacción cuerda/nieve forman parte del problema."
        ],
        "source": "e6-nps-crevasses",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "No equipara continuidad visual con soporte.",
    "No usa huellas como certificado.",
    "Separa ausencia de evidencia y evidencia de ausencia."
  ],
  "openAssessment": {
    "prompt": "Clasifica tres tarjetas: grieta visible, superficie continua y huellas antiguas. Escribe para cada una qué sabes y qué no puedes concluir.",
    "rubric": [
      "No equipara continuidad visual con soporte.",
      "No usa huellas como certificado.",
      "Separa ausencia de evidencia y evidencia de ausencia."
    ],
    "source": "e6-nps-crevasses",
    "difficulty": "integración"
  },
  "diagrams": [
    "e6-evidencia"
  ]
}
---

**CONTENIDO TEÓRICO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Fractura, Grieta visible y cubierta, Labio y puente. Observar una línea, depresión o cambio de forma es una pista que requiere interpretación; no es medición suficiente de resistencia.

## Teoría y toma de decisiones

Las grietas son fracturas asociadas a tensiones y deformación del hielo. Los cambios del flujo y del relieve ayudan a explicar dónde pueden aparecer, pero no permiten dibujar desde una foto todas sus posiciones. El NPS describe que la nieve puede ocultarlas. [Origen y ocultamiento](#fuente-e6-nps-crevasses). Aprender los términos grieta, labio y puente permite describir un problema sin confundir una superficie continua con soporte continuo.

Un puente de nieve puede cubrir una abertura; su apariencia no aporta por sí sola todas las variables necesarias para valorar su respuesta. Una depresión o línea es una pista, no una medida de resistencia. Del mismo modo, ausencia de una pista no elimina la fractura. La observación requiere contexto y formación. Esta lección no propone aproximarse a una grieta para medirla, sondearla o probarla caminando.

El labio también afecta a una eventual recuperación. La interacción entre cuerda, nieve y borde puede favorecer ciertas funciones de retención y al mismo tiempo dificultar el movimiento posterior. ACC analiza estos compromisos para equipos de dos. [Discusión técnica contextual](#fuente-e6-acc-team). El hecho de que una cuerda haya retenido algo no demuestra que el borde admita otra persona ni que el rescate sea sencillo.

Trabaja con tres tarjetas ficticias: abertura visible, superficie blanca continua y huellas antiguas. En cada una escribe un hecho verificable y dos conclusiones que no se justifican. Intercambia las tarjetas con otra persona y pide que subraye cualquier palabra que transforme incertidumbre en garantía. El objetivo no es acertar dónde está la grieta inventada: es reconocer cuándo la información disponible no alcanza para una decisión operativa.

## Procedimiento conceptual: objetivo, uso y límites

Relacionar fracturas con deformación diferencial. Esta unidad se utiliza para preparar el análisis y un taller, no para ejecutar una maniobra sin entrenamiento. La forma del terreno ayuda a formular hipótesis, pero no dibuja todas las fracturas ocultas.

Las variantes técnicas mantienen el ámbito de la fuente citada. Antes de cambiar una configuración se deben revisar sus funciones, comprobaciones y límites con instructor; no se combinan pasos de escuelas distintas por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario hipotético de aula.** Una fotografía sin escala muestra huellas sobre un puente supuesto. La fecha corresponde a otra semana. Explica por qué no permite asegurar capacidad de soporte ni escoger el punto de cruce.

## Errores frecuentes y puntos críticos

Usar huellas como certificado; confundir nieve dura superficial con soporte; acercarse sin protección para obtener una foto.

No se atribuye una garantía de seguridad al equipo, al quiz ni a una práctica en condiciones diferentes. Si falta un dato esencial para justificar el objetivo, declarar ese vacío es parte del aprendizaje.

## Material y equipo relacionado

Cuerda y material de protección/rescate del sistema planificado; instrumentos de orientación. Ninguna pieza por sí sola permite detectar todas las grietas.

[Inventario personal](../../equipo/): conserva referencia del manual y observaciones de inspección. El registro no declara aptitud de una pieza ni competencia de quien la porta.

## Autoevaluación y recuperación activa

- ¿Qué demuestra una huella y qué no?
- ¿Por qué la dificultad del borde importa después de detener una caída?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL de escritorio:** Clasifica tres tarjetas: grieta visible, superficie continua y huellas antiguas. Escribe para cada una qué sabes y qué no puedes concluir.

**PRÁCTICA SUPERVISADA:** el instructor adapta un taller con objetivos observables, protección y criterios de parada. No provocar caídas reales ni entrar a terreno expuesto para comprobar esta página. La evaluación presencial es independiente de la respuesta teórica.

## Evidencia requerida y criterios de competencia

- No equipara continuidad visual con soporte.
- No usa huellas como certificado.
- Separa ausencia de evidencia y evidencia de ausencia.

Estos criterios valoran razonamiento; para una competencia práctica, el instructor debe definir y observar la ejecución en un contexto explícito. No se preasigna una evaluación por estudiar.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s6-grietas). Registrar únicamente lo realizado: fecha, lugar, condiciones, objetivo, equipo, supervisor, resultado, errores, correcciones, evidencia, autonomía observada y próxima práctica. No guardar datos médicos ni información privada de pasajeros.

## Relaciones con etapas anteriores

[Glaciología introductoria](../glaciologia-intro/), [planificación invernal](../planificacion-invernal/), [encordamiento según contexto](../encordamiento-contexto/), [anclajes](../anclajes-reuniones/) y [ventaja mecánica](../ventaja-mecanica/). Estas dependencias orientan el estudio; no autorizan la aplicación técnica. [Ruta glaciar](../../glaciar/).
