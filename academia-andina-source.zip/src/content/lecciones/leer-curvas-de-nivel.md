---
{
  "title": "Leer el relieve: curvas de nivel",
  "description": "Comprende qué representa una curva y practica una diferencia de elevación en un ejemplo didáctico.",
  "module": "M14",
  "code": "NAV-01",
  "order": 3,
  "minutes": 12,
  "level": "Fundamentos",
  "status": "example",
  "reviewDate": "2026-10-21",
  "objectives": [
    "Explicar qué conecta una curva de nivel.",
    "Distinguir diferencia de elevación de distancia recorrida."
  ],
  "prerequisites": [
    "Lectura comprensiva; no se requiere ejecutar maniobras."
  ],
  "sources": [
    "usgs"
  ],
  "pending": [
    "Revisión pedagógica externa y ampliación del tema curricular.",
    "No incluye evaluación ni habilitación práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿Qué tienen en común los puntos de una curva de nivel?",
        "options": [
          "La misma distancia a la cumbre.",
          "La misma elevación respecto de una referencia.",
          "La misma temperatura."
        ],
        "answer": 1,
        "explanation": "La curva representa igual elevación. No describe temperatura ni distancia a un destino."
      },
      {
        "prompt": "Entre puntos de elevación 100 m y 140 m, ¿qué puedes calcular directamente?",
        "options": [
          "40 m de diferencia de elevación.",
          "40 m de distancia caminada.",
          "Un tiempo exacto de marcha."
        ],
        "answer": 0,
        "explanation": "140 − 100 = 40 m es una diferencia vertical; no determina longitud de recorrido ni tiempo."
      }
    ]
  }
}
---


## Conceptos
Un mapa topográfico representa la forma del terreno mediante curvas de nivel. Cada curva conecta puntos de igual elevación respecto de una superficie de referencia. La guía de símbolos del USGS explica esa relación entre curvas y relieve. [Fuente: USGS, Map Symbol Guide.]

En el ejemplo didáctico siguiente, las cifras son inventadas para practicar aritmética; no corresponden a una montaña ni a una ruta. Dos puntos a 100 y 140 metros tienen una diferencia de elevación de 40 metros. Esa resta no mide la distancia caminada ni el ascenso acumulado de un recorrido con subidas y bajadas.

| Punto del ejercicio | Elevación asignada |
| --- | --- |
| A | 100 m |
| B | 120 m |
| C | 140 m |

## Ejemplo
Si vas de A a C pasando por B en este ejercicio, la elevación final menos la inicial es 40 m. Si el recorrido real tuviera descensos intermedios, necesitarías información adicional para calcular todo el ascenso acumulado.

## Errores frecuentes
Leer una cifra de elevación como longitud del sendero; deducir un tiempo exacto usando solo una diferencia vertical; transferir símbolos de un mapa a otro sin revisar su leyenda.

## Límites
La fuente consultada es estadounidense y respalda el concepto general. No verifica cartografía ni accesos chilenos. Esta introducción no enseña navegación con niebla, elección de ruta ni uso de brújula. La lectura de un mapa no permite por sí sola evaluar las condiciones del terreno.

## Caso de estudio
Ejercicio ficticio: alguien dice «solo hay 40 metros entre A y C, llegaremos en un minuto». ¿Qué parte puede justificarse? La diferencia de elevación. La distancia y el tiempo carecen de datos suficientes.

## Recuperación activa
Explica qué une una curva de nivel y por qué diferencia de elevación y distancia recorrida no son equivalentes.

## Ejercicio
Dibuja en papel tres curvas conceptuales etiquetadas 100, 120 y 140 m. Escribe al lado: «Esquema didáctico sin escala; no sirve para navegar». Calcula la diferencia entre la primera y la última.

## Criterios de revisión
La explicación debe mencionar igual elevación y superficie de referencia. El cálculo debe ser 40 m y no interpretarse como longitud de ruta. Esta actividad de escritorio no evalúa orientación en terreno.

## Próximos pasos
Pendientes: escalas, equidistancia, coordenadas, datum y contraste mapa-terreno con supervisión. Anota las preguntas que necesitas resolver antes de trabajar con un mapa real.
