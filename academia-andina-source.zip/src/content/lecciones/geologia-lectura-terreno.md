---
{
  "title": "Geología de montaña: leer materiales y procesos",
  "description": "Separar observación de interpretación geológica.",
  "module": "M16",
  "code": "E45-27",
  "order": 326,
  "minutes": 35,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U45-03",
  "skills": [
    "s45-geologia-lectura-terreno"
  ],
  "critical": false,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Separar observación de interpretación geológica.",
    "Reconocer familias de rocas y procesos del relieve.",
    "Conectar incertidumbre geológica con evaluación de terreno."
  ],
  "prerequisites": [
    "s45-vulcanologia-territorial"
  ],
  "sources": [
    "lara-sarnoso",
    "mella-tronador",
    "uchile-casablanca"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente.",
    "PENDIENTE DE VERIFICACIÓN TERRITORIAL: accesos, límites administrativos, rutas y condiciones actuales."
  ],
  "diagrams": [
    "territorio-evidencia"
  ],
  "preparation": [
    "Distinguir hechos atribuidos, inferencias y datos pendientes.",
    "Explicar por qué la ficha no valida acceso, ruta ni condiciones.",
    "Preparar una observación sin extracción ni alteración del entorno."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "lara-sarnoso",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "“La roca es ígnea, por tanto este anclaje es confiable”. ¿Qué problema tiene?",
        "options": [
          "Confunde origen con evaluación de un sistema concreto.",
          "Es correcto para toda roca oscura.",
          "Solo falta conocer el nombre comercial de la cuerda."
        ],
        "answer": 0,
        "explanation": "La estabilidad del punto y las cargas no se resuelven identificando la familia de roca.",
        "source": "mella-tronador",
        "difficulty": "intermedia",
        "rationales": [
          "Separa preguntas distintas.",
          "El color tampoco evalúa estabilidad.",
          "La cuerda no resuelve la base geológica."
        ],
        "kind": "aplicación"
      },
      {
        "prompt": "En una fotografía ves capas y bloques. ¿Cuál es el primer registro más revisable?",
        "options": [
          "Es una falla activa.",
          "Son capas y bloques observables; origen y actividad quedan por investigar.",
          "No hay peligro porque existen capas."
        ],
        "answer": 1,
        "explanation": "La descripción permite contrastar hipótesis sin convertirlas en hechos.",
        "source": "lara-sarnoso",
        "difficulty": "intermedia",
        "rationales": [
          "Actividad necesita evidencia adicional.",
          "Conserva observación e incertidumbre.",
          "La estratificación no garantiza seguridad."
        ],
        "kind": "aplicación"
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

Rocas ígneas se forman al enfriarse material fundido; sedimentarias, por procesos que consolidan o precipitan sedimentos; metamórficas, por transformación de rocas bajo condiciones distintas sin fundirlas completamente. Esta clasificación introductoria describe origen, no resistencia de un bloque concreto. Estructura es la disposición de materiales; una falla implica desplazamiento a lo largo de una discontinuidad. No toda grieta visible es una falla tectónica.

Meteorización altera o desintegra material en el lugar. Erosión implica desgaste y remoción; transporte y depósito completan una historia que puede repetirse. Volcanismo construye y modifica relieves; glaciación puede excavar y remodelar edificios anteriores. Un paisaje conserva señales de más de un proceso.

## Teoría: observar antes de poner un nombre

El primer registro de un guía debe poder revisarlo otra persona. “Capas oscuras inclinadas”, “bloques angulosos sueltos” o “superficie pulida” son observaciones; “lava reciente”, “falla activa” o “roca firme” son interpretaciones que exigen evidencia adicional. La confianza en un nombre no sustituye la comprobación del lugar.

Los trabajos científicos de Los Lagos distinguen unidades y secuencias que una mirada rápida no separa. En Casablanca, la tesis de 2016 estudia centros y unidades con historia diferente; no basta el color para asignar cada fragmento a una de ellas [Referencia: uchile-casablanca](#fuente-uchile-casablanca). En Tronador, la relación entre depósitos volcánicos y erosión glaciar exige leer una secuencia, no elegir entre “volcán” o “glaciar” como explicaciones excluyentes [Referencia: mella-tronador](#fuente-mella-tronador).

Para guiado, la pregunta cambia de “¿qué roca es?” a “¿qué información del terreno afecta nuestra exposición?”. Identificar un material no permite asegurar un anclaje natural. Tamaño, fracturas, disposición, alteración, soporte y trayectoria de posibles desprendimientos son cuestiones situadas. Esta lección no enseña a validar roca para cargas humanas.

La interpretación ambiental también tiene límites. Puedes explicar una hipótesis de formación y el dato que la apoya sin prometer que cada relieve visible tenga una explicación definitiva. Una narración honesta muestra lo observable, la escala temporal y lo pendiente. La investigación puede corregir mapas anteriores sin que eso signifique que todo conocimiento sea arbitrario.

## Caso práctico: el bloque “volcánico y sólido”

En una simulación, un pasajero propone descansar bajo una pared porque “el basalto es duro”. Explica por qué un nombre de roca no evalúa fracturas, bloques ni exposición. Propón revisar la ubicación del grupo desde un lugar adecuado y solicitar evaluación competente cuando sea necesaria. No golpees, desprendas ni cargues bloques para hacer una demostración.

## Errores frecuentes y señales de alerta

Confundir dureza con estabilidad, forma cónica con volcán activo, pared estratificada con roca sedimentaria o grieta con falla activa. La señal de alerta académica es una conclusión precisa apoyada solo en una fotografía distante.

## Autoevaluación y respuestas explicadas

¿Una roca ígnea garantiza un anclaje? No; origen y comportamiento del sistema son preguntas diferentes. ¿Puede un relieve ser volcánico y glacial? Sí: construcción y erosión actúan en distintas etapas y pueden superponerse.

## Ejercicios y práctica presencial

Describe una fotografía con cinco observaciones sin interpretaciones. Luego propone dos hipótesis y una fuente que podría distinguirlas. En recorrido autorizado y supervisado, compara mapa y relieve sin extraer muestras.

## Evidencia requerida

Registro de observación, hipótesis alternativas, fuente y límite de inferencia. El instructor revisa especialmente cualquier salto desde identificación a afirmación de seguridad.

## Relaciones con otras habilidades

Conecta territorio, planificación y análisis conceptual de anclajes. La práctica geológica no acredita montaje ni evaluación de una reunión.
