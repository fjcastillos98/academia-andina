---
{
  "title": "Hipertrofia: adaptación muscular y objetivos de montaña",
  "description": "Separar aumento de tamaño muscular de fuerza y rendimiento específico.",
  "module": "M22",
  "code": "E10-03",
  "order": 1003,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U10-03",
  "skills": [
    "s10-hipertrofia"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Separar aumento de tamaño muscular de fuerza y rendimiento específico.",
    "Aplicar el concepto a una decisión de preparación de montaña y reconocer sus límites."
  ],
  "prerequisites": [
    "s10-fuerza-maxima"
  ],
  "sources": [
    "e10-strength",
    "e10-reds"
  ],
  "pending": [
    "Revisión por profesional del ejercicio e instructor de montaña pendiente. Nutrición y salud requieren revisión profesional específica; no se ha evaluado aptitud personal.",
    "Los casos y rúbricas son propuestas pedagógicas originales. La aplicación individual requiere evaluación, técnica y seguimiento.",
    "No se atribuyen requisitos de certificación, umbrales universales ni preparación técnica a los resultados físicos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Hipertrofia se refiere principalmente a…",
        "options": [
          "Tamaño muscular.",
          "Aclimatación.",
          "Lectura de mapa."
        ],
        "answer": 0,
        "explanation": "Es una adaptación muscular.",
        "rationales": [
          "Es una adaptación muscular.",
          "Es otro proceso fisiológico.",
          "Es una habilidad distinta."
        ],
        "source": "e10-strength",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Las series de ejercicios diferentes…",
        "options": [
          "Son siempre equivalentes.",
          "Necesitan contexto para interpretarse.",
          "No requieren ejecución definida."
        ],
        "answer": 1,
        "explanation": "La cifra sola no describe el estímulo.",
        "rationales": [
          "La tarea y el esfuerzo varían.",
          "La cifra sola no describe el estímulo.",
          "Sin definición no hay comparación."
        ],
        "source": "e10-strength",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un cambio de peso demuestra…",
        "options": [
          "Cuánto músculo se ganó exactamente.",
          "Éxito de cualquier programa.",
          "Un cambio de masa total, no su composición por sí solo."
        ],
        "answer": 2,
        "explanation": "La interpretación requiere más información.",
        "rationales": [
          "No separa componentes.",
          "Se necesitan objetivos y contexto.",
          "La interpretación requiere más información."
        ],
        "source": "e10-strength",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Define hipertrofia sin equipararla a fuerza.",
    "Relaciona volumen y contexto.",
    "No deduce cambios musculares de una medición aislada."
  ],
  "openAssessment": {
    "prompt": "Clasifica tres objetivos ficticios como fuerza, hipertrofia o tolerancia a esfuerzo prolongado, y explica por qué podrían coexistir.",
    "rubric": [
      "Define hipertrofia sin equipararla a fuerza.",
      "Relaciona volumen y contexto.",
      "No deduce cambios musculares de una medición aislada."
    ],
    "source": "e10-strength",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN PROFESIONAL PENDIENTE.** Este contenido no prescribe un programa individual ni acredita competencia técnica. Los ejercicios numéricos y casos son ficticios. No introduzcas datos médicos, mediciones corporales privadas ni antecedentes de terceros.

## Conceptos clave y propósito

Hipertrofia, volumen de trabajo, series, esfuerzo, recuperación y transferencia.

## Teoría y toma de decisiones

Hipertrofia significa aumento del tamaño muscular. No es sinónimo de fuerza máxima ni de capacidad para caminar durante horas. El entrenamiento de resistencia puede mejorar varias cualidades, pero la programación depende del objetivo; ACSM relaciona el desarrollo muscular con el volumen de entrenamiento y la individualización. [ACSM 2026](#fuente-e10-strength).

La utilidad para montaña se analiza por función, tolerancia y contexto. La pregunta no es si «más músculo siempre es mejor», sino qué capacidad falta y cómo se entrena sin desplazar el resto del programa. Una fase con más trabajo de fuerza también necesita tiempo de recuperación y alimentación suficiente.

En el modelo de aula se compara el número de series de un mismo ejercicio, con igual ejecución, sin convertirlo en dosis recomendada. Diez series mal definidas no son una unidad comparable con diez series de otra tarea. El registro distingue realizado y planificado.

Un cambio de báscula no identifica cuánto músculo se ganó. La composición corporal requiere método, condiciones y una interpretación profesional; no se deduce del aspecto de una foto. Esta unidad evalúa conceptos y lectura crítica de programas, no objetivos corporales personales.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación del aprendizaje:** Define el objetivo muscular y su relación con la actividad; registra ejercicio, series, repeticiones y ejecución. Revisa con profesional si el trabajo añadido cabe en la semana y cómo afecta otras sesiones. No aumentar volumen solo porque una cifra de internet parece un mínimo obligatorio.

La selección real de ejercicios, cargas, pruebas y progresión corresponde a una evaluación individual con profesionales. Las técnicas críticas de montaña requieren formación práctica y supervisión de instructor competente. El acondicionamiento físico no autoriza una maniobra.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una planificación ficticia añade cinco ejercicios de piernas el día previo a una marcha larga. Analiza objetivo, interferencia logística y recuperación sin ordenar una rutina.

Distingue dato, interpretación y decisión. Explica qué incertidumbre permanece. Los casos no representan un protocolo del organismo citado ni un criterio oficial de habilitación para guía.

## Errores frecuentes y puntos críticos de seguridad

Confundir peso corporal con músculo; buscar dolor como prueba de crecimiento; sumar series sin contexto; descuidar alimentación o resistencia.

## Material y equipo relacionado

Material de fuerza ajustable y ficha de seguimiento. No hace falta una báscula de composición corporal para completar el ejercicio académico.

[Consultar inventario](../../equipo/). Ajustar o poseer el equipo no demuestra dominarlo. Las prácticas técnicas se registran por separado del acondicionamiento.

## Autoevaluación y recuperación activa

- Explica la diferencia entre la capacidad que estudias y una tarea técnica de montaña.
- ¿Qué información falta en el caso y qué decisión modificaría?
- ¿Qué parte puede analizarse en escritorio y cuál necesita observación profesional?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Clasifica tres objetivos ficticios como fuerza, hipertrofia o tolerancia a esfuerzo prolongado, y explica por qué podrían coexistir.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Revisión técnica de un programa de resistencia con profesional; observar ejecución y adecuación sin prescribir metas de peso.

## Evidencia requerida y criterios de competencia

- Define hipertrofia sin equipararla a fuerza.
- Relaciona volumen y contexto.
- No deduce cambios musculares de una medición aislada.

**COMPETENCIA:** estos criterios describen aprendizaje que debe observar un profesional en contexto. No acreditan aptitud médica, entrenamiento personal, guiado ni maniobra técnica. Una lectura, prueba física o quiz no otorga certificación. Marca pendiente lo que no se haya evaluado.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s10-hipertrofia). Registra fecha, actividad, escenario, equipo, objetivo, errores, correcciones, supervisor y evidencia de aprendizaje. No guardes datos médicos ni contraseñas. No inventes sesiones, evaluaciones o repeticiones para completar la matriz.

## Relaciones con otros módulos

[Entrenamiento](../../entrenamiento/) · [Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Programa](../../programa/). Entrenamiento general, preparación específica, aclimatación y competencia técnica se relacionan, pero no son equivalentes.
