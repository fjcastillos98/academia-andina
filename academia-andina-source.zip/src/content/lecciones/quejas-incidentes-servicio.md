---
{
  "title": "Quejas e incidentes de servicio: escuchar, responder y aprender",
  "description": "Organizar un reclamo sin confundir respuesta, derivación y solución.",
  "module": "M19",
  "code": "E23-01",
  "order": 2301,
  "minutes": 45,
  "level": "Intermedio",
  "status": "development",
  "unit": "U23-01",
  "skills": [
    "s23-quejas"
  ],
  "critical": false,
  "reviewDate": "2026-10-29",
  "objectives": [
    "Separa hechos, versiones e incertidumbres.",
    "Identifica prioridad y responsable sin sustituir atención especializada.",
    "Formula respuesta y seguimiento comprobables."
  ],
  "prerequisites": [
    "Estudiar ética profesional y comunicación y conflictos."
  ],
  "sources": [
    "e23-quejas"
  ],
  "pending": [
    "Revisión docente y operativa pendiente.",
    "No se verifican plazos legales, derechos a compensación ni procedimientos regulatorios chilenos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una queja menciona una situación de peligro que continúa. ¿Cómo organizar el caso?",
        "options": [
          "Esperar la resolución comercial.",
          "Priorizar la respuesta de seguridad según el plan y mantener el seguimiento de la queja.",
          "Cerrar porque ya no es una queja."
        ],
        "answer": 1,
        "explanation": "Permite atender ambas dimensiones sin confundirlas.",
        "rationales": [
          "Pospone una necesidad distinta.",
          "Permite atender ambas dimensiones sin confundirlas.",
          "La derivación no resuelve el reclamo."
        ],
        "source": "e23-quejas",
        "difficulty": "intermedia",
        "kind": "caso"
      },
      {
        "prompt": "¿Qué diferencia una respuesta enviada de una solución comprobada?",
        "options": [
          "Ninguna.",
          "La cantidad de palabras.",
          "La evidencia de que se ejecutó la acción y se revisó su resultado."
        ],
        "answer": 2,
        "explanation": "Permite comprobar seguimiento.",
        "rationales": [
          "Son estados diferentes.",
          "La extensión no prueba ejecución.",
          "Permite comprobar seguimiento."
        ],
        "source": "e23-quejas",
        "difficulty": "intermedia",
        "kind": "caso"
      },
      {
        "prompt": "Dos relatos discrepan sobre el horario comunicado. ¿Qué registrar?",
        "options": [
          "Ambas versiones atribuidas y la evidencia que falta contrastar.",
          "Solo la versión del guía.",
          "Una hora inventada para cerrar."
        ],
        "answer": 0,
        "explanation": "Conserva hechos e incertidumbre.",
        "rationales": [
          "Conserva hechos e incertidumbre.",
          "Excluye información relevante.",
          "Falsea el registro."
        ],
        "source": "e23-quejas",
        "difficulty": "intermedia",
        "kind": "caso"
      },
      {
        "prompt": "El receptor no tiene autoridad para decidir una devolución. ¿Qué puede comprometer?",
        "options": [
          "Una devolución total inmediata sin consultar.",
          "Una revisión por el responsable y una próxima actualización concreta.",
          "Que la persona renuncie a reclamar."
        ],
        "answer": 1,
        "explanation": "Define seguimiento sin inventar el resultado.",
        "rationales": [
          "Promete una decisión fuera de su autoridad.",
          "Define seguimiento sin inventar el resultado.",
          "No corresponde condicionar la atención de esa forma."
        ],
        "source": "e23-quejas",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "openAssessment": {
    "prompt": "Resuelve un caso ficticio: recepción, hechos, prioridad, responsable, respuesta, evidencia de cierre y aprendizaje.",
    "rubric": [
      "Separa hechos, versiones e incertidumbres.",
      "Identifica prioridad y responsable sin sustituir atención especializada.",
      "Formula respuesta y seguimiento comprobables."
    ],
    "source": "e23-quejas",
    "difficulty": "integración"
  }
}
---

**CONTENIDO EN DESARROLLO · TALLER DE MESA · REVISIÓN DOCENTE Y OPERATIVA PENDIENTE.** No ingreses reclamos reales, datos de pasajeros ni antecedentes médicos.

## Conceptos clave y propósito

Una queja expresa disconformidad; un incidente describe un suceso que alteró la actividad. Pueden coexistir: una persona puede reclamar por cómo se comunicó una retirada y además informar un problema de equipo. El análisis necesita separar ambas dimensiones para no resolver una y olvidar la otra.

Recibir un reclamo no significa aceptar automáticamente todas sus conclusiones ni rechazarlo por incomodidad. Primero permite saber qué se afirma, qué efecto se describe y qué respuesta se solicita. La tarea docente consiste en conservar esa información, examinarla y formular una actuación verificable.

## Teoría y alcance de la referencia

La orientación del Public Service Ombudsman británico destaca responsabilidades claras, atención justa, aprendizaje y comunicación de los pasos siguientes cuando persiste la disconformidad. [Referencia consultada](#fuente-e23-quejas). Está dirigida a organismos públicos de su ámbito. Aquí se usa como apoyo conceptual, no como norma para operadores turísticos chilenos ni como procedimiento certificado.

El flujo siguiente es una propuesta educativa original de la academia. No fija plazos legales, compensaciones ni obligaciones de denuncia. Cuando una decisión dependa de esos elementos, se debe identificar la consulta pendiente y al responsable que la resolverá con fuentes aplicables.

## Recibir y reconocer

Escucha el relato sin discutir de inmediato cada palabra. Resume el problema en lenguaje concreto y pide confirmación: «Entiendo que recibiste dos horarios distintos y eso afectó tu llegada; ¿es ese el punto principal?». Distingue el efecto comunicado de una causa todavía no comprobada.

Pregunta qué resultado espera la persona. Esa expectativa orienta la revisión, pero no obliga al receptor a prometer algo que no puede decidir. En el taller, un acuse de recibo incluye asunto entendido, responsable de revisión, información que se contrastará y próxima actualización acordada. La fecha del ejercicio es un compromiso ficticio, no un plazo normativo.

## Prioridad y vías de atención

Si el relato incluye una situación de peligro vigente, lesión, amenaza o un problema fuera de la competencia del receptor, el trámite comercial no debe retrasar la atención pertinente. Se recurre al plan y a los responsables competentes; esta lección no enseña rescate, diagnóstico ni investigación de delitos.

La derivación no equivale a solución: registra qué asunto se trasladó, a quién corresponde revisarlo y qué seguimiento permanece pendiente. Un caso puede necesitar una vía de seguridad y otra de servicio. No cierres el reclamo porque alguien recibió un aviso ni uses el formulario como sustituto de una respuesta urgente.

En una empresa pequeña, quien recibe la queja puede estar involucrado en el hecho. Haz visible ese conflicto y define una revisión por otra persona competente cuando corresponda. Si no existe revisión independiente disponible, no la inventes ni la describas como realizada.

## Registrar y contrastar

El registro de aula distingue momento del hecho, momento del relato, fuente de cada versión, documentos disponibles, información faltante y acción propuesta. «El transporte salió a las 08:00» y «la persona afirma que salió a las 08:00» tienen alcances distintos si no has contrastado el dato.

Conserva contradicciones hasta poder aclararlas. Compara la oferta, la versión de instrucciones que recibió cada parte y el registro de cambios. No reescribas el relato inicial para hacerlo coincidir con una explicación posterior. Una corrección debe dejar claro qué se corrigió y por qué.

La academia solo conserva ejercicios ficticios. La documentación de un caso real requiere canales y controles apropiados de acceso, conservación y tratamiento de información; esos requisitos no quedan resueltos por esta plantilla.

## Responder con razones y límites

Una respuesta útil distingue hechos confirmados, puntos no resueltos, decisión, razones, acción y revisión siguiente. Reconoce un error comprobado con precisión: «En el mensaje se omitió el cambio de punto de encuentro». Evita una frase vaga que traslade toda la responsabilidad a quien reclamó sin examinar lo ocurrido.

Si falta evidencia, comunica qué se está revisando. No declares que el silencio de una persona demuestra conformidad. Tampoco uses una reseña negativa como razón para desacreditarla. La respuesta pública, si llegara a corresponder, necesita cuidar la información de terceros; este ejercicio no publica ni envía mensajes.

Las devoluciones, cobros, seguros y consecuencias contractuales requieren revisión específica. El taller puede proponer consultar al responsable, pero no determina una solución jurídica ni condiciona la atención a retirar una crítica.

## Cierre y aprendizaje

Enviar una respuesta no demuestra que la corrección se ejecutó. Distingue respuesta emitida, acción realizada, resultado comprobado y desacuerdo pendiente. El cierre administrativo debe expresar su alcance, sin afirmar satisfacción que no se confirmó ni eliminar vías de revisión que correspondan.

Para aprender, conecta el caso con una acción concreta: revisar una versión de instrucciones, comprobar una entrega de información o aclarar quién coordina un cambio. Asigna responsable y evidencia esperada. «Mejorar la comunicación» es insuficiente si nadie puede comprobar qué cambió.

## Caso práctico: dos puntos de encuentro

**Ficción didáctica:** una reserva recibe un correo con un punto de encuentro y después un mensaje con otro, sin indicación explícita de que reemplaza al primero. La persona llega al lugar inicial y reclama un cobro adicional. El guía sostiene que «se avisó».

Respuesta orientativa: conservar ambos mensajes, reconstruir qué información llegó y cuándo, reconocer la ambigüedad si se confirma y separar la revisión comunicativa de la decisión económica. El receptor propone una actualización por el responsable, sin inventar el derecho a cobrar o devolver. Como mejora, plantea una instrucción que identifique qué cambia y cómo se comprueba su recepción.

## Errores frecuentes

Confundir reclamo con ataque; etiquetar a la persona; prometer compensación sin autoridad; registrar suposiciones como hechos; dar por resuelto un asunto derivado; cerrar al enviar; medir éxito solo por menos quejas, sin comprobar si el canal sigue siendo accesible.

## Autoevaluación

¿Qué evidencia confirmaría cada versión? ¿Qué parte requiere atención distinta del reclamo comercial? ¿Qué puedes comprometer ahora y qué depende de otra revisión? ¿Qué dato faltaría para afirmar que una corrección funcionó?

## Ejercicios y revisión

Resuelve un caso del [taller de atención](../../atencion/). Un compañero actúa como revisor del expediente ficticio: busca una afirmación sin fuente y una promesa sin responsable. Reescribe la respuesta y conserva ambas versiones. No se simulan emergencias reales ni se contacta a terceros.

## Evidencia requerida

Acuse de recibo simulado, cronología atribuida, asuntos pendientes, decisión con límites, acción y verificación propuesta. La rúbrica revisa calidad del análisis, no certifica atención profesional. No registres el ensayo como realizado hasta que ocurra.

## Relaciones con otros módulos

Revisa [ética profesional](../etica-responsabilidad/), [comunicación y conflictos](../comunicacion-conflictos/) e [incidentes y retirada](../incidentes-retirada/). Los procedimientos técnicos y jurídicos necesitan sus propias fuentes y responsables.
