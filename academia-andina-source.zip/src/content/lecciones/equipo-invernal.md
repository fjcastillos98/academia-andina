---
{
  "title": "Equipo invernal: sistema personal y colectivo",
  "description": "Relacionar cada pieza con función, límite y compatibilidad.",
  "module": "M21",
  "code": "E5-27",
  "order": 526,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-24",
  "skills": [
    "s5-equipo-invernal"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Relacionar cada pieza con función, límite y compatibilidad.",
    "Preparar inspección y mantenimiento trazables por modelo.",
    "Distinguir disponibilidad de material de preparación del grupo."
  ],
  "prerequisites": [
    "s5-frio-fisiologia"
  ],
  "sources": [
    "e5-ms-kit",
    "e5-ms-crampon",
    "e5-grivel-gzero",
    "e5-sac-esqui"
  ],
  "pending": [
    "Revisión de instructor y contraste con manuales exactos del equipo disponible. Cualquier aplicación territorial permanece pendiente de reconocimiento y condiciones actuales."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Equipo registrado en el inventario significa…",
        "options": [
          "Material automáticamente apto.",
          "Historial disponible, sujeto a revisión.",
          "Competencia del usuario."
        ],
        "answer": 1,
        "explanation": "El registro es trazabilidad, no certificación.",
        "rationales": [
          "No hay evaluación automática.",
          "Mantiene el alcance del inventario.",
          "La habilidad requiere práctica."
        ],
        "source": "e5-ms-kit",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Cambiar una bota de pasajero exige…",
        "options": [
          "Mantener el ajuste anterior sin revisar.",
          "Solo revisar la talla escrita.",
          "Recomprobar compatibilidad del conjunto."
        ],
        "answer": 2,
        "explanation": "La interfaz física cambió.",
        "rationales": [
          "Puede alterar sujeción.",
          "La talla no describe toda geometría.",
          "Revisa el sistema real."
        ],
        "source": "e5-ms-crampon",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué hacer si no se conoce la versión de un piolet?",
        "options": [
          "Identificarla antes de aplicar documentación específica.",
          "Usar cualquier ficha comercial.",
          "Suponer que no cambió."
        ],
        "answer": 0,
        "explanation": "La documentación debe corresponder al equipo.",
        "rationales": [
          "Mantiene trazabilidad.",
          "Puede describir otra configuración.",
          "Es una suposición no verificada."
        ],
        "source": "e5-grivel-gzero",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "Relaciona pieza, tarea y limitación.",
    "Localiza manual y criterios de revisión del modelo.",
    "Identifica dependencias de formación y equipo que siguen pendientes."
  ],
  "openAssessment": {
    "prompt": "Audita un inventario ficticio por tareas: señala tres piezas con documentación pendiente y tres habilidades que no demuestra su posesión.",
    "rubric": [
      "Relaciona pieza, tarea y limitación.",
      "Localiza manual y criterios de revisión del modelo.",
      "Identifica dependencias de formación y equipo que siguen pendientes."
    ],
    "source": "e5-ms-kit",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-capas"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Reconoce cada pieza por su función y modelo; identifica tareas sin recurso o sin habilidad demostrada, incluso cuando el inventario está completo.

## Teoría y toma de decisiones

El equipo invernal funciona como un sistema de protección, movimiento, observación y respuesta. Una lista de compra no demuestra que esas funciones estén cubiertas. Mountaineering Scotland reúne ropa, protección ocular, navegación, luz, reservas y material técnico en su orientación para invierno [fuente](#fuente-e5-ms-kit); la selección final debe responder a actividad y personas. No se copia una capacidad de mochila o cantidad de prendas como regla universal.

Organiza el análisis en cuatro preguntas: qué tarea debe permitir una pieza, qué no resuelve, con qué debe ser compatible y cómo se comprobará. Las botas relacionan ajuste personal, protección y sistema de fijación; crampones y piolet se estudian en unidades prácticas independientes. Un casco necesita ajuste con las capas usadas y su ámbito de protección. Guantes deben permitir las tareas previstas; una reserva inaccesible o imposible de colocar con manos frías puede no cumplir su función cuando se necesita.

Capas interiores, aislamiento y protección exterior responden a humedad, esfuerzo y exposición. Chaqueta y pantalón forman parte de esa regulación, no de una competencia para permanecer indefinidamente al frío. Gafas y antiparras aportan protección visual diferente según diseño y condiciones; comprueba uso previsto, ajuste, estado y compatibilidad con casco. La visibilidad también es un recurso de navegación: si el sistema no permite ver, no se compensa simplemente aumentando confianza en un track.

DVA, pala y sonda cumplen funciones complementarias en rescate, junto con formación y organización. El SAC las incluye en preparación de esquí de montaña en terreno de avalancha [fuente](#fuente-e5-sac-esqui). Poseer DVA sin práctica de búsqueda, sondaje y excavación deja tareas sin resolver. El equipo de emergencia debe relacionarse con capacidad de proteger, comunicar y pedir apoyo. No se inventa cobertura de teléfono, VHF o mensajero satelital; medios y energía requieren plan propio.

La ficha de inventario ya permite marca, modelo, serie, compra, manual, inspecciones, daños, mantenimiento y retiro. Usa esos campos para distinguir un ejemplar concreto de una categoría genérica. La revisión previa a una práctica no sustituye los controles que exige el fabricante. Las fechas de uso vinculadas al diario ayudan a contextualizar observaciones, pero no calculan vida útil ni declaran aptitud. Si no se conoce el historial, el dato que falta debe quedar visible.

El ejercicio de aula consiste en escoger una tarea y recorrer su cadena de dependencias. Por ejemplo, reconocer una señal en DVA requiere equipo operativo, manejo de modos, control de interferencias, organización y capacidad de continuar las fases. Después busca un punto donde falle una dependencia y explica si existe alternativa real. Para Filo Austral, la familiaridad del guía con su propio material no demuestra que un pasajero pueda usar otro modelo. La práctica debe comprobar tareas por persona y conjunto, conservando límites observados. Las dieciséis fichas acompañantes son guías de preguntas, no instrucciones completas de fabricante.

## Qué observo, qué significa y qué no puedo concluir

Las fichas no certifican material ni sustituyen manuales. Mantenimiento, compatibilidad y retiro específicos requieren información del fabricante y revisión competente.

## Caso práctico y aplicación al guiado

El inventario de un grupo está completo, pero nadie ha ensayado ensamblar la sonda con guantes. Explica por qué disponibilidad no equivale preparación.

## Errores frecuentes y señales de alerta

Equiparar registro con aptitud; usar manual de otra generación; dejar reservas inaccesibles; asumir que todos manejan el equipo del guía.

## Autoevaluación y respuesta razonada

Audita un inventario ficticio por tareas: señala tres piezas con documentación pendiente y tres habilidades que no demuestra su posesión.

## Ejercicios y práctica supervisada

Revisión de mesa y taller supervisado de tareas con equipo exacto. Registrar errores y correcciones, sin marcar aptitud automática ni competencia por asistencia.

## Evidencia requerida

- Relaciona pieza, tarea y limitación.
- Localiza manual y criterios de revisión del modelo.
- Identifica dependencias de formación y equipo que siguen pendientes.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-equipo-invernal).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).

[Fichas educativas de equipo](../../invierno/equipo/).
