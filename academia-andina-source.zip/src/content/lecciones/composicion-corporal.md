---
{
  "title": "Composición corporal y disponibilidad energética",
  "description": "Evitar que el peso sustituya la evaluación de salud y rendimiento.",
  "module": "M22",
  "code": "E10-14",
  "order": 1014,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U10-14",
  "skills": [
    "s10-composicion-corporal"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Evitar que el peso sustituya la evaluación de salud y rendimiento.",
    "Aplicar el concepto a una decisión de preparación de montaña y reconocer sus límites."
  ],
  "prerequisites": [
    "s10-nutricion-entrenamiento"
  ],
  "sources": [
    "e10-reds"
  ],
  "pending": [
    "Revisión por profesional del ejercicio e instructor de montaña pendiente. Nutrición y salud requieren revisión profesional específica; no se ha evaluado aptitud personal.",
    "Los casos y rúbricas son propuestas pedagógicas originales. La aplicación individual requiere evaluación, técnica y seguimiento.",
    "No se atribuyen requisitos de certificación, umbrales universales ni preparación técnica a los resultados físicos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "REDs puede afectar…",
        "options": [
          "A mujeres y hombres.",
          "Solo a mujeres.",
          "Solo a quienes tienen un peso concreto."
        ],
        "answer": 0,
        "explanation": "El consenso incluye ambos.",
        "rationales": [
          "El consenso incluye ambos.",
          "Es una restricción incorrecta.",
          "No se define por una cifra única."
        ],
        "source": "e10-reds",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una medición aislada de composición…",
        "options": [
          "Prueba cambio exacto de músculo.",
          "Necesita contexto y método.",
          "Certifica rendimiento."
        ],
        "answer": 1,
        "explanation": "Permite interpretar sus límites.",
        "rationales": [
          "Tiene error y condiciones propias.",
          "Permite interpretar sus límites.",
          "No mide toda la función."
        ],
        "source": "e10-reds",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Bajar de peso mientras cae el rendimiento…",
        "options": [
          "Siempre es éxito.",
          "Exige más restricción automáticamente.",
          "Requiere revisar objetivos y evaluación profesional."
        ],
        "answer": 2,
        "explanation": "Evita conclusiones por una sola variable.",
        "rationales": [
          "No basta como criterio.",
          "Puede empeorar el problema.",
          "Evita conclusiones por una sola variable."
        ],
        "source": "e10-reds",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Separa masa, composición y función.",
    "Reconoce REDs sin autodiagnosticar.",
    "Evita metas corporales universales."
  ],
  "openAssessment": {
    "prompt": "Reformula tres metas ficticias centradas solo en peso como preguntas sobre función, continuidad y revisión profesional.",
    "rubric": [
      "Separa masa, composición y función.",
      "Reconoce REDs sin autodiagnosticar.",
      "Evita metas corporales universales."
    ],
    "source": "e10-reds",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN PROFESIONAL PENDIENTE.** Este contenido no prescribe un programa individual ni acredita competencia técnica. Los ejercicios numéricos y casos son ficticios. No introduzcas datos médicos, mediciones corporales privadas ni antecedentes de terceros.

## Conceptos clave y propósito

Masa corporal, composición, error de medición, disponibilidad energética y REDs.

## Teoría y toma de decisiones

La masa corporal no describe por sí sola fuerza, resistencia ni salud. Métodos de composición corporal tienen condiciones y error propios; comparar mediciones sin estandarización puede atribuir a tejidos cambios que no están demostrados.

El consenso IOC 2023 describe REDs en mujeres y hombres expuestos a baja disponibilidad energética problemática, con consecuencias posibles para salud y rendimiento. Su evaluación exige personal sanitario; no se diagnostica por peso, apariencia o una cuenta de calorías. [IOC REDs](#fuente-e10-reds).

Para montaña, la relación potencia-peso no justifica perseguir pérdida de peso a cualquier coste. El programa debe permitir adaptación y recuperación, y mantener separadas metas deportivas, nutricionales y clínicas. El ejercicio de esta unidad no solicita peso ni calcula IMC o grasa corporal.

En el caso original, una bajada de báscula se interpreta como mejora aunque empeore la capacidad de completar sesiones. La discusión pregunta qué objetivo se está midiendo y qué información necesita revisión profesional. La plataforma no emite un semáforo REDs ni almacena síntomas personales.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación del aprendizaje:** Define para qué se usaría una medición y si realmente es necesaria. Si se realiza fuera de la plataforma, debe seguir un método estandarizado e interpretación profesional. Ante deterioro persistente de rendimiento o recuperación, solicita evaluación en vez de intensificar restricción.

La selección real de ejercicios, cargas, pruebas y progresión corresponde a una evaluación individual con profesionales. Las técnicas críticas de montaña requieren formación práctica y supervisión de instructor competente. El acondicionamiento físico no autoriza una maniobra.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un plan felicita cualquier pérdida de peso sin revisar cómo se tolera el entrenamiento. Explica por qué ese criterio es incompleto.

Distingue dato, interpretación y decisión. Explica qué incertidumbre permanece. Los casos no representan un protocolo del organismo citado ni un criterio oficial de habilitación para guía.

## Errores frecuentes y puntos críticos de seguridad

Asumir que más liviano siempre es mejor; diagnosticar REDs por aspecto; interpretar bioimpedancia aislada como cambio de músculo; imponer déficit agresivo.

## Material y equipo relacionado

No se necesita báscula para el ejercicio académico. Mediciones reales y antecedentes se gestionan fuera del cuaderno por canales apropiados.

[Consultar inventario](../../equipo/). Ajustar o poseer el equipo no demuestra dominarlo. Las prácticas técnicas se registran por separado del acondicionamiento.

## Autoevaluación y recuperación activa

- Explica la diferencia entre la capacidad que estudias y una tarea técnica de montaña.
- ¿Qué información falta en el caso y qué decisión modificaría?
- ¿Qué parte puede analizarse en escritorio y cuál necesita observación profesional?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Reformula tres metas ficticias centradas solo en peso como preguntas sobre función, continuidad y revisión profesional.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Revisión educativa con nutricionista y profesional sanitario competente cuando corresponda; sin evaluación clínica dentro de la app.

## Evidencia requerida y criterios de competencia

- Separa masa, composición y función.
- Reconoce REDs sin autodiagnosticar.
- Evita metas corporales universales.

**COMPETENCIA:** estos criterios describen aprendizaje que debe observar un profesional en contexto. No acreditan aptitud médica, entrenamiento personal, guiado ni maniobra técnica. Una lectura, prueba física o quiz no otorga certificación. Marca pendiente lo que no se haya evaluado.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s10-composicion-corporal). Registra fecha, actividad, escenario, equipo, objetivo, errores, correcciones, supervisor y evidencia de aprendizaje. No guardes datos médicos ni contraseñas. No inventes sesiones, evaluaciones o repeticiones para completar la matriz.

## Relaciones con otros módulos

[Entrenamiento](../../entrenamiento/) · [Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Programa](../../programa/). Entrenamiento general, preparación específica, aclimatación y competencia técnica se relacionan, pero no son equivalentes.
