---
{
  "title": "Montaña estival: terreno, marcha y campamento",
  "description": "Distinguir dificultad técnica, esfuerzo y exposición en un recorrido.",
  "module": "M01",
  "code": "E4-01",
  "order": 201,
  "minutes": 45,
  "level": "Intermedio",
  "status": "development",
  "reviewDate": "2026-10-22",
  "unit": "U4-01",
  "skills": [
    "s4-estival-terreno"
  ],
  "critical": false,
  "objectives": [
    "Distinguir dificultad técnica, esfuerzo y exposición en un recorrido.",
    "Ajustar la marcha y el retorno al grupo observado.",
    "Justificar un campamento sin dar por válidos accesos o permisos."
  ],
  "prerequisites": [
    "Completar estudio de Fundamentales; la práctica previa debe revisarse presencialmente."
  ],
  "sources": [
    "nps-marcha",
    "nps-campamento"
  ],
  "pending": [
    "Revisión pedagógica y evaluación situada por instructor competente.",
    "Condiciones, accesos, permisos y compatibilidad del equipo requieren verificación para cada actividad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Dos rutas tienen igual distancia. ¿Qué falta comparar?",
        "options": [
          "Terreno, desnivel, exposición, grupo y retorno.",
          "Solo el color del track.",
          "Nada."
        ],
        "answer": 0,
        "explanation": "La distancia no representa por sí sola las demandas ni consecuencias de un recorrido."
      },
      {
        "prompt": "El grupo pierde ritmo. ¿Qué supuesto debes revisar?",
        "options": [
          "Que el descenso compensará siempre el retraso.",
          "Que todas las personas caminan igual.",
          "Ambos supuestos necesitan revisión."
        ],
        "answer": 2,
        "explanation": "Ni el ritmo homogéneo ni una bajada más rápida están garantizados."
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

**TEORÍA.** “Estival” describe una estación, no la ausencia de nieve, hielo, frío o terreno técnico. En este curso, una salida no técnica es un escenario de aprendizaje delimitado: sendero conocido, sin exposición que exija sistemas de protección, con retorno preparado. Si aparece un paso que excede ese marco, se revisa la actividad; no se convierte una cuerda transportada en solución improvisada.

**Dificultad** es la exigencia técnica; **esfuerzo** describe la demanda física; **exposición** expresa la posibilidad de sufrir consecuencias en un lugar. Un trayecto corto puede tener consecuencias graves ante una caída. **Desnivel acumulado** suma ascensos del recorrido; la diferencia entre inicio y final no lo sustituye. **Ritmo** incluye desplazamiento, pausas y organización, no solo velocidad.

## Teoría: leer el recorrido completo

El NPS propone elegir una caminata acorde con la capacidad y experiencia del grupo y preparar un plan de emergencia [Referencia: nps-marcha](#fuente-nps-marcha). Para aplicarlo al estudio del guiado, divide el itinerario en aproximación, ascenso, sector de mayor compromiso y descenso. En cada tramo describe superficie, pendiente, visibilidad de referencias, consecuencias de un tropiezo y posibilidades de retorno. La palabra “fácil” no informa de todo eso.

En un sendero sin exposición, practica una marcha que permita observar y colocar el pie de manera deliberada. Ajusta la longitud del paso al terreno; en descenso evita convertir la urgencia en carrera. Este ejercicio no enseña pasos de escalada ni progresión sobre nieve. La postura concreta y el uso de bastones deben observarse y corregirse presencialmente, especialmente al cambiar de superficie o llevar carga.

El ritmo del grupo se evalúa por lo que permite sostener: comunicación, atención, retorno y participación. Una persona que llega a cada pausa cuando las demás vuelven a partir no está recibiendo la misma recuperación. No uses vergüenza o comparación para acelerar al pasajero. Pregunta en privado qué necesita y revisa el plan.

El descenso merece una estimación independiente: no presupongas que siempre será más rápido. En el taller, identifica dónde la fatiga puede afectar atención, equilibrio y decisiones. Revisa calzado, distribución de carga y disponibilidad de recursos antes de atribuir toda dificultad a falta de entrenamiento.

## Campamento y recursos

La guía del NPS distingue requisitos del lugar, accesibilidad, duración, condiciones y alternativa de campamento [Referencia: nps-campamento](#fuente-nps-campamento). La selección no empieza al quedar poca luz. Antes de salir confirma que acampar esté permitido y cómo se gestionan agua, residuos y cocina. Un espacio aparentemente plano no constituye una evaluación de peligros.

En tu ficha de campamento compara dos opciones usando: autorización, exposición al terreno y tiempo, impacto, agua tratable, distancia al retorno y capacidad del grupo para instalarse. No plantes una carpa para “probar” un sitio expuesto. En una práctica controlada monta y desmonta el equipo conforme al fabricante, verifica qué piezas faltan y registra cuánto tarda el grupo. No uses fuego o cocina en interiores para el ejercicio.

Planifica agua y alimentación como recursos disponibles a lo largo de las etapas. No presupongas que un curso de agua será potable ni estará disponible. En esta unidad no se prescriben litros, calorías ni tratamientos universales: aprende a identificar dependencias y a comprobar el método que llevarás.

## Caso práctico: Yates, escenario ficticio

Un grupo asociado a Filo Austral prevé una jornada estival. La ficha no confirma condiciones del sector superior. Una persona pierde ritmo en la aproximación; el organizador propone “recuperar tiempo bajando”. No se proporciona aquí una ruta, altitud ni acceso validado de Yates.

Analiza qué falta: estado del terreno, capacidad de retorno, horario disponible, experiencia y posibilidad real de acortar. Una respuesta sólida no calcula una recuperación ficticia de tiempo: rediseña objetivo y retorno con los datos observados y mantiene la cancelación como alternativa.

## Errores frecuentes y señales de alerta

Confundir verano con ausencia de nieve; equiparar distancia con dificultad; tratar el descenso como tiempo sobrante; separar al lento sin plan; depender de un agua no verificada. Señales para reevaluar: tropiezos repetidos, comunicación que se deteriora, cambio de superficie, pérdida de referencias o discrepancia importante con el tiempo previsto. Son indicios para decidir, no diagnósticos médicos.

## Autoevaluación y respuestas explicadas

1. ¿Por qué dos recorridos de igual distancia pueden exigir planes distintos? **Porque terreno, desnivel, exposición, grupo y alternativas cambian el significado de esa distancia.**
2. ¿Qué evidencia falta si el campamento solo está marcado en una aplicación? **Permiso, condiciones, peligros, recursos y verificación del lugar. Un icono no los acredita.**

## Ejercicios y práctica presencial

**PRÁCTICA:** dibuja una ficha de cuatro tramos para un recorrido ficticio. Estima tiempos por separado y escribe sus supuestos. **SUPERVISIÓN:** en un sendero de entrenamiento conocido y no expuesto, un instructor observa marcha, pausas, comunicación y cambios de ritmo. La actividad se interrumpe si el contexto deja de ser el acordado.

## Evidencia requerida

Entrega ficha de tramos, comparación de campamentos y un registro con error observado, corrección y resultado. Explica qué cambiarías al repetir la jornada. Un tiempo rápido no es criterio suficiente de competencia.

## Relaciones con otras habilidades

Esta unidad se integra en la ruta estival. Consulta la ficha de habilidad y sus prerrequisitos en el programa. Registra práctica y evaluación por separado: estudiar y responder correctamente no acredita ejecución. Los ejercicios son propuestas didácticas originales; los casos no son rutas operativas.
