---
{
  "title": "Progresión alpina: terreno cambiante y elección de método",
  "description": "Separar dificultad de movimiento y consecuencias de una caída.",
  "module": "M06",
  "code": "E8-06",
  "order": 806,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U8-06",
  "skills": [
    "s8-progresion-alpina"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Separar dificultad de movimiento y consecuencias de una caída.",
    "Reconocer transiciones que obligan a revisar método y exposición."
  ],
  "prerequisites": [
    "s8-grupo-alpino"
  ],
  "sources": [
    "e8-scramble",
    "e8-simul",
    "e8-radline"
  ],
  "pending": [
    "Revisión docente y práctica presencial por instructor alpino competente pendientes. No se ha observado ni aprobado una maniobra.",
    "Compatibilidad y manual del equipo personal pendientes de verificación; no se extrapolan ejemplos GRIGRI/REVERSO/RAD LINE a ATC Guide u otras cuerdas."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un paso fácil con gran exposición…",
        "options": [
          "Exige considerar consecuencias y protección.",
          "Es automáticamente de riesgo bajo.",
          "No necesita decisión de método."
        ],
        "answer": 0,
        "explanation": "El movimiento no resume el riesgo. Separar dificultad de movimiento y consecuencias de una caída.",
        "rationales": [
          "El movimiento no resume el riesgo.",
          "La exposición cambia el problema.",
          "La protección requiere análisis propio."
        ],
        "source": "e8-scramble",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "El grupo no domina un método más rápido. ¿Qué concluye?",
        "options": [
          "Que debe usarlo para aprender en ruta.",
          "Que la rapidez no justifica emplearlo sin formación.",
          "Que el quiz sustituye el taller."
        ],
        "answer": 1,
        "explanation": "La capacidad disponible condiciona la decisión. Separar dificultad de movimiento y consecuencias de una caída.",
        "rationales": [
          "La ruta no es lugar para improvisar una técnica crítica.",
          "La capacidad disponible condiciona la decisión.",
          "El quiz solo aporta comprensión teórica."
        ],
        "source": "e8-scramble",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La transición debe…",
        "options": [
          "Excluirse del horario.",
          "Decidirse en el lugar más estrecho.",
          "Planificarse como una tarea con tiempo y lugar adecuados."
        ],
        "answer": 2,
        "explanation": "Es parte del recorrido y de su protección. Separar dificultad de movimiento y consecuencias de una caída.",
        "rationales": [
          "Consume tiempo y recursos.",
          "Puede perder opciones de organización.",
          "Es parte del recorrido y de su protección."
        ],
        "source": "e8-scramble",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue dificultad y consecuencia con un ejemplo concreto.",
    "Detecta cuándo cambian supuestos del método.",
    "Comunica un límite y reorganiza solo dentro de la formación recibida."
  ],
  "openAssessment": {
    "prompt": "Divide un croquis ficticio en tres tramos y dos transiciones. Anota dificultad de movimiento, consecuencia posible, información faltante y capacidad requerida; no asignes una ruta real.",
    "rubric": [
      "Distingue dificultad y consecuencia con un ejemplo concreto.",
      "Detecta cuándo cambian supuestos del método.",
      "Comunica un límite y reorganiza solo dentro de la formación recibida."
    ],
    "source": "e8-scramble",
    "difficulty": "integración"
  },
  "diagrams": [
    "e8-transicion"
  ]
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. Lecturas y cuestionarios no acreditan ejecución técnica ni guiado.**

## Conceptos clave y propósito

Terreno mixto, calidad del soporte, ruta, consecuencias, protección y reorganización.

## Teoría y toma de decisiones

La progresión alpina combina lectura del terreno y organización técnica. Un movimiento físicamente sencillo puede tener consecuencias graves si no existe margen ante un error. Por eso dificultad y riesgo no son sinónimos. La elección del método de protección depende de algo más que la capacidad de superar un paso. [Fuente de contraste](#fuente-e8-scramble).

La lectura del terreno incluye soporte, bloques, nieve, hielo, visibilidad y lo que ocurre encima o debajo del grupo. Las condiciones pueden cambiar entre sectores. La roca aparentemente fácil no autoriza a mantener una técnica de nieve; tampoco la presencia de nieve permite tratar cualquier pendiente como un glaciar.

Las variantes por largos, movimiento simultáneo y técnicas especializadas deben evaluarse por función, no como una carrera por reducir tiempos. Una opción más rápida en ejecución puede exigir habilidades que el grupo no tiene. Si la decisión no puede justificarse con capacidades observadas y protección apropiada, el plan necesita modificarse. [Fuente de contraste](#fuente-e8-simul).

Las transiciones suelen concentrar tareas: identificar lugar de reorganización, revisar el tramo siguiente y coordinar material y personas. Su tiempo debe incluirse en planificación. Esperar hasta el punto más incómodo para decidir puede limitar opciones que existían antes.

La práctica útil no consiste solo en llegar al final de un recorrido. El instructor observa selección del itinerario, control de movimiento, comunicación y reconocimiento de límites. El alumno debe poder señalar qué se practicó, bajo qué protección y qué no se evaluó. Ningún resultado de escritorio valida una técnica real de cuerda corta o progresión simultánea.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — análisis previo al taller.** Separar dificultad de movimiento y consecuencias de una caída. Se utiliza al preparar una tarea o revisar un cambio de contexto. Las comprobaciones se organizan por función, soporte, equipo, capacidades y continuidad de protección. La teoría y la rúbrica especifican qué observar en esta unidad.

El instructor selecciona método, protección y condiciones de parada. Si falta una condición esencial o el grupo no comprende una función, no se inicia la maniobra. Las variantes se mantienen dentro del contexto de su fuente: una página sobre vía equipada, un producto o senderismo no constituye un procedimiento universal alpino.

## Caso práctico y aplicación al guiado

**Escenario de aula:** Un caso presenta una cresta ficticia con pasos fáciles pero gran consecuencia de caída, seguida de una placa mojada. El grupo solo ha practicado largos protegidos. Explica por qué llamar fácil a la cresta no justifica cambiar a un método no aprendido.

Distingue hechos, suposiciones y preguntas antes de proponer una decisión. Los ejercicios, casos y rúbricas son propuestas pedagógicas originales de la academia pendientes de revisión docente. No se presentan como protocolos de los organismos citados.

## Errores frecuentes y puntos críticos de seguridad

Usar el grado como única medida; mantener un método por inercia; confundir rapidez y eficacia; improvisar técnica desconocida en una transición; olvidar exposición de quienes esperan.

Una práctica protegida tiene un alcance limitado; no valida todas las condiciones futuras. No se aprende una técnica crítica mediante una caída deliberada ni copiando una imagen en terreno expuesto.

## Material y equipo relacionado

Equipo determinado por terreno y método, casco, arnés, cuerda y protecciones apropiadas. No se identifica una combinación universal de roca, nieve e hielo por llevar todos los dispositivos.

[Consultar inventario](../../equipo/). Identifica modelo, documentación y datos pendientes. No inventes inspecciones ni atribuyas competencia a la compra de un dispositivo.

## Autoevaluación y recuperación activa

- Explica con un ejemplo: Separar dificultad de movimiento y consecuencias de una caída.
- ¿Qué información falta en el caso y qué decisión depende de ella?
- ¿Qué parte puedes revisar documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Divide un croquis ficticio en tres tramos y dos transiciones. Anota dificultad de movimiento, consecuencia posible, información faltante y capacidad requerida; no asignes una ruta real.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Instructor elige terreno protegido y objetivos acotados. Se observa lectura, comunicación y transición del método enseñado. Las técnicas especializadas tienen evaluación independiente, no se autorizan por completar el recorrido.

## Evidencia requerida y criterios de competencia

- Distingue dificultad y consecuencia con un ejemplo concreto.
- Detecta cuándo cambian supuestos del método.
- Comunica un límite y reorganiza solo dentro de la formación recibida.

**COMPETENCIA:** la ejecución debe evaluarse presencialmente en un contexto explícito por instructor competente. Las respuestas escritas no sustituyen esa observación. Se registra qué ocurrió, qué no se evaluó y qué debe corregirse. No hay un número de repeticiones que otorgue competencia automáticamente.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s8-progresion-alpina). Registra solo lo realizado: fecha, lugar, actividad, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Confianza, resultado y evaluación son datos diferentes. No guardar datos médicos, contraseñas ni datos privados de terceros.

## Relaciones con otros módulos

Integra [hielo](../../hielo/), [glaciar](../../glaciar/), [planificación invernal](../planificacion-invernal/) y [anclajes y reuniones](../anclajes-reuniones/). El [programa](../../programa/) muestra prerrequisitos; son académicos, no habilitaciones. [Volver al bloque alpino](../../alpina/).
