---
{
  "title": "Planificación y operación de una salida",
  "description": "Construir un expediente antes/durante/después de una salida.",
  "module": "M20",
  "code": "E4-02",
  "order": 202,
  "minutes": 45,
  "level": "Intermedio",
  "status": "development",
  "reviewDate": "2026-10-22",
  "unit": "U4-02",
  "skills": [
    "s4-plan-operacion"
  ],
  "critical": false,
  "objectives": [
    "Construir un expediente antes/durante/después de una salida.",
    "Distinguir estimaciones de límites de decisión y responsabilidades.",
    "Identificar documentación operativa pendiente sin declarar cumplimiento legal."
  ],
  "prerequisites": [
    "Completar estudio de Fundamentales; la práctica previa debe revisarse presencialmente.",
    "Estudiar Montaña estival: terreno, marcha y campamento."
  ],
  "sources": [
    "nps-plan",
    "sernatur-2026"
  ],
  "pending": [
    "Revisión pedagógica y evaluación situada por instructor competente.",
    "Condiciones, accesos, permisos y compatibilidad del equipo requieren verificación para cada actividad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un campo crítico está pendiente. ¿La plantilla completa autoriza salir?",
        "options": [
          "Sí, si hay suficientes casillas marcadas.",
          "No: el dato crítico debe resolverse o cambiar el plan.",
          "Sí, si el cliente acepta."
        ],
        "answer": 1,
        "explanation": "Las casillas no compensan una condición necesaria sin verificar."
      },
      {
        "prompt": "¿Qué debe conservar el plan B?",
        "options": [
          "Su propia justificación de recursos y retorno.",
          "Solo un nombre alternativo.",
          "El mismo paso comprometido sin revisión."
        ],
        "answer": 0,
        "explanation": "Una alternativa requiere evaluación real de sus dependencias."
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

**TEORÍA.** Un objetivo describe lo que se pretende; una ruta describe un recorrido; un plan explica cómo decidir ante cambios. **Itinerario** organiza etapas. **Turnaround time** es un límite de retorno previamente acordado; no obliga a esperar hasta esa hora si aparece otro motivo para abandonar. **Plan de contingencia** prepara respuestas a cambios previsibles; **plan de emergencia** organiza la solicitud de ayuda y acciones dentro de la competencia del equipo.

## Teoría: de la intención al expediente

La guía de planificación NPS está concebida para visitas diurnas o con pernocta y advierte que una expedición de varios días exige planificación adicional [Referencia: nps-plan](#fuente-nps-plan). En esta academia la plantilla es un instrumento educativo original para hacer explícitos supuestos y responsabilidades. No constituye autorización de salida, protocolo universal ni acreditación de una empresa.

Comienza por definir el objetivo mínimo satisfactorio y quiénes participan. La experiencia debe ser pertinente: caminar largas distancias no prueba destreza en terreno expuesto. Describe capacidades necesarias y verifica cómo se observaron; no uses un quiz ni una declaración de entusiasmo como prueba de aptitud. La condición física relevante se conversa y evalúa por canales adecuados; la academia no almacena fichas médicas.

Divide la ruta en etapas y documenta distancia, desnivel, terreno y dificultad con su fuente. Indica si cada dato es medido, estimado o pendiente. Calcula el retorno por separado, incorpora tareas y pausas, y no presentes el margen como tiempo libre para seguir ascendiendo. El plan B necesita recursos y salida propios; no basta escribir “otra ruta”. El plan C puede ser cancelar antes de iniciar.

## Plantilla operativa antes, durante y después

Usa la plantilla imprimible de la sección **Plan de salida**. Para cada fila anota dato, fuente/fecha, responsable y estado. Si falta una condición crítica, la ficha debe mostrarlo aunque todos los demás campos estén completos.

**Antes:** objetivo; ruta y alternativas; horarios; distancia y desnivel; terreno y dificultad; meteorología y condiciones; equipo individual/colectivo; comunicación; transporte; permisos; seguros; experiencia del grupo; revisión de fichas externas; contactos externos; plan de emergencia; escapes; horario límite y criterios de aborto. La ficha del pasajero y los contactos personales se gestionan fuera del almacenamiento público o local de esta academia: aquí solo se registra que fueron revisados por el responsable.

**Durante:** briefing, recuentos y puntos de reunión, ritmo, referencias de navegación, disponibilidad de agua/comida, observaciones de terreno y meteorología, cambios del grupo, decisión, responsable y siguiente revisión. La falta de novedades no justifica saltarse controles acordados.

**Después:** cierre del aviso, debriefing, incidentes y casi accidentes, decisiones, estado del equipo, correcciones con responsable y fecha. Un registro sin acción posterior sirve como memoria, pero no asegura aprendizaje organizacional.

## Operación de turismo aventura en Chile

SERNATUR publicó el 25 de septiembre de 2026 una explicación de las Resoluciones Exentas 271 y 340. Distingue actividades actualizadas de otras que siguen sujetas a instrumentos anteriores y enlaza parámetros aplicables por actividad [Referencia: sernatur-2026](#fuente-sernatur-2026). Esto demuestra por qué no debe trasladarse automáticamente una exigencia de montaña a senderismo o a otra prestación.

Antes de operar, identifica la actividad efectiva, consulta su instrumento aplicable y documenta los requisitos pertinentes. En esta lección no se afirma haber revisado íntegramente cada resolución, norma técnica, seguro o permiso. Los ratios guía/pasajeros, credenciales, acceso y condiciones contractuales **requieren verificación específica**. Un checklist marcado por el usuario no constituye cumplimiento legal.

## Caso práctico: Casablanca, escenario ficticio

La oferta comercial promete cumbre y horario fijo, pero la ficha técnica contempla una alternativa corta. El pronóstico se actualiza y el transporte tiene poca flexibilidad. El alumno debe encontrar la contradicción antes de recibir pasajeros.

Respuesta orientativa: aclarar qué servicio se ofrece, cómo se informan cambios, qué alternativa es realizable y qué condiciones obligan a cancelar. No resolver la contradicción presionando al guía a mantener una promesa incompatible con el contexto.

## Errores frecuentes y señales de alerta

Copiar tiempos ajenos sin supuestos; dejar permisos “para después”; fijar un objetivo comercial que anula la retirada; confundir un teléfono guardado con un acuerdo de seguimiento; usar la plantilla como formulario médico. Una señal de alerta organizativa es no poder identificar quién toma una decisión o quién confirma el cierre de la actividad.

## Autoevaluación y respuestas explicadas

1. ¿Un plan B es válido si depende del mismo paso comprometido que A? **No aporta una alternativa independiente respecto de ese problema; hay que reconocer la dependencia.**
2. ¿Qué hace útil un horario límite? **Un criterio, responsables y consecuencias acordadas. Es un límite máximo condicionado, no permiso de continuar hasta alcanzarlo.**

## Ejercicios y práctica presencial

**PRÁCTICA:** completa la plantilla con una salida ficticia, usando “pendiente” en vez de inventar datos. Otro alumno recibe solo la ficha y reconstruye decisiones. **SUPERVISIÓN:** un instructor revisa coherencia entre grupo, recorrido, recursos y retirada antes de cualquier aplicación real.

## Evidencia requerida

Expediente fechado, fuentes utilizadas, decisiones pendientes, comunicación al grupo y revisión de contradicciones. La competencia se evalúa observando planificación y actualización en un contexto definido, no contando casillas completas.

## Relaciones con otras habilidades

Esta unidad se integra en la ruta estival. Consulta la ficha de habilidad y sus prerrequisitos en el programa. Registra práctica y evaluación por separado: estudiar y responder correctamente no acredita ejecución. Los ejercicios son propuestas didácticas originales; los casos no son rutas operativas.
