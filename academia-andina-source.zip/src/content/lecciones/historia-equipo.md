---
{
  "title": "Historia del equipo: de objetos a ensayos",
  "description": "Distingue historia del estándar y estado del equipo individual.",
  "module": "M17",
  "code": "E13-04",
  "order": 1304,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U13-04",
  "skills": [
    "s13-historia-equipo"
  ],
  "critical": false,
  "reviewDate": "2026-10-27",
  "objectives": [
    "Distingue historia del estándar y estado del equipo individual.",
    "Compara documentos por la pregunta que pueden responder."
  ],
  "prerequisites": [
    "s13-historia-clubes-chile"
  ],
  "sources": [
    "e13-uiaa"
  ],
  "pending": [
    "Revisión por historiador o especialista de patrimonio e instructor de montaña pendiente.",
    "Primeras ascensiones de Los Lagos, historia completa de escuelas técnicas y testimonios comunitarios requieren investigación y revisión adicionales.",
    "Casos y rúbricas son propuestas pedagógicas originales; no certifican guiado ni competencia práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "La creación de un sello en 1960 demuestra…",
        "options": [
          "Que todo equipo antiguo es utilizable.",
          "Un hito institucional de evaluación de material.",
          "Que su portador sabe asegurar."
        ],
        "answer": 1,
        "explanation": "Es el hecho histórico documentado.",
        "rationales": [
          "La antigüedad no acredita estado.",
          "Es el hecho histórico documentado.",
          "La etiqueta no evalúa a la persona."
        ],
        "source": "e13-uiaa",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una fotografía antigua de una cuerda…",
        "options": [
          "Prueba su resistencia actual.",
          "Sustituye las instrucciones modernas.",
          "Permite observar rasgos visibles, con límites."
        ],
        "answer": 2,
        "explanation": "Delimita lo observable.",
        "rationales": [
          "No mide resistencia.",
          "No es un manual vigente.",
          "Delimita lo observable."
        ],
        "source": "e13-uiaa",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Para usar un dispositivo actual se necesita…",
        "options": [
          "Documentación del modelo y formación apropiada.",
          "Imitar una fotografía histórica.",
          "Conocer la fecha de creación de UIAA."
        ],
        "answer": 0,
        "explanation": "Separa conocimiento histórico y aprendizaje técnico.",
        "rationales": [
          "Separa conocimiento histórico y aprendizaje técnico.",
          "La imagen no basta para una maniobra segura.",
          "Ese dato no enseña el dispositivo."
        ],
        "source": "e13-uiaa",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue historia del estándar y estado del equipo individual.",
    "Compara documentos por la pregunta que pueden responder.",
    "No traslada una técnica histórica directamente a la práctica actual."
  ],
  "openAssessment": {
    "prompt": "Prepara una tabla de cuatro filas: casco, arnés, cuerda y mosquetón. Para cada objeto escribe una pregunta histórica y una comprobación actual distinta.",
    "rubric": [
      "Distingue historia del estándar y estado del equipo individual.",
      "Compara documentos por la pregunta que pueden responder.",
      "No traslada una técnica histórica directamente a la práctica actual."
    ],
    "source": "e13-uiaa",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ACADÉMICA PENDIENTE.** Historia documental e interpretación: no es formación para ejecutar maniobras. No guardes datos médicos, contraseñas, datos privados de terceros ni conocimientos de acceso restringido.

## Conceptos clave y propósito

Diseño, material, ensayo, estándar y uso. Distinguir historia de un sistema de evaluación de la inspección de una pieza concreta.

## Teoría y toma de decisiones

La historia de UIAA sitúa en 1960 el inicio de sus pruebas de cuerdas y la creación de su Safety Label, con reconocimiento internacional en 1965. Más adelante describe el desarrollo de estándares para mosquetones, cascos y arneses. Esta evolución permite estudiar un cambio importante: comparar prestaciones mediante ensayos definidos, en vez de inferirlas solo de la apariencia o de experiencias aisladas.

Un objeto histórico responde preguntas sobre fabricación, desgaste, usos representados y contexto. No demuestra por sí mismo cómo se empleó en cada salida. Un catálogo de época informa lo que ofrecía el fabricante; una fotografía muestra una configuración visible; un informe de ensayo responde a condiciones especificadas. Combinarlos requiere conservar esas diferencias.

Relaciona esta lectura con el casco, arnés, cuerda y mosquetones de tu inventario. La historia de una etiqueta no comprueba la compatibilidad de un conjunto ni el estado de una unidad usada. ATC Guide, Micro Traxion, poleas y otros dispositivos requieren sus instrucciones específicas y práctica supervisada cuando intervienen en seguridad. Este tema no propone recrear técnicas obsoletas ni fija fechas de invención de dispositivos que no se han documentado.

Fuentes de esta unidad: [Referencia 1](#fuente-e13-uiaa). Los ejercicios y criterios siguientes son diseño educativo original, no protocolos de las organizaciones citadas.

## Procedimiento: lectura, comprobaciones y variantes

**PROCEDIMIENTO — análisis documental:** Compara una ficha museográfica o catálogo histórico con una ficha actual identificada. Separa observación de material, función declarada, método de prueba e incertidumbre. Variante: analizar solo imágenes, marcando los aspectos que no pueden verificarse visualmente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un vendedor usa la antigüedad del sello UIAA para afirmar que cualquier cuerda con ese símbolo sigue apta. Explica por qué una historia institucional no es una inspección individual.

## Errores frecuentes y puntos críticos de seguridad

Confundir innovación con adopción universal; reutilizar objetos de colección como EPI; deducir compatibilidad por aspecto; interpretar una etiqueta como competencia del usuario.

Las maniobras críticas requieren formación práctica y supervisión de instructor competente. Estudiar cómo se actuaba antiguamente no habilita a reproducirlo. Este taller no requiere exposición en terreno.

## Material y equipo relacionado

Imágenes o réplicas sin función de seguridad. Equipo real solo para identificar modelo y documentación, sin cargar ni ensayar sistemas.

[Inventario educativo](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con una evidencia y un límite: Distingue historia del estándar y estado del equipo individual.
- Explica con una evidencia y un límite: Compara documentos por la pregunta que pueden responder.
- Explica con una evidencia y un límite: No traslada una técnica histórica directamente a la práctica actual.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Prepara una tabla de cuatro filas: casco, arnés, cuerda y mosquetón. Para cada objeto escribe una pregunta histórica y una comprobación actual distinta.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Revisión documental por instructor y responsable de colección si corresponde. Las demostraciones técnicas reales requieren formación y supervisión independiente.

## Evidencia requerida y criterios de competencia

- Distingue historia del estándar y estado del equipo individual.
- Compara documentos por la pregunta que pueden responder.
- No traslada una técnica histórica directamente a la práctica actual.

**COMPETENCIA:** se requiere revisión humana contextual del trabajo. Una lectura, quiz o guion no certifica guiado, interpretación profesional ni maniobras técnicas. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s13-historia-equipo). Registra fecha, lugar de estudio, documentos, habilidad, repeticiones, errores, correcciones, supervisor y evidencia textual no sensible. Diferencia taller ficticio y actividad real; no inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Historia y patrimonio](../../historia/) · [Territorio](../../territorio/) · [Geología](../../geologia/) · [Ecología](../../ecologia/) · [Programa](../../programa/). La interpretación histórica complementa la formación técnica; no sustituye condiciones ni permisos actuales.
