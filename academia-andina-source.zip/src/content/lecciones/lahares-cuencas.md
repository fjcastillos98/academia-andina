---
{
  "title": "Lahares y cuencas: agua, sedimento y cambios posteriores",
  "description": "Explica por qué un lahar puede ocurrir sin erupción simultánea.",
  "module": "M11",
  "code": "E12-06",
  "order": 1206,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U12-06",
  "skills": [
    "s12-lahares-cuencas"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Explica por qué un lahar puede ocurrir sin erupción simultánea.",
    "Relaciona exposición con cuenca y escenario, no solo distancia."
  ],
  "prerequisites": [
    "s12-corrientes-piroclasticas"
  ],
  "sources": [
    "e12-lahar"
  ],
  "pending": [
    "Revisión por especialista en geología y vulcanología e instructor de montaña pendiente. No valida una ruta, acceso ni evacuación.",
    "Alertas actuales, restricciones, cotas discrepantes y condiciones de terreno requieren verificación independiente; no hay datos operativos en tiempo real.",
    "Casos, rúbricas y ejercicios originales. Las descripciones científicas no acreditan competencia técnica ni un protocolo universal de seguridad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un lahar…",
        "options": [
          "Siempre coincide con lava visible.",
          "Puede ocurrir sin erupción simultánea.",
          "Es sinónimo de colada de lava."
        ],
        "answer": 1,
        "explanation": "Incluye mecanismos posteriores o independientes de emisión.",
        "rationales": [
          "No es condición necesaria.",
          "Incluye mecanismos posteriores o independientes de emisión.",
          "Los componentes y procesos difieren."
        ],
        "source": "e12-lahar",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una foto de cauce seco…",
        "options": [
          "Garantiza el estado de mañana.",
          "Sustituye cartografía de peligros.",
          "Describe ese momento, no una garantía futura."
        ],
        "answer": 2,
        "explanation": "Conserva el alcance de la observación.",
        "rationales": [
          "No incluye cambios posteriores.",
          "No representa escenarios.",
          "Conserva el alcance de la observación."
        ],
        "source": "e12-lahar",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La conexión de cuenca…",
        "options": [
          "Es relevante aunque el sitio esté lejos de la cumbre.",
          "Es irrelevante frente a distancia lineal.",
          "Permite un cruce seguro sin más datos."
        ],
        "answer": 0,
        "explanation": "El recorrido puede seguir drenajes.",
        "rationales": [
          "El recorrido puede seguir drenajes.",
          "Omite la geometría del proceso.",
          "No evalúa condiciones de paso."
        ],
        "source": "e12-lahar",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Explica por qué un lahar puede ocurrir sin erupción simultánea.",
    "Relaciona exposición con cuenca y escenario, no solo distancia.",
    "Distingue depósitos y peligros posteriores de actividad eruptiva actual."
  ],
  "openAssessment": {
    "prompt": "Construye una línea temporal ficticia con erupción, depósito y posible removilización posterior, marcando qué datos faltan para una decisión real.",
    "rubric": [
      "Explica por qué un lahar puede ocurrir sin erupción simultánea.",
      "Relaciona exposición con cuenca y escenario, no solo distancia.",
      "Distingue depósitos y peligros posteriores de actividad eruptiva actual."
    ],
    "source": "e12-lahar",
    "difficulty": "integración"
  },
  "diagrams": [
    "e12-procesos"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ESPECIALISTA PENDIENTE.** Estudio documental: no autoriza aproximación a fenómenos volcánicos ni acredita competencia de guía. No se publican alertas actuales. No guardes datos médicos ni contraseñas.

## Conceptos clave y propósito

Lahar, mezcla de agua y sedimento volcánico, cauce, cuenca, incorporación de material y removilización. El proceso puede ocurrir durante una erupción o sin una erupción simultánea.

## Teoría y toma de decisiones

USGS describe lahares que se desplazan por valles y cauces, incorporando agua y material a lo largo del recorrido. Su comportamiento no es el de una corriente de agua ordinaria ni el de lava. La fusión de nieve o hielo y la removilización de depósitos son mecanismos relevantes, pero no son una lista de condiciones suficientes para predecir un evento individual.

La conexión de una cuenca importa tanto como la proximidad visual a la cumbre. Una persona puede estar lejos del edificio y aun compartir un sistema de drenaje afectable. El razonamiento debe empezar por el proceso y la cartografía oficial, sin trazar un radio circular improvisado. Un cauce seco observado en una visita no demuestra que permanezca así.

Los depósitos dejados por una erupción pueden seguir siendo movilizados después. El fin de la emisión no borra automáticamente las consecuencias territoriales. Una planificación debe distinguir fecha del evento, condiciones posteriores e instrucciones aplicables. No se enseña a cruzar un flujo, aproximarse para medirlo ni escoger por intuición un refugio dentro de un valle.

Fuentes de esta unidad: [Referencia 1](#fuente-e12-lahar). Las aplicaciones de estudio y casos siguientes son elaboración pedagógica original, no protocolos de esas organizaciones.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — lectura y análisis documental:** En un mapa de estudio identifica cuenca y conexiones, después lee el escenario de lahar y su fecha. Separa generación, recorrido y cambios posteriores. Variante: evento asociado a erupción frente a removilización; no trasladar probabilidad entre ambos sin datos.

El ejercicio se realiza en escritorio o lugar autorizado. No expongas al grupo para comprobar actividad, gases, temperatura o estabilidad. Las maniobras críticas de montaña requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una ruta cruza un cauce lejano al cráter. El grupo usa la distancia como único argumento y una foto antigua del cauce seco. Explica las dos insuficiencias.

## Errores frecuentes y puntos críticos de seguridad

Asumir que todo lahar necesita erupción simultánea; considerar un valle seguro por estar lejos; intentar cruzar para no atrasarse; inventar un radio de exclusión.

## Material y equipo relacionado

Mapa y documentos oficiales, planificación y comunicaciones. Un vehículo o cuerda no se presentan como recursos para cruzar un lahar.

[Consultar inventario](../../equipo/). Poseer un dispositivo o equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Justifica con un ejemplo y un límite: Explica por qué un lahar puede ocurrir sin erupción simultánea.
- Justifica con un ejemplo y un límite: Relaciona exposición con cuenca y escenario, no solo distancia.
- Justifica con un ejemplo y un límite: Distingue depósitos y peligros posteriores de actividad eruptiva actual.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Construye una línea temporal ficticia con erupción, depósito y posible removilización posterior, marcando qué datos faltan para una decisión real.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Análisis de cuencas y rutas de evacuación oficiales en aula con especialista; sin entrar en cauces para probar su comportamiento.

## Evidencia requerida y criterios de competencia

- Explica por qué un lahar puede ocurrir sin erupción simultánea.
- Relaciona exposición con cuenca y escenario, no solo distancia.
- Distingue depósitos y peligros posteriores de actividad eruptiva actual.

**COMPETENCIA:** estos criterios requieren revisión humana contextual. Leer, resolver un quiz o presentar un documento no certifica guiado ni ejecución de maniobras. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s12-lahares-cuencas). Registra fecha, escenario, fuente, errores, correcciones, supervisor y evidencia de aprendizaje. Separa ejercicio ficticio de actividad real. No inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Geología y vulcanología](../../geologia/) · [Fichas territoriales](../../territorio/) · [Ecología](../../ecologia/) · [Glaciar](../../glaciar/) · [Planificación](../../planificacion/) · [Programa](../../programa/). El conocimiento del origen del relieve complementa la planificación; no reemplaza información actual ni evaluación de terreno.
