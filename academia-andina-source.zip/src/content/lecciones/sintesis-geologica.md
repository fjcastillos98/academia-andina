---
{
  "title": "Síntesis territorial: defender una afirmación con evidencia",
  "description": "Construye una afirmación trazable con fuente y límite.",
  "module": "M11",
  "code": "E12-10",
  "order": 1210,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U12-10",
  "skills": [
    "s12-sintesis-geologica"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Construye una afirmación trazable con fuente y límite.",
    "Distingue origen documentado de actividad actual y acceso."
  ],
  "prerequisites": [
    "s12-mapas-peligro-volcanico"
  ],
  "sources": [
    "e12-name-lara",
    "e12-name-antillanca",
    "e12-name-tronador",
    "e12-name-mella",
    "e12-name-puntiagudo"
  ],
  "pending": [
    "Revisión por especialista en geología y vulcanología e instructor de montaña pendiente. No valida una ruta, acceso ni evacuación.",
    "Alertas actuales, restricciones, cotas discrepantes y condiciones de terreno requieren verificación independiente; no hay datos operativos en tiempo real.",
    "Casos, rúbricas y ejercicios originales. Las descripciones científicas no acreditan competencia técnica ni un protocolo universal de seguridad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Cerro y complejo volcánico…",
        "options": [
          "Siempre se contradicen.",
          "Obligan a elegir uno y eliminar el otro.",
          "Pueden describir aspectos distintos del mismo ámbito."
        ],
        "answer": 2,
        "explanation": "Mantiene las escalas de descripción.",
        "rationales": [
          "Nombre y clasificación no son equivalentes.",
          "Se pueden conservar con explicación.",
          "Mantiene las escalas de descripción."
        ],
        "source": "e12-name-lara",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La fecha de un centro del grupo…",
        "options": [
          "Debe atribuirse a ese centro sin generalización automática.",
          "Fecha toda la montaña.",
          "Prueba el estado actual."
        ],
        "answer": 0,
        "explanation": "Respeta sujeto y alcance.",
        "rationales": [
          "Respeta sujeto y alcance.",
          "Se pierde precisión de entidad.",
          "Historia y estado actual son diferentes."
        ],
        "source": "e12-name-lara",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un expediente académico útil…",
        "options": [
          "Llena vacíos por intuición.",
          "Muestra pendientes y cómo verificarlos.",
          "Certifica guiado por completarlo."
        ],
        "answer": 1,
        "explanation": "Hace revisable el razonamiento.",
        "rationales": [
          "Fabricaría datos.",
          "Hace revisable el razonamiento.",
          "No existe esa certificación."
        ],
        "source": "e12-name-lara",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Construye una afirmación trazable con fuente y límite.",
    "Distingue origen documentado de actividad actual y acceso.",
    "Resuelve diferencias de entidad antes de comparar cifras."
  ],
  "openAssessment": {
    "prompt": "Escribe un informe de una página sobre uno de los cuatro casos: afirmación, evidencia, límites, datos operativos pendientes y explicación al visitante.",
    "rubric": [
      "Construye una afirmación trazable con fuente y límite.",
      "Distingue origen documentado de actividad actual y acceso.",
      "Resuelve diferencias de entidad antes de comparar cifras."
    ],
    "source": "e12-name-lara",
    "difficulty": "integración"
  },
  "diagrams": [
    "e12-documentos"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ESPECIALISTA PENDIENTE.** Estudio documental: no autoriza aproximación a fenómenos volcánicos ni acredita competencia de guía. No se publican alertas actuales. No guardes datos médicos ni contraseñas.

## Conceptos clave y propósito

Trazabilidad, entidad geológica, atribución, incertidumbre, dato histórico y dato operativo. La conclusión debe tener la misma escala y alcance que la evidencia que la respalda.

## Teoría y toma de decisiones

Los cuatro suplementos documentales de este bloque profundizan preguntas concretas: Sarnoso y el alcance de “cerro”; Casablanca dentro de Antillanca; Tronador y los centros de su grupo; Puntiagudo frente a Cordón Cenizos. No reemplazan las siete fichas territoriales anteriores ni completan sus rutas, accesos y cotas pendientes.

En Sarnoso, una descripción de aparato erosionado y centros superpuestos respalda el origen volcánico, pero no una edad única del conjunto. En Tronador, una referencia a Fonck no se traslada sin más a la cumbre principal. En Puntiagudo, los eventos del sistema catalogado deben atribuirse al centro señalado. Estos ejemplos enseñan a leer el sujeto de una afirmación, no solo su cifra o fecha.

Para comunicar al grupo prepara una explicación con dato, fuente y límite. Después separa las preguntas operativas que requieren otros documentos: accesos, restricciones y condiciones actuales. Un buen expediente no elimina vacíos; los hace visibles y asigna cómo resolverlos. En esta academia una conclusión documental no acredita competencia de guía ni valida maniobras. Su revisión debe incluir precisión científica y claridad para personas sin formación geológica.

Fuentes de esta unidad: [Referencia 1](#fuente-e12-name-lara) · [Referencia 2](#fuente-e12-name-antillanca) · [Referencia 3](#fuente-e12-name-tronador) · [Referencia 4](#fuente-e12-name-mella) · [Referencia 5](#fuente-e12-name-puntiagudo). Las aplicaciones de estudio y casos siguientes son elaboración pedagógica original, no protocolos de esas organizaciones.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — lectura y análisis documental:** Formula una afirmación; identifica entidad y escala; cita el pasaje; redacta una conclusión limitada; añade pendiente y fuente necesaria. Variante: dos fuentes que parecen contradecirse pueden describir entidades diferentes; compruébalo antes de decidir que una está equivocada.

El ejercicio se realiza en escritorio o lugar autorizado. No expongas al grupo para comprobar actividad, gases, temperatura o estabilidad. Las maniobras críticas de montaña requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un cartel turístico llama cerro a Sarnoso; un artículo describe un complejo volcánico. Redacta una explicación compatible con ambos usos sin inventar cota, extinción o ruta.

## Errores frecuentes y puntos críticos de seguridad

Copiar una última erupción de catálogo como si correspondiera a cada cumbre; resolver discrepancias por promedio; inventar traducciones, primeras ascensiones o permisos; ocultar incertidumbres para sonar experto.

## Material y equipo relacionado

Fuentes documentales, cuaderno y fichas comparables. No se necesitan salidas a zonas de peligro para completar el expediente académico.

[Consultar inventario](../../equipo/). Poseer un dispositivo o equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Justifica con un ejemplo y un límite: Construye una afirmación trazable con fuente y límite.
- Justifica con un ejemplo y un límite: Distingue origen documentado de actividad actual y acceso.
- Justifica con un ejemplo y un límite: Resuelve diferencias de entidad antes de comparar cifras.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Escribe un informe de una página sobre uno de los cuatro casos: afirmación, evidencia, límites, datos operativos pendientes y explicación al visitante.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Presentación ante especialista e instructor con preguntas cruzadas; revisar si cada conclusión conserva la escala de su fuente.

## Evidencia requerida y criterios de competencia

- Construye una afirmación trazable con fuente y límite.
- Distingue origen documentado de actividad actual y acceso.
- Resuelve diferencias de entidad antes de comparar cifras.

**COMPETENCIA:** estos criterios requieren revisión humana contextual. Leer, resolver un quiz o presentar un documento no certifica guiado ni ejecución de maniobras. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s12-sintesis-geologica). Registra fecha, escenario, fuente, errores, correcciones, supervisor y evidencia de aprendizaje. Separa ejercicio ficticio de actividad real. No inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Geología y vulcanología](../../geologia/) · [Fichas territoriales](../../territorio/) · [Ecología](../../ecologia/) · [Glaciar](../../glaciar/) · [Planificación](../../planificacion/) · [Programa](../../programa/). El conocimiento del origen del relieve complementa la planificación; no reemplaza información actual ni evaluación de terreno.
