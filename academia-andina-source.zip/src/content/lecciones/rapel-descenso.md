---
{
  "title": "Rápel y descenso de un pasajero: funciones y límites",
  "description": "Distinguir rápel de descenso controlado desde una reunión.",
  "module": "M08",
  "code": "E43-18",
  "order": 317,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U43-09",
  "skills": [
    "s43-rapel-descenso"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir rápel de descenso controlado desde una reunión.",
    "Analizar funciones de control, respaldo y comunicación sin proponer un montaje universal.",
    "Justificar criterios de aborto y alternativas para un caso conceptual del Calbuco."
  ],
  "prerequisites": [
    "s43-analisis-reunion"
  ],
  "sources": [
    "bd-atc",
    "petzl-partner",
    "petzl-transferencia"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "descenso-funciones"
  ],
  "preparation": [
    "Explicar los conceptos sin confundir un modelo con una maniobra.",
    "Reconocer al menos dos errores del caso y justificar una alternativa.",
    "Identificar la documentación y las competencias prácticas que faltan."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "bd-atc",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "En el caso Calbuco falta saber si la cuerda alcanza.",
        "options": [
          "La técnica conocida compensa esa duda.",
          "Debe resolverse antes de plantear la ejecución.",
          "El pasajero puede comprobarlo al bajar."
        ],
        "answer": 1,
        "explanation": "Es información crítica previa.",
        "rationales": [
          "La competencia no crea longitud.",
          "Es información crítica previa.",
          "Eso transfiere incertidumbre a una exposición real."
        ],
        "source": "bd-atc",
        "kind": "caso",
        "difficulty": "intermedia"
      },
      {
        "prompt": "Rápel y descenso de un pasajero…",
        "options": [
          "Son siempre intercambiables.",
          "Tienen idéntica comunicación.",
          "Difieren en funciones y contingencias; requieren formación específica."
        ],
        "answer": 2,
        "explanation": "La tarea debe analizarse de forma completa.",
        "rationales": [
          "Cambian operador y control.",
          "Pueden cambiar visibilidad y confirmaciones.",
          "La tarea debe analizarse de forma completa."
        ],
        "source": "petzl-partner",
        "kind": "aplicación",
        "difficulty": "intermedia"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

En un rápel, quien desciende participa normalmente en el control de su desplazamiento mediante un sistema definido. En un descenso de otra persona, el operador puede permanecer arriba y controlar su movimiento. Esa diferencia funcional afecta comunicación, observación y contingencias; no basta cambiar quién sostiene la cuerda.

## Teoría y decisiones

Analiza el recorrido completo, no solo el dispositivo. Deben conocerse destino, obstáculos, aristas, dirección de carga, longitud útil, extremos y posibilidad de comunicación durante toda la acción. Un aparato capaz de controlar fricción no vuelve adecuado un anclaje, una cuerda corta o una trayectoria desconocida.

Un autobloqueante es un componente cuya función depende de la configuración; «respaldo» es una función del sistema. No son sinónimos automáticos de independencia ni de control garantizado. Su compatibilidad, colocación y comportamiento necesitan fuente técnica y taller. Aquí no se ofrece una secuencia de instalación o liberación bajo carga.

Control del extremo de cuerda significa identificar qué puede ocurrir al agotarse el recorrido o al perder referencia de un extremo; la solución concreta pertenece al sistema y escenario. La longitud nominal no equivale a longitud disponible para descender: intervienen conexiones, recorrido y modo de uso. No se calcula una longitud para la Pirámide Cumbrera sin mediciones y planificación verificadas.

Los manuales de dispositivos delimitan modos y compatibilidades; en ATC Guide no deben confundirse funciones de aseguramiento, bloqueo y descenso [Referencia: bd-atc](#fuente-bd-atc). Una técnica de rescate profesional puede depender de dispositivos, accesos y condiciones que no existen en una cordada de montaña [Referencia: petzl-transferencia](#fuente-petzl-transferencia).

El guía que permanece en la reunión necesita prever el control del pasajero, del resto del grupo y de su propia situación final. Bajar a una persona sin una solución para quien queda arriba puede crear una nueva emergencia. No se presupone que el cliente puede liberar conexiones, cambiar de sistema o ayudar al llegar.

## Caso práctico y aplicación al guiado

**Pirámide Cumbrera del Calbuco, escenario ficticio:** se propone que el guía permanezca arriba y baje a un pasajero. No hay confirmación de anclajes, reunión, pendiente, longitud, recepción abajo ni condiciones de nieve/hielo. Entrega: información necesaria; peligros de operador y pasajero; alternativas, incluida renuncia al tramo; funciones conceptuales de soporte, frenado y protección; protocolo de comunicación; recursos y criterios de aborto; plan B y salida del guía. Ningún esquema de esta unidad autoriza ese descenso real.

## Errores frecuentes y señales de alerta

Convertir una fotografía en evaluación del anclaje; confiar en que «la cuerda alcanza»; usar autobloqueante como palabra tranquilizadora; ignorar al último integrante; permitir una transición sin confirmación; pretender liberar un sistema cargado sin entrenamiento.

## Autoevaluación y respuestas explicadas

¿El pasajero descendido deja al guía fuera de riesgo? **No, su permanencia y retirada forman parte del plan.** ¿Un dispositivo bloqueado se libera por intuición? **No: la liberación puede implicar pérdida de control y requiere técnica específica.**

## Ejercicios y práctica presencial

Individual: diagrama de funciones y lista de información ausente para el caso. Presencial: formación diferenciada de rápel y descenso de otra persona con instructor, entorno controlado y medidas apropiadas. No realizar ensayos desde balcones, árboles o pendientes.

## Evidencia requerida

Análisis del caso con alternativas y límites, comprobación documental del equipo y evaluación presencial separada por técnica. No se valida el caso Calbuco ni una competencia de rescate.

## Relaciones con otras habilidades

Revisa los prerrequisitos y el contrato de habilidad de esta unidad en el programa. Contrasta la explicación con las fuentes indicadas: las cifras de un ejercicio no son límites de uso de un equipo. Toda transferencia a una situación con personas requiere formación y revisión presencial.
