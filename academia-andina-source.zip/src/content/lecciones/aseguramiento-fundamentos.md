---
{
  "title": "Aseguramiento, dispositivos y descenso controlado",
  "description": "Identificar cuerda activa, ramal de frenado y funciones del asegurador.",
  "module": "M07",
  "code": "E43-15",
  "order": 314,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U43-06",
  "skills": [
    "s43-aseguramiento-fundamentos"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Identificar cuerda activa, ramal de frenado y funciones del asegurador.",
    "Distinguir dispositivo tubular, frenado asistido y captura de progreso.",
    "Reconocer errores de compatibilidad y comunicación que impiden comenzar una práctica."
  ],
  "prerequisites": [
    "s43-encordamiento-contexto"
  ],
  "sources": [
    "bd-atc",
    "petzl-partner"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "aseguramiento-funciones"
  ],
  "preparation": [
    "Explicar los conceptos sin confundir un modelo con una maniobra.",
    "Reconocer al menos dos errores del caso y justificar una alternativa.",
    "Identificar la documentación y las competencias prácticas que faltan."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "bd-atc",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Frenado asistido significa…",
        "options": [
          "No hace falta controlar el sistema.",
          "Una función del modelo que no elimina las tareas del asegurador.",
          "Que sirve cualquier cuerda."
        ],
        "answer": 1,
        "explanation": "Hay que seguir el manual y la formación específica.",
        "rationales": [
          "La asistencia no reemplaza el control.",
          "Hay que seguir el manual y la formación específica.",
          "La compatibilidad sigue siendo obligatoria."
        ],
        "source": "bd-atc",
        "kind": "conocimiento",
        "difficulty": "intermedia"
      },
      {
        "prompt": "Un alumno cambia de modelo de dispositivo. ¿Qué corresponde?",
        "options": [
          "Transferir todos los gestos automáticamente.",
          "Omitir el control cruzado.",
          "Revisar manual, compatibilidad y formación del modelo."
        ],
        "answer": 2,
        "explanation": "La semejanza externa no demuestra equivalencia.",
        "rationales": [
          "Pueden cambiar funciones y límites.",
          "La novedad aumenta la necesidad de comprobación.",
          "La semejanza externa no demuestra equivalencia."
        ],
        "source": "bd-atc",
        "kind": "aplicación",
        "difficulty": "intermedia"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

Asegurador y asegurado son funciones dentro de un sistema. El ramal que va hacia la persona y el ramal de frenado deben identificarse sin ambigüedad; «cuerda activa» no debe usarse sin señalar cuál es. Frenado asistido no significa manos libres ni ausencia de supervisión.

## Teoría y decisiones

Un dispositivo no actúa separado de la cuerda, conectores, posición, tarea y comportamiento del usuario. Un tubular gestiona rozamiento mediante su configuración; un dispositivo con asistencia incorpora una función adicional cuyo alcance depende del modelo y modo de uso. No trasladar gestos, diámetros o procedimientos de desbloqueo entre aparatos por semejanza visual.

El ATC Guide tiene documentación propia, distinta de la de ATC Alpine Guide. Su manual debe contrastarse con el ejemplar y la cuerda concretos. La función de asegurar y una eventual función de descenso tienen requisitos diferentes: no convertir la capacidad de bloquear en capacidad de liberar de cualquier manera [Referencia: bd-atc](#fuente-bd-atc). Aquí no se enseñan secuencias de desbloqueo ni se ofrecen rangos como si fueran universales.

La posición del asegurador condiciona observación, estabilidad y dirección de las fuerzas. La decisión no consiste en estar «cerca» o «lejos» por regla fija, sino en comprender el sistema y sus limitaciones en ese escenario. La distracción, el exceso de confianza y la presión por atender al resto del grupo pueden degradar el control incluso con material correctamente seleccionado.

Antes de una demostración, el instructor identifica la configuración, la función de cada mano y las comprobaciones correspondientes al dispositivo. Durante un descenso controlado, también se requiere conocer destino, longitud útil, recorrido, comunicación y cómo se respondería a una interrupción. No se considera una extensión trivial de «dar cuerda».

Para el guía, una explicación pedagógica debe comprobar que el alumno entiende qué función no puede abandonar. Pedir que repita un movimiento sin explicar su finalidad no permite evaluar comprensión ni detectar transferencia equivocada a otro aparato.

## Caso práctico y aplicación al guiado

Un alumno conoce otro asegurador y afirma que el ATC Guide se maneja igual. El guía recibe además una pregunta de un pasajero mientras atiende el sistema. Identifica dos fallos potenciales de organización y una alternativa de enseñanza: detener la transición, asignar atención al grupo y revisar manual y técnica con instructor.

## Errores frecuentes y señales de alerta

Considerar la asistencia un sustituto de control; usar un dispositivo como polea bloqueadora sin documentación; mezclar modelos; no prever descenso; hablar sin confirmar. El control cruzado previo no elimina la necesidad de atención continua.

## Autoevaluación y respuestas explicadas

¿Bloquear y descender son la misma tarea? **No; liberar y controlar exige funciones y formación específicas.** ¿Un rango de diámetro basta? **No; también importan tipo, condición y configuración documentada.**

## Ejercicios y práctica presencial

Comparar manuales de dos aparatos sin montarlos. En taller presencial, el instructor dirige simulación controlada con respaldo apropiado, revisión cruzada y respuesta a una interrupción. No cargar personas a partir de esta lectura.

## Evidencia requerida

Ficha de modelo/manual, explicación de ramales y funciones, registro de errores observados por instructor. Evaluación presencial antes de asegurar a terceros.

## Relaciones con otras habilidades

Revisa los prerrequisitos y el contrato de habilidad de esta unidad en el programa. Contrasta la explicación con las fuentes indicadas: las cifras de un ejercicio no son límites de uso de un equipo. Toda transferencia a una situación con personas requiere formación y revisión presencial.
