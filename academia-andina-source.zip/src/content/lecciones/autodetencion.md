---
{
  "title": "Autodetención: reconocer límites antes de una caída",
  "description": "Distinguir prevención del resbalón y detención de una caída.",
  "module": "M02",
  "code": "E5-19",
  "order": 518,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-16",
  "skills": [
    "s5-autodetencion"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir prevención del resbalón y detención de una caída.",
    "Analizar orientación corporal, velocidad y consecuencias sin reproducir una receta.",
    "Definir qué debe controlar un instructor en una práctica."
  ],
  "prerequisites": [
    "s5-piolet",
    "s5-cramponaje"
  ],
  "sources": [
    "e5-ms-winter",
    "e5-bmc-arrest"
  ],
  "pending": [
    "Revisión de instructor y contraste con manuales exactos del equipo disponible. Cualquier aplicación territorial permanece pendiente de reconocimiento y condiciones actuales."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una detención lograda en un taller permite concluir…",
        "options": [
          "Que todas las caídas podrán detenerse.",
          "Que hubo un resultado en condiciones concretas.",
          "Que no es necesario elegir terreno."
        ],
        "answer": 1,
        "explanation": "El contexto limita la evidencia.",
        "rationales": [
          "Generalización no respaldada.",
          "Describe lo observado.",
          "La prevención sigue siendo fundamental."
        ],
        "source": "e5-bmc-arrest",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Dónde decidir la práctica real?",
        "options": [
          "En cualquier pendiente corta.",
          "Solo mirando su inclinación.",
          "Con instructor que evalúe terreno, final y organización."
        ],
        "answer": 2,
        "explanation": "El lugar y la progresión forman parte de la seguridad del taller.",
        "rationales": [
          "Ignora obstáculos y final.",
          "Una variable no basta.",
          "Integra condiciones y supervisión."
        ],
        "source": "e5-ms-winter",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Por qué analizar el retraso de respuesta?",
        "options": [
          "Porque cambian velocidad y opciones.",
          "Porque fija un tiempo universal de éxito.",
          "Porque hace innecesaria la prevención."
        ],
        "answer": 0,
        "explanation": "El movimiento evoluciona durante la caída.",
        "rationales": [
          "Explica el mecanismo sin prometer resultados.",
          "No se dispone de ese umbral.",
          "No elimina consecuencias."
        ],
        "source": "e5-bmc-arrest",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "Distingue prevención, apoyo y detención.",
    "Identifica variables y consecuencias faltantes.",
    "Explica por qué necesita taller y evaluación contextual."
  ],
  "openAssessment": {
    "prompt": "Compara dos escenarios ficticios de caída y explica qué información falta, qué no puede garantizar la autodetención y qué revisarías antes de una práctica.",
    "rubric": [
      "Distingue prevención, apoyo y detención.",
      "Identifica variables y consecuencias faltantes.",
      "Explica por qué necesita taller y evaluación contextual."
    ],
    "source": "e5-ms-winter",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Reconoce variables de una caída y el tramo de consecuencias, no solo el punto donde empieza. Describe lo observado antes de inferir éxito posible.

## Teoría y toma de decisiones

Autodetención designa la respuesta aprendida para intentar detener una caída deslizante, habitualmente con piolet en este contexto. No debe confundirse con una medida que vuelva aceptable cualquier pendiente. El BMC advierte que la detención puede ser difícil incluso para personas entrenadas; su extracto consultado enfatiza prevenir el resbalón [fuente](#fuente-e5-bmc-arrest). Esta unidad prepara el reconocimiento de escenarios y la conversación con un instructor, no una secuencia que pueda leerse durante una emergencia.

Analiza una caída por sus condiciones iniciales y consecuencias posibles. Importan superficie, inclinación y continuidad del terreno, obstáculos, exposición final, velocidad adquirida, posición del cuerpo, orientación de cabeza y pies, mochila y equipo. No se asignan probabilidades de éxito ni una pendiente límite. Una imagen estática no muestra cuánto tiempo transcurrió ni cómo responde la nieve al piolet. Si falta esa información, reconocer el vacío es parte de la respuesta correcta.

Posición corporal y orientación afectan qué movimientos serían necesarios y qué riesgos podrían aparecer. En una práctica, el instructor debe observar esa relación directamente, corregirla y decidir progresión. Repetir un nombre de técnica no demuestra que puedas orientarte bajo estrés. Del mismo modo, conseguir una detención en una superficie de entrenamiento no permite extrapolar el resultado a nieve muy dura, hielo, mayor velocidad o un tramo con rocas. La evaluación siempre debe identificar el contexto observado.

El retraso importa porque durante el deslizamiento cambian velocidad, distancia disponible y posibilidad de control. En el ejercicio teórico, dibuja dos puntos sobre una ladera ficticia: inicio de pérdida de equilibrio y comienzo de respuesta. Sin introducir cifras no verificadas, explica por qué una reacción posterior no equivale a una anterior. El objetivo es comprender la pérdida de opciones, no aprender una distancia de frenado. No se realiza ningún ensayo real a partir del dibujo.

Los crampones y el piolet añaden elementos que pueden engancharse o lesionar. Su gestión durante una práctica pertenece al diseño del taller y a las instrucciones presenciales; no se improvisa una caída con crampones para comprobar esta lección. Tampoco se practica en una pendiente elegida solo por parecer suave. El lugar necesita evaluación de recorrido, final de deslizamiento, obstáculos, nieve, personas alrededor y método de supervisión. Mountaineering Scotland presenta estas habilidades como parte de formación práctica con instructores [fuente](#fuente-e5-ms-winter).

Para aplicar el aprendizaje al guiado, plantea una pregunta previa: si alguien resbala en el terreno propuesto, ¿qué consecuencias no puedo gestionar? La respuesta puede exigir retirar el objetivo o adquirir formación antes de continuar. Una demostración de autodetención no sustituye planificación, selección de terreno ni aseguramiento cuando proceda. En el diario, diferencia explicación conceptual, ejercicios efectivamente realizados y evaluación contextual. No registres «dominio universal» ni interpretes confianza subjetiva como evidencia de competencia.

## Qué observo, qué significa y qué no puedo concluir

REQUIERE PRÁCTICA PRESENCIAL SUPERVISADA. No utilizar esta lección como única preparación para una emergencia. No realizar deslizamientos deliberados sin instructor.

## Caso práctico y aplicación al guiado

Una persona propone atravesar un tramo expuesto porque vio un video de autodetención. Identifica qué premisa de su decisión es inválida.

## Errores frecuentes y señales de alerta

Tratar el piolet como garantía; extrapolar un ensayo exitoso; practicar sin evaluar final de pendiente; olvidar riesgos de enganche y compañeros.

## Autoevaluación y respuesta razonada

Compara dos escenarios ficticios de caída y explica qué información falta, qué no puede garantizar la autodetención y qué revisarías antes de una práctica.

## Ejercicios y práctica supervisada

Antes del taller, analizar dibujos y explicar límites. El instructor selecciona lugar, equipo, progresión y criterios de interrupción; el alumno registra solo lo realizado.

## Evidencia requerida

- Distingue prevención, apoyo y detención.
- Identifica variables y consecuencias faltantes.
- Explica por qué necesita taller y evaluación contextual.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-autodetencion).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
