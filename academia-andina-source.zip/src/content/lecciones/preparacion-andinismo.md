---
{
  "title": "Preparación física para andinismo",
  "description": "Distinguir capacidades físicas y demandas de una actividad.",
  "module": "M22",
  "code": "E4-11",
  "order": 211,
  "minutes": 45,
  "level": "Intermedio",
  "status": "development",
  "reviewDate": "2026-10-22",
  "unit": "U4-11",
  "skills": [
    "s4-preparacion-andinismo"
  ],
  "critical": false,
  "objectives": [
    "Distinguir capacidades físicas y demandas de una actividad.",
    "Separar preparación general, guiado y expedición específica.",
    "Proponer observaciones de adaptación sin prescribir un plan clínico."
  ],
  "prerequisites": [
    "Completar estudio de Fundamentales; la práctica previa debe revisarse presencialmente.",
    "Estudiar Incidentes, telecomunicaciones y debriefing."
  ],
  "sources": [
    "acsm-fuerza",
    "acsm-aerobico",
    "nps-marcha"
  ],
  "pending": [
    "Revisión pedagógica y evaluación situada por instructor competente.",
    "Condiciones, accesos, permisos y compatibilidad del equipo requieren verificación para cada actividad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "La preparación de guía añade…",
        "options": [
          "Solo velocidad.",
          "Nada respecto de una salida individual.",
          "Demandas de atención, coordinación y responsabilidad."
        ],
        "answer": 2,
        "explanation": "El rendimiento deportivo aislado no observa todas las tareas del guiado."
      },
      {
        "prompt": "La hipertrofia y la resistencia aeróbica…",
        "options": [
          "Son la misma capacidad.",
          "Son adaptaciones distintas.",
          "Se certifican por un quiz."
        ],
        "answer": 1,
        "explanation": "El tamaño muscular no demuestra automáticamente capacidad aeróbica."
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

**TEORÍA.** Fuerza máxima describe capacidad de producir fuerza elevada; hipertrofia, aumento del tamaño muscular; potencia, producción de trabajo por tiempo; resistencia muscular, sostener o repetir esfuerzos locales. La resistencia aeróbica se relaciona con sostener actividad mediante procesos de aporte y uso de oxígeno. No son capacidades intercambiables ni se deducen unas de otras por apariencia corporal.

ACSM distingue resultados de fuerza, hipertrofia, potencia y rendimiento, y su actualización de 2026 destaca la importancia de la participación regular [Referencia: acsm-fuerza](#fuente-acsm-fuerza). Sus recomendaciones generales no equivalen a un plan personalizado para guiar en montaña. Las orientaciones de actividad aeróbica son un marco general de salud, no una prueba de aptitud expedicionaria [Referencia: acsm-aerobico](#fuente-acsm-aerobico).

## Teoría: especificidad sin perder la base

Caminar sobre terreno variable añade demandas de equilibrio, control del descenso, duración y carga. La economía de marcha describe el coste de desplazarse en unas condiciones determinadas; no se reduce a caminar más rápido. El desnivel acumulado y el peso transportado ayudan a describir la tarea, pero faltan superficie, duración, distribución del esfuerzo y recuperación.

El trabajo excéntrico implica producir fuerza mientras el músculo se alarga; resulta relevante para comprender el control del descenso. Aprender el concepto no prescribe cargas ni volumen. Movilidad y estabilidad se estudian por su relación con tareas concretas, no como una promesa genérica de prevenir todas las lesiones.

## Tres objetivos diferentes

| Preparación | Pregunta que orienta el estudio |
| --- | --- |
| Andinista | ¿Qué demandas tiene el objetivo deportivo y qué capacidades debo desarrollar? |
| Guía | ¿Puedo sostener atención, comunicación y tareas de responsabilidad además de desplazarme? |
| Expedición específica | ¿Qué duración, altitud, carga, terreno y recuperación condicionan ese objetivo? |

No existe una equivalencia automática entre buen rendimiento deportivo y capacidad de guiar. Tampoco una temporada de entrenamiento prueba aclimatación para una expedición de altura. Cada dimensión necesita preparación y evaluación pertinente.

## Progresión y recuperación

Como marco educativo, organiza base → desarrollo → específico → puesta a punto → expedición → recuperación. La base establece regularidad y capacidades generales; el desarrollo trabaja demandas identificadas; lo específico se aproxima gradualmente a la tarea; la puesta a punto busca llegar recuperado manteniendo preparación; después se revisan respuesta y recuperación. No se asignan aquí semanas, intensidades, calorías ni cargas obligatorias.

Un registro de estudio puede describir duración, terreno, carga, percepción de esfuerzo y recuperación percibida sin almacenar datos médicos. No aumentes simultáneamente todas las variables porque un día resultó fácil. La respuesta individual y el asesoramiento competente deben orientar una planificación real, especialmente ante síntomas, lesión o cambios importantes de salud.

## Sueño, nutrición e hidratación como preguntas de preparación

Planifica oportunidades de descanso y abastecimiento, y evita probar por primera vez una estrategia de alimentación en una actividad exigente. En esta introducción no se indican dietas, cantidades de agua ni cambios de composición corporal. La composición corporal no sustituye rendimiento, técnica ni juicio; perder peso no certifica capacidad de ascenso.

Para estudiar una expedición, identifica qué decisiones sobre sueño, alimentación y recuperación requieren asesoramiento específico. Escribe las preguntas y conserva las respuestas en el canal adecuado, sin cargar informes médicos o bioimpedancia en la academia.

## Caso práctico: deportista rápido, guía sobrecargado

Caso ficticio: una persona completa una caminata individual rápidamente. Al conducir un grupo lleva más material, responde preguntas, adapta pausas y termina exhausta. Concluye que necesita “solo más fuerza”.

Respuesta orientativa: comparar duración, carga, tareas cognitivas y organización antes de elegir una capacidad como explicación única. El caso no permite diagnosticar ni prescribir. Sí permite identificar información necesaria para diseñar una preparación pertinente.

## Errores frecuentes y señales de alerta

Copiar entrenamiento de otro; equiparar hipertrofia y resistencia; usar calorías del reloj como medida de competencia; normalizar agotamiento persistente; omitir recuperación; confundir simulación de carga con permiso para esfuerzos máximos. Ante síntomas o dolor, el objetivo educativo no justifica forzar una prueba física.

## Autoevaluación y respuestas explicadas

1. ¿Por qué una prueba individual no acredita preparación para guiar? **No observa necesariamente carga, continuidad de atención, coordinación y responsabilidad de esa tarea.**
2. ¿Qué cambia entre preparación general y específica? **La segunda responde a demandas concretas del objetivo; no elimina la necesidad de base ni recuperación.**

## Ejercicios y práctica presencial

Describe las demandas de tres objetivos ficticios: caminata de un día, guiado estival y expedición. Separa capacidades físicas, técnicas y organizativas. Con un profesional competente, selecciona evaluaciones apropiadas antes de plantear cargas; esta unidad no incluye pruebas máximas autoadministradas.

## Evidencia requerida

Mapa de demandas, preguntas pendientes y justificación de una progresión conceptual. No se evalúa composición corporal ni se otorga aptitud médica.

## Relaciones con otras habilidades

Esta unidad se integra en la ruta estival. Consulta la ficha de habilidad y sus prerrequisitos en el programa. Registra práctica y evaluación por separado: estudiar y responder correctamente no acredita ejecución. Los ejercicios son propuestas didácticas originales; los casos no son rutas operativas.
