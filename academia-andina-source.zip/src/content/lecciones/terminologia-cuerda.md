---
{
  "title": "Terminología y lectura visual de un sistema",
  "description": "Reconocer cabo, chicote, firme, seno, vuelta y gaza en un esquema.",
  "module": "M07",
  "code": "E43-02",
  "order": 301,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U43-02",
  "skills": [
    "s43-terminologia-cuerda"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Reconocer cabo, chicote, firme, seno, vuelta y gaza en un esquema.",
    "Distinguir anclaje, reunión, punto maestro y sistema de aseguramiento.",
    "Describir conexiones con términos verificables y confirmar significados regionales."
  ],
  "prerequisites": [
    "s43-fisica-cuerda"
  ],
  "sources": [
    "petzl-nudos-435",
    "icar-tipos"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "partes-cuerda",
    "familias-ocho"
  ],
  "preparation": [
    "Explicar los conceptos sin confundir un modelo con una maniobra.",
    "Reconocer al menos dos errores del caso y justificar una alternativa.",
    "Identificar la documentación y las competencias prácticas que faltan."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "petzl-nudos-435",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "«Ocho doble» sin imagen ni función…",
        "options": [
          "Basta para elegir un montaje.",
          "Puede ser ambiguo entre escuelas.",
          "Siempre es dos nudos distintos."
        ],
        "answer": 1,
        "explanation": "Hay que acordar configuración y función antes de actuar.",
        "rationales": [
          "El nombre no define el sistema.",
          "Hay que acordar configuración y función antes de actuar.",
          "No se puede deducir eso del nombre."
        ],
        "source": "petzl-nudos-435",
        "kind": "conocimiento",
        "difficulty": "intermedia"
      },
      {
        "prompt": "Una cuerda tendida es una línea de vida apta…",
        "options": [
          "Por estar tensada.",
          "Si tiene un color visible.",
          "Solo puede evaluarse con diseño, instalación, documentación y uso definidos."
        ],
        "answer": 2,
        "explanation": "Falta evaluar el sistema completo, no solo nombrarlo.",
        "rationales": [
          "La tensión no valida la función.",
          "El color no acredita aptitud.",
          "Falta evaluar el sistema completo, no solo nombrarlo."
        ],
        "source": "icar-tipos",
        "kind": "aplicación",
        "difficulty": "intermedia"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

La nomenclatura facilita una comunicación verificable. En esta academia, chicote es el extremo libre; firme, el tramo de referencia o que recibe la carga según el contexto; seno, una porción doblada sin exigir cruce; vuelta, un recorrido alrededor de un objeto; gaza, un ojo formado en la cuerda; bucle, una curvatura que puede cerrar o cruzarse según el uso del término. Cabo puede significar extremo o cuerda en distintas escuelas: siempre se debe precisar.

## Teoría y decisiones

Estas son convenciones de lenguaje para estudiar, no una norma universal del español técnico. Antes de un taller, pide al instructor que señale cada término en el objeto. Una frase como «toma el cabo» puede resultar ambigua si hay varios extremos. Es preferible identificar función y posición: extremo libre de la cuerda marcada A, sin presuponer que su color certifica el tipo.

Anclaje designa aquí un punto o elemento que transmite carga al soporte; reunión, el sistema que organiza conexiones y cargas para una tarea. Punto maestro es la zona de conexión principal de ese sistema. Sistema de aseguramiento incluye personas, cuerda, conexiones, dispositivos y comunicación: no se reduce al aparato de frenado. Línea de vida describe una función de protección cuya instalación, diseño y uso deben especificarse; una cuerda tendida no adquiere esa función por nombrarla así.

En el diagrama de nomenclatura, las letras señalan regiones y formas, no una secuencia para hacer un nudo. Los ejemplos técnicos del fabricante permiten contrastar vocabulario funcional, pero la traducción local debe acordarse [Referencia: petzl-nudos-435](#fuente-petzl-nudos-435). En especial, no deduzcas de «ocho doble» si se habla de una gaza construida con cuerda doblada o de dos gazas: la academia los separa explícitamente.

Para leer un sistema, sigue en un dibujo la relación entre soporte, conexiones, cuerda y persona. Pregunta cuál es la función de cada elemento y dónde acabaría una carga. Si un participante emplea una palabra distinta, comprobar el objeto es más útil que discutir el nombre sin contexto.

## Caso práctico y aplicación al guiado

En una sesión de Filo Austral, dos alumnos llaman firme a tramos distintos. El instructor detiene el ejercicio, hace señalar extremos y funciones, y pide repetir la instrucción con referencias inequívocas. Explica cómo detectarías el desacuerdo antes de que alguien manipule un sistema.

## Errores frecuentes y señales de alerta

Tratar un término regional como error automáticamente; confundir gaza con nudo completo; llamar reunión a cualquier punto; llamar línea de vida a una cuerda sin diseño; usar «activa» o «libre» sin acordar a qué tramo se refieren.

## Autoevaluación y respuestas explicadas

¿Una gaza identifica el nudo? **No; describe un ojo y falta conocer su configuración.** ¿Por qué el firme puede requerir aclaración? **La referencia depende del sistema y del lenguaje acordado.**

## Ejercicios y práctica presencial

Identifica las regiones A–D del diagrama y redacta una instrucción inequívoca sin mover material. En mesa con instructor, señala los términos sobre una cuerda sin carga y compara el glosario local con el de su escuela.

## Evidencia requerida

Glosario ilustrado propio, dos ambigüedades corregidas y explicación oral. La capacidad de señalar elementos no acredita montaje ni aseguramiento.

## Relaciones con otras habilidades

Revisa los prerrequisitos y el contrato de habilidad de esta unidad en el programa. Contrasta la explicación con las fuentes indicadas: las cifras de un ejercicio no son límites de uso de un equipo. Toda transferencia a una situación con personas requiere formación y revisión presencial.
