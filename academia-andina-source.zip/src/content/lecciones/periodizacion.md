---
{
  "title": "Periodización: ordenar prioridades y revisar la carga",
  "description": "Construir una secuencia de preparación adaptable al objetivo.",
  "module": "M22",
  "code": "E10-15",
  "order": 1015,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U10-15",
  "skills": [
    "s10-periodizacion"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Construir una secuencia de preparación adaptable al objetivo.",
    "Aplicar el concepto a una decisión de preparación de montaña y reconocer sus límites."
  ],
  "prerequisites": [
    "s10-composicion-corporal"
  ],
  "sources": [
    "e10-injury",
    "e10-periodization"
  ],
  "pending": [
    "Revisión por profesional del ejercicio e instructor de montaña pendiente. Nutrición y salud requieren revisión profesional específica; no se ha evaluado aptitud personal.",
    "Los casos y rúbricas son propuestas pedagógicas originales. La aplicación individual requiere evaluación, técnica y seguimiento.",
    "No se atribuyen requisitos de certificación, umbrales universales ni preparación técnica a los resultados físicos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Periodizar implica…",
        "options": [
          "Ordenar y revisar estímulos en el tiempo.",
          "Subir carga todas las semanas.",
          "Eliminar recuperación."
        ],
        "answer": 0,
        "explanation": "El ajuste forma parte del proceso.",
        "rationales": [
          "El ajuste forma parte del proceso.",
          "No es una regla necesaria.",
          "Contradice el objetivo de adaptación."
        ],
        "source": "e10-injury",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una semana perdida…",
        "options": [
          "Se duplica siempre después.",
          "Requiere revisar el punto de partida.",
          "No afecta nunca al plan."
        ],
        "answer": 1,
        "explanation": "El contexto ha cambiado.",
        "rationales": [
          "Puede concentrar carga inapropiada.",
          "El contexto ha cambiado.",
          "Depende de duración y respuesta."
        ],
        "source": "e10-injury",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "El programa de montaña integra…",
        "options": [
          "Solo gimnasio.",
          "Solo kilometraje.",
          "Capacidades físicas y práctica técnica diferenciadas."
        ],
        "answer": 2,
        "explanation": "Permite mantener sus alcances separados.",
        "rationales": [
          "Faltan otras demandas.",
          "No observa técnicas ni decisiones.",
          "Permite mantener sus alcances separados."
        ],
        "source": "e10-injury",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Ordena prioridades por demanda.",
    "Distingue previsto y realizado.",
    "Ajusta tras interrupciones sin duplicar automáticamente."
  ],
  "openAssessment": {
    "prompt": "Diseña un mapa de cuatro bloques ficticios con objetivo, capacidad prioritaria, práctica técnica y criterio de revisión.",
    "rubric": [
      "Ordena prioridades por demanda.",
      "Distingue previsto y realizado.",
      "Ajusta tras interrupciones sin duplicar automáticamente."
    ],
    "source": "e10-injury",
    "difficulty": "integración"
  },
  "diagrams": [
    "e10-medicion"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN PROFESIONAL PENDIENTE.** Este contenido no prescribe un programa individual ni acredita competencia técnica. Los ejercicios numéricos y casos son ficticios. No introduzcas datos médicos, mediciones corporales privadas ni antecedentes de terceros.

## Conceptos clave y propósito

Objetivo, bloque, semana, sesión, progresión, especificidad y ajuste.

## Teoría y toma de decisiones

Periodizar es organizar el entrenamiento en el tiempo según prioridades y respuesta. No es dibujar semanas cada vez más difíciles. La unidad parte de un objetivo y distingue preparación general, específica, recuperación y evaluación.

La carga se revisa en conjunto: fuerza, resistencia, marchas y actividades ajenas al entrenamiento consumen recursos y tiempo. El seguimiento ayuda a ajustar, pero un número no decide solo. [Consenso de carga](#fuente-e10-injury). No se calcula una razón aguda-crónica como autorización para aumentar trabajo.

En el ejemplo original, una semana tiene una sesión de fuerza, dos aeróbicas y una marcha. Añadir mochila, desnivel e intensidad a la vez cambia varias demandas. El estudiante debe explicar cuál es prioritaria y qué ajuste preserva la coherencia, sin recibir una receta semanal universal.

Los bloques no son compartimentos completamente aislados. Una prioridad puede coexistir con mantenimiento de otras capacidades. El calendario también debe reservar revisión del equipo y práctica técnica supervisada; convertir todo en acondicionamiento físico deja incompleta la preparación de montaña.

Rhea y colaboradores compararon organización lineal y ondulante en un ensayo de fuerza con una muestra pequeña de hombres jóvenes. El estudio ilustra cómo investigar organización temporal, no qué calendario debe usar todo montañista. [Ensayo y límites](#fuente-e10-periodization).

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación del aprendizaje:** Parte de demandas, tiempo disponible y evaluación profesional. Ordena prioridades y criterios de revisión; diferencia plan de realizado. Ante una interrupción, reevalúa el punto de partida y no acumules sesiones atrasadas como deuda. Registra qué cambió y por qué.

La selección real de ejercicios, cargas, pruebas y progresión corresponde a una evaluación individual con profesionales. Las técnicas críticas de montaña requieren formación práctica y supervisión de instructor competente. El acondicionamiento físico no autoriza una maniobra.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una persona pierde una semana y quiere duplicar la siguiente para recuperar el plan. Analiza qué supone esa decisión sobre capacidad y recuperación.

Distingue dato, interpretación y decisión. Explica qué incertidumbre permanece. Los casos no representan un protocolo del organismo citado ni un criterio oficial de habilitación para guía.

## Errores frecuentes y puntos críticos de seguridad

Confundir calendario con adaptación; aumentar todo; recuperar sesiones como deuda; copiar planificación de élite sin contexto.

## Material y equipo relacionado

Agenda, registro de tareas y comunicación con entrenador e instructor. No hace falta una plataforma compleja para explicitar prioridades.

[Consultar inventario](../../equipo/). Ajustar o poseer el equipo no demuestra dominarlo. Las prácticas técnicas se registran por separado del acondicionamiento.

## Autoevaluación y recuperación activa

- Explica la diferencia entre la capacidad que estudias y una tarea técnica de montaña.
- ¿Qué información falta en el caso y qué decisión modificaría?
- ¿Qué parte puede analizarse en escritorio y cuál necesita observación profesional?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Diseña un mapa de cuatro bloques ficticios con objetivo, capacidad prioritaria, práctica técnica y criterio de revisión.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Taller de planificación con profesional del ejercicio e instructor, usando un escenario sin datos clínicos.

## Evidencia requerida y criterios de competencia

- Ordena prioridades por demanda.
- Distingue previsto y realizado.
- Ajusta tras interrupciones sin duplicar automáticamente.

**COMPETENCIA:** estos criterios describen aprendizaje que debe observar un profesional en contexto. No acreditan aptitud médica, entrenamiento personal, guiado ni maniobra técnica. Una lectura, prueba física o quiz no otorga certificación. Marca pendiente lo que no se haya evaluado.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s10-periodizacion). Registra fecha, actividad, escenario, equipo, objetivo, errores, correcciones, supervisor y evidencia de aprendizaje. No guardes datos médicos ni contraseñas. No inventes sesiones, evaluaciones o repeticiones para completar la matriz.

## Relaciones con otros módulos

[Entrenamiento](../../entrenamiento/) · [Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Programa](../../programa/). Entrenamiento general, preparación específica, aclimatación y competencia técnica se relacionan, pero no son equivalentes.
