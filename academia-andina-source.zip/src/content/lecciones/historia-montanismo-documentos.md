---
{
  "title": "Historia de montaña: documentos, personas y versiones",
  "description": "Diferenciar hecho documentado, tradición, relato e inferencia.",
  "module": "M17",
  "code": "E45-30",
  "order": 329,
  "minutes": 35,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U45-06",
  "skills": [
    "s45-historia-montanismo-documentos"
  ],
  "critical": false,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Diferenciar hecho documentado, tradición, relato e inferencia.",
    "Construir una cronología que explicite vacíos.",
    "Examinar críticamente una atribución de primera ascensión."
  ],
  "prerequisites": [
    "s45-ecologia-los-lagos"
  ],
  "sources": [
    "mhn-andes",
    "conaf-parque-centenario",
    "conaf-puyehue-historia",
    "patrimonio-futahuillimapu"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente.",
    "PENDIENTE DE VERIFICACIÓN TERRITORIAL: accesos, límites administrativos, rutas y condiciones actuales."
  ],
  "diagrams": [
    "territorio-evidencia"
  ],
  "preparation": [
    "Distinguir hechos atribuidos, inferencias y datos pendientes.",
    "Explicar por qué la ficha no valida acceso, ruta ni condiciones.",
    "Preparar una observación sin extracción ni alteración del entorno."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "mhn-andes",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "No encuentras una ascensión en una aplicación. ¿Puedes anunciar “primera ascensión”?",
        "options": [
          "Sí, porque la aplicación es completa.",
          "No: ausencia en esa base no prueba ausencia histórica.",
          "Sí, si el recorrido fue difícil."
        ],
        "answer": 1,
        "explanation": "Se necesitan definición del logro y fuentes independientes antes de una atribución.",
        "source": "mhn-andes",
        "difficulty": "intermedia",
        "rationales": [
          "Presupone exhaustividad no demostrada.",
          "Mantiene una conclusión acorde a la evidencia.",
          "Dificultad no establece prioridad histórica."
        ],
        "kind": "aplicación"
      },
      {
        "prompt": "Una memoria local discrepa con una publicación. ¿Qué haces?",
        "options": [
          "Eliminas la memoria.",
          "Inventas una fecha intermedia.",
          "Documentas ambas, su contexto y la evidencia disponible."
        ],
        "answer": 2,
        "explanation": "La comparación crítica conserva voces sin igualar automáticamente su fuerza probatoria.",
        "source": "patrimonio-futahuillimapu",
        "difficulty": "intermedia",
        "rationales": [
          "Pierde una fuente y su contexto.",
          "No produce evidencia.",
          "Permite revisión y búsqueda adicional."
        ],
        "kind": "aplicación"
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

Hecho documentado es una afirmación sustentada por una evidencia identificable y evaluada. Relato expresa una narración situada; tradición conserva transmisión colectiva; inferencia propone una conclusión a partir de datos. Ninguna categoría debe ocultar quién habla, cuándo y con qué alcance. Un documento escrito tampoco es neutral por el solo hecho de existir.

## Teoría: más de una historia de la montaña

La historia del montañismo deportivo no agota la relación humana con los Andes. Tránsito, residencia, conocimientos locales, exploración científica, delimitación estatal, clubes, turismo y conservación producen documentos distintos. Llamar “descubrimiento” a una visita exige preguntar para quién era nuevo el lugar y qué presencias fueron omitidas.

El Museo Histórico Nacional difundió en 2024 una exposición con registros de los Andes centrales de 1927–1942, recuperados junto al Club Alemán Andino de Santiago, en su centenario [Referencia: mhn-andes](#fuente-mhn-andes). Es un punto de entrada a fuentes deportivas, no prueba de que antes no hubiera conocimiento o ascensos. El extracto institucional fue consultado, pero la apertura completa quedó restringida; no se atribuyen aquí primeras ascensiones particulares.

La historia de áreas protegidas agrega otra línea. Vicente Pérez Rosales conmemoró cien años en 2026; Puyehue fue creado el 8 de abril de 1941 según la reseña institucional [Referencia: conaf-parque-centenario](#fuente-conaf-parque-centenario) [Referencia: conaf-puyehue-historia](#fuente-conaf-puyehue-historia). Crear un parque no significa que comenzara entonces la historia del territorio. La propia conmemoración de 2026 habla de transición institucional: no extrapoles una administración antigua al presente.

Para investigar una ascensión, registra cumbre exacta, fecha, participantes, ruta, documento contemporáneo y contexto de publicación. Distingue primera ascensión documentada, primera por una vía, primera invernal y repetición. Una foto puede apoyar presencia, pero puede no distinguir cumbre principal y antecumbre. Si dos versiones discrepan, muestra ambas y el tipo de evidencia; no inventes una conciliación.

La historia local de Los Lagos exige archivo y colaboración territorial. Hay pendientes concretos: cronologías de clubes regionales, expediciones y primeras ascensiones de las fichas. No se sustituyen por una lista de nombres repetida en redes. El estudio de Futahuillimapu también muestra por qué leer documentación estatal exige atender relaciones de poder y desposesión [Referencia: patrimonio-futahuillimapu](#fuente-patrimonio-futahuillimapu).

## Caso práctico: “nadie había subido antes”

Un folleto presenta una expedición como primera ascensión porque no aparece en una aplicación. Reescribe la afirmación como hipótesis pendiente. Propón consultar archivos de clubes, publicaciones contemporáneas, cartografía y memorias locales, con atribución y consentimiento cuando corresponda. Ausencia de un registro digital no prueba ausencia de historia.

## Errores frecuentes y señales de alerta

Usar “primero” sin definir qué se hizo, confundir memoria y acta, borrar participación de acompañantes o comunidades, copiar fecha de publicación como fecha del evento. El relato heroico no debe impedir revisar evidencia.

## Autoevaluación y respuestas explicadas

¿Dos versiones deben tener el mismo peso? No necesariamente: se comparan evidencia y contexto, sin ocultarlas. ¿Un relato oral es inútil? No: se documenta como tal y se investiga sin transformarlo automáticamente en cronología exacta.

## Ejercicios y práctica presencial

Construye una ficha documental con autor, fecha, objeto, afirmación y límite. Para una entrevista, acuerda propósito, uso y atribución; no almacenes datos personales innecesarios en la academia.

## Evidencia requerida

Cronología de cinco entradas distinguiendo hecho, relato e inferencia, más tres preguntas pendientes. Se evalúa método crítico, no cantidad de fechas.

## Relaciones con otras habilidades

Conecta comunicación, territorio y ética del guía. La unidad inicia investigación histórica; no presenta una historia exhaustiva ni primeras ascensiones sin corroboración.
