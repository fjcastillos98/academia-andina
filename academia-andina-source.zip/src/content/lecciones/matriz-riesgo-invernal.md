---
{
  "title": "Matriz de riesgo: controles, incertidumbre y retirada",
  "description": "Distinguir peligro, probabilidad, consecuencia y exposición.",
  "module": "M13",
  "code": "E5-24",
  "order": 523,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-21",
  "skills": [
    "s5-matriz-riesgo-invernal"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir peligro, probabilidad, consecuencia y exposición.",
    "Evaluar si un control cambia realmente el escenario.",
    "Explicar riesgo residual sin fabricar una precisión numérica."
  ],
  "prerequisites": [
    "s5-tres-por-tres-invernal"
  ],
  "sources": [
    "e5-exposure",
    "e5-danger-scale",
    "e5-human"
  ],
  "pending": [
    "Revisión pedagógica y de instructor. Condiciones, cobertura de boletines y aplicación territorial real: PENDIENTE DE VERIFICACIÓN."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Añadir un DVA modifica automáticamente…",
        "options": [
          "La resistencia del manto.",
          "Los recursos de búsqueda, no la estabilidad.",
          "La pendiente."
        ],
        "answer": 1,
        "explanation": "Equipo de rescate y prevención del desencadenamiento son distintos.",
        "rationales": [
          "No afecta estructura.",
          "Función correctamente delimitada.",
          "No cambia geometría."
        ],
        "source": "e5-exposure",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "Si no puedes justificar una probabilidad…",
        "options": [
          "Usa la media.",
          "Elige la que permita continuar.",
          "Declara incertidumbre y limita la decisión."
        ],
        "answer": 2,
        "explanation": "No se debe fabricar precisión.",
        "rationales": [
          "No hay base estadística.",
          "Introduce sesgo de objetivo.",
          "Conserva evidencia y límites."
        ],
        "source": "e5-danger-scale",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "«Ser cuidadosos» es un control suficiente?",
        "options": [
          "No; falta conducta verificable, responsable y límite.",
          "Sí, si lo dice el guía.",
          "Sí, si todos asienten."
        ],
        "answer": 0,
        "explanation": "Una declaración no demuestra mecanismo ni ejecución.",
        "rationales": [
          "Permite comprobarlo.",
          "Autoridad no lo concreta.",
          "Acuerdo no define acción."
        ],
        "source": "e5-human",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Separa variables y alcance.",
    "Explica mecanismo y fallo de controles.",
    "Decide con incertidumbre visible y alternativa ejecutable."
  ],
  "openAssessment": {
    "prompt": "Construye una matriz cualitativa de un caso, rechaza un control aparente y justifica una decisión con riesgo residual explícito.",
    "rubric": [
      "Separa variables y alcance.",
      "Explica mecanismo y fallo de controles.",
      "Decide con incertidumbre visible y alternativa ejecutable."
    ],
    "source": "e5-exposure",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-riesgo"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Un control comprobable tiene mecanismo, responsable y límite; los adjetivos no permiten comprobar su ejecución.

## Teoría y toma de decisiones

Una matriz de riesgo sirve para hacer explícitas relaciones que de otro modo quedan ocultas en frases como «parece aceptable». En esta academia se usa un registro cualitativo: peligro, probabilidad argumentada, consecuencia, exposición, controles, incertidumbre residual y decisión. No se impone una tabla de colores ni se asignan números que aparenten una precisión inexistente. La matriz es una herramienta editorial para discutir un caso, no un sistema certificado de operación.

Peligro nombra el fenómeno capaz de producir daño; consecuencia describe qué podría suceder a personas o recursos expuestos. Probabilidad necesita un ámbito: no es lo mismo que se produzca una avalancha en una región que que un grupo sea afectado en un tramo. La escala de peligro de EAWS integra estabilidad, distribución y tamaño en espacio y tiempo [fuente](#fuente-e5-danger-scale). No debe copiarse como probabilidad individual dentro de una matriz distinta.

Exposición pregunta por posición y duración de la interacción con el terreno [fuente](#fuente-e5-exposure). Un control debe explicar qué modifica. Cambiar objetivo puede evitar un terreno; una mejora de comunicación puede ayudar a coordinar una retirada, pero no estabiliza una placa; llevar DVA, pala y sonda aporta recursos de rescate, sin impedir el desencadenamiento. Para evaluar un control, escribe su mecanismo, quién lo implementa y cómo comprobarás que existe. «Ser prudente» no basta como control verificable.

Riesgo residual describe lo que permanece después de controles y supuestos. No es sinónimo de riesgo aceptable. Pregunta qué ocurre si un control falla, si la información de base era incompleta o si un integrante no puede ejecutar la alternativa. Dos controles pueden depender de un mismo recurso: mapa digital y track en el mismo teléfono comparten vulnerabilidades. Esta observación conecta con redundancia y análisis de fallos de Etapa 4, sin repetir su contenido técnico.

La decisión debe conservar incertidumbre. Si no puedes defender la probabilidad con evidencia, escribe «no estimada con confianza» y explica cómo afecta al alcance de la actividad. No conviertas ese vacío en un valor medio para terminar la tabla. Los factores humanos pueden favorecer una cifra compatible con el objetivo deseado [fuente](#fuente-e5-human). En una discusión, pide que se argumenten también las razones para no continuar y las consecuencias de equivocarse.

Ejercicio original: un caso combina una ladera no evaluada, retraso y comunicación intermitente. Compara tres controles propuestos: añadir un DVA, reducir el objetivo antes de entrar o prometer caminar más rápido. Para cada uno explica qué modifica y qué deja igual. Luego analiza una retirada con terreno desconocido: puede ser una intención adecuada, pero todavía necesita una alternativa ejecutable. La rúbrica valora conexiones y límites, no que la tabla termine en verde. Una revisión presencial deberá observar cómo se toman decisiones bajo condiciones reales y dentro de la formación del participante.

## Qué observo, qué significa y qué no puedo concluir

No se calcula riesgo real ni se decide aceptabilidad legal o profesional mediante esta tabla.

## Caso práctico y aplicación al guiado

Un grupo propone llevar más material de rescate para mantener una exposición no evaluada. ¿Qué cambia y qué permanece?

## Errores frecuentes y señales de alerta

Multiplicar categorías ordinales como probabilidades exactas; llamar aceptable a todo residual; atribuir al DVA prevención de avalancha; ocultar incertidumbre con un número.

## Autoevaluación y respuesta razonada

Construye una matriz cualitativa de un caso, rechaza un control aparente y justifica una decisión con riesgo residual explícito.

## Ejercicios y práctica supervisada

Comparar matrices de escritorio con revisión de argumentos; aplicar luego en prácticas bajo instructor, sin entrar para completar un ejercicio.

## Evidencia requerida

- Separa variables y alcance.
- Explica mecanismo y fallo de controles.
- Decide con incertidumbre visible y alternativa ejecutable.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-matriz-riesgo-invernal).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
