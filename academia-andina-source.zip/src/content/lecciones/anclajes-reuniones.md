---
{
  "title": "Anclajes y reuniones: diseñar para un escenario",
  "description": "Distinguir punto de anclaje, reunión y punto maestro.",
  "module": "M07",
  "code": "E43-16",
  "order": 315,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U43-07",
  "skills": [
    "s43-anclajes-reuniones"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir punto de anclaje, reunión y punto maestro.",
    "Analizar cómo dirección, ángulo y extensión modifican un modelo de carga.",
    "Justificar por qué redundancia no implica independencia de fallos."
  ],
  "prerequisites": [
    "s43-aseguramiento-fundamentos"
  ],
  "sources": [
    "petzl-reunion-actual",
    "dmm-inspeccion"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "angulos-carga",
    "reunion-fallos"
  ],
  "preparation": [
    "Explicar los conceptos sin confundir un modelo con una maniobra.",
    "Reconocer al menos dos errores del caso y justificar una alternativa.",
    "Identificar la documentación y las competencias prácticas que faltan."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "petzl-reunion-actual",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Dos ramas terminan sobre un mismo soporte dudoso.",
        "options": [
          "Son necesariamente independientes.",
          "Pueden compartir una causa de fallo.",
          "La duda desaparece con más conectores."
        ],
        "answer": 1,
        "explanation": "La independencia debe analizar el soporte también.",
        "rationales": [
          "La conexión común puede invalidar esa inferencia.",
          "La independencia debe analizar el soporte también.",
          "Duplicar metal no corrige el soporte."
        ],
        "source": "petzl-reunion-actual",
        "kind": "errores",
        "difficulty": "intermedia"
      },
      {
        "prompt": "La ficha de reunión en vía equipada se aplica a nieve…",
        "options": [
          "Sin revisar.",
          "Solo cambiando la cuerda.",
          "No automáticamente: el alcance y soporte son distintos."
        ],
        "answer": 2,
        "explanation": "Hay que estudiar otra técnica y escenario.",
        "rationales": [
          "Excede el alcance declarado.",
          "Cambiar un componente no valida el diseño.",
          "Hay que estudiar otra técnica y escenario."
        ],
        "source": "petzl-reunion-actual",
        "kind": "aplicación",
        "difficulty": "intermedia"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

Un punto de anclaje transmite carga al soporte. Una reunión organiza puntos, conexiones y funciones para una tarea. El punto maestro concentra conexiones según el diseño. Redundancia describe alternativas frente a fallos previstos; independencia exige preguntarse si esas alternativas comparten una causa de fallo.

## Teoría y decisiones

Un árbol, bloque o elemento instalado no es confiable por pertenecer a una categoría. En un anclaje natural hay que evaluar el soporte y el entorno; en uno artificial, su instalación, estado y modo de carga. Esta unidad no enseña a validar roca, madera, hielo o nieve a distancia. Textiles y metales tienen mecanismos de deterioro y modos de trabajo distintos, y sus conexiones deben estudiarse conjuntamente.

Distribución de carga no equivale a igualdad perfecta. La geometría, dirección de tracción, rigidez, rozamiento y movimiento modifican qué recibe cada punto. Extensión es el desplazamiento que puede producirse al cambiar o fallar un componente; debe considerarse junto con la continuidad de protección y la nueva dirección de carga. Reducir un riesgo puede introducir otro y requiere decisión contextual.

La ficha Petzl utilizada se limita a reuniones en vías de varios largos equipadas; advierte que parte de sus conceptos no se transfiere a protecciones removibles o puntos naturales [Referencia: petzl-reunion-actual](#fuente-petzl-reunion-actual). Por eso no se adopta su ejemplo como receta de reunión para cualquier terreno ni se extrapolan sus ensayos a Calbuco.

Compara tareas: asegurar a un primero, recibir a un segundo, rapelar, bajar a otra persona o realizar rescate. Cambian movimientos, direcciones, cargas posibles, acceso al sistema y recursos. Una reunión concebida para una función no se declara válida para todas las demás. Identifica quién permanece conectado, quién opera y qué ocurriría durante una transición.

El esquema de dos ramas es un modelo de vectores, no un montaje. Para una carga vertical W y dos ramas simétricas ideales con ángulo total θ, el equilibrio da T = W/[2 cos(θ/2)]. Con W=100 N, θ=60° da aproximadamente 57,7 N por rama, y θ=120° da 100 N. Es una deducción estática sin caída ni material real; no permite establecer ángulos permitidos ni resistencia necesaria. Lo útil es reconocer que abrir el ángulo puede aumentar las tensiones.

## Caso práctico y aplicación al guiado

Dos conectores independientes terminan en el mismo bloque de estabilidad desconocida. El grupo cuenta «dos puntos». Dibuja la causa común de fallo y explica por qué contar componentes no basta. Propón recopilar información y evaluar alternativas con un instructor, sin inventar una prueba de resistencia.

## Errores frecuentes y señales de alerta

Confundir cantidad con independencia; ignorar aristas; asumir reparto igual; no prever cambio de dirección; diseñar solo para la posición inicial; deducir resistencia del material por una foto. Una checklist completa puede documentar un sistema inadecuado si sus respuestas no tienen evidencia.

## Autoevaluación y respuestas explicadas

¿Dos ramales siempre reparten W/2? **Solo bajo hipótesis geométricas específicas; el modelo angular muestra por qué no.** ¿Un punto maestro elimina dependencias? **No: hay que seguir las trayectorias de carga hasta el soporte.**

## Ejercicios y práctica presencial

En papel, comparar tres tareas y sus direcciones. Resolver el ejercicio angular y declarar sus hipótesis. En presencial, reconocer soportes y analizar configuraciones bajo dirección de instructor; no realizar pruebas improvisadas de carga.

## Evidencia requerida

Diagrama con direcciones, inventario de fallos comunes, limitaciones del modelo y revisión situada. Competencia evaluada solo en el contexto práctico observado.

## Relaciones con otras habilidades

Revisa los prerrequisitos y el contrato de habilidad de esta unidad en el programa. Contrasta la explicación con las fuentes indicadas: las cifras de un ejercicio no son límites de uso de un equipo. Toda transferencia a una situación con personas requiere formación y revisión presencial.
