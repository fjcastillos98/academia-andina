---
{
  "title": "Sistemas de izado: arquitectura y control",
  "description": "Reconocer las funciones de soporte, captura de progreso y conexión a la carga.",
  "module": "M07",
  "code": "E44-21",
  "order": 320,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U44-03",
  "skills": [
    "s44-izado-conceptual"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Reconocer las funciones de soporte, captura de progreso y conexión a la carga.",
    "Analizar fricción y comunicación en un esquema conceptual de izado.",
    "Identificar riesgos de transición y límites que requieren formación presencial."
  ],
  "prerequisites": [
    "s44-poleas-bloqueadores"
  ],
  "sources": [
    "petzl-ma",
    "petzl-transferencia"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "izado-bloques"
  ],
  "preparation": [
    "Explicar los conceptos sin confundir un modelo con una maniobra.",
    "Reconocer al menos dos errores del caso y justificar una alternativa.",
    "Identificar la documentación y las competencias prácticas que faltan."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "petzl-ma",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "La carga deja de avanzar por causa desconocida.",
        "options": [
          "Aumentar ventaja de inmediato.",
          "Revisar la causa y detener el ensayo si no hay control.",
          "Añadir más personas tirando."
        ],
        "answer": 1,
        "explanation": "La causa debe comprenderse antes de modificar el sistema.",
        "rationales": [
          "Puede aumentar fuerzas sobre un bloqueo.",
          "La causa debe comprenderse antes de modificar el sistema.",
          "Más esfuerzo no resuelve incertidumbre."
        ],
        "source": "petzl-ma",
        "kind": "decisiones",
        "difficulty": "intermedia"
      },
      {
        "prompt": "Una flecha «transferir carga» en un esquema…",
        "options": [
          "Es una instrucción completa.",
          "No requiere revisión.",
          "Oculta una fase que exige técnica, control y práctica."
        ],
        "answer": 2,
        "explanation": "La fase necesita un plan y entrenamiento específico.",
        "rationales": [
          "No describe cómo se mantiene protección.",
          "Puede cambiar la distribución de esfuerzos.",
          "La fase necesita un plan y entrenamiento específico."
        ],
        "source": "petzl-transferencia",
        "kind": "aplicación",
        "difficulty": "intermedia"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

Un izado combina soporte, trayectoria de fuerza, conexión a la carga, control de avance y coordinación. La relación mecánica es una propiedad del esquema; la viabilidad depende además del escenario. La transición modifica funciones y merece una revisión propia.

## Teoría y decisiones

Empieza por describir la tarea y la carga, no por elegir 3:1 o 5:1. En un dibujo identifica: anclaje y sus direcciones; cuerda y recorrido; conexión a la carga; captura de progreso; operador; observador; zona de llegada. Cada vínculo necesita una justificación y cada ausencia debe quedar visible.

Preparación conceptual significa conocer recursos, capacidades, recorrido y alternativa. La comunicación debe distinguir iniciar, detener y confirmar, además de señalar quién puede ordenar parada. No se presume que quien tracciona ve a la persona o al componente que recibe más carga. Un movimiento suave para el operador puede ser problemático en otro punto.

El ejercicio de fuerzas permite contrastar esfuerzo y desplazamiento [Referencia: petzl-ma](#fuente-petzl-ma). Pero aumentar ventaja sin analizar por qué la carga no se mueve puede empeorar un atasco o una sobrecarga. El diagnóstico no consiste en «poner otra polea» automáticamente: primero se revisa la hipótesis de fricción, obstáculo, captura o recorrido.

Reducir fricción no significa eliminar una protección o cambiar una redirección sin revisar sus funciones. El rozamiento, el soporte, las aristas y la dirección están conectados. Antes de una transición se necesita una explicación de qué sostiene la carga en cada estado y qué controles permanecen activos.

La nota técnica Petzl sobre transferencia de una persona suspendida muestra que la elasticidad puede complicar una transición en su configuración profesional específica [Referencia: petzl-transferencia](#fuente-petzl-transferencia). No se importa esa técnica al guiado ni se enseñan liberaciones aquí. Se usa para identificar por qué una flecha entre dos estados oculta un problema real que requiere práctica avanzada.

## Caso práctico y aplicación al guiado

El diagrama muestra carga, captura, tracción y llegada, pero no una salida controlada si el sistema se bloquea. Añade al informe esa ausencia. Luego introduce un cambio ficticio: el observador pierde comunicación. Justifica una parada y la revisión necesaria antes de continuar, sin proponer manipular conexiones cargadas.

## Errores frecuentes y señales de alerta

Diseñar solo la fase de subida; no asignar observador; no prever recorrido de cuerda; confundir bloqueo con estabilidad; aumentar tracción ante resistencia desconocida; omitir llegada y retirada del equipo.

## Autoevaluación y respuestas explicadas

¿Qué falta en un dibujo que solo contiene tres poleas? **Funciones, carga, soporte, control, comunicación y transiciones.** ¿Una ventaja alta resuelve una carga atascada? **No: puede ocultar el problema y aumentar fuerzas.**

## Ejercicios y práctica presencial

Anotar funciones y fallos de un esquema abstracto. Taller con instructor: demostrar fases sobre material didáctico sin personas, explicar un bloqueo y detener. Los montajes con personas y sus transiciones requieren formación específica adicional.

## Evidencia requerida

Esquema funcional, análisis de dos fallos y protocolo de parada. Evaluación supervisada del método de revisión antes de una evaluación de ejecución.

## Relaciones con otras habilidades

Revisa los prerrequisitos y el contrato de habilidad de esta unidad en el programa. Contrasta la explicación con las fuentes indicadas: las cifras de un ejercicio no son límites de uso de un equipo. Toda transferencia a una situación con personas requiere formación y revisión presencial.
