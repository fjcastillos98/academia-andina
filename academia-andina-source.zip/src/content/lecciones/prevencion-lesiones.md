---
{
  "title": "Prevención de lesiones: gestionar exposición y respuesta",
  "description": "Reconocer que el riesgo es multifactorial y no se calcula con una regla única.",
  "module": "M22",
  "code": "E10-11",
  "order": 1011,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U10-11",
  "skills": [
    "s10-prevencion-lesiones"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Reconocer que el riesgo es multifactorial y no se calcula con una regla única.",
    "Aplicar el concepto a una decisión de preparación de montaña y reconocer sus límites."
  ],
  "prerequisites": [
    "s10-movilidad-estabilidad"
  ],
  "sources": [
    "e10-injury"
  ],
  "pending": [
    "Revisión por profesional del ejercicio e instructor de montaña pendiente. Nutrición y salud requieren revisión profesional específica; no se ha evaluado aptitud personal.",
    "Los casos y rúbricas son propuestas pedagógicas originales. La aplicación individual requiere evaluación, técnica y seguimiento.",
    "No se atribuyen requisitos de certificación, umbrales universales ni preparación técnica a los resultados físicos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "La prevención puede…",
        "options": [
          "Reducir riesgos sin eliminarlos.",
          "Garantizar cero lesiones.",
          "Sustituir valoración clínica."
        ],
        "answer": 0,
        "explanation": "El riesgo tiene varias causas.",
        "rationales": [
          "El riesgo tiene varias causas.",
          "No existe esa garantía.",
          "Son funciones diferentes."
        ],
        "source": "e10-injury",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Iguales metros semanales…",
        "options": [
          "Siempre producen igual respuesta.",
          "No describen por sí solos toda la carga.",
          "Eliminan la necesidad de descanso."
        ],
        "answer": 1,
        "explanation": "Faltan variables relevantes.",
        "rationales": [
          "Cambian terreno, intensidad y persona.",
          "Faltan variables relevantes.",
          "La recuperación sigue importando."
        ],
        "source": "e10-injury",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una regla porcentual…",
        "options": [
          "Autoriza cualquier progresión.",
          "Diagnostica lesión.",
          "No garantiza tolerancia individual."
        ],
        "answer": 2,
        "explanation": "Debe revisarse con respuesta y tarea.",
        "rationales": [
          "No contempla todo el contexto.",
          "No es una herramienta diagnóstica.",
          "Debe revisarse con respuesta y tarea."
        ],
        "source": "e10-injury",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue carga externa e interna.",
    "No emplea un umbral como garantía.",
    "Reconoce cuándo detener y derivar."
  ],
  "openAssessment": {
    "prompt": "Construye tres preguntas de revisión de una semana ficticia y explica qué decisión modificaría cada respuesta.",
    "rubric": [
      "Distingue carga externa e interna.",
      "No emplea un umbral como garantía.",
      "Reconoce cuándo detener y derivar."
    ],
    "source": "e10-injury",
    "difficulty": "integración"
  },
  "diagrams": [
    "e10-medicion"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN PROFESIONAL PENDIENTE.** Este contenido no prescribe un programa individual ni acredita competencia técnica. Los ejercicios numéricos y casos son ficticios. No introduzcas datos médicos, mediciones corporales privadas ni antecedentes de terceros.

## Conceptos clave y propósito

Carga externa, carga interna, progresión, antecedentes, recuperación y riesgo.

## Teoría y toma de decisiones

La prevención reduce riesgos; no puede garantizar que nunca ocurra una lesión. El consenso IOC sobre carga destaca que entrenamiento, competición y contexto deben considerarse conjuntamente. [Consenso de carga](#fuente-e10-injury).

Carga externa describe la tarea —minutos, desnivel, peso— y carga interna su respuesta. El mismo recorrido puede sentirse distinto por condiciones y recuperación. Ninguna multiplicación representa toda la tensión de tejidos o el riesgo de lesión.

El caso original añade una marcha larga a una semana ya exigente porque el reloj muestra una meta incompleta. El análisis pregunta qué demanda aporta, qué se retira o ajusta y qué recuperación queda. La meta del dispositivo no es una obligación fisiológica.

No se utiliza una «regla del 10%» ni un cociente de cargas como semáforo universal. Ante dolor persistente, pérdida de función o cambios preocupantes, se requiere valoración. El registro académico recoge decisiones y aprendizaje, sin almacenar diagnósticos ni información clínica privada.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación del aprendizaje:** Revisa distribución de tareas y respuesta con profesional. Diferencia molestias transitorias de problemas que necesitan evaluación, sin autodiagnosticar. Si una sesión no se tolera, modifica el plan antes de repetirla; no uses analgésicos como herramienta para cumplir objetivos de entrenamiento.

La selección real de ejercicios, cargas, pruebas y progresión corresponde a una evaluación individual con profesionales. Las técnicas críticas de montaña requieren formación práctica y supervisión de instructor competente. El acondicionamiento físico no autoriza una maniobra.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un reloj propone completar más actividad después de una semana con carga de mochila y descenso. ¿Qué información falta para decidir?

Distingue dato, interpretación y decisión. Explica qué incertidumbre permanece. Los casos no representan un protocolo del organismo citado ni un criterio oficial de habilitación para guía.

## Errores frecuentes y puntos críticos de seguridad

Prometer ausencia de lesiones; usar un porcentaje fijo como garantía; ignorar dolor; confundir carga numérica y tolerancia de tejidos.

## Material y equipo relacionado

Registro de tareas y comunicación con profesional. No se necesita un sensor nuevo para identificar un cambio de función.

[Consultar inventario](../../equipo/). Ajustar o poseer el equipo no demuestra dominarlo. Las prácticas técnicas se registran por separado del acondicionamiento.

## Autoevaluación y recuperación activa

- Explica la diferencia entre la capacidad que estudias y una tarea técnica de montaña.
- ¿Qué información falta en el caso y qué decisión modificaría?
- ¿Qué parte puede analizarse en escritorio y cuál necesita observación profesional?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Construye tres preguntas de revisión de una semana ficticia y explica qué decisión modificaría cada respuesta.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Revisión de planificación con entrenador; valoración clínica de molestias reales fuera de la plataforma cuando corresponda.

## Evidencia requerida y criterios de competencia

- Distingue carga externa e interna.
- No emplea un umbral como garantía.
- Reconoce cuándo detener y derivar.

**COMPETENCIA:** estos criterios describen aprendizaje que debe observar un profesional en contexto. No acreditan aptitud médica, entrenamiento personal, guiado ni maniobra técnica. Una lectura, prueba física o quiz no otorga certificación. Marca pendiente lo que no se haya evaluado.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s10-prevencion-lesiones). Registra fecha, actividad, escenario, equipo, objetivo, errores, correcciones, supervisor y evidencia de aprendizaje. No guardes datos médicos ni contraseñas. No inventes sesiones, evaluaciones o repeticiones para completar la matriz.

## Relaciones con otros módulos

[Entrenamiento](../../entrenamiento/) · [Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Programa](../../programa/). Entrenamiento general, preparación específica, aclimatación y competencia técnica se relacionan, pero no son equivalentes.
