---
{
  "title": "Planificación de altitud: noches, alternativas y responsabilidades",
  "description": "Construir un perfil de pernoctas con alternativas de retirada.",
  "module": "M03",
  "code": "E9-06",
  "order": 906,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U9-06",
  "skills": [
    "s9-planificacion-altitud"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Construir un perfil de pernoctas con alternativas de retirada.",
    "Preparar preguntas para consulta médica sin almacenar información sensible."
  ],
  "prerequisites": [
    "s9-hape-altitud"
  ],
  "sources": [
    "e9-cdc",
    "e9-wms"
  ],
  "pending": [
    "Revisión médica por profesional de medicina de montaña y revisión docente por instructor pendientes. No se ha evaluado atención clínica ni rescate.",
    "Casos, ejercicios y criterios son propuestas pedagógicas originales; no autorizan decisiones clínicas individuales.",
    "Condiciones de rutas, comunicaciones y recursos de atención locales requieren verificación antes de cada salida."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿Dónde empieza el perfil de exposición?",
        "options": [
          "En el punto de partida, incluido el traslado.",
          "Solo en el campo base.",
          "En la foto de cumbre."
        ],
        "answer": 0,
        "explanation": "El transporte también cambia la altitud.",
        "rationales": [
          "El transporte también cambia la altitud.",
          "Puede omitir una ganancia inicial importante.",
          "No describe las noches anteriores."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Eliminar una noche intermedia por retraso…",
        "options": [
          "No cambia nada fisiológicamente.",
          "Obliga a revisar el perfil y las opciones.",
          "Queda autorizado por haber pagado."
        ],
        "answer": 1,
        "explanation": "El calendario nuevo necesita revisión.",
        "rationales": [
          "Cambia el tiempo de exposición.",
          "El calendario nuevo necesita revisión.",
          "El pago no determina tolerancia."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué se guarda en esta plataforma?",
        "options": [
          "Historia clínica del grupo.",
          "Recetas y diagnósticos de pasajeros.",
          "Aprendizaje de escenarios ficticios sin datos médicos."
        ],
        "answer": 2,
        "explanation": "Es el alcance definido del cuaderno.",
        "rationales": [
          "No es un registro clínico.",
          "Son datos sensibles ajenos al propósito.",
          "Es el alcance definido del cuaderno."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Incluye traslado inicial y pernoctas.",
    "Define alternativas con datos verificables.",
    "Separa plan académico y evaluación médica individual."
  ],
  "openAssessment": {
    "prompt": "Completa una tabla ficticia de cuatro noches y tres alternativas. Marca expresamente «requiere verificación» donde falte una fuente.",
    "rubric": [
      "Incluye traslado inicial y pernoctas.",
      "Define alternativas con datos verificables.",
      "Separa plan académico y evaluación médica individual."
    ],
    "source": "e9-cdc",
    "difficulty": "integración"
  },
  "diagrams": [
    "e9-pernocta"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN MÉDICA Y DE INSTRUCTOR PENDIENTES.** No es una herramienta de diagnóstico ni prescripción. Los casos son ficticios; no introduzcas datos médicos personales. Una emergencia real requiere asistencia urgente, no completar esta lección.

## Conceptos clave y propósito

Perfil de viaje, altitud inicial, pernocta, contingencia, consulta previa y responsabilidad.

## Teoría y toma de decisiones

Una expedición empieza antes del sendero. Para quien vive cerca del nivel del mar, el traslado por carretera o avión puede concentrar mucha ganancia de altitud antes del primer día deportivo. El perfil debe empezar en el punto de partida y describir las noches, no solamente el día de cumbre.

La consulta médica previa requiere el itinerario, las actividades y la posibilidad real de acceder a atención. La academia no necesita recoger diagnósticos ni medicamentos para enseñar a preparar esas preguntas. Se conserva el documento clínico por los canales adecuados; en este cuaderno solo se registra el aprendizaje.

En la propuesta original, cada noche tiene cinco campos de trabajo: cota, procedencia del dato, acceso, alternativa inferior y responsable de comprobarla. «Hay un vehículo» no completa el campo de evacuación: faltan ubicación, disponibilidad, conductor y acceso. No se supone cobertura por tener inReach o VHF.

El horario se revisa junto con meteorología, terreno y personas. Una reserva de días no obliga a gastarla antes de retirarse, y una reserva económica no sustituye la asistencia disponible. La capacidad de cambiar el programa forma parte del objetivo formativo. [Contexto médico de planificación](#fuente-e9-cdc).

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación y análisis de aula.** Escribe perfil y fuente de cada noche; contrasta las recomendaciones de aclimatación; define quién puede detener el plan y cómo comunicarlo. Haz una simulación de transporte cancelado. Si la nueva versión elimina escalones o salidas, reevalúa o cancela en vez de conservar la cumbre por defecto. El profesional médico decide indicaciones individuales, incluidas las farmacológicas.

Las indicaciones clínicas dependen del paciente y los recursos. Las maniobras de movilización, oxigenoterapia y rescate requieren formación práctica y supervisión competente. No extrapolar un caso de escritorio a una actuación real ni elegir fármacos a partir de un quiz.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un viaje ficticio desde la costa pierde un día por retraso. Para llegar a la fecha de cumbre se propone quitar la primera noche intermedia. Identifica qué ha cambiado además del calendario.

Identifica hechos, incertidumbres y decisiones. Explica qué información podría modificar tu propuesta. La rúbrica es docente, no un protocolo avalado por las instituciones citadas.

## Errores frecuentes y puntos críticos de seguridad

Omitir altitud inicial; promediar ascenso; presuponer helicóptero o cobertura; copiar fármacos de otra persona; almacenar datos médicos en las notas de la plataforma.

## Material y equipo relacionado

Cartografía con procedencia, plan de comunicaciones, energía de reserva, equipo adecuado al terreno. InReach Mini 2 y VHF requieren preparación, cobertura/servicio y uso legal verificados.

[Inventario educativo](../../equipo/). Tener el recurso no demuestra saber utilizarlo. El diario no es una ficha clínica.

## Autoevaluación y recuperación activa

- ¿Puedes explicar el concepto central sin confundirlo con una autorización de salida?
- ¿Qué dato falta en el escenario y qué decisión depende de él?
- ¿Qué tarea exige formación sanitaria o técnica y no se evalúa aquí?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Completa una tabla ficticia de cuatro noches y tres alternativas. Marca expresamente «requiere verificación» donde falte una fuente.

**PRÁCTICA SUPERVISADA — propuesta:** Taller de mesa con instructor y revisión médica del diseño del itinerario. No se simulan indicaciones farmacológicas ni se incorporan historias clínicas.

## Evidencia requerida y criterios de competencia

- Incluye traslado inicial y pernoctas.
- Define alternativas con datos verificables.
- Separa plan académico y evaluación médica individual.

**COMPETENCIA:** requiere observación contextual por instructor competente y revisión sanitaria cuando corresponda. Estos criterios evalúan preparación, comunicación y límites de actuación; no habilitan como profesional sanitario ni guía. La plataforma no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de la habilidad](../../practicas/?habilidad=s9-planificacion-altitud). Registra fecha, actividad, escenario ficticio, equipo, errores, correcciones, supervisor y evidencia del aprendizaje. No incluyas diagnósticos, recetas, mediciones personales ni datos de pacientes. Marca pendiente toda evaluación no realizada.

## Relaciones con otros módulos

[Volver a Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Escalada alpina](../../alpina/) · [Programa](../../programa/). La secuencia académica conecta planificación, comunicación y riesgo; no acredita aptitud clínica ni práctica.
