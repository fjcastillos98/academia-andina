---
{
  "title": "Ética y responsabilidad profesional en el guiado",
  "description": "Analizar promesas, límites de competencia, trato y efectos sobre terceros.",
  "module": "M00",
  "code": "E21-01",
  "order": 2101,
  "minutes": 45,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U21-01",
  "skills": [
    "s21-etica"
  ],
  "critical": false,
  "reviewDate": "2026-10-28",
  "objectives": [
    "Distinguir criterio ético, código asociativo y obligación legal por verificar.",
    "Justificar una decisión considerando a pasajeros, equipo y comunidad.",
    "Corregir una afirmación profesional que excede la evidencia."
  ],
  "prerequisites": [
    "Estudiar Aprender con evidencia y Gestión del riesgo."
  ],
  "sources": [
    "e21-angm",
    "e21-uiaa"
  ],
  "pending": [
    "Revisión por docente y guía competente pendiente.",
    "No se verifican requisitos legales específicos ni habilitación del lector.",
    "Los casos son originales y no constituyen protocolos ANGM o UIAA."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿Qué alcance tiene el código ANGM consultado?",
        "options": [
          "Es una ley que habilita a cualquier lector.",
          "Se dirige a miembros de la asociación; leerlo no otorga certificación.",
          "Sustituye la verificación de permisos."
        ],
        "answer": 1,
        "explanation": "El destinatario del código y una habilitación profesional son cosas distintas.",
        "rationales": [
          "No es una ley ni una credencial.",
          "Reconoce el ámbito de la fuente.",
          "Un código no acredita los permisos de una actividad."
        ],
        "source": "e21-angm",
        "difficulty": "intermedia",
        "kind": "caso"
      },
      {
        "prompt": "Una publicidad atribuye al guía una certificación que aún no tiene. ¿Qué acción corresponde al caso?",
        "options": [
          "Mantenerla hasta que alguien pregunte.",
          "Añadir una foto de equipo técnico.",
          "Corregir la afirmación y describir la formación real."
        ],
        "answer": 2,
        "explanation": "La información profesional debe poder sostenerse con antecedentes comprobables.",
        "rationales": [
          "Mantiene una representación engañosa.",
          "Una imagen no acredita formación.",
          "Ajusta la promesa a la evidencia."
        ],
        "source": "e21-angm",
        "difficulty": "intermedia",
        "kind": "caso"
      },
      {
        "prompt": "¿Cómo se usa la declaración UIAA en este bloque?",
        "options": [
          "Como referencia ética, con aplicación contextual y límites explícitos.",
          "Como autorización de acceso a cualquier predio.",
          "Como sustituto del plan de emergencia."
        ],
        "answer": 0,
        "explanation": "La página presenta recomendaciones y normas de conducta, no una autorización operacional.",
        "rationales": [
          "Distingue principios de permisos.",
          "No otorga acceso a un lugar.",
          "No define una respuesta específica a emergencias."
        ],
        "source": "e21-uiaa",
        "difficulty": "intermedia",
        "kind": "caso"
      },
      {
        "prompt": "Una objeción de un pasajero incomoda al grupo. ¿Qué respuesta permite analizarla?",
        "options": [
          "Descalificarlo para mantener autoridad.",
          "Pedir la observación concreta y revisar sus implicaciones sin humillarlo.",
          "Resolver toda condición técnica por mayoría."
        ],
        "answer": 1,
        "explanation": "Escuchar conserva información y dignidad; la decisión técnica necesita su propia justificación.",
        "rationales": [
          "Puede silenciar información relevante.",
          "Separa trato respetuoso y decisión fundamentada.",
          "La votación no valida condiciones técnicas."
        ],
        "source": "e21-angm",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "openAssessment": {
    "prompt": "Analiza un caso del taller: hechos, afectados, tensión ética, dos opciones, decisión, límite y acción verificable.",
    "rubric": [
      "Distingue hechos de supuestos.",
      "Incluye efectos sobre otras personas.",
      "Reconoce límites y consultas pendientes.",
      "Propone una corrección observable."
    ],
    "source": "e21-angm",
    "difficulty": "integración"
  }
}
---

**BLOQUE EN DESARROLLO · REVISIÓN DOCENTE Y PROFESIONAL PENDIENTE.** Los ejercicios se realizan en mesa. Esta unidad aporta una primera correspondencia parcial con M00.05; no acredita ética profesional ni habilitación para guiar.

## Conceptos clave y propósito

La ética ayuda a justificar cómo actuamos cuando una decisión afecta a otras personas, al territorio o a la confianza depositada en nosotros. Una decisión puede ser rentable y seguir siendo difícil de defender. Cumplir una instrucción tampoco elimina la necesidad de reconocer sus efectos y límites.

En este bloque, responsabilidad significa poder explicar qué se sabía, qué se decidió, quién podía resultar afectado y qué se hará para corregir un problema. Esa definición es una herramienta docente del proyecto: no define responsabilidad civil, penal o administrativa.

Distingue tres planos: un principio orienta el juicio; un código asociativo establece expectativas para sus destinatarios; una obligación legal exige identificar la norma y su aplicación. No transfieras automáticamente el contenido de uno a otro. Cuando falte una verificación jurídica, registra la pregunta concreta, la autoridad o asesor competente y la decisión que depende de resolverla.

## Teoría y alcance de las fuentes

El código publicado por ANGM se dirige a sus miembros. Incluye prioridad del cliente, trabajo dentro de la certificación, representación veraz de credenciales, dignidad y rechazo de conductas abusivas. También contempla ayuda a terceros condicionada a no comprometer la seguridad del cliente o guía. [Código ANGM](#fuente-e21-angm). Consultar ese texto no convierte al lector en asociado ni demuestra que cumpla sus condiciones.

La página de la declaración UIAA presenta recomendaciones sobre honestidad, efectos del riesgo sobre otras personas, ayuda, ecosistemas y respeto a comunidades y reglas locales. [Declaración UIAA](#fuente-e21-uiaa). Se consultó la página de presentación y sus principios, no el PDF completo. No es un permiso para acceder a un predio ni un protocolo de rescate.

Los casos, la ficha de decisión y la rúbrica siguientes son propuestas originales de la academia. Se usan para discutir razones y correcciones, no para atribuir aprobación institucional a una respuesta.

## De una intención a una conducta comprobable

«Ser responsable» necesita concretarse. En la preparación de una oferta, separa lo que puedes demostrar, lo que estimas y lo que depende de condiciones futuras. Si una frase promete una capacidad o credencial que no puedes respaldar, identifica la frase y corrígela antes de usarla. No sustituyas el dato faltante con fotografías, confianza personal o experiencia en una actividad distinta.

Una persona puede expresar entusiasmo y no haber comprendido una dificultad. Para el ejercicio docente, pide que explique con sus palabras lo que espera y las alternativas que reconoce. La respuesta permite detectar una diferencia entre la oferta y lo entendido. Esta comprobación educativa no reemplaza un consentimiento ni demuestra su validez jurídica.

Cuando chocan intereses, describe la tensión sin etiquetar a las personas. Puede haber dinero invertido, una fotografía deseada, cansancio del equipo o temor a una mala reseña. Anota cómo cada interés influye en la opción preferida y qué dato podría hacerte cambiar. Un incentivo económico no prueba que una exposición sea aceptable.

Escuchar no exige aceptar toda petición. Puedes explicar un límite con hechos, reconocer la decepción y ofrecer una alternativa que realmente pueda evaluarse. Evita desacreditar a quien comunica una dificultad: la humillación puede hacer que el grupo deje de informar. Si existe una situación de abuso o amenaza, el taller no intenta resolverla mediante un debate improvisado; identifica la necesidad de apoyo y el canal apropiado, sin investigar ni publicar datos de personas reales.

El respeto territorial requiere preguntas situadas. Que una actividad se haya realizado antes no demuestra autorización actual ni acuerdo de una comunidad. En el caso de aula se revisa quién puede responder sobre acceso, nombres y prácticas locales. No se inventan portavoces ni se presentan costumbres de una comunidad como si fueran universales.

## Ficha de decisión ética

1. **Hechos:** escribe lo observado y separa lo que todavía supones.
2. **Afectados:** considera pasajero, equipo, terceros y comunidad, incluso si no participan en la conversación.
3. **Tensión:** identifica qué objetivos, intereses o expectativas entran en conflicto.
4. **Opciones:** compara al menos dos acciones y sus consecuencias previsibles; declara la información faltante.
5. **Límites:** indica qué no puedes resolver por tu formación o por falta de verificación.
6. **Acción:** redacta una decisión, una comunicación y una corrección comprobable, con responsable y momento de revisión.

No sumes puntos para declarar una decisión ética. La ficha organiza argumentos; una respuesta escrita persuasiva puede ocultar una acción inviable. El revisor debe poder señalar dónde falta evidencia y qué parte necesita otra competencia.

## Caso práctico: una promesa que excede la evidencia

**Ficción didáctica:** una oferta anuncia «guía certificado para cualquier montaña» y garantiza llegar a la cumbre. El responsable posee formación acotada y no puede justificar la afirmación general. Una reserva ya está confirmada.

Separa el problema de información de la evaluación técnica de una salida. Una respuesta orientativa corrige la descripción, comunica la discrepancia y revisa qué servicio puede ofrecerse con evidencia suficiente. Las consecuencias contractuales y los derechos de las partes se deben verificar por la vía pertinente; el ejercicio no determina reembolsos ni inventa obligaciones legales. La corrección debe poder verse en una versión revisada de la oferta y en un registro ficticio de la comunicación.

Una respuesta incompleta sería cambiar únicamente «cualquier» por «muchas»: sigue faltando un alcance comprobable. Otra sería prometer más esfuerzo para compensar el error; no resuelve la representación de capacidad.

## Errores frecuentes

Confundir una aspiración con una credencial; asumir que una firma resuelve toda cuestión ética; ocultar desacuerdos para proteger la imagen; atribuir mala intención sin evidencia; declarar que una práctica está permitida porque nadie se opuso; describir una decisión como correcta solo porque terminó sin incidentes.

## Autoevaluación

- ¿Qué afirmación de la oferta puede comprobarse y cuál excede la evidencia?
- ¿Qué cambia si la persona afectada no está presente para explicar su posición?
- ¿Qué consulta necesitas formular antes de dar una respuesta jurídica?
- ¿Qué corrección sería observable mañana, además de una declaración de buenas intenciones?

## Ejercicios y revisión supervisada

Completa uno de los cuatro casos del [taller de ética](../../etica/). Una persona presenta la decisión y otra busca un supuesto no demostrado. Después intercambian roles. No se reproducen maniobras ni situaciones de riesgo para evaluar una conducta ética.

El revisor solicita razones, identifica a quién se omitió y comprueba que la corrección responde al problema. Si un criterio no se cumple, registra la brecha y repite el análisis con nueva información. No se aprueba competencia profesional por terminar el taller o contestar el cuestionario.

## Evidencia requerida

Conserva una primera respuesta, la objeción recibida, la revisión y una acción verificable. La rúbrica pide hechos diferenciados, personas afectadas, límites reconocidos y una decisión explicable. No recojas nombres, diagnósticos ni denuncias reales en esta plataforma de estudio.

## Relaciones con otros módulos

[Aprender con evidencia](../aprender-con-evidencia/), [gestión del riesgo](../gestion-del-riesgo/), [comunicación y conflictos](../comunicacion-conflictos/) y [planificación operativa](../plan-operacion/) aportan herramientas complementarias. La [matriz curricular](../../trazabilidad/) mantiene explícitos los vacíos y la revisión pendiente.
