---
{
  "title": "Fisiología de la altitud: presión, oxígeno y respuesta",
  "description": "Distinguir presión de oxígeno, saturación y capacidad funcional.",
  "module": "M03",
  "code": "E9-01",
  "order": 901,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U9-01",
  "skills": [
    "s9-fisiologia-altitud"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Distinguir presión de oxígeno, saturación y capacidad funcional.",
    "Explicar por qué entrenamiento y aclimatación responden a problemas diferentes."
  ],
  "prerequisites": [
    "s8-riesgo-alpino"
  ],
  "sources": [
    "e9-cdc",
    "e9-fda-oximeter"
  ],
  "pending": [
    "Revisión médica por profesional de medicina de montaña y revisión docente por instructor pendientes. No se ha evaluado atención clínica ni rescate.",
    "Casos, ejercicios y criterios son propuestas pedagógicas originales; no autorizan decisiones clínicas individuales.",
    "Condiciones de rutas, comunicaciones y recursos de atención locales requieren verificación antes de cada salida."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿Qué cambia principalmente al ascender?",
        "options": [
          "La presión parcial de oxígeno disponible.",
          "El aire pierde todo su oxígeno.",
          "El entrenamiento elimina la hipoxia."
        ],
        "answer": 0,
        "explanation": "La menor presión atmosférica reduce la disponibilidad de oxígeno.",
        "rationales": [
          "La menor presión atmosférica reduce la disponibilidad de oxígeno.",
          "No desaparece el oxígeno del aire.",
          "La condición física no elimina la exposición."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué proceso participa en la adaptación inicial?",
        "options": [
          "Solo fabricar glóbulos rojos durante una noche.",
          "Aumentar la ventilación.",
          "Dejar de respirar durante el descanso."
        ],
        "answer": 1,
        "explanation": "La ventilación participa en la respuesta temprana.",
        "rationales": [
          "No explica la adaptación aguda.",
          "La ventilación participa en la respuesta temprana.",
          "No es una estrategia de aclimatación."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La buena marca deportiva del caso…",
        "options": [
          "Garantiza tolerancia a la altitud.",
          "Sustituye las noches intermedias.",
          "No demuestra aclimatación."
        ],
        "answer": 2,
        "explanation": "Entrenamiento y aclimatación son distintos.",
        "rationales": [
          "No predice una respuesta individual infalible.",
          "El itinerario sigue siendo relevante.",
          "Entrenamiento y aclimatación son distintos."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Explica la diferencia entre presión y concentración.",
    "Separa capacidad deportiva y exposición reciente.",
    "Reconoce que un instrumento no descarta por sí solo una urgencia."
  ],
  "openAssessment": {
    "prompt": "Dibuja ambiente → respuesta → observación → decisión. Añade un ejemplo de información que no proporciona cada eslabón.",
    "rubric": [
      "Explica la diferencia entre presión y concentración.",
      "Separa capacidad deportiva y exposición reciente.",
      "Reconoce que un instrumento no descarta por sí solo una urgencia."
    ],
    "source": "e9-cdc",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN MÉDICA Y DE INSTRUCTOR PENDIENTES.** No es una herramienta de diagnóstico ni prescripción. Los casos son ficticios; no introduzcas datos médicos personales. Una emergencia real requiere asistencia urgente, no completar esta lección.

## Conceptos clave y propósito

Hipobaria, hipoxia, ventilación, oxigenación, aclimatación y capacidad funcional.

## Teoría y toma de decisiones

El problema fisiológico no consiste en que la montaña haya consumido el oxígeno del aire: al disminuir la presión atmosférica disminuye la presión parcial de oxígeno disponible. La ventilación es una respuesta importante a ese cambio. En la adaptación inicial aumenta la ventilación; fabricar más glóbulos rojos no explica por sí solo los primeros días. [CDC, fisiología y aclimatación](#fuente-e9-cdc).

Conviene separar tres preguntas: qué exposición tendrá la persona, qué respuesta observamos y qué significa para la tarea. Un número del dispositivo describe una medición; la capacidad de atender una conversación o caminar no se reduce a ese número. La lección no propone una saturación que autorice a subir.

Como ejercicio conceptual, compara dos deportistas con la misma marca de carrera al nivel del mar. Uno llega después de varias noches intermedias y otro en transporte directo. La marca deportiva no informa de esa diferencia de exposición. Tener buen rendimiento previo no garantiza protección frente a enfermedad de altitud; esa distinción impide usar el entrenamiento como sustituto del itinerario gradual.

El propósito del bloque es aprender a explicar mecanismos sin inventar diagnósticos. En la pizarra dibuja una cadena entre ambiente, respuesta corporal y decisión. Señala con otro color dónde faltan observaciones. La diferencia entre una explicación fisiológica y una conclusión clínica debe permanecer visible.

La FDA advierte que circulación, temperatura de piel, pigmentación y esmalte pueden afectar la lectura del oxímetro. Los productos deportivos no equivalen necesariamente a dispositivos evaluados para uso médico. [Limitaciones de oximetría](#fuente-e9-fda-oximeter).

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación y análisis de aula.** Para analizar una ficha ficticia, separa exposición (pernoctas y tiempos), observaciones y explicaciones posibles. Comprueba si cada conclusión está realmente respaldada por el dato. No conviertas una lectura aislada de oxímetro en permiso para continuar; la interpretación clínica y las limitaciones del dispositivo se revisan con un profesional.

Las indicaciones clínicas dependen del paciente y los recursos. Las maniobras de movilización, oxigenoterapia y rescate requieren formación práctica y supervisión competente. No extrapolar un caso de escritorio a una actuación real ni elegir fármacos a partir de un quiz.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una deportista dice: «Me siento muy fuerte, por eso puedo saltarme las noches intermedias». Redacta una respuesta que reconozca su preparación sin atribuirle aclimatación.

Identifica hechos, incertidumbres y decisiones. Explica qué información podría modificar tu propuesta. La rúbrica es docente, no un protocolo avalado por las instituciones citadas.

## Errores frecuentes y puntos críticos de seguridad

Confundir porcentaje de oxígeno con su presión; atribuir la adaptación de una noche a nuevos glóbulos rojos; usar condición física o un dato instrumental para descartar enfermedad.

## Material y equipo relacionado

Croquis del perfil, reloj, ficha de observación ficticia. Un oxímetro, si se estudia en taller, exige conocer su manual y limitaciones; no es un certificado de aptitud.

[Inventario educativo](../../equipo/). Tener el recurso no demuestra saber utilizarlo. El diario no es una ficha clínica.

## Autoevaluación y recuperación activa

- ¿Puedes explicar el concepto central sin confundirlo con una autorización de salida?
- ¿Qué dato falta en el escenario y qué decisión depende de él?
- ¿Qué tarea exige formación sanitaria o técnica y no se evalúa aquí?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Dibuja ambiente → respuesta → observación → decisión. Añade un ejemplo de información que no proporciona cada eslabón.

**PRÁCTICA SUPERVISADA — propuesta:** Taller de interpretación de casos con docente de medicina de montaña. Comparar explicaciones sin someter a nadie a hipoxia ni registrar mediciones personales.

## Evidencia requerida y criterios de competencia

- Explica la diferencia entre presión y concentración.
- Separa capacidad deportiva y exposición reciente.
- Reconoce que un instrumento no descarta por sí solo una urgencia.

**COMPETENCIA:** requiere observación contextual por instructor competente y revisión sanitaria cuando corresponda. Estos criterios evalúan preparación, comunicación y límites de actuación; no habilitan como profesional sanitario ni guía. La plataforma no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de la habilidad](../../practicas/?habilidad=s9-fisiologia-altitud). Registra fecha, actividad, escenario ficticio, equipo, errores, correcciones, supervisor y evidencia del aprendizaje. No incluyas diagnósticos, recetas, mediciones personales ni datos de pacientes. Marca pendiente toda evaluación no realizada.

## Relaciones con otros módulos

[Volver a Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Escalada alpina](../../alpina/) · [Programa](../../programa/). La secuencia académica conecta planificación, comunicación y riesgo; no acredita aptitud clínica ni práctica.
