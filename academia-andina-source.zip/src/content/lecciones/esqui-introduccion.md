---
{
  "title": "Esquí de pista y de montaña: una transición de responsabilidades",
  "description": "Distinguir entorno de pista y esquí de montaña.",
  "module": "M02",
  "code": "E5-21",
  "order": 520,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-18",
  "skills": [
    "s5-esqui-introduccion"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir entorno de pista y esquí de montaña.",
    "Reconocer equipo de ascenso y transiciones.",
    "Explicar límites de experiencia y rol del guía."
  ],
  "prerequisites": [
    "s5-raquetas"
  ],
  "sources": [
    "e5-sac-esqui",
    "e5-fis-conducta"
  ],
  "pending": [
    "Revisión de instructor y contraste con manuales exactos del equipo disponible. Cualquier aplicación territorial permanece pendiente de reconocimiento y condiciones actuales."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Esquiar cerca de una estación garantiza…",
        "options": [
          "Control de avalanchas en todo el entorno.",
          "Nada sobre la gestión del terreno fuera de su ámbito.",
          "Rescate inmediato."
        ],
        "answer": 1,
        "explanation": "El ámbito gestionado debe comprobarse.",
        "rationales": [
          "Extrapola cobertura.",
          "Reconoce el límite territorial.",
          "No hay tiempo garantizado."
        ],
        "source": "e5-sac-esqui",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Según el principio de conducta FIS, la velocidad debe…",
        "options": [
          "Depender solo de la habilidad percibida.",
          "Ser la misma en toda pista.",
          "Adaptarse a capacidad y condiciones del entorno."
        ],
        "answer": 2,
        "explanation": "El control depende también de nieve, visibilidad y usuarios.",
        "rationales": [
          "Omite entorno.",
          "Ignora cambios de condiciones.",
          "Integra factores relevantes."
        ],
        "source": "e5-fis-conducta",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué demuestra aprobar teoría de avalanchas?",
        "options": [
          "Comprensión evaluada, no dominio del descenso.",
          "Que puede enseñar esquí.",
          "Que las fijaciones están ajustadas."
        ],
        "answer": 0,
        "explanation": "Son competencias distintas.",
        "rationales": [
          "Mantiene separación de evidencias.",
          "Falta formación técnica y pedagógica.",
          "Requiere revisión de equipo."
        ],
        "source": "e5-sac-esqui",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "Distingue contexto y responsabilidades.",
    "Identifica funciones y compatibilidades de equipo.",
    "Declara límites y preparación específica pendiente."
  ],
  "openAssessment": {
    "prompt": "Construye un plan de retorno al esquí de montaña con evidencias para ascenso, transición y descenso, sin elegir una ruta real no verificada.",
    "rubric": [
      "Distingue contexto y responsabilidades.",
      "Identifica funciones y compatibilidades de equipo.",
      "Declara límites y preparación específica pendiente."
    ],
    "source": "e5-sac-esqui",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Reconoce qué parte del entorno está gestionada y qué se desconoce; distingue modo de marcha, modo de descenso y elementos que requieren manual específico.

## Teoría y toma de decisiones

El esquí de pista y el esquí de montaña comparten desplazamiento con esquíes, pero no el mismo contexto de gestión. En una estación deben respetarse apertura, señalización y reglas locales; fuera del terreno gestionado no se presume que exista evaluación o intervención equivalente. Subir por medios propios o salir cerca de un remonte no determina por sí solo la exposición. La proximidad a infraestructura puede crear una expectativa de ayuda que debe verificarse.

El código FIS exige adaptar velocidad y conducta a capacidad, terreno, nieve, tiempo y otros usuarios [fuente](#fuente-e5-fis-conducta). Esa idea permite formular una pregunta de aprendizaje: ¿puedo controlar trayectoria y detenerme dentro de lo que veo y de mi capacidad? No se enseña aquí técnica de giro. Un curso de esquí y evaluación presencial deben comprobar control en las condiciones que se pretenden abordar. Haber esquiado una pista no demuestra dominio de nieve variable con mochila.

En esquí de montaña se añaden tareas de ascenso y transiciones. Las pieles aportan resistencia direccional al deslizamiento durante la subida; fijaciones y botas compatibles permiten funciones específicas de marcha y descenso. El modo correcto, el ajuste y las comprobaciones pertenecen al manual de cada sistema. No se indican valores de liberación ni combinaciones automáticas. Cuchillas, crampones u otros accesorios no deben tratarse como solución que evita aprender a reconocer límites de la nieve y del terreno.

Una transición es un cambio de actividad y organización, no solo quitar pieles. El grupo debe mantener control del material, protección frente al ambiente y claridad del siguiente movimiento. Analiza dónde se detendría, qué exposición existe, qué puede perderse y qué haría una persona con menor destreza. No se prescribe un orden universal: modelos, viento, terreno y supervisión cambian las decisiones. En aula se puede reconocer un error de modo o compatibilidad, pero manipular bajo presión requiere práctica.

El SAC relaciona planificación, capacidades del grupo, condiciones y equipo de emergencia en esquí de montaña [fuente](#fuente-e5-sac-esqui). En este currículo, nieve, avalanchas, DVA, pala y sonda son prerrequisitos de comprensión; su práctica sigue siendo independiente del rendimiento al esquiar. Una persona técnicamente hábil puede elegir una exposición injustificada. A la inversa, comprender un boletín no permite descender una pendiente que supera la técnica disponible.

Para Filo Austral, el límite de guiado debe incluir la formación específica para la actividad y las capacidades realmente demostradas. Esta introducción no habilita clases ni conducción de grupos de esquí. El ejercicio final construye una matriz de tareas: ascenso, transición, descenso, comunicación y respuesta a incidente. Para cada tarea anota evidencia disponible, práctica pendiente y qué alternativa existe si alguien no puede ejecutarla. En un retorno al randonée después de una pausa, reevaluar técnica y funcionamiento del equipo es una tarea concreta, no una pérdida de experiencia acumulada.

## Qué observo, qué significa y qué no puedo concluir

Introducción teórica: no es curso técnico de esquí ni habilitación de guía. No se establecen ajustes de fijación, rutas o dificultad.

## Caso práctico y aplicación al guiado

Una persona con experiencia antigua en pista propone una salida de randonée sin práctica reciente. Identifica qué capacidades deben observarse antes de elegir terreno.

## Errores frecuentes y señales de alerta

Confundir cercanía a remonte con control de avalanchas; usar experiencia antigua como evaluación actual; improvisar transición; cambiar fijaciones sin manual.

## Autoevaluación y respuesta razonada

Construye un plan de retorno al esquí de montaña con evidencias para ascenso, transición y descenso, sin elegir una ruta real no verificada.

## Ejercicios y práctica supervisada

Revisión de equipo y práctica de técnica y transiciones con instructor competente en esquí. Evaluar por separado análisis de avalanchas y técnica de descenso.

## Evidencia requerida

- Distingue contexto y responsabilidades.
- Identifica funciones y compatibilidades de equipo.
- Declara límites y preparación específica pendiente.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-esqui-introduccion).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
