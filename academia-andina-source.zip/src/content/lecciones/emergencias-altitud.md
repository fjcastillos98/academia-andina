---
{
  "title": "Emergencias en altitud: comunicar y coordinar la evacuación",
  "description": "Integrar señales de alarma, comunicación y evacuación en un caso ficticio.",
  "module": "M03",
  "code": "E9-10",
  "order": 910,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U9-10",
  "skills": [
    "s9-emergencias-altitud"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Integrar señales de alarma, comunicación y evacuación en un caso ficticio.",
    "Reconocer los límites de formación y recursos disponibles."
  ],
  "prerequisites": [
    "s9-hidratacion-altitud"
  ],
  "sources": [
    "e9-cdc",
    "e9-wms"
  ],
  "pending": [
    "Revisión médica por profesional de medicina de montaña y revisión docente por instructor pendientes. No se ha evaluado atención clínica ni rescate.",
    "Casos, ejercicios y criterios son propuestas pedagógicas originales; no autorizan decisiones clínicas individuales.",
    "Condiciones de rutas, comunicaciones y recursos de atención locales requieren verificación antes de cada salida."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "En una simulación de comunicaciones…",
        "options": [
          "Se usan canales de ensayo sin activar SOS real.",
          "Se activa siempre el rescate real.",
          "Se inventa un paciente para llamar al servicio."
        ],
        "answer": 0,
        "explanation": "Evita movilizaciones falsas.",
        "rationales": [
          "Evita movilizaciones falsas.",
          "No corresponde a un ejercicio académico.",
          "No es una práctica autorizada."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Si una opción aérea no está confirmada…",
        "options": [
          "Se promete al grupo.",
          "Se conserva como incertidumbre y se preparan alternativas.",
          "Se da por disponible por tener satélite."
        ],
        "answer": 1,
        "explanation": "Permite planificar con información honesta.",
        "rationales": [
          "Sería una garantía sin fundamento.",
          "Permite planificar con información honesta.",
          "Comunicar no garantiza una aeronave."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "El quiz de emergencias acredita…",
        "options": [
          "Capacidad clínica completa.",
          "Competencia de rescate técnico.",
          "Solo comprensión teórica."
        ],
        "answer": 2,
        "explanation": "Es el alcance de esta evaluación.",
        "rationales": [
          "No hay evaluación clínica presencial.",
          "No observa maniobras reales.",
          "Es el alcance de esta evaluación."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Prioriza asistencia y evacuación ante alarma.",
    "Comunica hechos y recursos sin inventarlos.",
    "Reconoce límites técnicos y no activa alertas reales en un ensayo."
  ],
  "openAssessment": {
    "prompt": "Escribe un mensaje de emergencia solo con datos inventados del caso. Añade una lista de datos desconocidos y quién podría verificarlos.",
    "rubric": [
      "Prioriza asistencia y evacuación ante alarma.",
      "Comunica hechos y recursos sin inventarlos.",
      "Reconoce límites técnicos y no activa alertas reales en un ensayo."
    ],
    "source": "e9-cdc",
    "difficulty": "integración"
  },
  "diagrams": [
    "e9-observar"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN MÉDICA Y DE INSTRUCTOR PENDIENTES.** No es una herramienta de diagnóstico ni prescripción. Los casos son ficticios; no introduzcas datos médicos personales. Una emergencia real requiere asistencia urgente, no completar esta lección.

## Conceptos clave y propósito

Reconocimiento, prioridad, acompañamiento, comunicación, apoyo y transferencia de atención.

## Teoría y toma de decisiones

La planificación de emergencia une dos dimensiones: lo que necesita la persona y lo que el terreno permite. La sospecha de HACE o HAPE exige atención urgente y descenso/evacuación; si el terreno o el tiempo lo impiden, se necesita apoyo inmediato, no asumir que esperar resuelve la enfermedad. [CDC](#fuente-e9-cdc).

El caso integrador empieza con hechos observables y termina con una transferencia de información. Describe cambios y cronología; no uses una etiqueta diagnóstica para rellenar lo que no sabes. En un mensaje ficticio se incluyen posición del escenario, número de personas, problema observado, peligros, recursos y ayuda solicitada.

Asignar a alguien la comunicación no elimina la necesidad de acompañar a la persona. Tener un dispositivo satelital tampoco garantiza atención inmediata. El grupo debe saber quién sostiene cada función y cuál es la alternativa cuando falla una. Los tiempos de respuesta y servicios locales requieren verificación para cada expedición.

Oxígeno, cámara hiperbárica y fármacos aparecen en las guías clínicas, pero requieren un plan y capacidades que esta lectura no acredita. No se generan dosis ni recomendaciones individuales. La práctica posterior evalúa decisiones, comunicación y acciones dentro de la formación recibida, con revisión sanitaria.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación y análisis de aula.** En la simulación: reconocer alarma, detener el objetivo, pedir ayuda, acompañar y preparar evacuación con protección del terreno. Comunicar barreras para el descenso y actualizar cambios. Si hay una emergencia real, actuar según la formación de primeros auxilios y obtener atención urgente; no usar la academia como sistema de triaje ni esperar a responder un formulario.

Las indicaciones clínicas dependen del paciente y los recursos. Las maniobras de movilización, oxigenoterapia y rescate requieren formación práctica y supervisión competente. No extrapolar un caso de escritorio a una actuación real ni elegir fármacos a partir de un quiz.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** A 4200 m ficticios, una persona está confusa y otra no puede ayudar a cargar. El viento bloquea una opción aérea no confirmada. Redacta prioridades que no dependan de ese recurso supuesto.

Identifica hechos, incertidumbres y decisiones. Explica qué información podría modificar tu propuesta. La rúbrica es docente, no un protocolo avalado por las instituciones citadas.

## Errores frecuentes y puntos críticos de seguridad

Esperar al rescate sin medidas de apoyo; prometer helicóptero; ocultar recursos insuficientes; dar diagnósticos inventados; dejar sola a la persona o improvisar transporte técnico.

## Material y equipo relacionado

InReach Mini 2, VHF y otros medios con preparación previa; abrigo y material de evacuación según terreno y formación. Botiquín y recursos médicos definidos por personal competente.

[Inventario educativo](../../equipo/). Tener el recurso no demuestra saber utilizarlo. El diario no es una ficha clínica.

## Autoevaluación y recuperación activa

- ¿Puedes explicar el concepto central sin confundirlo con una autorización de salida?
- ¿Qué dato falta en el escenario y qué decisión depende de él?
- ¿Qué tarea exige formación sanitaria o técnica y no se evalúa aquí?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Escribe un mensaje de emergencia solo con datos inventados del caso. Añade una lista de datos desconocidos y quién podría verificarlos.

**PRÁCTICA SUPERVISADA — propuesta:** Simulación con instructor de rescate y primeros auxilios remotos: sin activar SOS real, sin llamar servicios reales y sin administrar tratamientos. Revisar roles, claridad y límites.

## Evidencia requerida y criterios de competencia

- Prioriza asistencia y evacuación ante alarma.
- Comunica hechos y recursos sin inventarlos.
- Reconoce límites técnicos y no activa alertas reales en un ensayo.

**COMPETENCIA:** requiere observación contextual por instructor competente y revisión sanitaria cuando corresponda. Estos criterios evalúan preparación, comunicación y límites de actuación; no habilitan como profesional sanitario ni guía. La plataforma no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de la habilidad](../../practicas/?habilidad=s9-emergencias-altitud). Registra fecha, actividad, escenario ficticio, equipo, errores, correcciones, supervisor y evidencia del aprendizaje. No incluyas diagnósticos, recetas, mediciones personales ni datos de pacientes. Marca pendiente toda evaluación no realizada.

## Relaciones con otros módulos

[Volver a Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Escalada alpina](../../alpina/) · [Programa](../../programa/). La secuencia académica conecta planificación, comunicación y riesgo; no acredita aptitud clínica ni práctica.
