---
{
  "title": "Física, materiales e inspección de cuerda",
  "description": "Explicar tensión, dirección de carga y absorción de energía sin confundir fuerza con masa.",
  "module": "M07",
  "code": "E43-01",
  "order": 300,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U43-01",
  "skills": [
    "s43-fisica-cuerda"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Explicar tensión, dirección de carga y absorción de energía sin confundir fuerza con masa.",
    "Comparar materiales y compatibilidades utilizando documentación del fabricante.",
    "Identificar daños e incertidumbres que exigen aislar material y consultar a una persona competente."
  ],
  "prerequisites": [
    "s4-grupo-liderazgo",
    "s4-riesgo-decisiones",
    "s4-carta-brujula",
    "s4-pronostico-decision"
  ],
  "sources": [
    "icar-tipos",
    "dmm-inspeccion",
    "petzl-factor"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "carga-direccion"
  ],
  "preparation": [
    "Explicar los conceptos sin confundir un modelo con una maniobra.",
    "Reconocer al menos dos errores del caso y justificar una alternativa.",
    "Identificar la documentación y las competencias prácticas que faltan."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "icar-tipos",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Dos cuerdas tienen el mismo color. ¿Qué permite clasificarlas?",
        "options": [
          "Su apariencia.",
          "Identificación y documentación de cada producto.",
          "La preferencia del grupo."
        ],
        "answer": 1,
        "explanation": "La identificación documentada permite contrastar el uso previsto.",
        "rationales": [
          "El color no demuestra construcción ni función.",
          "La identificación documentada permite contrastar el uso previsto.",
          "La preferencia no es evidencia técnica."
        ],
        "source": "icar-tipos",
        "kind": "aplicación",
        "difficulty": "intermedia"
      },
      {
        "prompt": "En el modelo 2 m de caída / 4 m de cuerda, el factor es…",
        "options": [
          "0,5, sin que eso determine toda la fuerza.",
          "2 y certifica la reunión.",
          "4 kN."
        ],
        "answer": 0,
        "explanation": "Es una razón sin unidades; faltan otras variables.",
        "rationales": [
          "Es una razón sin unidades; faltan otras variables.",
          "Se invierte el cociente y se añade una conclusión injustificada.",
          "Se confunde una razón con una fuerza."
        ],
        "source": "petzl-factor",
        "kind": "aplicación",
        "difficulty": "intermedia"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

Una cuerda transmite tensión y puede gestionar energía según su construcción y el sistema. Carga es la acción que recibe un componente; tensión es la fuerza transmitida a lo largo de un tramo. Dirección y magnitud importan: una flecha sin dirección definida no permite analizar un conector. Rozamiento y fricción designan aquí la interacción que se opone al deslizamiento; su efecto puede ayudar al frenado o dificultar el movimiento.

## Teoría y decisiones

Separa tres preguntas: qué cuerda es, qué función se le pide y qué condiciones cambiarán su respuesta. «Dinámica», «de bajo alargamiento» y «estática» no son etiquetas intercambiables. ICAR advierte sobre la confusión por colores y recomienda una identificación inequívoca dentro del equipo [Referencia: icar-tipos](#fuente-icar-tipos). No clasifiques una cuerda por tocarla o mirar su funda.

El factor de caída teórico es altura de caída dividida por longitud de cuerda que participa en absorberla; no expresa por sí solo la fuerza resultante. El rozamiento puede limitar la longitud que trabaja. La energía de una caída se reparte entre deformaciones y movimientos del sistema, no desaparece al cerrar un mosquetón [Referencia: petzl-factor](#fuente-petzl-factor). En un problema de papel, 2 m/4 m y 1 m/2 m dan 0,5; no autorizan una caída de ensayo ni garantizan fuerzas iguales en situaciones reales.

Una cuerda dinámica y una cinta poco extensible no son sustitutos aunque soporten una carga estática parecida en algún ensayo. El comportamiento del material, la construcción, la humedad y las condiciones de uso deben consultarse en la documentación específica. No trasladar una cifra de poliamida a otro textil, ni de un producto nuevo a otro desgastado. Diámetro y longitud nominal no resuelven por sí solos compatibilidad con un dispositivo: importan su modelo, función, manual, desgaste y configuración.

La inspección combina trazabilidad e identificación de anomalías. DMM describe revisión de toda la longitud, zonas planas o abultadas, funda dañada y efectos de calor, con vida útil según fabricante [Referencia: dmm-inspeccion](#fuente-dmm-inspeccion). No convertir «parece limpia» en ausencia de contaminación; si se desconoce su historial, esa incertidumbre se registra y se deriva a revisión competente.

## Caso práctico y aplicación al guiado

Filo Austral recibe dos cuerdas sin etiqueta, una húmeda y otra guardada junto a sustancias desconocidas. Un compañero propone elegir la más gruesa. Redacta una decisión de no incorporación al sistema hasta resolver identidad, historial, inspección y uso previsto. La alternativa es conseguir material documentado y personal competente, no ensayar su resistencia con pasajeros.

## Errores frecuentes y señales de alerta

Confundir kg con N; identificar material por color; asumir que redundancia elimina un fallo común; comparar solo cargas de rotura; olvidar longitud útil, extremos y recorrido. Un daño o historial incierto no se corrige completando un formulario de inventario.

## Autoevaluación y respuestas explicadas

1. ¿Un factor de caída calculado certifica el sistema? **No: es un modelo parcial y omite múltiples variables.**
2. ¿Por qué registrar el manual? **Vincula el ejemplar y su función con criterios comprobables, en vez de memorizar valores universales.**

## Ejercicios y práctica presencial

Trabajo individual: fichar dos productos mediante sus manuales, sin cargarlos. Taller supervisado: identificar cuerda, inspeccionar un ejemplar didáctico y explicar hallazgos. Los ensayos de caída, suspensión o carga no forman parte de la práctica individual.

## Evidencia requerida

Dos fichas con modelo, documento y revisión; dibujo de dirección de carga; informe de anomalías e incertidumbres. El instructor evalúa reconocimiento y selección contextual, no solo recitado.

## Relaciones con otras habilidades

Revisa los prerrequisitos y el contrato de habilidad de esta unidad en el programa. Contrasta la explicación con las fuentes indicadas: las cifras de un ejercicio no son límites de uso de un equipo. Toda transferencia a una situación con personas requiere formación y revisión presencial.
