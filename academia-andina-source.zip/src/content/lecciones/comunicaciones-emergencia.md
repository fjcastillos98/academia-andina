---
{
  "title": "Comunicaciones y emergencia",
  "description": "Preparar mensajes claros, medios y contingencias sin confundir comunicación con rescate garantizado.",
  "module": "M00",
  "code": "P1-J",
  "order": 110,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "pilot",
  "reviewDate": "2026-10-22",
  "objectives": [
    "Redactar un mensaje simulado con ubicación y necesidad explícitas.",
    "Preparar verificación de medios sin activar una emergencia real.",
    "Reconocer límites de conectividad y respuesta."
  ],
  "prerequisites": [
    "Estudiar Cuerdas y conceptos básicos de anclaje y explicar sus límites."
  ],
  "sources": [
    "garmin-sos"
  ],
  "pending": [
    "Revisión pedagógica y validación de criterios por instructor competente.",
    "Aplicación territorial en Los Lagos: requiere verificación situada."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Para practicar un aviso de emergencia debes…",
        "options": [
          "Activar SOS para ver cuánto demora.",
          "Hacer un simulacro sin alarma real y seguir el manual para pruebas del equipo.",
          "Transmitir en cualquier frecuencia disponible."
        ],
        "answer": 1,
        "explanation": "SOS se reserva para emergencias reales. Las pruebas se realizan mediante los procedimientos autorizados del fabricante."
      },
      {
        "prompt": "Un mensaje con coordenadas debería…",
        "options": [
          "Omitir el formato para ser breve.",
          "Garantizar el rescate inmediato.",
          "Indicar referencia y formato y comprobar comprensión cuando sea posible."
        ],
        "answer": 2,
        "explanation": "La ubicación debe ser interpretable; la comunicación no garantiza tiempos de respuesta ni evacuación."
      }
    ]
  },
  "pilot": {
    "position": 10,
    "requires": [
      "cuerdas-anclajes"
    ],
    "critical": false,
    "classifications": [
      "TEORÍA",
      "PROCEDIMIENTO",
      "PRÁCTICA INDIVIDUAL",
      "PRÁCTICA SUPERVISADA",
      "COMPETENCIA"
    ],
    "relatedModules": [
      "M00"
    ],
    "criteria": [
      "Comunica hechos y ubicación con referencia, distingue confirmación de envío, explica una contingencia y sabe qué datos operativos siguen por verificar. Evaluación presencial antes de asumir comunicaciones de grupo."
    ]
  }
}
---
## Conceptos

**TEORÍA.** Comunicar exige emisor, medio, destinatario y confirmación de comprensión. Que una pantalla muestre una posición no prueba que el mensaje haya llegado. Un plan distingue avisos rutinarios, cambios y solicitud de ayuda.

Garmin indica para inReach Mini 2 que SOS requiere una suscripción satelital activa y acceso a cielo abierto; la función SOS se reserva para emergencias reales [Garmin](#fuente-garmin-sos). El manual debe consultarse para la prueba y operación del equipo. Poseer el dispositivo no acredita su configuración ni garantiza un tiempo de respuesta.

## Desarrollo teórico y toma de decisiones

**PROCEDIMIENTO · análisis y preparación.** En un simulacro de mesa, estructura un mensaje: quién comunica y cómo devolver el contacto; qué sucede; dónde, con referencia y formato de coordenadas; cuántas personas necesitan ayuda; peligros inmediatos observados; ayuda solicitada; recursos y limitaciones relevantes. Separa hechos de sospechas y confirma que el receptor entendió la posición. No uses datos reales de pacientes en el diario.

Antes de salir, acuerda responsables, medios disponibles, energía, horario o condición de los avisos y alternativa si no se recibe confirmación. Los destinatarios y procedimientos locales se verifican para el lugar; este piloto no publica teléfonos ni frecuencias como vigentes.

Para VHF, autorización, canal, cobertura y reglas aplicables en Chile **requieren verificación con SUBTEL y el servicio pertinente antes de transmitir**. No se presupone un canal universal de montaña. Con inReach, estudiar el manual y practicar mediante la función de prueba que allí se indique es distinto de activar SOS. Nunca actives una emergencia para completar este ejercicio.

## Ejemplo

Actividad didáctica original, no descripción de una ruta operativa.

## Caso de estudio

Caso ficticio: el grupo envía «estamos mal cerca del cerro» y apaga el equipo para ahorrar batería. El contacto no sabe si hubo confirmación ni dónde está el grupo. Reescribe el mensaje sin inventar diagnóstico ni ubicación.

Respuesta orientativa: usar una ubicación comprobada con su referencia, describir hechos, declarar lo desconocido y acordar continuidad de comunicación conforme a instrucciones del receptor y equipo. Solicitar ayuda no autoriza a improvisar una maniobra técnica.

## Errores frecuentes

Confundir envío con recepción; omitir referencia de coordenadas; transmitir hipótesis como hechos; creer que SOS asegura evacuación inmediata; activar una alarma para practicar.

## Límites y puntos críticos de seguridad

La autoprotección y la evaluación local preceden a una maniobra improvisada. Este módulo no enseña atención médica ni rescate técnico; ambos requieren formación específica.

## Material y equipo relacionado

InReach Mini 2, VHF, teléfono, energía y plan de comunicación. Manual y configuración reales deben verificarse; no almacenar contraseñas, claves ni datos médicos aquí.

## Recuperación activa

- ¿Qué diferencia hay entre mensaje enviado y comprendido?
- ¿Qué falta verificar antes de usar una VHF en una salida?

Responde antes de consultar el texto. Luego anota qué cambiaste y por qué; el recuerdo sin justificación no basta.

## Ejercicio y práctica

**PRÁCTICA INDIVIDUAL** limitada a análisis en mesa u observación segura. Con dos personas en una habitación, redacta y lee un mensaje ficticio; el receptor lo resume y señala datos ausentes. Usa tarjetas o equipos apagados: no emitas tráfico de emergencia ni actives SOS.

**PRÁCTICA SUPERVISADA.** Un instructor competente selecciona el contexto y observa la ejecución pertinente; este texto no autoriza a realizar maniobras técnicas sin esa formación. Antes de la sesión, acuerda objetivo, límites y cómo se interrumpirá el ejercicio.

## Registro de práctica

Abre el Diario de prácticas desde la navegación y selecciona esta habilidad. Registra fecha, lugar, condiciones, actividad, equipo, repeticiones, errores, correcciones y evidencia. Identifica al supervisor solo cuando estuvo presente. La confianza es una percepción, no un resultado de competencia. No incluyas datos médicos, contraseñas ni información privada de terceros.

## Criterios de revisión y competencia

**COMPETENCIA · evaluación pendiente.** Comunica hechos y ubicación con referencia, distingue confirmación de envío, explica una contingencia y sabe qué datos operativos siguen por verificar. Evaluación presencial antes de asumir comunicaciones de grupo.

La evaluación debe indicar quién observó, qué contexto y evidencia revisó, qué criterio aplicó y cuál fue el resultado. El diario conserva una declaración del usuario: no verifica identidad ni credenciales del evaluador y no emite certificaciones. Una lectura o quiz nunca demuestra ejecución técnica.

## Próximos pasos y relación con otros módulos

Integra los diez temas en un plan ficticio y revisa sus contradicciones antes de preparar una salida supervisada.

Relación con el currículo original: M00. Esta secuencia pertenece al bloque piloto **Módulo 1 — Fundamentales**; no renumera las 376 entradas pendientes del mapa original. Meteorología, navegación y decisiones se revisitan en montaña estival, invernal y glaciar; no son prerrequisitos prácticos ya acreditados.
