---
{
  "title": "Física de la nieve: estructura, agua y transformación",
  "description": "Distinguir densidad, cohesión y humedad.",
  "module": "M09",
  "code": "E5-02",
  "order": 501,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-02",
  "skills": [
    "s5-nieve-propiedades"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir densidad, cohesión y humedad.",
    "Explicar cómo precipitación, viento y temperatura modifican la nieve.",
    "Describir una superficie sin inferir estabilidad de todo el manto."
  ],
  "prerequisites": [
    "s5-invierno-fundamentos"
  ],
  "sources": [
    "e5-snow-science",
    "e5-metamorphism",
    "e5-eaws-glossary"
  ],
  "pending": [
    "Revisión pedagógica y de instructor. Condiciones, cobertura de boletines y aplicación territorial real: PENDIENTE DE VERIFICACIÓN."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Densidad significa…",
        "options": [
          "Masa por volumen.",
          "Seguridad de la ladera.",
          "Temperatura de la capa."
        ],
        "answer": 0,
        "explanation": "Es una propiedad física específica.",
        "rationales": [
          "Definición correcta.",
          "No es evaluación de riesgo.",
          "Es otra variable."
        ],
        "source": "e5-snow-science",
        "difficulty": "intermedia",
        "kind": "conocimiento"
      },
      {
        "prompt": "Una superficie endurecida soporta una bota. ¿Qué demuestra?",
        "options": [
          "Toda la ladera es estable.",
          "Ninguna capa débil existe.",
          "Una observación local de soporte bajo esas condiciones."
        ],
        "answer": 2,
        "explanation": "No informa todas las relaciones del manto.",
        "rationales": [
          "Extrapola espacialmente.",
          "No se examinó el interior.",
          "Delimita la observación."
        ],
        "source": "e5-metamorphism",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "Una foto de formas de nieve recibe el nombre penitentes. ¿Qué falta?",
        "options": [
          "Nada: todo relieve blanco lo es.",
          "Contrastar forma, proceso y localización.",
          "Solo medir la altitud."
        ],
        "answer": 1,
        "explanation": "La identificación exige evidencia, no un nombre sugerido.",
        "rationales": [
          "Confunde formas diferentes.",
          "Permite contrastar la hipótesis.",
          "Altitud sola no identifica proceso."
        ],
        "source": "e5-snow-science",
        "difficulty": "intermedia",
        "kind": "errores"
      }
    ]
  },
  "preparation": [
    "Usa términos distintos para propiedades distintas.",
    "Relaciona transformación con una hipótesis verificable.",
    "Explica por qué una muestra no describe toda la ladera."
  ],
  "openAssessment": {
    "prompt": "Describe tres propiedades de una muestra ficticia y explica dos conclusiones que no puedes obtener de ellas.",
    "rubric": [
      "Usa términos distintos para propiedades distintas.",
      "Relaciona transformación con una hipótesis verificable.",
      "Explica por qué una muestra no describe toda la ladera."
    ],
    "source": "e5-snow-science",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-manto"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Nombrar depósito, dureza aparente, humedad observada y forma son operaciones diferentes; registrar cada una evita conclusiones ambiguas.

## Teoría y toma de decisiones

La nieve comienza con cristales de hielo que se forman en la atmósfera y pueden agregarse o modificarse antes de llegar al suelo. Una vez depositada, contiene una estructura de hielo y espacios con aire; cuando hay fusión, también interviene agua líquida. La densidad expresa masa por volumen. Cohesión describe la unión entre partículas: dos muestras con densidad semejante pueden tener estructura y comportamiento distintos. La humedad no se deduce solo del color ni equivale a la temperatura del aire [NSIDC](#fuente-e5-snow-science).

El término nieve reciente describe una historia de depósito, no una garantía de blandura ni una duración universal. Nieve vieja indica que ha evolucionado respecto de la precipitación original; no significa necesariamente nieve estable. La nieve transportada ha sido desplazada por viento y la nieve venteada describe una superficie o depósito afectado por ese proceso. El viento puede fragmentar cristales y redistribuirlos, dejando sectores erosionados y acumulaciones. Una placa es una capa relativamente cohesionada, no un sinónimo de hielo: puede presentar diferentes durezas [EAWS](#fuente-e5-eaws-glossary).

Metamorfismo es la transformación de la microestructura. Temperatura, diferencias de temperatura dentro del manto y presencia de agua influyen en los procesos y propiedades. No se trata de una sucesión obligatoria de nieve peligrosa a nieve segura: una capa puede ganar cohesión mientras queda sobre otra menos resistente [SLF](#fuente-e5-metamorphism). En la unidad de nivología se estudian los mecanismos con más detalle. Aquí importa distinguir qué variable se está nombrando antes de extraer una consecuencia.

Durante un ciclo de fusión y rehielo puede aparecer una costra. «Costra» describe una capa endurecida; su origen, espesor, continuidad y relación con otras capas deben investigarse. Una superficie que soporta el peso no demuestra que la nieve profunda o la ladera contigua tenga el mismo comportamiento. Tampoco un hundimiento local demuestra por sí solo qué tipo de avalancha podría producirse. La descripción gana utilidad cuando compara posiciones y momentos sin omitir sus límites.

Los penitentes son formas puntiagudas de nieve o hielo endurecido, especialmente asociadas a regiones áridas como los Andes secos [NSIDC](#fuente-e5-snow-science). No deben confundirse con cualquier relieve de nieve modelado por viento ni usarse para afirmar presencia en una montaña de Los Lagos. Para reconocer una forma local hace falta evidencia del lugar y del proceso; una fotografía aislada puede resultar insuficiente.

En el ejercicio de aula, usa tres muestras descritas con datos ficticios: una ligera y poco cohesionada, otra compacta y cohesionada, y una tercera con agua líquida. Escribe qué dato adicional pedirías antes de compararlas. Después añade una capa inferior desconocida. La nueva pregunta debe cambiar: ya no comparas solamente muestras, sino relaciones entre capas. Un buen registro evita adjetivos globales como «buena nieve» y conserva una descripción que otro alumno pueda revisar.

## Qué observo, qué significa y qué no puedo concluir

No se estima estabilidad, densidad numérica ni capacidad portante de toda una ladera por aspecto superficial.

## Caso práctico y aplicación al guiado

Una persona dice «la nieve está dura, por eso no puede haber avalancha». Identifica qué propiedad observó y qué relación falta.

## Errores frecuentes y señales de alerta

Confundir densidad con resistencia; vieja con estable; costra con hielo macizo; penitentes con cualquier acumulación.

## Autoevaluación y respuesta razonada

Describe tres propiedades de una muestra ficticia y explica dos conclusiones que no puedes obtener de ellas.

## Ejercicios y práctica supervisada

Clasificar fotografías o muestras didácticas bajo guía, sin entrar a una ladera para obtenerlas.

## Evidencia requerida

- Usa términos distintos para propiedades distintas.
- Relaciona transformación con una hipótesis verificable.
- Explica por qué una muestra no describe toda la ladera.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-nieve-propiedades).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
