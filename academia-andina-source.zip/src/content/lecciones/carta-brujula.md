---
{
  "title": "Cartografía, brújula y orientación por terreno",
  "description": "Interpretar escala, relieve y sistema de coordenadas de una carta.",
  "module": "M14",
  "code": "E4-04",
  "order": 204,
  "minutes": 60,
  "level": "Intermedio",
  "status": "development",
  "reviewDate": "2026-10-22",
  "unit": "U4-04",
  "skills": [
    "s4-carta-brujula"
  ],
  "critical": false,
  "objectives": [
    "Interpretar escala, relieve y sistema de coordenadas de una carta.",
    "Resolver azimuts didácticos declarando el norte de referencia.",
    "Contrastar una posición mediante terreno y visuales sin ocultar incertidumbre."
  ],
  "prerequisites": [
    "Completar estudio de Fundamentales; la práctica previa debe revisarse presencialmente.",
    "Estudiar Gestión dinámica del riesgo y decisiones 3×3."
  ],
  "sources": [
    "usgs-navegacion",
    "noaa-declinacion",
    "usgs-nortes"
  ],
  "pending": [
    "Revisión pedagógica y evaluación situada por instructor competente.",
    "Condiciones, accesos, permisos y compatibilidad del equipo requieren verificación para cada actividad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "A escala 1:50 000, 3 cm equivalen a…",
        "options": [
          "150 m.",
          "1.500 m horizontales.",
          "3 km de marcha real."
        ],
        "answer": 1,
        "explanation": "3 × 50 000 cm = 150 000 cm = 1.500 m en planta."
      },
      {
        "prompt": "Con declinación ficticia +5° y azimut magnético 80°, el verdadero es…",
        "options": [
          "75°.",
          "80°.",
          "85°, con la convención indicada."
        ],
        "answer": 2,
        "explanation": "Se suma declinación este positiva. No es un valor local ni una conversión desde cuadrícula."
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

**TEORÍA.** La carta representa una selección del terreno, no sus condiciones actuales. **Escala** relaciona distancias del mapa y horizontales del terreno; **equidistancia** es el intervalo vertical entre curvas; **datum** es la referencia geodésica; **coordenadas** expresan una posición dentro de un sistema. Las curvas de nivel unen igual elevación; consulta equidistancia y leyenda antes de interpretar separación [Referencia: usgs-navegacion](#fuente-usgs-navegacion).

En esta unidad **azimut** es un ángulo horario entre 0° y 360° desde un norte declarado. Usamos **rumbo cuadrantal** para expresiones como N 30° E; en otros contextos “rumbo” se usa de manera más amplia. Acordar vocabulario evita comparar números que representan convenciones distintas.

## Teoría: leer relieve antes de dibujar una ruta

Busca valles, divisorias, cambios de pendiente y referencias identificables. Curvas próximas indican mayor pendiente a una escala y equidistancia dadas; no indican por sí solas calidad de roca, vegetación o paso practicable. Un espacio blanco no significa ausencia de peligros. La fecha del mapa importa para senderos y otros elementos cambiantes.

En un ejercicio de escala 1:50 000, 3 cm representan 1.500 m horizontales. Si un itinerario sube 200 m, baja 100 m y vuelve a subir 150 m, acumula 350 m de ascenso y termina 250 m sobre el inicio. Explica por qué ni la distancia en planta ni el desnivel neto bastan para estimar esfuerzo y tiempo.

Con coordenadas geográficas distingue grados decimales de grados y minutos. Con UTM registra zona y hemisferio además de este/norte. La cifra sin formato y datum puede producir una posición equivocada o imposible de interpretar. En los ejercicios no uses coordenadas reales de pasajeros ni ubicaciones privadas.

## Norte, declinación y brújula

USGS distingue norte geográfico, magnético y de cuadrícula [Referencia: usgs-nortes](#fuente-usgs-nortes). La declinación magnética es la diferencia angular entre norte magnético y geográfico; cambia con lugar y fecha [Referencia: noaa-declinacion](#fuente-noaa-declinacion). No reutilices un valor antiguo de una carta como si fuera invariable.

Con la convención de NOAA —este positivo, oeste negativo— el azimut verdadero se obtiene sumando la declinación al magnético y normalizando a 0–360°. **Ejemplo ficticio, no valor de Los Lagos:** magnético 80° y declinación +5° producen verdadero 85°. Un dato de cuadrícula puede requerir además considerar convergencia; esta fórmula no convierte automáticamente norte de cuadrícula. Comprueba la convención del mapa y del instrumento antes de practicar.

En mesa identifica cápsula, aguja, flecha de dirección y referencias de tu brújula siguiendo su manual. Distingue orientar el mapa de trasladar una dirección del mapa al terreno. La aguja no señala el destino. Mantén la lectura alejada de fuentes de interferencia según instrucciones del fabricante; la verificación práctica exige comparación con referencias conocidas.

## Orientación por terreno y triangulación

Para el ejercicio, elige referencias inequívocas en una carta didáctica. Una identificación incorrecta puede producir una intersección geométricamente convincente pero falsa. La localización por visuales a puntos conocidos se denomina a menudo “triangulación” en enseñanza básica; técnicamente conviene distinguirla de la triangulación de levantamiento.

Traza las direcciones inversas desde referencias identificadas usando el mismo norte y convención. En la realidad las líneas pueden delimitar una zona de incertidumbre, no un punto. Una tercera visual permite contrastar, pero no corrige automáticamente haber confundido dos cumbres. Valida también relieve, sentido de avance y referencias cercanas.

## Caso práctico: cordillera de Los Lagos, simulación

Dos integrantes reportan 120°, uno desde norte magnético y otro desde cuadrícula. Creen estar de acuerdo. Un tercero reconoce una loma, pero no puede distinguirla de otra similar. ¿Qué falta antes de desplazar al grupo?

Respuesta orientativa: acordar referencias, revisar datos de conversión y confirmar la identificación del terreno. La coincidencia numérica no representa necesariamente la misma dirección. El ejercicio se resuelve en mesa, no recorriendo un azimut hacia terreno desconocido.

## Errores frecuentes y señales de alerta

Leer la cuadrícula equivocada; omitir hemisferio; mezclar metros y grados; inferir transitabilidad de un color; orientar con una aguja interferida; aceptar una intersección sin contexto. Señal de revisión: posición calculada incompatible con un elemento visible o con la distancia recorrida.

## Autoevaluación y respuestas explicadas

1. Convierte N 30° E a azimut: **30° desde el mismo norte.** S 30° E corresponde a **150°**. Cambiar de convención no cambia el norte de referencia.
2. ¿Qué significa que tres visuales no coincidan exactamente? **Hay incertidumbre de lectura, referencia o trazado; no debes esconderla eligiendo el punto más conveniente.**

## Ejercicios y práctica presencial

Resuelve escala y desnivel del ejemplo, dibuja cuatro azimuts y convierte el caso ficticio de declinación. Después, con instructor en un espacio conocido y no expuesto, orienta la carta y explica dos referencias visibles. No practiques inicialmente de noche, en niebla ni cerca de cortados.

## Evidencia requerida

Carta anotada, cálculos con unidades, norte y fecha de referencia; explicación de una discrepancia y corrección observada. La tarea se considera demostrada solo dentro del contexto que observe el evaluador.

## Relaciones con otras habilidades

Esta unidad se integra en la ruta estival. Consulta la ficha de habilidad y sus prerrequisitos en el programa. Registra práctica y evaluación por separado: estudiar y responder correctamente no acredita ejecución. Los ejercicios son propuestas didácticas originales; los casos no son rutas operativas.
