---
{
  "title": "Capacidad de ascenso y desnivel: medir la tarea completa",
  "description": "Calcular ritmo vertical y distinguir ganancia acumulada de altitud.",
  "module": "M22",
  "code": "E10-07",
  "order": 1007,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U10-07",
  "skills": [
    "s10-ascenso-desnivel"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Calcular ritmo vertical y distinguir ganancia acumulada de altitud.",
    "Aplicar el concepto a una decisión de preparación de montaña y reconocer sus límites."
  ],
  "prerequisites": [
    "s10-umbral-vo2max"
  ],
  "sources": [
    "e10-load",
    "e10-monitoring"
  ],
  "pending": [
    "Revisión por profesional del ejercicio e instructor de montaña pendiente. Nutrición y salud requieren revisión profesional específica; no se ha evaluado aptitud personal.",
    "Los casos y rúbricas son propuestas pedagógicas originales. La aplicación individual requiere evaluación, técnica y seguimiento.",
    "No se atribuyen requisitos de certificación, umbrales universales ni preparación técnica a los resultados físicos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "600 m en 90 minutos equivalen a…",
        "options": [
          "400 m/h.",
          "600 m/h.",
          "900 m/h."
        ],
        "answer": 0,
        "explanation": "90 minutos son 1,5 horas.",
        "rationales": [
          "90 minutos son 1,5 horas.",
          "Ignora parte del tiempo.",
          "Mezcla unidades."
        ],
        "source": "e10-load",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Dos rutas con igual subida…",
        "options": [
          "Son idénticas.",
          "Pueden diferir en bajada, terreno y carga.",
          "Tienen la misma dificultad técnica."
        ],
        "answer": 1,
        "explanation": "El desnivel no describe todo.",
        "rationales": [
          "Faltan variables.",
          "El desnivel no describe todo.",
          "La dificultad requiere información propia."
        ],
        "source": "e10-load",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un ritmo vertical es…",
        "options": [
          "Una autorización para guiar.",
          "Una predicción segura.",
          "Un descriptor dependiente del contexto."
        ],
        "answer": 2,
        "explanation": "Requiere definición y condiciones.",
        "rationales": [
          "No observa guiado.",
          "No garantiza condiciones futuras.",
          "Requiere definición y condiciones."
        ],
        "source": "e10-load",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Calcula unidades correctamente.",
    "Distingue altitud y acumulado.",
    "Incluye descenso y condiciones."
  ],
  "openAssessment": {
    "prompt": "Calcula 600 m / 1,5 h y describe tres razones por las que no predice otra ruta.",
    "rubric": [
      "Calcula unidades correctamente.",
      "Distingue altitud y acumulado.",
      "Incluye descenso y condiciones."
    ],
    "source": "e10-load",
    "difficulty": "integración"
  },
  "diagrams": [
    "e10-medicion"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN PROFESIONAL PENDIENTE.** Este contenido no prescribe un programa individual ni acredita competencia técnica. Los ejercicios numéricos y casos son ficticios. No introduzcas datos médicos, mediciones corporales privadas ni antecedentes de terceros.

## Conceptos clave y propósito

Desnivel positivo, desnivel negativo, altitud, tiempo total, pausas y ritmo vertical.

## Teoría y toma de decisiones

Altitud es la cota de un punto; desnivel acumulado suma los ascensos o descensos del recorrido. Una ruta ondulada puede terminar cerca de su inicio y acumular mucha subida. Para preparar montaña, ambas cifras responden preguntas distintas.

El ritmo vertical educativo se calcula como desnivel positivo dividido por tiempo en horas. En un ejemplo original, 600 m positivos en 90 minutos equivalen a 400 m/h si esos 90 minutos incluyen todas las pausas. Usar solo tiempo en movimiento cambia el significado. La fórmula no estima por sí sola la duración de una ruta real.

La velocidad debe interpretarse con pendiente, firme, carga, altitud y contexto. Los estudios de marcha con carga muestran que la tarea externa altera su coste; no existe una conversión universal entre un buen tiempo urbano y una ascensión remota. [Investigación de carga](#fuente-e10-load).

La preparación también incluye bajada y gestión del esfuerzo hasta el regreso. El laboratorio conserva metros positivos y negativos separados. No suma ambos como si fueran una única adaptación ni usa una cifra de ascenso para certificar competencia.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación del aprendizaje:** Registra qué considera el dispositivo como desnivel y tiempo; conserva la definición al comparar. Anota terreno y mochila junto al número. Revisa errores de medición antes de interpretar cambios pequeños. No persigas una marca cuando empeoran visibilidad o apoyo.

La selección real de ejercicios, cargas, pruebas y progresión corresponde a una evaluación individual con profesionales. Las técnicas críticas de montaña requieren formación práctica y supervisión de instructor competente. El acondicionamiento físico no autoriza una maniobra.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Dos itinerarios tienen 600 m positivos: uno termina con un descenso largo y otro junto a transporte. ¿Por qué no representan la misma tarea?

Distingue dato, interpretación y decisión. Explica qué incertidumbre permanece. Los casos no representan un protocolo del organismo citado ni un criterio oficial de habilitación para guía.

## Errores frecuentes y puntos críticos de seguridad

Confundir cumbre con desnivel; excluir pausas sin decirlo; omitir bajada; convertir m/h en garantía de horario.

## Material y equipo relacionado

Mapa, altímetro o GPS con sus limitaciones, cronómetro y registro. El equipo de navegación no sustituye saber orientarse.

[Consultar inventario](../../equipo/). Ajustar o poseer el equipo no demuestra dominarlo. Las prácticas técnicas se registran por separado del acondicionamiento.

## Autoevaluación y recuperación activa

- Explica la diferencia entre la capacidad que estudias y una tarea técnica de montaña.
- ¿Qué información falta en el caso y qué decisión modificaría?
- ¿Qué parte puede analizarse en escritorio y cuál necesita observación profesional?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Calcula 600 m / 1,5 h y describe tres razones por las que no predice otra ruta.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Comparación de registros y marcha submáxima supervisada en recorrido conocido; prioridad al control y retorno.

## Evidencia requerida y criterios de competencia

- Calcula unidades correctamente.
- Distingue altitud y acumulado.
- Incluye descenso y condiciones.

**COMPETENCIA:** estos criterios describen aprendizaje que debe observar un profesional en contexto. No acreditan aptitud médica, entrenamiento personal, guiado ni maniobra técnica. Una lectura, prueba física o quiz no otorga certificación. Marca pendiente lo que no se haya evaluado.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s10-ascenso-desnivel). Registra fecha, actividad, escenario, equipo, objetivo, errores, correcciones, supervisor y evidencia de aprendizaje. No guardes datos médicos ni contraseñas. No inventes sesiones, evaluaciones o repeticiones para completar la matriz.

## Relaciones con otros módulos

[Entrenamiento](../../entrenamiento/) · [Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Programa](../../programa/). Entrenamiento general, preparación específica, aclimatación y competencia técnica se relacionan, pero no son equivalentes.
