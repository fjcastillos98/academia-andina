---
{
  "title": "Volcán, cerro, complejo y macizo: nombrar la entidad correcta",
  "description": "Separa topónimo, edificio y conjunto volcánico.",
  "module": "M11",
  "code": "E12-02",
  "order": 1202,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U12-02",
  "skills": [
    "s12-edificios-volcanicos"
  ],
  "critical": false,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Separa topónimo, edificio y conjunto volcánico.",
    "Atribuye una clasificación a una fuente y escala."
  ],
  "prerequisites": [
    "s12-tectonica-subduccion"
  ],
  "sources": [
    "e12-glossary",
    "e12-name-lara",
    "e12-name-antillanca"
  ],
  "pending": [
    "Revisión por especialista en geología y vulcanología e instructor de montaña pendiente. No valida una ruta, acceso ni evacuación.",
    "Alertas actuales, restricciones, cotas discrepantes y condiciones de terreno requieren verificación independiente; no hay datos operativos en tiempo real.",
    "Casos, rúbricas y ejercicios originales. Las descripciones científicas no acreditan competencia técnica ni un protocolo universal de seguridad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Cerro Sarnoso…",
        "options": [
          "No puede tener origen volcánico por llamarse cerro.",
          "Es necesariamente extinto.",
          "Puede nombrar un relieve de origen volcánico documentado."
        ],
        "answer": 2,
        "explanation": "Las fuentes permiten esa distinción.",
        "rationales": [
          "El topónimo no determina la génesis.",
          "La etiqueta no demuestra estado eruptivo.",
          "Las fuentes permiten esa distinción."
        ],
        "source": "e12-glossary",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Casablanca y Antillanca…",
        "options": [
          "Deben distinguirse como centro y conjunto según la fuente.",
          "Son siempre entidades idénticas.",
          "Tienen todos los mismos eventos individuales."
        ],
        "answer": 0,
        "explanation": "Respeta el alcance del catálogo.",
        "rationales": [
          "Respeta el alcance del catálogo.",
          "Borra diferencias de escala.",
          "No se transfiere así una cronología."
        ],
        "source": "e12-glossary",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La silueta de un cerro…",
        "options": [
          "Prueba su edad.",
          "No sustituye un estudio geológico.",
          "Autoriza un acceso."
        ],
        "answer": 1,
        "explanation": "Erosión y construcción pueden superponerse.",
        "rationales": [
          "La forma no basta para fechar.",
          "Erosión y construcción pueden superponerse.",
          "Es una decisión de otro ámbito."
        ],
        "source": "e12-glossary",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Separa topónimo, edificio y conjunto volcánico.",
    "Atribuye una clasificación a una fuente y escala.",
    "Evita trasladar eventos del conjunto a cada cumbre."
  ],
  "openAssessment": {
    "prompt": "Construye una tabla de Sarnoso y Casablanca con nombre cotidiano, entidad geológica, fuente y equivalencia pendiente.",
    "rubric": [
      "Separa topónimo, edificio y conjunto volcánico.",
      "Atribuye una clasificación a una fuente y escala.",
      "Evita trasladar eventos del conjunto a cada cumbre."
    ],
    "source": "e12-glossary",
    "difficulty": "integración"
  },
  "diagrams": [
    "e12-documentos"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ESPECIALISTA PENDIENTE.** Estudio documental: no autoriza aproximación a fenómenos volcánicos ni acredita competencia de guía. No se publican alertas actuales. No guardes datos médicos ni contraseñas.

## Conceptos clave y propósito

Topónimo: nombre del lugar. Edificio volcánico: relieve construido por actividad volcánica. Centro emisor, estratovolcán, escudo, cono, complejo y grupo. Macizo es un término geográfico que no determina por sí solo origen ni actividad.

## Teoría y toma de decisiones

Un nombre cotidiano y una clasificación geológica responden preguntas distintas. “Cerro” nombra una elevación sin descartar que sea volcánica. “Complejo” puede agrupar varios centros y episodios; su alcance debe leerse en el trabajo que lo define. No equivale automáticamente a una cumbre, un cráter o una unidad administrativa.

Los estratovolcanes se construyen por acumulación de unidades eruptivas sucesivas; los volcanes escudo suelen presentar relieves amplios de pendientes suaves. La geometría visible también cambia por erosión y colapso, por lo que la silueta aislada no basta para clasificar un lugar. Un cráter y una caldera tampoco son sinónimos de cualquier depresión.

El catálogo GVP distingue Casablanca de otros centros de Antillanca. Lara y colaboradores documentan estructura volcánica del Complejo Sarnoso. Estas referencias permiten explicar por qué llamar “cerro” a Sarnoso no refuta su origen. La equivalencia precisa entre topónimo excursionista, cota y extensión de una unidad geológica continúa necesitando cartografía. No se asigna una única edad o estado eruptivo a todos los componentes de un conjunto.

Fuentes de esta unidad: [Referencia 1](#fuente-e12-glossary) · [Referencia 2](#fuente-e12-name-lara) · [Referencia 3](#fuente-e12-name-antillanca). Las aplicaciones de estudio y casos siguientes son elaboración pedagógica original, no protocolos de esas organizaciones.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — lectura y análisis documental:** Escribe el nombre utilizado y la entidad que describe cada fuente. Compara escala, límites y centros incluidos. Variante: ficha de catálogo frente a artículo con unidades; conserva sus diferencias en vez de fusionarlas.

El ejercicio se realiza en escritorio o lugar autorizado. No expongas al grupo para comprobar actividad, gases, temperatura o estabilidad. Las maniobras críticas de montaña requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una tabla dice “Antillanca” y una foto muestra Casablanca. Alguien transfiere a la cumbre cada evento de la tabla. Identifica el salto de escala.

## Errores frecuentes y puntos críticos de seguridad

Confundir complejo y cumbre; inferir extinción por erosión; considerar toda depresión un cráter; resolver homónimos solo por una imagen.

## Material y equipo relacionado

Catálogo, artículo y mapa de referencia. No extraer muestras ni acercarse a cráteres para completar la clasificación.

[Consultar inventario](../../equipo/). Poseer un dispositivo o equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Justifica con un ejemplo y un límite: Separa topónimo, edificio y conjunto volcánico.
- Justifica con un ejemplo y un límite: Atribuye una clasificación a una fuente y escala.
- Justifica con un ejemplo y un límite: Evita trasladar eventos del conjunto a cada cumbre.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Construye una tabla de Sarnoso y Casablanca con nombre cotidiano, entidad geológica, fuente y equivalencia pendiente.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Revisión documental con especialista; discusión de entidades sobre mapas publicados sin crear itinerarios operativos.

## Evidencia requerida y criterios de competencia

- Separa topónimo, edificio y conjunto volcánico.
- Atribuye una clasificación a una fuente y escala.
- Evita trasladar eventos del conjunto a cada cumbre.

**COMPETENCIA:** estos criterios requieren revisión humana contextual. Leer, resolver un quiz o presentar un documento no certifica guiado ni ejecución de maniobras. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s12-edificios-volcanicos). Registra fecha, escenario, fuente, errores, correcciones, supervisor y evidencia de aprendizaje. Separa ejercicio ficticio de actividad real. No inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Geología y vulcanología](../../geologia/) · [Fichas territoriales](../../territorio/) · [Ecología](../../ecologia/) · [Glaciar](../../glaciar/) · [Planificación](../../planificacion/) · [Programa](../../programa/). El conocimiento del origen del relieve complementa la planificación; no reemplaza información actual ni evaluación de terreno.
