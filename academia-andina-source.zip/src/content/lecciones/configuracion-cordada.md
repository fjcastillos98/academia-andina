---
{
  "title": "Configurar una cordada: capacidades y recursos",
  "description": "Relacionar integrantes, capacidades, reserva y rescate previsto.",
  "module": "M04",
  "code": "E6-05",
  "order": 605,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U6-05",
  "skills": [
    "s6-configuracion-cordada"
  ],
  "critical": true,
  "reviewDate": "2026-10-23",
  "objectives": [
    "Relacionar integrantes, capacidades, reserva y rescate previsto.",
    "Comparar límites de dos frente a varios sin recetar una composición universal."
  ],
  "prerequisites": [
    "s6-progresion-glaciar"
  ],
  "sources": [
    "e6-acc-team",
    "e6-petzl-team"
  ],
  "pending": [
    "Revisión de instructor y normativa/criterios de operación aplicables, fuera de esta síntesis. PENDIENTE DE VERIFICACIÓN.",
    "Revisión presencial por instructor competente pendiente. No se ha realizado ni aprobado ninguna práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Petzl presenta dos integrantes. ¿Eso recomienda dos para pasajeros?",
        "options": [
          "Sí, para todos.",
          "No; es un ejemplo contextual con límites.",
          "Sí, si hay más equipo."
        ],
        "answer": 1,
        "explanation": "No convertir un ejemplo técnico en composición universal.",
        "rationales": [
          "No se justifica: No convertir un ejemplo técnico en composición universal.",
          "Correcta: No convertir un ejemplo técnico en composición universal.",
          "No se justifica: No convertir un ejemplo técnico en composición universal."
        ],
        "source": "e6-petzl-team",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "El experto lleva todo el material. ¿Qué analizar?",
        "options": [
          "Solo el peso.",
          "Solo la marca.",
          "Qué capacidad queda si ese integrante no colabora."
        ],
        "answer": 2,
        "explanation": "La disponibilidad debe revisarse por escenarios.",
        "rationales": [
          "No se justifica: La disponibilidad debe revisarse por escenarios.",
          "No se justifica: La disponibilidad debe revisarse por escenarios.",
          "Correcta: La disponibilidad debe revisarse por escenarios."
        ],
        "source": "e6-acc-team",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Los nudos de frenado…",
        "options": [
          "Pueden ayudar en ciertas condiciones y complicar la extracción.",
          "Garantizan detener cualquier caída.",
          "Eliminan la necesidad de reserva."
        ],
        "answer": 0,
        "explanation": "Las fuentes describen efectos y compromisos, no garantías.",
        "rationales": [
          "Correcta: Las fuentes describen efectos y compromisos, no garantías.",
          "No se justifica: Las fuentes describen efectos y compromisos, no garantías.",
          "No se justifica: Las fuentes describen efectos y compromisos, no garantías."
        ],
        "source": "e6-acc-team",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "Considera quién queda disponible si alguien cae.",
    "Incluye reserva y acceso al material.",
    "No fija una proporción guía/pasajeros ni norma no verificada."
  ],
  "openAssessment": {
    "prompt": "Elabora una tabla de tres grupos ficticios con experiencia desigual. Anota qué habilidades faltan y por qué añadir equipo no las suple.",
    "rubric": [
      "Considera quién queda disponible si alguien cae.",
      "Incluye reserva y acceso al material.",
      "No fija una proporción guía/pasajeros ni norma no verificada."
    ],
    "source": "e6-acc-team",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**CONTENIDO TEÓRICO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Distribución de capacidades, Reserva accesible, Escenarios de caída. El ejemplo de Petzl de dos personas no convierte dos en recomendación para un grupo de pasajeros.

## Teoría y toma de decisiones

Configurar una cordada implica decidir quiénes participan, qué capacidades aportan y qué recursos seguirían disponibles tras una caída. El número de personas no es un sustituto de competencia. Petzl analiza un ejemplo de dos; ACC enfatiza la vulnerabilidad de esa composición. [Petzl](#fuente-e6-petzl-team) y [ACC](#fuente-e6-acc-team) deben leerse con su ámbito, no combinarse como si una cifra universal resolviera la discusión.

Una comparación útil considera escenarios. Si cae quien concentra el conocimiento o porta el material que los demás no saben utilizar, la disponibilidad inicial de equipo puede resultar engañosa. Pregunta qué tareas puede sostener el resto, cómo accede a reserva de cuerda y cómo comunica. Añadir una pieza sin entrenar su uso no añade automáticamente capacidad al grupo. Añadir una persona también exige coordinación y revisión del conjunto.

Los nudos de frenado ilustran una decisión con efectos posteriores: las fuentes discuten una ayuda condicionada a ciertas situaciones de nieve y la dificultad que introducen en la extracción. No basta elegirlos por una prueba aislada ni rechazarlos porque complican una fase; hay que comprender la estrategia completa con el instructor. Esta unidad no fija separación, longitud de reserva o composición para clientes.

En un ejercicio original, compara un grupo de dos con capacidades desiguales, uno de tres que nunca ha entrenado junto y uno que documentó un taller reciente. Para cada uno escribe qué sabes, qué falta observar y qué tarea perdería el grupo si un integrante no pudiera colaborar. El tercer grupo no queda aprobado automáticamente: una práctica anterior tiene contexto y límites. La decisión de guiado exige revisión profesional y de requisitos aplicables, que no se sustituyen por esta tabla.

## Procedimiento conceptual: objetivo, uso y límites

Relacionar integrantes, capacidades, reserva y rescate previsto. Esta unidad se utiliza para preparar el análisis y un taller, no para ejecutar una maniobra sin entrenamiento. ACC discute la fragilidad de esa configuración y cómo las decisiones previas complican o facilitan la extracción.

Las variantes técnicas mantienen el ámbito de la fuente citada. Antes de cambiar una configuración se deben revisar sus funciones, comprobaciones y límites con instructor; no se combinan pasos de escuelas distintas por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario hipotético de aula.** El integrante más experimentado propone llevar todo el material para simplificar mochilas. Analiza disponibilidad después de una caída, acceso, formación y alternativas sin asignar una posición universal.

## Errores frecuentes y puntos críticos

Contar personas sin evaluar capacidades; concentrar conocimiento; extrapolar un ejemplo de dos a pasajeros; inventar una proporción normativa.

No se atribuye una garantía de seguridad al equipo, al quiz ni a una práctica en condiciones diferentes. Si falta un dato esencial para justificar el objetivo, declarar ese vacío es parte del aprendizaje.

## Material y equipo relacionado

Identidad y acceso al material de cada persona, reserva de cuerda, comunicación y documentación de prácticas.

[Inventario personal](../../equipo/): conserva referencia del manual y observaciones de inspección. El registro no declara aptitud de una pieza ni competencia de quien la porta.

## Autoevaluación y recuperación activa

- ¿Qué capacidad desaparece si una persona no puede colaborar?
- ¿Por qué una ayuda en la detención puede complicar la extracción?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL de escritorio:** Elabora una tabla de tres grupos ficticios con experiencia desigual. Anota qué habilidades faltan y por qué añadir equipo no las suple.

**PRÁCTICA SUPERVISADA:** el instructor adapta un taller con objetivos observables, protección y criterios de parada. No provocar caídas reales ni entrar a terreno expuesto para comprobar esta página. La evaluación presencial es independiente de la respuesta teórica.

## Evidencia requerida y criterios de competencia

- Considera quién queda disponible si alguien cae.
- Incluye reserva y acceso al material.
- No fija una proporción guía/pasajeros ni norma no verificada.

Estos criterios valoran razonamiento; para una competencia práctica, el instructor debe definir y observar la ejecución en un contexto explícito. No se preasigna una evaluación por estudiar.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s6-configuracion-cordada). Registrar únicamente lo realizado: fecha, lugar, condiciones, objetivo, equipo, supervisor, resultado, errores, correcciones, evidencia, autonomía observada y próxima práctica. No guardar datos médicos ni información privada de pasajeros.

## Relaciones con etapas anteriores

[Glaciología introductoria](../glaciologia-intro/), [planificación invernal](../planificacion-invernal/), [encordamiento según contexto](../encordamiento-contexto/), [anclajes](../anclajes-reuniones/) y [ventaja mecánica](../ventaja-mecanica/). Estas dependencias orientan el estudio; no autorizan la aplicación técnica. [Ruta glaciar](../../glaciar/).
