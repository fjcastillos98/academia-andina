---
{
  "title": "Tefra y ceniza: fragmentación, transporte y depósito",
  "description": "Distingue tefra, ceniza, nube y depósito.",
  "module": "M11",
  "code": "E12-04",
  "order": 1204,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U12-04",
  "skills": [
    "s12-tefra-ceniza"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Distingue tefra, ceniza, nube y depósito.",
    "Explica por qué viento y escenario importan para interpretar dispersión."
  ],
  "prerequisites": [
    "s12-magma-lava-domos"
  ],
  "sources": [
    "e12-ash"
  ],
  "pending": [
    "Revisión por especialista en geología y vulcanología e instructor de montaña pendiente. No valida una ruta, acceso ni evacuación.",
    "Alertas actuales, restricciones, cotas discrepantes y condiciones de terreno requieren verificación independiente; no hay datos operativos en tiempo real.",
    "Casos, rúbricas y ejercicios originales. Las descripciones científicas no acreditan competencia técnica ni un protocolo universal de seguridad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "La ceniza volcánica es…",
        "options": [
          "Humo de madera quemada.",
          "Agua vaporizada únicamente.",
          "Fragmentos de roca, minerales y vidrio."
        ],
        "answer": 2,
        "explanation": "Corresponde a la descripción especializada.",
        "rationales": [
          "No procede de esa combustión.",
          "Vapor y ceniza son distintos.",
          "Corresponde a la descripción especializada."
        ],
        "source": "e12-ash",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La distancia al cráter…",
        "options": [
          "No basta para descartar caída de ceniza.",
          "Garantiza seguridad si es grande.",
          "Sustituye conocer el viento."
        ],
        "answer": 0,
        "explanation": "La dispersión depende de otros factores.",
        "rationales": [
          "La dispersión depende de otros factores.",
          "No existe esa garantía universal.",
          "Son datos distintos."
        ],
        "source": "e12-ash",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un mapa de dispersión debe leerse con…",
        "options": [
          "Solo su color más intenso.",
          "Leyenda, escenario, fecha y límites.",
          "Una ruta elegida por popularidad."
        ],
        "answer": 1,
        "explanation": "Permite interpretar qué representa.",
        "rationales": [
          "El color sin leyenda es ambiguo.",
          "Permite interpretar qué representa.",
          "No informa el fenómeno modelado."
        ],
        "source": "e12-ash",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue tefra, ceniza, nube y depósito.",
    "Explica por qué viento y escenario importan para interpretar dispersión.",
    "Reconoce límites de una fotografía para evaluar exposición."
  ],
  "openAssessment": {
    "prompt": "Dibuja una cadena emisión–transporte–depósito y añade en cada etapa una pregunta que requiere dato, no intuición.",
    "rubric": [
      "Distingue tefra, ceniza, nube y depósito.",
      "Explica por qué viento y escenario importan para interpretar dispersión.",
      "Reconoce límites de una fotografía para evaluar exposición."
    ],
    "source": "e12-ash",
    "difficulty": "integración"
  },
  "diagrams": [
    "e12-procesos"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ESPECIALISTA PENDIENTE.** Estudio documental: no autoriza aproximación a fenómenos volcánicos ni acredita competencia de guía. No se publican alertas actuales. No guardes datos médicos ni contraseñas.

## Conceptos clave y propósito

Tefra: material fragmentario expulsado. Ceniza: fracción fina, aproximadamente menor de 2 mm según la referencia especializada. Columna eruptiva, nube de ceniza, caída, dispersión y removilización son conceptos diferentes.

## Teoría y toma de decisiones

La ceniza volcánica contiene fragmentos de roca, minerales y vidrio; no equivale a ceniza de combustión. USGS la describe como abrasiva e insoluble en agua. Su tamaño fino no elimina sus efectos sobre equipos y personas. La fragmentación puede relacionarse con expansión de gases o interacción con agua, entre otros aspectos del proceso eruptivo.

La expulsión, el transporte atmosférico y la caída no son una única fase. El viento condiciona la dispersión; una nube no tiene por qué distribuirse simétricamente alrededor de la cumbre. La lectura de un mapa de caída requiere saber qué escenario, fecha y condiciones representa. Estar lejos del cráter no resuelve por sí solo exposición a ceniza.

En una observación no profesional conviene describir “columna visible” y su contexto antes de asegurar composición o concentración. Una fotografía no mide tamaño de partícula ni calidad del aire. Esta unidad no prescribe equipos respiratorios ni exposición aceptable. Para decisiones reales se necesita información oficial y medidas aplicables; el aprendizaje se realiza con documentos, sin recolectar ni levantar polvo.

Fuentes de esta unidad: [Referencia 1](#fuente-e12-ash). Las aplicaciones de estudio y casos siguientes son elaboración pedagógica original, no protocolos de esas organizaciones.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — lectura y análisis documental:** Separa emisión, nube y depósito; identifica material y proceso en la fuente; comprueba si la imagen o mapa describe observación, simulación o situación histórica. Variante: caída inicial frente a material levantado nuevamente por viento; no atribuir toda nube a nueva emisión.

El ejercicio se realiza en escritorio o lugar autorizado. No expongas al grupo para comprobar actividad, gases, temperatura o estabilidad. Las maniobras críticas de montaña requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una captura de un penacho se comparte sin fecha ni orientación. El grupo concluye que un valle está a salvo porque está lejos. Enumera los datos que faltan.

## Errores frecuentes y puntos críticos de seguridad

Confundir vapor y ceniza; suponer dispersión circular; tratar una mascarilla como autorización de exposición; interpretar polvo removilizado como erupción nueva sin comprobarlo.

## Material y equipo relacionado

Documentos y mapa con leyenda. Cámaras, óptica y comunicaciones pueden requerir protección según fabricante, pero no se ensaya en ceniza real.

[Consultar inventario](../../equipo/). Poseer un dispositivo o equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Justifica con un ejemplo y un límite: Distingue tefra, ceniza, nube y depósito.
- Justifica con un ejemplo y un límite: Explica por qué viento y escenario importan para interpretar dispersión.
- Justifica con un ejemplo y un límite: Reconoce límites de una fotografía para evaluar exposición.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Dibuja una cadena emisión–transporte–depósito y añade en cada etapa una pregunta que requiere dato, no intuición.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Lectura de una imagen y un mapa fechados con especialista; sin manipulación de ceniza ni ensayo de protección respiratoria.

## Evidencia requerida y criterios de competencia

- Distingue tefra, ceniza, nube y depósito.
- Explica por qué viento y escenario importan para interpretar dispersión.
- Reconoce límites de una fotografía para evaluar exposición.

**COMPETENCIA:** estos criterios requieren revisión humana contextual. Leer, resolver un quiz o presentar un documento no certifica guiado ni ejecución de maniobras. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s12-tefra-ceniza). Registra fecha, escenario, fuente, errores, correcciones, supervisor y evidencia de aprendizaje. Separa ejercicio ficticio de actividad real. No inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Geología y vulcanología](../../geologia/) · [Fichas territoriales](../../territorio/) · [Ecología](../../ecologia/) · [Glaciar](../../glaciar/) · [Planificación](../../planificacion/) · [Programa](../../programa/). El conocimiento del origen del relieve complementa la planificación; no reemplaza información actual ni evaluación de terreno.
