---
{
  "title": "Relieve volcánico y glaciar: leer una historia superpuesta",
  "description": "Explica superposición de construcción volcánica y erosión glaciar.",
  "module": "M11",
  "code": "E12-07",
  "order": 1207,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U12-07",
  "skills": [
    "s12-relieve-volcanico-glaciar"
  ],
  "critical": false,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Explica superposición de construcción volcánica y erosión glaciar.",
    "Distingue edad de una unidad de edad de un conjunto."
  ],
  "prerequisites": [
    "s12-lahares-cuencas"
  ],
  "sources": [
    "e12-name-mella",
    "e12-name-puntiagudo"
  ],
  "pending": [
    "Revisión por especialista en geología y vulcanología e instructor de montaña pendiente. No valida una ruta, acceso ni evacuación.",
    "Alertas actuales, restricciones, cotas discrepantes y condiciones de terreno requieren verificación independiente; no hay datos operativos en tiempo real.",
    "Casos, rúbricas y ejercicios originales. Las descripciones científicas no acreditan competencia técnica ni un protocolo universal de seguridad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un relieve puede ser…",
        "options": [
          "Solo volcánico o solo glaciar, nunca ambos.",
          "Seguro por estar erosionado.",
          "Volcánico en origen y modificado por glaciares."
        ],
        "answer": 2,
        "explanation": "Respeta la historia de construcción y modificación.",
        "rationales": [
          "Los procesos pueden superponerse.",
          "La erosión no certifica estabilidad.",
          "Respeta la historia de construcción y modificación."
        ],
        "source": "e12-name-mella",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La edad de una muestra…",
        "options": [
          "No se aplica automáticamente a todo el macizo.",
          "Fecha cada cumbre cercana.",
          "Describe el estado del hielo actual."
        ],
        "answer": 0,
        "explanation": "La atribución tiene alcance definido.",
        "rationales": [
          "La atribución tiene alcance definido.",
          "Falta demostrar equivalencia de unidades.",
          "Son datos de procesos y tiempos distintos."
        ],
        "source": "e12-name-mella",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Identificar roca volcánica…",
        "options": [
          "Aprueba un anclaje.",
          "No reemplaza evaluación de estabilidad y sistema técnico.",
          "Excluye fracturas."
        ],
        "answer": 1,
        "explanation": "Separa dos preguntas diferentes.",
        "rationales": [
          "La clasificación no es una prueba técnica.",
          "Separa dos preguntas diferentes.",
          "Una roca volcánica puede estar fracturada."
        ],
        "source": "e12-name-mella",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Explica superposición de construcción volcánica y erosión glaciar.",
    "Distingue edad de una unidad de edad de un conjunto.",
    "Evita inferir estabilidad técnica a partir de origen geológico."
  ],
  "openAssessment": {
    "prompt": "Dibuja dos secuencias hipotéticas que puedan explicar un relieve y enumera la evidencia que permitiría diferenciarlas.",
    "rubric": [
      "Explica superposición de construcción volcánica y erosión glaciar.",
      "Distingue edad de una unidad de edad de un conjunto.",
      "Evita inferir estabilidad técnica a partir de origen geológico."
    ],
    "source": "e12-name-mella",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ESPECIALISTA PENDIENTE.** Estudio documental: no autoriza aproximación a fenómenos volcánicos ni acredita competencia de guía. No se publican alertas actuales. No guardes datos médicos ni contraseñas.

## Conceptos clave y propósito

Construcción volcánica, erosión, depósito, secuencia, unidad geológica y edad atribuida. Una forma actual puede reunir procesos ocurridos en momentos distintos.

## Teoría y toma de decisiones

El trabajo de Mella y colaboradores sobre Tronador distingue unidades y centros dentro de un grupo volcánico y relaciona su historia con procesos glaciares. El relieve actual no se explica escogiendo una sola etiqueta entre volcán y glaciar: construcción y modificación pueden coexistir en la misma historia.

GVP describe Puntiagudo como un edificio volcánico fuertemente erosionado por glaciares. La pérdida de una forma cónica no elimina el origen volcánico. Sin embargo, llamar “erosionado” a un edificio tampoco demuestra que sea extinto ni que sus rocas sean estables para escalada. La geomorfología no reemplaza evaluación de terreno.

Para leer una secuencia separa observación, relación temporal y edad numérica. Una superficie que corta otra puede sugerir una relación relativa si se demuestra el contacto; asignarle miles de años requiere datos y métodos adicionales. No se datan rocas por color ni se transfiere la edad de una muestra a todo un macizo. El objetivo es explicar cómo se construye una interpretación y dónde deja de sostenerse.

Fuentes de esta unidad: [Referencia 1](#fuente-e12-name-mella) · [Referencia 2](#fuente-e12-name-puntiagudo). Las aplicaciones de estudio y casos siguientes son elaboración pedagógica original, no protocolos de esas organizaciones.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — lectura y análisis documental:** Describe formas y contactos visibles en material documental; plantea una secuencia; busca qué unidades y métodos identifica la fuente; conserva alternativas. Variante: edad relativa frente a edad numérica publicada. No convertir un dibujo en evidencia de un contacto real.

El ejercicio se realiza en escritorio o lugar autorizado. No expongas al grupo para comprobar actividad, gases, temperatura o estabilidad. Las maniobras críticas de montaña requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una persona llama no volcánica a la aguja Puntiagudo porque no tiene cono regular y luego la considera roca firme por antigua. Identifica ambas conclusiones injustificadas.

## Errores frecuentes y puntos críticos de seguridad

Confundir edad de una muestra y del conjunto; asignar erosión solo por una foto; usar génesis o antigüedad para validar anclajes, puentes de nieve o estabilidad.

## Material y equipo relacionado

Artículo, esquema y fotografía atribuida. No golpear ni cargar bloques como prueba geológica; el material técnico se evalúa en su formación específica.

[Consultar inventario](../../equipo/). Poseer un dispositivo o equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Justifica con un ejemplo y un límite: Explica superposición de construcción volcánica y erosión glaciar.
- Justifica con un ejemplo y un límite: Distingue edad de una unidad de edad de un conjunto.
- Justifica con un ejemplo y un límite: Evita inferir estabilidad técnica a partir de origen geológico.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Dibuja dos secuencias hipotéticas que puedan explicar un relieve y enumera la evidencia que permitiría diferenciarlas.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Lectura de paisaje desde lugar autorizado con especialista y evaluación de terreno por instructor; sin colecta ni pruebas de carga.

## Evidencia requerida y criterios de competencia

- Explica superposición de construcción volcánica y erosión glaciar.
- Distingue edad de una unidad de edad de un conjunto.
- Evita inferir estabilidad técnica a partir de origen geológico.

**COMPETENCIA:** estos criterios requieren revisión humana contextual. Leer, resolver un quiz o presentar un documento no certifica guiado ni ejecución de maniobras. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s12-relieve-volcanico-glaciar). Registra fecha, escenario, fuente, errores, correcciones, supervisor y evidencia de aprendizaje. Separa ejercicio ficticio de actividad real. No inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Geología y vulcanología](../../geologia/) · [Fichas territoriales](../../territorio/) · [Ecología](../../ecologia/) · [Glaciar](../../glaciar/) · [Planificación](../../planificacion/) · [Programa](../../programa/). El conocimiento del origen del relieve complementa la planificación; no reemplaza información actual ni evaluación de terreno.
