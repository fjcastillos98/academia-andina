---
{
  "title": "Montañas de Los Lagos: nombre, estructura y evidencia",
  "description": "Distinguir un topónimo de una clasificación geológica.",
  "module": "M18",
  "code": "E45-25",
  "order": 324,
  "minutes": 35,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U45-01",
  "skills": [
    "s45-territorio-nombres"
  ],
  "critical": false,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir un topónimo de una clasificación geológica.",
    "Construir una ficha territorial que conserve incertidumbres.",
    "Reconocer discrepancias de altitud y de escala del objeto descrito."
  ],
  "prerequisites": [
    "s4-grupo-liderazgo",
    "s4-riesgo-decisiones",
    "s4-carta-brujula",
    "s4-pronostico-decision"
  ],
  "sources": [
    "gvp-calbuco",
    "gvp-osorno",
    "gvp-puntiagudo",
    "gvp-yate",
    "uchile-casablanca",
    "lara-sarnoso",
    "mella-tronador"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente.",
    "PENDIENTE DE VERIFICACIÓN TERRITORIAL: accesos, límites administrativos, rutas y condiciones actuales."
  ],
  "diagrams": [
    "territorio-evidencia"
  ],
  "preparation": [
    "Distinguir hechos atribuidos, inferencias y datos pendientes.",
    "Explicar por qué la ficha no valida acceso, ruta ni condiciones.",
    "Preparar una observación sin extracción ni alteración del entorno."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "gvp-calbuco",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una ficha llama al lugar “cerro”, pero un artículo describe un complejo volcánico. ¿Qué corresponde?",
        "options": [
          "Conservar ambos términos y explicar qué objeto describe cada uno.",
          "Borrar el artículo porque contradice el nombre popular.",
          "Declarar automáticamente que el lugar está extinto."
        ],
        "answer": 0,
        "explanation": "Topónimo y clasificación tienen funciones distintas; la correspondencia espacial debe verificarse.",
        "source": "lara-sarnoso",
        "difficulty": "intermedia",
        "rationales": [
          "Reconoce las dos escalas sin inventar equivalencia.",
          "El nombre común no refuta una investigación geológica.",
          "La descripción de origen no determina actividad futura."
        ],
        "kind": "aplicación"
      },
      {
        "prompt": "Dos fuentes atribuyen altitudes diferentes al mismo nombre. ¿Cómo documentas?",
        "options": [
          "Promedias las cifras.",
          "Conservas ambas con fuente y marcas la discrepancia pendiente.",
          "Escoges la cifra que produce una salida más atractiva."
        ],
        "answer": 1,
        "explanation": "Antes de resolver la diferencia se debe comprobar fecha, método y objeto medido.",
        "source": "gvp-osorno",
        "difficulty": "intermedia",
        "rationales": [
          "El promedio no corresponde necesariamente a una medición.",
          "Conserva trazabilidad e incertidumbre.",
          "El objetivo comercial no valida un dato."
        ],
        "kind": "aplicación"
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

Montaña y cerro nombran relieves; no certifican un origen. Volcán describe un sistema o edificio relacionado con emisión de materiales desde el interior terrestre. Macizo agrupa un relieve montañoso; complejo volcánico puede reunir edificios o centros de historia relacionada. Nevado puede ser un topónimo o descripción de cobertura: no demuestra glaciación actual. Usa estas distinciones de trabajo y conserva la denominación exacta de cada fuente científica.

## Teoría: del nombre al objeto que estudias

Una ficha comienza preguntando qué objeto describe. “Casablanca”, “Antillanca” y un centro eruptivo cercano no son nombres intercambiables. Tampoco una coordenada del complejo es un waypoint validado para la cumbre. La tesis de Carrasco Lira estudia unidades de Casablanca junto con otros centros de Antillanca [Referencia: uchile-casablanca](#fuente-uchile-casablanca). Esa relación geológica no resuelve permisos ni rutas.

Sarnoso ofrece un ejercicio especialmente útil: Lara y colaboradores describen un complejo erosionado con conos piroclásticos, algunos posglaciales [Referencia: lara-sarnoso](#fuente-lara-sarnoso). Por tanto, repetir “cerro no volcánico” sería incorrecto; escribir “todo el conjunto extinto” también excede lo respaldado. El artículo no identifica por sí solo la cumbre recreativa que alguien llama Sarnoso.

Tronador exige distinguir grupo volcánico, complejo y cumbre. El trabajo de Mella y colaboradores documenta estructuras de distintas edades [Referencia: mella-tronador](#fuente-mella-tronador). Un nombre popular no sustituye esa escala. Mantén campos separados: nombre del lugar, denominación de fuente, objeto geológico y correspondencia cartográfica pendiente.

Las fichas adjuntas muestran altitudes atribuidas, no una precisión inventada. En Calbuco y Osorno, tablas actuales y leyendas históricas del catálogo presentan cifras diferentes. La respuesta profesional no es promediarlas: conserva fuente y fecha, consulta cartografía y explica por qué aún no adoptas una cota única para un documento operativo.

## Caso práctico: folleto para Filo Austral

Un borrador anuncia “Sarnoso, volcán extinto de acceso sencillo”. Subraya cuáles son tres afirmaciones diferentes: clasificación geológica, estado eruptivo y dificultad/acceso. Solo una parte de la primera tiene respaldo aquí. Reescribe el folleto como invitación interpretativa sin prometer un itinerario que no fue verificado. Explica al pasajero qué información falta antes de ofrecer una salida.

## Errores frecuentes y señales de alerta

Confundir el centro de un catálogo con una cima, trasladar la altura de un grupo al cerro, interpretar “sin erupción conocida” como ausencia de peligro o citar un blog como prueba geológica. Una fuente muy precisa en petrología puede no decir nada sobre transitabilidad.

## Autoevaluación y respuestas explicadas

¿Por qué dos cifras no se resuelven eligiendo la más repetida? Porque repetición no verifica método, fecha u objeto medido. ¿Qué confirma una roca volcánica? Un material de origen volcánico; no identifica por sí sola edad, edificio completo o actividad futura.

## Ejercicios y práctica presencial

Completa tres columnas para cada ficha: comprobado y atribuido, interpretación, pendiente. En una salida interpretativa supervisada, contrasta relieve visible con mapa sin salir del lugar autorizado ni acercarte a paredes para recoger muestras.

## Evidencia requerida

Ficha con alcance, citas, discrepancias y solicitudes concretas de verificación. Se evalúa reconocer los límites del dato, no memorizar altitudes.

## Relaciones con otras habilidades

Conecta geología, cartografía, planificación y comunicación. Una ficha documental no acredita navegación, guiado ni capacidad de ascenso.
