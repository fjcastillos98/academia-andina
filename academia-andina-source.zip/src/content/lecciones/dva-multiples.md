---
{
  "title": "Múltiples señales, marcación y límites del dispositivo",
  "description": "Distinguir señales detectadas, personas desaparecidas y personas confirmadas.",
  "module": "M09",
  "code": "E5-12",
  "order": 511,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-09",
  "skills": [
    "s5-dva-multiples"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir señales detectadas, personas desaparecidas y personas confirmadas.",
    "Comparar marcación con supresión de señal sin asumir equivalencia entre fabricantes.",
    "Identificar por qué múltiples víctimas exigen coordinación y formación avanzada."
  ],
  "prerequisites": [
    "s5-dva-fina"
  ],
  "sources": [
    "e5-bca-manual",
    "e5-bca-multiples",
    "e5-icar-dva"
  ],
  "pending": [
    "Funciones avanzadas y protocolos del equipo de rescate: revisión especializada pendiente."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una señal marcada significa…",
        "options": [
          "Víctima extraída.",
          "Estado clínico estable.",
          "Una función aplicada a una señal según el equipo."
        ],
        "answer": 2,
        "explanation": "La pantalla no documenta la extracción.",
        "rationales": [
          "Confunde interfaz y resultado.",
          "El DVA no mide estabilidad clínica.",
          "Conserva el alcance real."
        ],
        "source": "e5-bca-multiples",
        "difficulty": "intermedia",
        "kind": "conocimiento"
      },
      {
        "prompt": "Dos personas faltan y aparece una sola señal. ¿Qué es correcto?",
        "options": [
          "Reducir el recuento a una persona.",
          "Mantener el recuento y explicar la incertidumbre de recepción.",
          "Dar la búsqueda por terminada."
        ],
        "answer": 1,
        "explanation": "No toda persona desaparecida tiene necesariamente señal detectable.",
        "rationales": [
          "Elimina evidencia de testigos.",
          "Integra fuentes sin sustituirlas.",
          "No se ha completado localización."
        ],
        "source": "e5-icar-dva",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "¿Cuándo introducir modos complejos en formación?",
        "options": [
          "Tras dominar el escenario básico, con instructor y manual del modelo.",
          "Antes de aprender a cambiar de modo.",
          "Solo con un video sin equipo."
        ],
        "answer": 0,
        "explanation": "La complejidad exige fundamentos observables.",
        "rationales": [
          "Secuencia pedagógica coherente.",
          "Invierte prerrequisitos.",
          "No demuestra manejo presencial."
        ],
        "source": "e5-bca-multiples",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "Mantiene separados tres recuentos y explica discrepancias.",
    "Consulta funcionamiento específico de marcación/supresión.",
    "Reconoce límites humanos y clínicos del grupo."
  ],
  "openAssessment": {
    "prompt": "Construye un parte que distinga desaparecidos, señales, localizaciones y capacidad disponible sin inventar un triaje.",
    "rubric": [
      "Mantiene separados tres recuentos y explica discrepancias.",
      "Consulta funcionamiento específico de marcación/supresión.",
      "Reconoce límites humanos y clínicos del grupo."
    ],
    "source": "e5-bca-manual",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Comparar recuento de personas con señales e hitos confirmados; identificar el modo mostrado por el propio DVA.

## Teoría y toma de decisiones

Una indicación de múltiples señales es información electrónica, no un censo completo de personas. El número de desaparecidos procede también del grupo, testigos y recuento; una persona puede no emitir una señal detectable. A la inversa, un emisor de un rescatista puede confundirse con un objetivo si los modos no están coordinados. En la clase se mantienen tres columnas: personas que faltan, señales interpretadas y localizaciones confirmadas. Las columnas se relacionan, pero no se sustituyen entre sí.

Marcar o suprimir ayuda a gestionar señales durante búsquedas complejas, pero no elimina físicamente un emisor ni demuestra que alguien haya sido extraído. En la familia Tracker documentada, BCA describe supresión de la señal más fuerte y modos avanzados de visión general. [Funciones BCA](#fuente-e5-bca-multiples). Otro modelo puede tener un comportamiento diferente. Las duraciones, condiciones de retorno y confirmaciones de pantalla se estudian en el manual correspondiente; el alumno no debe trasladar una secuencia de botones aprendida en otro equipo.

El manual Tracker muestra por qué una función debe estudiarse dentro de su sistema de mandos y mensajes. [Manual de estos modelos](#fuente-e5-bca-manual). La práctica progresiva comienza con un objetivo simple antes de introducir señales próximas, pérdidas o tareas simultáneas. Agregar complejidad sin consolidar las fases básicas puede ocultar errores de localización detrás del uso de funciones avanzadas. «Pude marcar» describe una acción sobre la interfaz, no una búsqueda completa ni una decisión correcta sobre asignación de rescatistas.

El recurso escaso puede ser la capacidad de excavar y atender, no el número de aparatos. En un escenario ficticio con dos señales y tres compañeros disponibles, identifica funciones: búsqueda, confirmación, excavación, atención, coordinación y vigilancia de amenazas. No asignes automáticamente una persona a cada función como si pudieran multiplicarse. El ejercicio exige declarar qué tareas pueden coincidir, cuáles requieren ayuda y qué riesgo añade una sobrecarga. No pide decidir prioridades médicas basándose en un icono o en una cifra de profundidad.

La recomendación ICAR incluye funciones relevantes para el ámbito profesional y exige práctica continua y un estándar de desempeño del equipo. [Recomendación ICAR](#fuente-e5-icar-dva). Esto no convierte esa lista en una acreditación chilena ni autoriza al alumno a asumir un rescate organizado. Un grupo de compañeros tiene recursos limitados y debe comunicar lo que realmente conoce. La coordinación externa necesita información clara sobre desaparecidos, localizados, accesos y amenazas; «el aparato dice dos» es solo una pieza del mensaje.

Ejercicio original: cuatro tarjetas dicen «dos personas no regresan», «tres señales en pantalla», «una sonda con contacto» y «un recién llegado sigue emitiendo». Explica al menos dos hipótesis compatibles con las tarjetas y qué dato resolvería la discrepancia. No inventes un desenlace. Después cambia una tarjeta por «se pierde una señal»: indica por qué no puede eliminarse una persona del recuento. La incertidumbre permanece hasta que exista evidencia suficiente.

En el debriefing se evalúa si el alumno distinguió personas de señales, mantuvo referencias y evitó anunciar que una marcación significaba rescate finalizado. El registro de práctica identifica modelo, firmware, número de emisores de entrenamiento, tarea, errores y ayuda recibida. Las maniobras de múltiples sepultamientos, alternativas cuando falla marcación y coordinación con atención clínica corresponden a formación presencial avanzada. La lección prepara preguntas y reconoce límites; no entrega un algoritmo universal de triaje ni una garantía de resolver cualquier combinación de señales.

## Qué observo, qué significa y qué no puedo concluir

La marcación electrónica no equivale a extracción, identidad ni prioridad médica.

## Caso práctico y aplicación al guiado

Dos desaparecidos y tres señales: un recién llegado está emitiendo. Formula hipótesis antes de anunciar tres víctimas.

## Errores frecuentes y señales de alerta

Contar iconos como personas; asumir marcación permanente; asignar tareas imposibles; saltar entrenamiento de un objetivo.

## Autoevaluación y respuesta razonada

Construye un parte que distinga desaparecidos, señales, localizaciones y capacidad disponible sin inventar un triaje.

## Ejercicios y práctica supervisada

Taller progresivo con emisores inertes, instructor y control de escenarios múltiples después del dominio básico.

## Evidencia requerida

- Mantiene separados tres recuentos y explica discrepancias.
- Consulta funcionamiento específico de marcación/supresión.
- Reconoce límites humanos y clínicos del grupo.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-dva-multiples).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
