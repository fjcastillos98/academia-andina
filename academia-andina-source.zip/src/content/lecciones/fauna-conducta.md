---
{
  "title": "Comportamiento y seguridad frente a fauna: observar sin provocar",
  "description": "Describe conducta sin atribuir intenciones no comprobadas.",
  "module": "M15",
  "code": "E11-08",
  "order": 1108,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U11-08",
  "skills": [
    "s11-fauna-conducta"
  ],
  "critical": false,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Describe conducta sin atribuir intenciones no comprobadas.",
    "Justifica detener una observación por posible perturbación."
  ],
  "prerequisites": [
    "s11-invasoras-bioseguridad"
  ],
  "sources": [
    "e11-fauna"
  ],
  "pending": [
    "Revisión por especialista en ecología e instructor territorial pendiente. Los ejercicios no autorizan acceso, colecta o manejo de fauna.",
    "Categorías legales vigentes, protocolos de encuentro específicos y claves taxonómicas completas: requieren verificación.",
    "Casos, rúbricas y propuestas de práctica originales; no constituyen un protocolo oficial ni una certificación."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Alimentar fauna para acercarla…",
        "options": [
          "Mejora siempre su bienestar.",
          "Es parte necesaria de identificarla.",
          "Contradice la observación responsable."
        ],
        "answer": 2,
        "explanation": "La fuente recomienda no alimentar.",
        "rationales": [
          "Puede alterar conducta y salud.",
          "No es requisito de identificación.",
          "La fuente recomienda no alimentar."
        ],
        "source": "e11-fauna",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un animal inmóvil…",
        "options": [
          "No demuestra que el acercamiento sea inocuo.",
          "Siempre está cómodo.",
          "Autoriza tocarlo."
        ],
        "answer": 0,
        "explanation": "La interpretación requiere cautela.",
        "rationales": [
          "La interpretación requiere cautela.",
          "Atribuye un estado no demostrado.",
          "No hay autorización ni necesidad."
        ],
        "source": "e11-fauna",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una distancia universal…",
        "options": [
          "Resuelve toda situación.",
          "No reemplaza criterios de especie, contexto y reglas locales.",
          "Permite ignorar el terreno."
        ],
        "answer": 1,
        "explanation": "No simplifica indebidamente la decisión.",
        "rationales": [
          "Las condiciones varían.",
          "No simplifica indebidamente la decisión.",
          "La seguridad del grupo sigue vigente."
        ],
        "source": "e11-fauna",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Describe conducta sin atribuir intenciones no comprobadas.",
    "Justifica detener una observación por posible perturbación.",
    "Distingue cuidado general de protocolo específico por especie."
  ],
  "openAssessment": {
    "prompt": "Escribe tres mensajes de guía: evitar alimentación, finalizar una observación y explicar por qué no se comparte un punto de nidificación.",
    "rubric": [
      "Describe conducta sin atribuir intenciones no comprobadas.",
      "Justifica detener una observación por posible perturbación.",
      "Distingue cuidado general de protocolo específico por especie."
    ],
    "source": "e11-fauna",
    "difficulty": "integración"
  },
  "diagrams": [
    "e11-impacto"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ECOLÓGICA PENDIENTE.** Observación responsable para estudio personal. No acredita identificación taxonómica, competencia profesional ni autorización de acceso. No guardes datos médicos ni localizaciones precisas de especies sensibles.

## Conceptos clave y propósito

Perturbación, habituación, alimentación artificial, refugio, nidificación y distancia de observación. Describir conducta observable es diferente de atribuir intención al animal.

## Teoría y toma de decisiones

Leave No Trace recomienda observar a distancia, evitar seguimiento y no alimentar fauna. La fuente también destaca momentos sensibles como reproducción y crianza. Son principios generales de cuidado; no establecen una distancia única válida para todas las especies, terrenos o situaciones.

Antes de interpretar “está tranquilo”, describe hechos: dejó de alimentarse, se orientó al grupo, se desplazó o se ocultó. No son por sí solos un diagnóstico conductual, pero obligan a revisar si la presencia humana está interfiriendo. Una buena práctica puede consistir en suspender la observación. El interés fotográfico no justifica acorralar, cortar una vía de retirada o acercarse a una cría.

La seguridad humana sigue vinculada al terreno y al plan. No se propone retroceder ciegamente hacia un borde ni una maniobra universal ante cualquier animal. Mantén al grupo organizado, evita perseguir o tocar y solicita orientación pertinente ante fauna herida o un encuentro que no se puede gestionar con distancia. Las respuestas específicas por especie y las intervenciones requieren formación y protocolos aplicables.

Referencias de esta unidad: [Fuente 1](#fuente-e11-fauna). Los casos y las aplicaciones pedagógicas que siguen son elaboración original; no se atribuyen como protocolos de las fuentes.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — observación y decisión:** Define un punto de observación compatible con el sendero; revisa conducta visible y posibilidad de retirada del grupo; detén el acercamiento; aplica reglas del área y evita alimentar. Variante: observación lejana frente a animal que bloquea el paso; no convertir el paso obligado en motivo para hostigarlo.

No manipules fauna, no recolectes material y no salgas del itinerario autorizado para completar el ejercicio. La conducción real y las maniobras técnicas requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un ave deja de atender el nido mientras el grupo toma fotos. Algunos piden solo un minuto más. Redacta una indicación breve que priorice terminar la perturbación sin abandonar la seguridad del grupo.

## Errores frecuentes y puntos críticos de seguridad

Interpretar inmovilidad como consentimiento; ofrecer comida; perseguir crías; tocar animales heridos; prometer una distancia universal segura.

## Material y equipo relacionado

Prismáticos y zoom; comunicación del grupo. No se necesitan cebos, reproducción de cantos ni material de captura.

[Revisar inventario](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica cómo comprobarías este criterio: Describe conducta sin atribuir intenciones no comprobadas.
- Explica cómo comprobarías este criterio: Justifica detener una observación por posible perturbación.
- Explica cómo comprobarías este criterio: Distingue cuidado general de protocolo específico por especie.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Escribe tres mensajes de guía: evitar alimentación, finalizar una observación y explicar por qué no se comparte un punto de nidificación.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Simulación de conducción de grupo con observador humano y escenario ficticio; revisión de instrucciones claras y gestión del terreno, sin provocar encuentros reales.

## Evidencia requerida y criterios de competencia

- Describe conducta sin atribuir intenciones no comprobadas.
- Justifica detener una observación por posible perturbación.
- Distingue cuidado general de protocolo específico por especie.

**COMPETENCIA:** requiere observación y revisión humana en contexto. Una lectura, registro o quiz no certifica guiado, identificación experta ni maniobras. La plataforma no verifica credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s11-fauna-conducta) y [cuaderno de observación](../../ecologia/#observaciones). Separa ejercicio ficticio, observación real y práctica evaluada. Registra errores, correcciones, supervisor y evidencia sin inventar resultados. Mantén áreas generales; el texto libre no filtra automáticamente ubicaciones sensibles.

## Relaciones con otros módulos

[Ecología](../../ecologia/) · [Fichas de especies](../../especies/) · [Territorio](../../territorio/) · [Planificación](../../planificacion/) · [Programa](../../programa/). La interpretación ambiental se relaciona con geología, cartografía, gestión de grupos y patrimonio, sin sustituir su formación específica.
