---
{
  "title": "Resistencia aeróbica y zona 2: nombrar bien la intensidad",
  "description": "Interpretar zonas de entrenamiento sin asumir equivalencia entre modelos.",
  "module": "M22",
  "code": "E10-05",
  "order": 1005,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U10-05",
  "skills": [
    "s10-resistencia-zonas"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Interpretar zonas de entrenamiento sin asumir equivalencia entre modelos.",
    "Aplicar el concepto a una decisión de preparación de montaña y reconocer sus límites."
  ],
  "prerequisites": [
    "s10-fuerza-resistencia"
  ],
  "sources": [
    "e10-zones"
  ],
  "pending": [
    "Revisión por profesional del ejercicio e instructor de montaña pendiente. Nutrición y salud requieren revisión profesional específica; no se ha evaluado aptitud personal.",
    "Los casos y rúbricas son propuestas pedagógicas originales. La aplicación individual requiere evaluación, técnica y seguimiento.",
    "No se atribuyen requisitos de certificación, umbrales universales ni preparación técnica a los resultados físicos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "La expresión zona 2…",
        "options": [
          "Necesita definir el modelo.",
          "Siempre significa lo mismo.",
          "Certifica buena salud."
        ],
        "answer": 0,
        "explanation": "Los límites varían entre modelos.",
        "rationales": [
          "Los límites varían entre modelos.",
          "Tres y cinco zonas no son equivalentes.",
          "No es una evaluación clínica."
        ],
        "source": "e10-zones",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un reloj estima una zona; eso…",
        "options": [
          "Mide necesariamente el umbral.",
          "No demuestra por sí solo el umbral individual.",
          "Elimina la necesidad de contexto."
        ],
        "answer": 1,
        "explanation": "Hay que conocer el método.",
        "rationales": [
          "Puede usar fórmulas o ajustes generales.",
          "Hay que conocer el método.",
          "Modalidad y condiciones importan."
        ],
        "source": "e10-zones",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Para comparar dos planes conviene…",
        "options": [
          "Mirar solo el color.",
          "Ignorar número de zonas.",
          "Conocer definición, modalidad e intensidad."
        ],
        "answer": 2,
        "explanation": "Permite interpretar la tarea.",
        "rationales": [
          "Los colores no estandarizan fisiología.",
          "Cambia el significado.",
          "Permite interpretar la tarea."
        ],
        "source": "e10-zones",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Identifica el modelo antes de usar una zona.",
    "Separa estimación y medición.",
    "Relaciona modalidad general y demanda específica."
  ],
  "openAssessment": {
    "prompt": "Dibuja dos modelos de zonas sin asignar pulsaciones personales. Señala qué información necesitas para relacionarlos.",
    "rubric": [
      "Identifica el modelo antes de usar una zona.",
      "Separa estimación y medición.",
      "Relaciona modalidad general y demanda específica."
    ],
    "source": "e10-zones",
    "difficulty": "integración"
  },
  "diagrams": [
    "e10-medicion"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN PROFESIONAL PENDIENTE.** Este contenido no prescribe un programa individual ni acredita competencia técnica. Los ejercicios numéricos y casos son ficticios. No introduzcas datos médicos, mediciones corporales privadas ni antecedentes de terceros.

## Conceptos clave y propósito

Resistencia aeróbica, intensidad, volumen, modelos de zonas y umbrales.

## Teoría y toma de decisiones

La resistencia aeróbica permite sostener trabajo mediante procesos oxidativos. La sesión se describe por intensidad, duración y frecuencia; una etiqueta no reemplaza esas variables. La base general puede desarrollarse en modalidades distintas, pero cada modalidad deja pendientes demandas específicas de montaña.

«Zona 2» no es un idioma universal. En un modelo de tres zonas delimitado por dos umbrales, la zona intermedia no representa lo mismo que la zona 2 baja de muchos relojes con cinco zonas. Debe citarse modelo, criterio y método de delimitación. [Modelo de zonas del estudio](#fuente-e10-zones).

Un porcentaje genérico de frecuencia cardíaca no demuestra dónde están los umbrales de una persona. También hay diferencias entre estimación de reloj, prueba de laboratorio y sensaciones. En este curso, la intensidad se estudia leyendo cómo fue definida; no se calculan pulsaciones personales por edad.

Ejercicio original: dos planes dicen «60 minutos en zona 2». El primero tiene tres zonas y el segundo cinco. Antes de comparar, pide sus definiciones. El objetivo de la conversación es hacer explícita la intensidad prevista, no declarar superior un reloj o un modelo.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación del aprendizaje:** Identifica el modelo de zonas, su origen y modalidad. Contrasta con el profesional cómo se controla el esfuerzo y qué condiciones cambian la lectura. Si no hay delimitación válida, conserva la incertidumbre; no conviertas la pantalla del reloj en una prueba clínica.

La selección real de ejercicios, cargas, pruebas y progresión corresponde a una evaluación individual con profesionales. Las técnicas críticas de montaña requieren formación práctica y supervisión de instructor competente. El acondicionamiento físico no autoriza una maniobra.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un entrenador describe zona 2 en tres zonas y un reloj usa cinco. El deportista cree que ambas sesiones son equivalentes. Explica el dato que falta.

Distingue dato, interpretación y decisión. Explica qué incertidumbre permanece. Los casos no representan un protocolo del organismo citado ni un criterio oficial de habilitación para guía.

## Errores frecuentes y puntos críticos de seguridad

Usar nombres sin definirlos; tratar 220 menos edad como medición individual; hacer todas las sesiones intensas; equiparar buena forma y aclimatación.

## Material y equipo relacionado

Reloj opcional, registro de duración y descripción de esfuerzo. El instrumento debe acompañarse de su método y limitaciones.

[Consultar inventario](../../equipo/). Ajustar o poseer el equipo no demuestra dominarlo. Las prácticas técnicas se registran por separado del acondicionamiento.

## Autoevaluación y recuperación activa

- Explica la diferencia entre la capacidad que estudias y una tarea técnica de montaña.
- ¿Qué información falta en el caso y qué decisión modificaría?
- ¿Qué parte puede analizarse en escritorio y cuál necesita observación profesional?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Dibuja dos modelos de zonas sin asignar pulsaciones personales. Señala qué información necesitas para relacionarlos.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Taller de lectura de planes con profesional; observación submáxima en entorno controlado sin test máximo autónomo.

## Evidencia requerida y criterios de competencia

- Identifica el modelo antes de usar una zona.
- Separa estimación y medición.
- Relaciona modalidad general y demanda específica.

**COMPETENCIA:** estos criterios describen aprendizaje que debe observar un profesional en contexto. No acreditan aptitud médica, entrenamiento personal, guiado ni maniobra técnica. Una lectura, prueba física o quiz no otorga certificación. Marca pendiente lo que no se haya evaluado.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s10-resistencia-zonas). Registra fecha, actividad, escenario, equipo, objetivo, errores, correcciones, supervisor y evidencia de aprendizaje. No guardes datos médicos ni contraseñas. No inventes sesiones, evaluaciones o repeticiones para completar la matriz.

## Relaciones con otros módulos

[Entrenamiento](../../entrenamiento/) · [Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Programa](../../programa/). Entrenamiento general, preparación específica, aclimatación y competencia técnica se relacionan, pero no son equivalentes.
