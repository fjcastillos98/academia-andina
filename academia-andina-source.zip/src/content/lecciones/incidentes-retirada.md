---
{
  "title": "Incidentes, telecomunicaciones y debriefing",
  "description": "Organizar un análisis inicial de incidente dentro de límites formativos.",
  "module": "M23",
  "code": "E4-10",
  "order": 210,
  "minutes": 45,
  "level": "Intermedio",
  "status": "development",
  "reviewDate": "2026-10-22",
  "unit": "U4-10",
  "skills": [
    "s4-incidentes-retirada"
  ],
  "critical": true,
  "objectives": [
    "Organizar un análisis inicial de incidente dentro de límites formativos.",
    "Comunicar hechos y ubicación sin inventar diagnósticos.",
    "Cerrar una actividad con debriefing y acciones verificables."
  ],
  "prerequisites": [
    "Completar estudio de Fundamentales; la práctica previa debe revisarse presencialmente.",
    "Estudiar Guiado de grupos, liderazgo y comunicación."
  ],
  "sources": [
    "nps-emergencia",
    "garmin-sos",
    "senapred-lagos"
  ],
  "pending": [
    "Revisión pedagógica y evaluación situada por instructor competente.",
    "Condiciones, accesos, permisos y compatibilidad del equipo requieren verificación para cada actividad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un casi accidente sin lesión…",
        "options": [
          "Puede mostrar fallos que requieren revisión.",
          "Prueba que la decisión fue correcta.",
          "No merece registro."
        ],
        "answer": 0,
        "explanation": "El desenlace favorable no valida todas las decisiones previas."
      },
      {
        "prompt": "Un mensaje de emergencia simulado debe…",
        "options": [
          "Activar SOS.",
          "Describir hechos, ubicación y límites sin alarma real.",
          "Inventar un diagnóstico."
        ],
        "answer": 1,
        "explanation": "El ejercicio evalúa comunicación; no justifica emitir emergencias ni diagnósticos."
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

**TEORÍA.** Un incidente altera la actividad; un **casi accidente** o *near miss* es un evento sin el daño potencial que pudo producirse. La ausencia de lesión no prueba que el sistema funcionó. Una revisión útil pregunta qué barreras actuaron y qué dependió de circunstancias favorables.

Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica. El contenido organiza decisiones y comunicación; no enseña evaluación clínica, inmovilización, traslado ni rescate con cuerda.

## Teoría: un cambio de objetivo explícito

Ante una caída, lesión hipotética o deterioro importante del grupo, el objetivo puede pasar de completar recorrido a proteger al grupo y conseguir ayuda adecuada. El NPS incluye preparación ante pérdida o lesión en su planificación de emergencia [Referencia: nps-emergencia](#fuente-nps-emergencia). No esperes a necesitar recursos para descubrir quién los lleva o cómo contactar ayuda.

En una simulación distingue: situación y peligros presentes; personas y recursos disponibles; información comprobada; necesidad de asistencia; comunicaciones; alternativas y revisión. Son campos de análisis, no un protocolo médico. No convertir la lista en una orden de mover a una persona sin evaluación competente.

Una evacuación no es solo elegir un destino en el mapa. Requiere valorar capacidad, terreno, condiciones y recursos. Si excede la formación del grupo, solicitar apoyo no es un fallo del curso: reconocer el límite forma parte del criterio. No se ofrecen aquí tiempos de rescate ni garantías de acceso.

## Telecomunicaciones y reporte

Prepara un mensaje con identificación funcional, situación, ubicación con formato y referencia, número de personas, peligros observados, ayuda solicitada y medio de retorno. Distingue hechos de sospechas. La repetición por el receptor permite detectar errores de ubicación. No incluyas información médica identificable en este cuaderno de estudio.

El inReach Mini 2 requiere servicio satelital activo y condiciones de recepción pertinentes para SOS; el manual reserva SOS para emergencias reales [Referencia: garmin-sos](#fuente-garmin-sos). Los simulacros del curso no activan alarmas. VHF necesita verificación de autorización, canales y cobertura aplicables; no se asigna una frecuencia universal. Un mensaje enviado, uno recibido y uno comprendido son estados diferentes.

Los planos de evacuación de SENAPRED para Los Lagos incluyen amenazas específicas [Referencia: senapred-lagos](#fuente-senapred-lagos). No son automáticamente rutas de rescate de montaña ni sustituyen las indicaciones de la autoridad durante un evento. Consulta alcance y fecha antes de utilizarlos.

## Criterios de aborto y continuidad

La lesión no es el único motivo para terminar: puede fallar comunicación esencial, deteriorarse el terreno o perderse una alternativa prevista. Describe el motivo con hechos y revisa qué decisión reduce exposición desde donde se encuentra el grupo. No mantengas la actividad para evitar explicar una cancelación.

Continuar tras una pausa requiere una nueva justificación: qué problema se resolvió, con qué evidencia, qué queda pendiente y cuándo se revisará. “Ahora parece mejor” puede ser un dato, pero necesita contexto. No uses una mejoría aparente como diagnóstico ni como autorización de esfuerzo.

## Debriefing orientado a acciones

Separa la cronología de la interpretación. Primero reconstruye decisiones con la información disponible entonces; después pregunta qué señales se reconocieron o no, qué controles funcionaron y qué cambiar. Evita evaluar únicamente por el desenlace: una decisión deficiente puede no acabar en daño.

La ficha final contiene hecho, impacto, explicación provisional, corrección, responsable y verificación posterior. Revisa también el equipo usado o dañado y enlaza su inspección al inventario. No conviertas el debriefing en búsqueda de culpables ni en exposición pública de datos personales.

## Caso práctico: comunicación fallida y pasajero con síntomas

Escenario ficticio: el grupo informa malestar de un pasajero, cambia el objetivo y envía un aviso sin confirmación. No se ofrecen signos clínicos para deducir una enfermedad. El alumno identifica qué puede comunicar y qué debe dejar al personal formado.

Respuesta orientativa: describir observaciones, confirmar posición, revisar recursos y contingencia de comunicación, mantener control del grupo y solicitar asistencia según necesidad y formación. No inventar un diagnóstico para completar el formulario ni improvisar un descenso técnico.

## Errores frecuentes y señales de alerta

Seguir con el objetivo original; atribuir síntomas a cansancio sin evaluación; separar al grupo sin plan; usar SOS como prueba; ocultar un casi accidente porque no hubo lesión; cerrar el informe sin acciones. Una contradicción sobre dónde está el grupo necesita aclaración prioritaria.

## Autoevaluación y respuestas explicadas

1. ¿Por qué un casi accidente merece revisión? **Permite analizar exposición y controles antes de que ocurra daño, sin asumir que la ausencia de daño valida la decisión.**
2. ¿Qué diferencia hay entre describir síntomas y diagnosticar? **La descripción comunica hechos observados; la interpretación clínica necesita formación y contexto que este curso no proporciona.**

## Ejercicios y práctica presencial

En mesa, dos personas intercambian un mensaje ficticio y registran qué entendió cada una. Simula una pérdida de comunicación con tarjetas, sin emitir alarmas. Realiza debriefing de los casos de Calbuco y Osorno. La práctica médica y de evacuación se realiza en formación presencial específica, compatible con el alcance WFR que corresponda.

## Evidencia requerida

Reporte simulado, cronología, límites reconocidos, decisiones y tres acciones de mejora. No se almacena información de pacientes ni se acredita rescate por completar el caso.

## Relaciones con otras habilidades

Esta unidad se integra en la ruta estival. Consulta la ficha de habilidad y sus prerrequisitos en el programa. Registra práctica y evaluación por separado: estudiar y responder correctamente no acredita ejecución. Los ejercicios son propuestas didácticas originales; los casos no son rutas operativas.
