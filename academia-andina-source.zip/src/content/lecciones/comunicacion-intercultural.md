---
{
  "title": "Comunicación intercultural: escuchar y comprobar",
  "description": "Distinguir observación, interpretación y generalización cultural.",
  "module": "M19",
  "code": "E22-01",
  "order": 2201,
  "minutes": 40,
  "level": "Intermedio",
  "status": "development",
  "unit": "U22-01",
  "skills": [
    "s22-comunicacion-intercultural"
  ],
  "critical": false,
  "reviewDate": "2026-10-28",
  "objectives": [
    "Distinguir observación, interpretación y generalización cultural.",
    "Comprobar comprensión sin inferirla de la identidad o del silencio.",
    "Delimitar qué relato necesita consulta y acuerdo."
  ],
  "prerequisites": [
    "Estudiar ética profesional y patrimonio vivo."
  ],
  "sources": [
    "e22-unesco"
  ],
  "pending": [
    "Revisión docente y contextual pendiente.",
    "No se realizaron consultas comunitarias ni se verificaron permisos o hechos ambientales locales."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una persona calla después de una consigna. ¿Qué puedes afirmar?",
        "options": [
          "Que comprende por cortesía.",
          "Que no respondió; la razón aún debe aclararse.",
          "Que su cultura rechaza la actividad."
        ],
        "answer": 1,
        "explanation": "Describe la observación sin atribuir causa.",
        "rationales": [
          "El silencio no demuestra comprensión.",
          "Describe la observación sin atribuir causa.",
          "Atribuye una explicación sin evidencia."
        ],
        "source": "e22-unesco",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un participante conoce un relato local. ¿Puede autorizar su uso por toda la comunidad?",
        "options": [
          "Siempre que viva cerca.",
          "Sí, si lo cuenta durante una salida.",
          "No se puede inferir esa representación; hay que aclarar el alcance."
        ],
        "answer": 2,
        "explanation": "Distingue testimonio y ámbito de representación.",
        "rationales": [
          "El domicilio no demuestra representación.",
          "Compartir algo no acredita autoridad colectiva.",
          "Distingue testimonio y ámbito de representación."
        ],
        "source": "e22-unesco",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué evidencia sirve para revisar la consigna del taller?",
        "options": [
          "La reformulación recibida y la diferencia detectada.",
          "La nacionalidad del grupo.",
          "Una marca automática de lectura."
        ],
        "answer": 0,
        "explanation": "Permite revisar un mensaje concreto.",
        "rationales": [
          "Permite revisar un mensaje concreto.",
          "No mide comprensión.",
          "No documenta la conversación."
        ],
        "source": "e22-unesco",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "openAssessment": {
    "prompt": "Entrega una primera versión, la observación de un compañero y la corrección justificada del ejercicio.",
    "rubric": [
      "Distinguir observación, interpretación y generalización cultural.",
      "Comprobar comprensión sin inferirla de la identidad o del silencio.",
      "Delimitar qué relato necesita consulta y acuerdo."
    ],
    "source": "e22-unesco",
    "difficulty": "integración"
  }
}
---

**CONTENIDO EN DESARROLLO · TALLER DE MESA · REVISIÓN DOCENTE PENDIENTE.**

## Conceptos clave y propósito

La comunicación intercultural exige atención a diferencias de lenguaje, experiencia y significado sin reducir a una persona a una categoría. En este taller se trabaja con conversaciones ficticias. El objetivo observable es reformular una instrucción, pedir aclaración y reconocer lo que no se puede atribuir a otros.

Distingue observación de interpretación: «no respondió a la pregunta» describe una conducta; «no le interesa por su cultura» añade una explicación no comprobada. Puede haber ruido, vocabulario poco claro, una pregunta incómoda o una razón que desconoces. Ninguna de esas posibilidades debe convertirse en diagnóstico automático.

## Teoría y alcance de la fuente

Los principios éticos de UNESCO sitúan a las comunidades en un papel principal respecto de su patrimonio vivo y vinculan la interacción con diálogo, colaboración y consentimiento libre, previo, sostenido e informado. También reconocen límites consuetudinarios de acceso. [Referencia UNESCO](#fuente-e22-unesco). Se consultó texto indexado; la apertura directa quedó bloqueada. No se presenta una explicación de obligaciones jurídicas chilenas.

La pauta comunicativa siguiente es un diseño educativo original. No es un protocolo UNESCO ni una descripción de cómo se comporta un pueblo. La adaptación a una situación real necesita escuchar a quienes participan y revisar sus condiciones concretas.

## Pauta de conversación

Antes de explicar, pregunta qué necesita saber la persona y en qué formato le resulta más claro. Formula una idea por vez, evita abreviaturas no explicadas y ofrece una representación visual cuando sea útil. No presupongas preferencias por nacionalidad, edad o apariencia. Una persona puede conocer el terreno y necesitar aclaración del vocabulario; otra puede dominar las palabras y desconocer la tarea.

Después pide una reformulación acotada: «¿Cómo describirías el punto de encuentro que acabamos de acordar?». Aclara que buscas comprobar tu explicación, no examinar su inteligencia. Si aparece una diferencia, corrige la instrucción y vuelve a comprobar. Repetir más fuerte la misma frase no resuelve por sí solo una ambigüedad.

Cuando la comprensión de un acuerdo crítico no pueda comprobarse, registra ese límite y revisa la actividad con el responsable competente. Una traducción improvisada o una aplicación puede apoyar la conversación, pero el ejercicio no la declara suficiente para una tarea técnica. No asigna a un participante una función de intérprete profesional por hablar dos idiomas.

Una persona no representa automáticamente a una comunidad por compartir un apellido, idioma o lugar de origen. Pregunta por el ámbito en que habla y evita convertir una opinión individual en autorización colectiva. Tampoco trates diferencias entre relatos como una obligación de elegir inmediatamente cuál es el auténtico: pueden referirse a momentos, experiencias o contextos distintos.

## Relatos, consulta y límites

Para preparar un relato de guiado, separa documento público, testimonio atribuido y conocimiento cuyo uso requiere consulta. En la propuesta de aula se registra quién podría revisar una afirmación, qué uso se pretende y qué contenido debe quedar fuera mientras no exista acuerdo. No inventes un consentimiento para completar la ficha.

Si alguien no quiere compartir un relato, ofrece una alternativa documentada que no suplante su voz. El silencio no es un permiso. La academia no almacena entrevistas, información privada ni conocimiento restringido: el ejercicio trabaja exclusivamente con materiales públicos o tarjetas ficticias.

## Caso práctico y respuesta orientativa

**Ficción:** en un taller, una participante dice que la explicación de un nombre no coincide con la que conoce. El guía responde que su versión está en internet y pide continuar.

Una respuesta orientativa agradece la observación, pregunta qué afirmación se está contrastando y reconoce que la publicación tiene un autor y un contexto. La participante no está obligada a revelar un relato personal. Se puede retirar la atribución general del guion y anotar la consulta pendiente. El objetivo es mejorar precisión y trato, no obtener una historia más atractiva a toda costa.

## Errores frecuentes

Atribuir intenciones a una identidad; pedir a una sola persona que hable por todos; confundir acceso público con libertad de reutilización; tomar cortesía como comprensión; corregir una pronunciación sin comprobar la fuente; convertir una discrepancia en espectáculo frente al grupo.

## Autoevaluación

Transforma «no entendieron porque son de otra cultura» en una observación, una pregunta y una comprobación. Explica qué seguirías sin saber después de esa conversación. Distingue corregir una instrucción de atribuir una incapacidad a quien la recibe.

## Ejercicios y revisión

En parejas, usa una tarjeta con un punto de encuentro ficticio y una expresión ambigua. Una persona explica, otra reformula y un observador anota dónde cambió el sentido. Reescribe la consigna. No se realizan desplazamientos ni se simulan riesgos físicos.

## Evidencia requerida

Primera consigna, reformulación recibida, diferencia detectada y versión corregida. Añade una afirmación cultural que decidiste no difundir y explica qué consulta necesitarías. La rúbrica exige observación sin estereotipos, comprobación concreta y límites explícitos.

## Relaciones con otros módulos

Revisa [briefing participativo](../briefing-participativo/), [patrimonio vivo](../historia-patrimonio-vivo/) y [ética profesional](../etica-responsabilidad/). Continúa con [interpretación ambiental](../interpretacion-con-evidencia/) y el [taller de guion](../../interpretacion/).
