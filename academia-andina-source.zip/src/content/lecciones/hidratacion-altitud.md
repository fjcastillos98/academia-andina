---
{
  "title": "Hidratación y agua: disponibilidad no es tratamiento",
  "description": "Distinguir hidratación, potabilización y tratamiento de enfermedad de altitud.",
  "module": "M03",
  "code": "E9-09",
  "order": 909,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U9-09",
  "skills": [
    "s9-hidratacion-altitud"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Distinguir hidratación, potabilización y tratamiento de enfermedad de altitud.",
    "Planificar acceso al agua sin prescribir volúmenes universales."
  ],
  "prerequisites": [
    "s9-nutricion-altitud"
  ],
  "sources": [
    "e9-wms",
    "e9-water"
  ],
  "pending": [
    "Revisión médica por profesional de medicina de montaña y revisión docente por instructor pendientes. No se ha evaluado atención clínica ni rescate.",
    "Casos, ejercicios y criterios son propuestas pedagógicas originales; no autorizan decisiones clínicas individuales.",
    "Condiciones de rutas, comunicaciones y recursos de atención locales requieren verificación antes de cada salida."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Forzar mucha agua para prevenir MAM…",
        "options": [
          "No es una prevención demostrada y puede ser perjudicial.",
          "Reemplaza el ascenso gradual.",
          "Permite ignorar síntomas."
        ],
        "answer": 0,
        "explanation": "No debe promoverse como profilaxis.",
        "rationales": [
          "No debe promoverse como profilaxis.",
          "Son problemas distintos.",
          "Los síntomas requieren atención."
        ],
        "source": "e9-wms",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Agua transparente…",
        "options": [
          "Siempre es potable.",
          "No demuestra ausencia de microorganismos.",
          "Nunca necesita evaluación."
        ],
        "answer": 1,
        "explanation": "El peligro puede no ser visible.",
        "rationales": [
          "El aspecto no basta.",
          "El peligro puede no ser visible.",
          "Requiere valorar origen y tratamiento."
        ],
        "source": "e9-wms",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La ficha del filtro debe incluir…",
        "options": [
          "Solo color y peso.",
          "Una eficacia inventada.",
          "Condiciones de uso, límites y mantenimiento."
        ],
        "answer": 2,
        "explanation": "Son datos relevantes del método.",
        "rationales": [
          "No permite evaluar su función sanitaria.",
          "Se necesita documentación real.",
          "Son datos relevantes del método."
        ],
        "source": "e9-wms",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Rechaza sobrehidratación como prevención del MAM.",
    "Separa claridad visual y tratamiento.",
    "Identifica límites del método sin inventar un volumen diario."
  ],
  "openAssessment": {
    "prompt": "Construye una ficha de un equipo ficticio con fuente, tratamiento, limitación y alternativa; marca los datos ausentes sin inventar tiempos ni eficacias.",
    "rubric": [
      "Rechaza sobrehidratación como prevención del MAM.",
      "Separa claridad visual y tratamiento.",
      "Identifica límites del método sin inventar un volumen diario."
    ],
    "source": "e9-wms",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN MÉDICA Y DE INSTRUCTOR PENDIENTES.** No es una herramienta de diagnóstico ni prescripción. Los casos son ficticios; no introduzcas datos médicos personales. Una emergencia real requiere asistencia urgente, no completar esta lección.

## Conceptos clave y propósito

Agua disponible, agua tratada, acceso, reposición y sobrehidratación.

## Teoría y toma de decisiones

La hidratación y la prevención de enfermedad de altitud no son equivalentes. Forzar grandes cantidades de agua no ha demostrado prevenir MAM y puede causar daño. El plan no debe presentar beber más como sustituto de aclimatación o descenso. [WMS, intervenciones sin beneficio](#fuente-e9-wms).

El agua clara tampoco demuestra ausencia de microorganismos. La selección del tratamiento depende del peligro, del equipo y de sus condiciones de uso. Los procedimientos y tiempos se consultan en fuentes sanitarias y en el manual concreto; filtrar, desinfectar y hervir no son sinónimos. [CDC, tratamiento de agua](#fuente-e9-water).

En el modelo docente se separan origen, tratamiento, almacenamiento y acceso. Un recipiente lleno que está inaccesible durante horas no resuelve la logística. Un filtro sin información sobre congelación o mantenimiento queda pendiente de revisión, no aprobado por su apariencia.

El ejercicio no recomienda litros por persona ni utiliza color de orina para diagnosticar MAM. El requerimiento real cambia con contexto e individuo; síntomas persistentes o incapacidad de beber requieren valoración, no completar una cuota a la fuerza. La práctica consiste en leer el manual, identificar límites y preparar una alternativa compatible.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación y análisis de aula.** Para el caso ficticio, identifica la fuente de agua y el peligro que pretende controlar cada método. Comprueba manual, mantenimiento y almacenamiento del sistema. No marques «potable» por transparencia. Mantén la decisión médica separada de la logística: ante signos de enfermedad, no retrases ayuda por intentar resolverlo bebiendo.

Las indicaciones clínicas dependen del paciente y los recursos. Las maniobras de movilización, oxigenoterapia y rescate requieren formación práctica y supervisión competente. No extrapolar un caso de escritorio a una actuación real ni elegir fármacos a partir de un quiz.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un grupo tiene agua visualmente transparente y cree que duplicar la cantidad bebida evitará cualquier problema de altitud. Identifica dos afirmaciones distintas que necesitan corrección.

Identifica hechos, incertidumbres y decisiones. Explica qué información podría modificar tu propuesta. La rúbrica es docente, no un protocolo avalado por las instituciones citadas.

## Errores frecuentes y puntos críticos de seguridad

Equiparar agua transparente a potable; forzar ingesta; confundir potabilización con aclimatación; aplicar tiempos de tratamiento sin considerar producto y condiciones.

## Material y equipo relacionado

Recipientes, aislamiento cuando corresponda y método de tratamiento con documentación. Los filtros y químicos tienen límites propios; el inventario no verifica por sí solo su eficacia.

[Inventario educativo](../../equipo/). Tener el recurso no demuestra saber utilizarlo. El diario no es una ficha clínica.

## Autoevaluación y recuperación activa

- ¿Puedes explicar el concepto central sin confundirlo con una autorización de salida?
- ¿Qué dato falta en el escenario y qué decisión depende de él?
- ¿Qué tarea exige formación sanitaria o técnica y no se evalúa aquí?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Construye una ficha de un equipo ficticio con fuente, tratamiento, limitación y alternativa; marca los datos ausentes sin inventar tiempos ni eficacias.

**PRÁCTICA SUPERVISADA — propuesta:** Taller de lectura de manuales y manipulación higiénica con instructor. No beber agua de procedencia desconocida para comprobar un método.

## Evidencia requerida y criterios de competencia

- Rechaza sobrehidratación como prevención del MAM.
- Separa claridad visual y tratamiento.
- Identifica límites del método sin inventar un volumen diario.

**COMPETENCIA:** requiere observación contextual por instructor competente y revisión sanitaria cuando corresponda. Estos criterios evalúan preparación, comunicación y límites de actuación; no habilitan como profesional sanitario ni guía. La plataforma no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de la habilidad](../../practicas/?habilidad=s9-hidratacion-altitud). Registra fecha, actividad, escenario ficticio, equipo, errores, correcciones, supervisor y evidencia del aprendizaje. No incluyas diagnósticos, recetas, mediciones personales ni datos de pacientes. Marca pendiente toda evaluación no realizada.

## Relaciones con otros módulos

[Volver a Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Escalada alpina](../../alpina/) · [Programa](../../programa/). La secuencia académica conecta planificación, comunicación y riesgo; no acredita aptitud clínica ni práctica.
