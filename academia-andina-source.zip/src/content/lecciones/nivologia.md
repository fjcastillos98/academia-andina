---
{
  "title": "Nivología: leer capas, interfaces y evolución",
  "description": "Interpretar estratificación e interfaces como historia del manto.",
  "module": "M09",
  "code": "E5-03",
  "order": 502,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-03",
  "skills": [
    "s5-nivologia"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Interpretar estratificación e interfaces como historia del manto.",
    "Comparar redondeamiento, faceteado y fusión/rehielo.",
    "Separar observación, interpretación y límite de representatividad."
  ],
  "prerequisites": [
    "s5-nieve-propiedades"
  ],
  "sources": [
    "e5-round-facet",
    "e5-surface-hoar",
    "e5-persistent",
    "e5-metamorphism"
  ],
  "pending": [
    "Revisión pedagógica y de instructor. Condiciones, cobertura de boletines y aplicación territorial real: PENDIENTE DE VERIFICACIÓN."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "No se observa escarcha enterrada en un perfil. ¿Qué concluyes?",
        "options": [
          "No existe en toda la ladera.",
          "No se identificó en esa observación.",
          "Ya no es necesario consultar historia."
        ],
        "answer": 1,
        "explanation": "La preservación puede ser espacialmente variable.",
        "rationales": [
          "Extrapola sin evidencia.",
          "Conserva el alcance del dato.",
          "Omite evolución previa."
        ],
        "source": "e5-surface-hoar",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "Una capa gana cohesión sobre una capa débil. ¿Qué conviene analizar?",
        "options": [
          "Solo la dureza superficial.",
          "La relación placa-capa débil.",
          "Únicamente la edad de la nevada."
        ],
        "answer": 1,
        "explanation": "La estructura depende de relaciones, no una propiedad aislada.",
        "rationales": [
          "Omite la interfaz.",
          "Integra capas y unión.",
          "La edad no resume la estructura."
        ],
        "source": "e5-round-facet",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "No hay whumpfs. ¿Se descarta un problema persistente?",
        "options": [
          "Sí.",
          "Solo si no hay huellas.",
          "No; las señales pueden faltar."
        ],
        "answer": 2,
        "explanation": "SLF advierte que el reconocimiento es difícil.",
        "rationales": [
          "Ausencia de señal no descarta.",
          "Las huellas no verifican capas.",
          "Reconoce la incertidumbre."
        ],
        "source": "e5-persistent",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Separa observación e hipótesis.",
    "Distingue procesos sin reglas universales.",
    "Explica límites de espacio y tiempo del perfil."
  ],
  "openAssessment": {
    "prompt": "Completa las columnas observo/interpreto/no concluyo para un perfil con costra, placa y capa débil potencial.",
    "rubric": [
      "Separa observación e hipótesis.",
      "Distingue procesos sin reglas universales.",
      "Explica límites de espacio y tiempo del perfil."
    ],
    "source": "e5-round-facet",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-manto"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Una línea en un dibujo representa una hipótesis de interfaz; en terreno hay que observar propiedades y límites del método.

## Teoría y toma de decisiones

Un perfil nivológico describe capas, sus límites y relaciones en un lugar y momento. Estratificación no significa que cada nevada siga siendo una lámina intacta: depósito, transporte, asentamiento y transformación modifican la estructura. Una interfaz es la transición entre capas; puede tener relevancia aunque sea delgada. Para interpretar el conjunto se necesita historia meteorológica y distribución espacial, además de una observación local. Esta lección no enseña a usar un pozo o test como permiso de paso.

En el metamorfismo de redondeamiento, a veces llamado destructivo, las formas originales pierden rasgos y cambian las uniones entre granos. El faceteado, asociado al término constructivo, produce formas angulosas por transferencia de vapor bajo condiciones favorables; el gradiente de temperatura importa. Esos nombres describen geometría y procesos, no un juicio de «bueno» o «malo». Una capa cohesionada puede actuar como placa sobre otra débil. La explicación universitaria de UBC es introductoria y no convierte un valor de gradiente en criterio universal de tránsito [fuente](#fuente-e5-round-facet).

En metamorfismo de fusión interviene agua líquida; el rehielo cambia de nuevo las conexiones y puede producir costras. La temperatura del aire no equivale a la de todas las capas. La evolución depende del estado previo, por lo que dos perfiles con una superficie parecida pueden tener historias distintas [SLF](#fuente-e5-metamorphism). En vez de memorizar «calor estabiliza» o «frío estabiliza», pregunta qué proceso, en qué capa y durante qué intervalo está ocurriendo.

La escarcha de superficie crece sobre la nieve en determinadas condiciones atmosféricas. Si se conserva y queda enterrada, puede constituir una capa débil; su continuidad puede variar mucho porque viento, sol o lluvia afectan su preservación [fuente](#fuente-e5-surface-hoar). No encontrarla en un punto no prueba su ausencia en otro. Facetas, escarcha de profundidad y escarcha enterrada se relacionan con problemas de capas débiles persistentes. SLF destaca que pueden ser difíciles de reconocer y que las señales de inestabilidad no siempre están presentes [fuente](#fuente-e5-persistent).

Organiza el registro en tres columnas. «Observo» conserva una descripción local: cambio de dureza, granos, interfaz o sonido. «Interpreto» propone una explicación que puede contrastarse. «No concluyo» impide que el dato se transforme en garantía: una capa no identificada no desaparece por no saber nombrarla, y un resultado localizado no representa automáticamente todo el itinerario. Anota errores de observación, condiciones y límites del método usado por el instructor.

Como ejercicio, compara dos perfiles ficticios dibujados: ambos tienen una placa y una costra, pero solo uno muestra una interfaz débil representada. Explica qué información falta en ambos antes de atribuir probabilidad de desencadenamiento. Luego cambia orientación y fecha. El objetivo es reconocer cómo aumenta la incertidumbre al extrapolar. La práctica de descripción y cualquier prueba de estabilidad requieren formación presencial, selección apropiada del lugar y supervisión.

## Qué observo, qué significa y qué no puedo concluir

La teoría no autoriza a elegir una zona de muestreo ni a interpretar un test como semáforo de paso.

## Caso práctico y aplicación al guiado

Dos perfiles cercanos difieren en una capa fina. ¿Cuál representa la ladera? Explica por qué la pregunta requiere información espacial adicional.

## Errores frecuentes y señales de alerta

Equivaler facetas a avalancha inevitable; declarar estabilidad por no oír colapsos; extrapolar un perfil; confundir escarcha superficial y escarcha enterrada.

## Autoevaluación y respuesta razonada

Completa las columnas observo/interpreto/no concluyo para un perfil con costra, placa y capa débil potencial.

## Ejercicios y práctica supervisada

Comparar perfiles documentados y practicar descripción en taller supervisado. No buscar capas débiles entrando en terreno expuesto.

## Evidencia requerida

- Separa observación e hipótesis.
- Distingue procesos sin reglas universales.
- Explica límites de espacio y tiempo del perfil.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-nivologia).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
