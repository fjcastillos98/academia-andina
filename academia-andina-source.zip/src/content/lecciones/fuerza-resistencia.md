---
{
  "title": "Fuerza-resistencia: repetir acciones con control",
  "description": "Relacionar repetición de esfuerzos y calidad de movimiento.",
  "module": "M22",
  "code": "E10-04",
  "order": 1004,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U10-04",
  "skills": [
    "s10-fuerza-resistencia"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Relacionar repetición de esfuerzos y calidad de movimiento.",
    "Aplicar el concepto a una decisión de preparación de montaña y reconocer sus límites."
  ],
  "prerequisites": [
    "s10-hipertrofia"
  ],
  "sources": [
    "e10-strength"
  ],
  "pending": [
    "Revisión por profesional del ejercicio e instructor de montaña pendiente. Nutrición y salud requieren revisión profesional específica; no se ha evaluado aptitud personal.",
    "Los casos y rúbricas son propuestas pedagógicas originales. La aplicación individual requiere evaluación, técnica y seguimiento.",
    "No se atribuyen requisitos de certificación, umbrales universales ni preparación técnica a los resultados físicos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Igual número de repeticiones implica…",
        "options": [
          "Solo igual conteo, si no hay más datos.",
          "Idéntica demanda.",
          "Idéntica adaptación."
        ],
        "answer": 0,
        "explanation": "Faltan carga, pausas y ejecución.",
        "rationales": [
          "Faltan carga, pausas y ejecución.",
          "Puede variar mucho.",
          "No se deduce del conteo."
        ],
        "source": "e10-strength",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Si se pierde control del apoyo…",
        "options": [
          "Se acelera para terminar.",
          "Se revisa o detiene la tarea.",
          "Se añaden kilos."
        ],
        "answer": 1,
        "explanation": "La técnica es un criterio de ajuste.",
        "rationales": [
          "Puede aumentar el riesgo.",
          "La técnica es un criterio de ajuste.",
          "No resuelve la pérdida de control."
        ],
        "source": "e10-strength",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un circuito se practica…",
        "options": [
          "En un filo para hacerlo realista.",
          "Sin definir pausas.",
          "En entorno controlado con tarea definida."
        ],
        "answer": 2,
        "explanation": "Permite observar y ajustar.",
        "rationales": [
          "El error tendría consecuencias evitables.",
          "Impide describir la sesión.",
          "Permite observar y ajustar."
        ],
        "source": "e10-strength",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Define la tarea repetida.",
    "Registra pausas y técnica.",
    "No confunde fatiga extrema con calidad."
  ],
  "openAssessment": {
    "prompt": "Diseña una ficha de circuito ficticio con cinco variables y un criterio técnico de parada.",
    "rubric": [
      "Define la tarea repetida.",
      "Registra pausas y técnica.",
      "No confunde fatiga extrema con calidad."
    ],
    "source": "e10-strength",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN PROFESIONAL PENDIENTE.** Este contenido no prescribe un programa individual ni acredita competencia técnica. Los ejercicios numéricos y casos son ficticios. No introduzcas datos médicos, mediciones corporales privadas ni antecedentes de terceros.

## Conceptos clave y propósito

Fatiga local, repetición, densidad, descanso y mantenimiento de técnica.

## Teoría y toma de decisiones

La fuerza-resistencia describe la capacidad de sostener o repetir una producción de fuerza durante una tarea. No es simplemente usar poco peso sin límite. La tarea define la demanda: subir escalones, sostener una postura o manejar una carga no son pruebas intercambiables.

La preparación general crea una base de fuerza y control. La específica practica patrones pertinentes en condiciones graduadas, incluyendo descansos y técnica. En la academia, esa relación es una propuesta pedagógica a revisar con profesional, no una receta derivada de un ensayo sobre un ejercicio distinto. [Marco de entrenamiento de resistencia](#fuente-e10-strength).

Un circuito registra más que repeticiones: altura del escalón, apoyo, carga, tiempo y criterio de finalización. Si aumenta la velocidad a costa de apoyo inseguro, no está demostrado que mejore la capacidad útil. El descenso de cada repetición también pertenece a la tarea.

En el caso original, dos sesiones tienen 60 repeticiones; una las distribuye con pausas y la otra las concentra. La misma suma no implica la misma exigencia. La densidad de trabajo se interpreta junto con la recuperación, sin convertir la fatiga máxima en objetivo de toda sesión.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación del aprendizaje:** Acuerda patrón, carga, duración y pausa con el profesional. Observa si la ejecución se mantiene. Ajusta la sesión cuando el criterio deje de cumplirse. No hagas circuitos de fatiga en escaleras expuestas, bordes o terreno donde un error produzca una caída.

La selección real de ejercicios, cargas, pruebas y progresión corresponde a una evaluación individual con profesionales. Las técnicas críticas de montaña requieren formación práctica y supervisión de instructor competente. El acondicionamiento físico no autoriza una maniobra.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Dos registros de 60 escalones no especifican altura ni pausas. Diseña una comparación que permita aprender algo real.

Distingue dato, interpretación y decisión. Explica qué incertidumbre permanece. Los casos no representan un protocolo del organismo citado ni un criterio oficial de habilitación para guía.

## Errores frecuentes y puntos críticos de seguridad

Contar repeticiones deterioradas; equiparar ardor con eficacia; omitir descenso y pausas; usar terreno expuesto como circuito.

## Material y equipo relacionado

Escalón estable, apoyo si corresponde y carga seleccionada. La mochila se incorpora de forma individualizada, no como lastre obligatorio.

[Consultar inventario](../../equipo/). Ajustar o poseer el equipo no demuestra dominarlo. Las prácticas técnicas se registran por separado del acondicionamiento.

## Autoevaluación y recuperación activa

- Explica la diferencia entre la capacidad que estudias y una tarea técnica de montaña.
- ¿Qué información falta en el caso y qué decisión modificaría?
- ¿Qué parte puede analizarse en escritorio y cuál necesita observación profesional?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Diseña una ficha de circuito ficticio con cinco variables y un criterio técnico de parada.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Taller de escalón o patrón equivalente bajo supervisión profesional, en superficie estable y con adaptación individual.

## Evidencia requerida y criterios de competencia

- Define la tarea repetida.
- Registra pausas y técnica.
- No confunde fatiga extrema con calidad.

**COMPETENCIA:** estos criterios describen aprendizaje que debe observar un profesional en contexto. No acreditan aptitud médica, entrenamiento personal, guiado ni maniobra técnica. Una lectura, prueba física o quiz no otorga certificación. Marca pendiente lo que no se haya evaluado.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s10-fuerza-resistencia). Registra fecha, actividad, escenario, equipo, objetivo, errores, correcciones, supervisor y evidencia de aprendizaje. No guardes datos médicos ni contraseñas. No inventes sesiones, evaluaciones o repeticiones para completar la matriz.

## Relaciones con otros módulos

[Entrenamiento](../../entrenamiento/) · [Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Programa](../../programa/). Entrenamiento general, preparación específica, aclimatación y competencia técnica se relacionan, pero no son equivalentes.
