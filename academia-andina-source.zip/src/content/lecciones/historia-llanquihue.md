---
{
  "title": "Los Lagos: exploración escrita y relato de colonización",
  "description": "Distingue exploración documentada de inicio de ocupación humana.",
  "module": "M17",
  "code": "E13-07",
  "order": 1307,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U13-07",
  "skills": [
    "s13-historia-llanquihue"
  ],
  "critical": false,
  "reviewDate": "2026-10-27",
  "objectives": [
    "Distingue exploración documentada de inicio de ocupación humana.",
    "Reconoce el propósito y perspectiva del relato de colonización."
  ],
  "prerequisites": [
    "s13-historia-socorro"
  ],
  "sources": [
    "e13-recuerdos-ficha",
    "e13-recuerdos-critica",
    "e13-philippi"
  ],
  "pending": [
    "Revisión por historiador o especialista de patrimonio e instructor de montaña pendiente.",
    "Primeras ascensiones de Los Lagos, historia completa de escuelas técnicas y testimonios comunitarios requieren investigación y revisión adicionales.",
    "Casos y rúbricas son propuestas pedagógicas originales; no certifican guiado ni competencia práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "El inicio de una memoria escrita indica…",
        "options": [
          "El comienzo de toda historia territorial.",
          "La ausencia de habitantes anteriores.",
          "Un punto de entrada a un relato situado."
        ],
        "answer": 2,
        "explanation": "Permite estudiar perspectiva y contexto.",
        "rationales": [
          "Confunde documento con territorio.",
          "El texto no prueba ausencia.",
          "Permite estudiar perspectiva y contexto."
        ],
        "source": "e13-recuerdos-ficha",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Para atribuir un episodio detallado del libro…",
        "options": [
          "Basta el título del catálogo.",
          "Hay que consultar el pasaje y su edición.",
          "Se puede completar con imaginación."
        ],
        "answer": 1,
        "explanation": "Permite una atribución comprobable.",
        "rationales": [
          "El título no aporta el episodio.",
          "Permite una atribución comprobable.",
          "Fabricaría historia."
        ],
        "source": "e13-recuerdos-ficha",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una voz omitida por el autor…",
        "options": [
          "Es una pregunta para contrastar con otras fuentes.",
          "No existió.",
          "Debe reemplazarse por una leyenda inventada."
        ],
        "answer": 0,
        "explanation": "La omisión abre investigación.",
        "rationales": [
          "La omisión abre investigación.",
          "No es una conclusión justificada.",
          "No se inventan testimonios."
        ],
        "source": "e13-recuerdos-ficha",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue exploración documentada de inicio de ocupación humana.",
    "Reconoce el propósito y perspectiva del relato de colonización.",
    "Explicita límites de acceso a la obra y pendientes de contraste."
  ],
  "openAssessment": {
    "prompt": "Escribe un guion de dos minutos con una afirmación atribuida, una crítica de alcance y dos preguntas que exigirían archivo o colaboración territorial.",
    "rubric": [
      "Distingue exploración documentada de inicio de ocupación humana.",
      "Reconoce el propósito y perspectiva del relato de colonización.",
      "Explicita límites de acceso a la obra y pendientes de contraste."
    ],
    "source": "e13-recuerdos-ficha",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ACADÉMICA PENDIENTE.** Historia documental e interpretación: no es formación para ejecutar maniobras. No guardes datos médicos, contraseñas, datos privados de terceros ni conocimientos de acceso restringido.

## Conceptos clave y propósito

Memoria retrospectiva, colonización, autorrepresentación, territorio y voces ausentes. Explorar o describir para un público no equivale a descubrir un territorio deshabitado.

## Teoría y toma de decisiones

Memoria Chilena vincula los capítulos finales de Recuerdos del pasado con el trabajo de Pérez Rosales como agente de colonización y sus recorridos del sur. Su reseña aborda el carácter construido del relato y presenta lecturas críticas de sus objetivos. Para una academia territorial, esto exige leer no solo dónde viajó el autor, sino para quién escribió y qué intereses organizan su descripción.

Una descripción de terreno como disponible, vacío o desconocido debe examinarse como lenguaje de una fuente situada. No la adoptes automáticamente como hecho sobre las personas que habitaban o conocían el lugar. Contrasta la historia de la administración y la colonización con trabajos territoriales, registros locales y voces comunitarias; no atribuyas a una sola memoria la representación de todos esos actores.

Para un guion de guiado sobre Llanquihue, separa la geografía que puedes observar, un episodio documental delimitado y una pregunta histórica pendiente. No asignes primeras ascensiones del Osorno ni recorridos exactos a partir de una ficha bibliográfica. Si quieres utilizar un pasaje, lee la edición, identifica su ubicación y examina el contexto completo. No se ha realizado aquí una lectura integral del libro: se trabaja con catálogo y reseña crítica explícitamente identificados.

Otro caso de lectura crítica es Bernardo Eunom Philippi: Memoria Chilena registra su Relación del descubrimiento del lago Llanquihue (1842) y un mapa publicado en 1846, y explica que ignoraba la visita anterior de Claudio Gay. La corrección no debe reducirse a decidir cuál europeo llegó primero: ninguna de esas atribuciones establece el inicio de la presencia humana. Tampoco debe confundirse a Bernardo Eunom con su hermano Rodulfo Amando.

Fuentes de esta unidad: [Referencia 1](#fuente-e13-recuerdos-ficha) · [Referencia 2](#fuente-e13-recuerdos-critica) · [Referencia 3](#fuente-e13-philippi). Los ejercicios y criterios siguientes son diseño educativo original, no protocolos de las organizaciones citadas.

## Procedimiento: lectura, comprobaciones y variantes

**PROCEDIMIENTO — análisis documental:** Reescribe un párrafo turístico ficticio que hable de descubrimiento. Sustituye afirmaciones universales por atribuciones verificables y añade la pregunta «¿para quién era desconocido?». Variante: contrastar dos mapas históricos atendiendo a autor, propósito y nombres omitidos.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un folleto afirma que la historia de Llanquihue empezó con un explorador del siglo XIX. Explica qué confunde y diseña un plan de contraste sin inventar una tradición alternativa.

## Errores frecuentes y puntos críticos de seguridad

Tratar colonización como sinónimo de inicio de historia; repetir lenguaje de época sin contextualización; inventar diálogos indígenas; publicar localizaciones patrimoniales sensibles.

Las maniobras críticas requieren formación práctica y supervisión de instructor competente. Estudiar cómo se actuaba antiguamente no habilita a reproducirlo. Este taller no requiere exposición en terreno.

## Material y equipo relacionado

Catálogo, edición identificada, mapa histórico y cuaderno sin datos personales ni ubicaciones sensibles.

[Inventario educativo](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con una evidencia y un límite: Distingue exploración documentada de inicio de ocupación humana.
- Explica con una evidencia y un límite: Reconoce el propósito y perspectiva del relato de colonización.
- Explica con una evidencia y un límite: Explicita límites de acceso a la obra y pendientes de contraste.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Escribe un guion de dos minutos con una afirmación atribuida, una crítica de alcance y dos preguntas que exigirían archivo o colaboración territorial.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Revisión por historiador local y, si se incluyen voces o conocimientos comunitarios, colaboración acordada con sus portadores antes de difundirlos.

## Evidencia requerida y criterios de competencia

- Distingue exploración documentada de inicio de ocupación humana.
- Reconoce el propósito y perspectiva del relato de colonización.
- Explicita límites de acceso a la obra y pendientes de contraste.

**COMPETENCIA:** se requiere revisión humana contextual del trabajo. Una lectura, quiz o guion no certifica guiado, interpretación profesional ni maniobras técnicas. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s13-historia-llanquihue). Registra fecha, lugar de estudio, documentos, habilidad, repeticiones, errores, correcciones, supervisor y evidencia textual no sensible. Diferencia taller ficticio y actividad real; no inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Historia y patrimonio](../../historia/) · [Territorio](../../territorio/) · [Geología](../../geologia/) · [Ecología](../../ecologia/) · [Programa](../../programa/). La interpretación histórica complementa la formación técnica; no sustituye condiciones ni permisos actuales.
