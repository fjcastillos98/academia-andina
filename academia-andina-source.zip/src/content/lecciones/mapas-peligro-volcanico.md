---
{
  "title": "Mapas de peligro: escenarios, exposición y límites",
  "description": "Identifica proceso, escenario y escala antes de interpretar un mapa.",
  "module": "M11",
  "code": "E12-09",
  "order": 1209,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U12-09",
  "skills": [
    "s12-mapas-peligro-volcanico"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Identifica proceso, escenario y escala antes de interpretar un mapa.",
    "Distingue peligro y exposición sin afirmar riesgo cero."
  ],
  "prerequisites": [
    "s12-monitoreo-volcanico"
  ],
  "sources": [
    "e12-hazard-maps",
    "e12-visor"
  ],
  "pending": [
    "Revisión por especialista en geología y vulcanología e instructor de montaña pendiente. No valida una ruta, acceso ni evacuación.",
    "Alertas actuales, restricciones, cotas discrepantes y condiciones de terreno requieren verificación independiente; no hay datos operativos en tiempo real.",
    "Casos, rúbricas y ejercicios originales. Las descripciones científicas no acreditan competencia técnica ni un protocolo universal de seguridad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Fuera de un polígono de un proceso…",
        "options": [
          "Se garantiza riesgo cero.",
          "No se descartan otros procesos o escenarios.",
          "Siempre hay acceso autorizado."
        ],
        "answer": 1,
        "explanation": "La conclusión conserva el alcance del producto.",
        "rationales": [
          "El mapa tiene límites.",
          "La conclusión conserva el alcance del producto.",
          "Una capa no es un permiso."
        ],
        "source": "e12-hazard-maps",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Antes de interpretar colores se revisa…",
        "options": [
          "La popularidad del sendero.",
          "Solo el tamaño de pantalla.",
          "La leyenda y el escenario."
        ],
        "answer": 2,
        "explanation": "Da significado a la representación.",
        "rationales": [
          "No explica el mapa.",
          "No define su contenido.",
          "Da significado a la representación."
        ],
        "source": "e12-hazard-maps",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Aumentar el zoom…",
        "options": [
          "No crea precisión cartográfica nueva.",
          "Mejora automáticamente la escala original.",
          "Convierte un mapa en plano de evacuación."
        ],
        "answer": 0,
        "explanation": "Solo amplía la representación.",
        "rationales": [
          "Solo amplía la representación.",
          "La información original no cambia.",
          "Son productos de propósito distinto."
        ],
        "source": "e12-hazard-maps",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Identifica proceso, escenario y escala antes de interpretar un mapa.",
    "Distingue peligro y exposición sin afirmar riesgo cero.",
    "Explica por qué un mapa no sustituye instrucciones de evacuación o acceso."
  ],
  "openAssessment": {
    "prompt": "Compara dos mapas ficticios de procesos distintos y escribe qué pregunta responde cada uno y qué no puede concluirse de su superposición.",
    "rubric": [
      "Identifica proceso, escenario y escala antes de interpretar un mapa.",
      "Distingue peligro y exposición sin afirmar riesgo cero.",
      "Explica por qué un mapa no sustituye instrucciones de evacuación o acceso."
    ],
    "source": "e12-hazard-maps",
    "difficulty": "integración"
  },
  "diagrams": [
    "e12-documentos"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ESPECIALISTA PENDIENTE.** Estudio documental: no autoriza aproximación a fenómenos volcánicos ni acredita competencia de guía. No se publican alertas actuales. No guardes datos médicos ni contraseñas.

## Conceptos clave y propósito

Peligro, exposición, vulnerabilidad y riesgo. Leyenda, escala, escenario, cobertura y fecha. Un polígono representa un modelo o interpretación con alcance definido, no una pared física.

## Teoría y toma de decisiones

Un mapa de peligros expresa dónde pueden presentarse efectos de procesos bajo las hipótesis descritas en su elaboración. Para interpretarlo necesitas identificar qué proceso y escenario representa, su leyenda, escala y límites. Un color no tiene significado independiente de la leyenda ni debe transferirse entre mapas distintos.

Exposición se refiere a personas o elementos que podrían estar afectados; vulnerabilidad, a su susceptibilidad a sufrir consecuencias. La decisión de un grupo no se resume a pintar su ruta sobre un mapa. También intervienen información actual, restricciones, accesibilidad y capacidades. El visor Chile Preparado de SENAPRED presenta información territorial para preparación; no se utiliza aquí como recomendador automático de itinerarios.

La ausencia de color en un punto puede reflejar el alcance del escenario o cobertura del producto; no demuestra riesgo cero frente a todos los fenómenos. Tampoco hay una vigencia universal que pueda calcularse solo desde la fecha del mapa. Se requiere identificar si existe una versión actualizada y para qué uso fue elaborado. El trabajo de aula compara documentos y sus preguntas, sin inventar un perímetro de exclusión.

Fuentes de esta unidad: [Referencia 1](#fuente-e12-hazard-maps) · [Referencia 2](#fuente-e12-visor). Las aplicaciones de estudio y casos siguientes son elaboración pedagógica original, no protocolos de esas organizaciones.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — lectura y análisis documental:** Lee título y leyenda antes de ubicar un punto. Anota proceso, escenario, fecha, escala y cobertura; distingue mapa de peligro y plano de evacuación; formula preguntas no resueltas. Variante: mapa general frente a detalle local; no ampliar una imagen más allá de su resolución útil.

El ejercicio se realiza en escritorio o lugar autorizado. No expongas al grupo para comprobar actividad, gases, temperatura o estabilidad. Las maniobras críticas de montaña requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una ruta aparece fuera de una mancha de lahares y el grupo la llama segura frente a ceniza y corrientes piroclásticas. ¿Qué cambia entre proceso representado y conclusión pretendida?

## Errores frecuentes y puntos críticos de seguridad

Usar “fuera del polígono” como garantía; confundir zona de peligro y ruta autorizada; medir precisión de GPS con un mapa de escala insuficiente; superponer capas sin revisar datum o fecha.

## Material y equipo relacionado

Mapa completo con leyenda y fuente, reglas cartográficas y plan oficial aplicable. El GPS no mejora por sí mismo la precisión de la capa geológica.

[Consultar inventario](../../equipo/). Poseer un dispositivo o equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Justifica con un ejemplo y un límite: Identifica proceso, escenario y escala antes de interpretar un mapa.
- Justifica con un ejemplo y un límite: Distingue peligro y exposición sin afirmar riesgo cero.
- Justifica con un ejemplo y un límite: Explica por qué un mapa no sustituye instrucciones de evacuación o acceso.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Compara dos mapas ficticios de procesos distintos y escribe qué pregunta responde cada uno y qué no puede concluirse de su superposición.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Lectura de cartografía oficial con especialista e instructor; no diseñar ni validar un escape improvisado mediante el ejercicio.

## Evidencia requerida y criterios de competencia

- Identifica proceso, escenario y escala antes de interpretar un mapa.
- Distingue peligro y exposición sin afirmar riesgo cero.
- Explica por qué un mapa no sustituye instrucciones de evacuación o acceso.

**COMPETENCIA:** estos criterios requieren revisión humana contextual. Leer, resolver un quiz o presentar un documento no certifica guiado ni ejecución de maniobras. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s12-mapas-peligro-volcanico). Registra fecha, escenario, fuente, errores, correcciones, supervisor y evidencia de aprendizaje. Separa ejercicio ficticio de actividad real. No inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Geología y vulcanología](../../geologia/) · [Fichas territoriales](../../territorio/) · [Ecología](../../ecologia/) · [Glaciar](../../glaciar/) · [Planificación](../../planificacion/) · [Programa](../../programa/). El conocimiento del origen del relieve complementa la planificación; no reemplaza información actual ni evaluación de terreno.
