---
{
  "title": "Revisión posterior y próxima práctica",
  "description": "Relaciona la corrección con una observación.",
  "module": "M19",
  "code": "E16-06",
  "order": 1606,
  "minutes": 30,
  "level": "Intermedio",
  "status": "development",
  "unit": "U16-06",
  "skills": [
    "s16-debriefing-aprendizaje"
  ],
  "critical": false,
  "reviewDate": "2026-10-28",
  "objectives": [
    "Relaciona la corrección con una observación.",
    "Define una próxima prueba concreta."
  ],
  "prerequisites": [
    "s16-decisiones-grupo"
  ],
  "sources": [
    "e16-feedback"
  ],
  "pending": [
    "Revisión por docente e instructor competente pendiente.",
    "Casos y rúbricas originales; no certifican guiado ni sustituyen formación técnica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Terminar sin problemas prueba…",
        "options": [
          "Que no hubo errores de proceso.",
          "Solo ese resultado; hay que revisar también cómo se llegó.",
          "Competencia profesional completa."
        ],
        "answer": 1,
        "explanation": "Distingue resultado y proceso.",
        "rationales": [
          "Pueden existir omisiones sin consecuencia observada.",
          "Distingue resultado y proceso.",
          "El ejercicio no certifica una profesión."
        ],
        "source": "e16-feedback",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué mejora es comprobable en el próximo taller?",
        "options": [
          "Ser mejor líder.",
          "Tener más confianza.",
          "Pedir una reformulación y registrar lo que faltó."
        ],
        "answer": 2,
        "explanation": "Permite observar una actuación concreta.",
        "rationales": [
          "No define conducta.",
          "Es percepción, no criterio de ejecución.",
          "Permite observar una actuación concreta."
        ],
        "source": "e16-feedback",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué evidencia corresponde al ejercicio propuesto en esta unidad?",
        "options": [
          "Un registro de la tarea, errores y correcciones observados.",
          "Una declaración automática de competencia por leer.",
          "Una valoración del carácter de la persona."
        ],
        "answer": 0,
        "explanation": "La rúbrica pide observaciones de una tarea concreta; su evaluación sigue siendo humana.",
        "rationales": [
          "Es evidencia contextual del taller.",
          "Leer no demuestra ejecución.",
          "Se evalúan actuaciones, no etiquetas personales."
        ],
        "source": "e16-feedback",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Relaciona la corrección con una observación.",
    "Define una próxima prueba concreta.",
    "Distingue autoevaluación y evaluación supervisada."
  ],
  "openAssessment": {
    "prompt": "Redacta un debriefing con hecho, criterio, corrección y siguiente ensayo. Añade una conclusión que no puedas sostener con esa evidencia.",
    "rubric": [
      "Relaciona la corrección con una observación.",
      "Define una próxima prueba concreta.",
      "Distingue autoevaluación y evaluación supervisada."
    ],
    "source": "e16-feedback",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**BLOQUE EN DESARROLLO · REVISIÓN DOCENTE E INSTRUCTORA PENDIENTE.** Talleres de mesa con personajes ficticios, sin exposición en terreno ni datos personales.

## Conceptos clave y propósito

El debriefing de este bloque reconstruye lo ocurrido, compara la actuación con un criterio y acuerda un cambio comprobable. No busca producir un relato perfecto después de conocer el desenlace.

## Teoría y alcance de la fuente

La EEF advierte que el valor de la retroalimentación depende de sus principios y efectos, no simplemente de si se entrega por escrito u oralmente. Su evidencia escolar no valida automáticamente esta aplicación al guiado adulto.

[Fuente conceptual y límites](#fuente-e16-feedback). El diseño de tareas, preguntas y criterios siguiente es una propuesta original de la academia; no se atribuye a la organización citada ni constituye un estándar de acreditación.

## Aplicación docente propuesta

Propuesta de revisión: comienza por la tarea prevista y recoge observaciones de participantes y observador. Distingue un resultado favorable de un proceso bien fundamentado; un ejercicio puede salir bien pese a una omisión. Describe una corrección concreta y reserva una nueva oportunidad para ponerla a prueba.

En vez de «comunicar mejor», acuerda «en el próximo briefing pediré una reformulación y registraré la diferencia encontrada». No necesitas transformar cada observación en una nota numérica. Mantén aparte autoevaluación, comentario de un compañero y evaluación por instructor. Registra solo lo que ocurrió, con contexto suficiente y sin datos sensibles de terceros. Una revisión pendiente debe seguir pendiente aunque el participante esté satisfecho.

## Caso práctico

**Escenario ficticio:** Un equipo termina una simulación sin incidentes, pero el observador registró que nadie verificó un cambio de consigna.

Explica qué observación necesitas antes de concluir y qué parte de tu respuesta es todavía una hipótesis.

## Errores frecuentes

Confundir confianza con evidencia, registrar como realizada una práctica solo preparada y trasladar el resultado de una simulación a terreno real. Revisa también si describiste un hecho o una interpretación.

## Material y equipo

Cuaderno, tarjetas con roles ficticios y una ficha territorial de la academia. No se requieren cuerdas, anclajes ni exposición al terreno para estos ejercicios.

## Autoevaluación

- Relaciona la corrección con una observación.
- Define una próxima prueba concreta.
- Distingue autoevaluación y evaluación supervisada.

## Ejercicios y práctica supervisada

Redacta un debriefing con hecho, criterio, corrección y siguiente ensayo. Añade una conclusión que no puedas sostener con esa evidencia.

En un taller con docente o instructor, alterna participante, facilitador y observador. Define antes el criterio y recoge después una corrección. El instructor decide si corresponde otra práctica; no aumentes exposición para producir evidencia.

## Evidencia requerida

Conserva objetivo, tarea, observación, error, corrección y próxima práctica. La revisión humana debe indicar contexto y límites; no basta una etiqueta de «logrado». El quiz registra conocimiento teórico y no cambia competencias prácticas.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s16-debriefing-aprendizaje). Solo registra el taller después de realizarlo. No inventes supervisor, evaluación ni repeticiones.

## Relaciones con otros módulos

[Pedagogía y liderazgo](../../liderazgo/) · [Fundamentos de grupo](../../lecciones/grupo-liderazgo/) · [Programa](../../programa/). Las maniobras y decisiones técnicas requieren sus propias competencias y supervisión.
