---
{
  "title": "Búsqueda fina: precisión y transición a la sonda",
  "description": "Distinguir mínimo indicado de confirmación mediante contacto.",
  "module": "M09",
  "code": "E5-11",
  "order": 510,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-09",
  "skills": [
    "s5-dva-fina"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir mínimo indicado de confirmación mediante contacto.",
    "Explicar control de orientación y altura en un modelo de búsqueda fina.",
    "Preparar una transferencia clara entre buscador y persona que sondea."
  ],
  "prerequisites": [
    "s5-dva-aproximacion"
  ],
  "sources": [
    "e5-fina-canada",
    "e5-sonda-canada"
  ],
  "pending": [
    "Método de búsqueda fina del modelo exacto y criterio de evaluación presencial pendientes."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una lectura mínima equivale a…",
        "options": [
          "Confirmación clínica.",
          "Una referencia instrumental para continuar la localización.",
          "Garantía de que solo hay una víctima."
        ],
        "answer": 1,
        "explanation": "No identifica anatomía ni estado de la persona.",
        "rationales": [
          "No evalúa funciones vitales.",
          "Describe evidencia instrumental.",
          "No determina el número total."
        ],
        "source": "e5-fina-canada",
        "difficulty": "intermedia",
        "kind": "conocimiento"
      },
      {
        "prompt": "¿Por qué importa conservar altura y orientación en el modelo mostrado?",
        "options": [
          "Para comparar movimientos sin alterar varias variables a la vez.",
          "Para aumentar la autonomía de las pilas de forma garantizada.",
          "Para saber la temperatura del manto."
        ],
        "answer": 0,
        "explanation": "El control favorece una interpretación coherente.",
        "rationales": [
          "Relaciona control y lectura.",
          "No es el objetivo de esa instrucción.",
          "El DVA no mide ese dato."
        ],
        "source": "e5-fina-canada",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "El compañero recibe el DVA pero desconoce el punto seleccionado. ¿Qué falló?",
        "options": [
          "El registro de marca.",
          "La legislación.",
          "La transferencia de información entre fases."
        ],
        "answer": 2,
        "explanation": "La referencia debe poder usarse en la siguiente tarea.",
        "rationales": [
          "No resuelve localización.",
          "No hay evidencia de un problema legal.",
          "Identifica el fallo funcional."
        ],
        "source": "e5-sonda-canada",
        "difficulty": "intermedia",
        "kind": "errores"
      }
    ]
  },
  "preparation": [
    "Distingue mínimo, contacto y extracción.",
    "Explica control de variables y transición.",
    "Registra una corrección observable sin declarar competencia por tiempo."
  ],
  "openAssessment": {
    "prompt": "Describe una transferencia clara desde búsqueda fina a sondaje y enumera lo que sigue sin conocerse.",
    "rubric": [
      "Distingue mínimo, contacto y extracción.",
      "Explica control de variables y transición.",
      "Registra una corrección observable sin declarar competencia por tiempo."
    ],
    "source": "e5-fina-canada",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-sonda"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Control estable, patrón explicable y referencia compartida del punto; distinguir lectura de contacto físico.

## Teoría y toma de decisiones

La búsqueda fina intenta acotar una posición con suficiente precisión para orientar el sondaje. El problema ya no es cubrir un área extensa ni recorrer la trayectoria de aproximación. Ahora pequeños movimientos y cambios en la posición del aparato importan. Avalanche Canada presenta un patrón sistemático de acotación y destaca mantener estable orientación y distancia respecto de la superficie. [Búsqueda fina](#fuente-e5-fina-canada). Se trata de un modelo educativo que debe contrastarse con las ayudas y mensajes del equipo concreto.

Un mínimo de lectura es un resultado instrumental, no una confirmación de una persona. Puede permitir seleccionar dónde iniciar la siguiente fase, pero no informa por sí solo sobre vía aérea, postura o lesiones. Esa distinción cambia el lenguaje: «punto mínimo indicado» conserva el significado; «víctima encontrada y rescatada» adelanta conclusiones. El trabajo fino reduce incertidumbre espacial; la sonda aporta otro tipo de evidencia. Después habrá que crear acceso y atender a la persona.

Imagina un ejercicio de aula donde el aparato se levanta y baja mientras se mueve lateralmente. Si el número cambia, no sabes qué parte del cambio procede de la posición lateral y cuál de la altura. La decisión pedagógica consiste en controlar variables, no perseguir cualquier número bajo. Un segundo croquis muestra un registro sistemático con referencias mantenidas. No garantiza una solución real, pero permite discutir qué se hizo y repetirlo bajo supervisión. La precisión es una conducta observable: ritmo, control y confirmación, no una cualidad que se atribuye al alumno por haber leído el manual.

El punto seleccionado debe comunicarse sin perderse durante el cambio de herramientas. Avalanche Canada conecta la menor distancia de la fase fina con el inicio del sondaje y describe mantener una referencia cuando hay contacto. [Paso al sondaje](#fuente-e5-sonda-canada). Esta relación explica por qué una búsqueda fina descuidada puede multiplicar trabajo posterior. Sin embargo, repetir indefinidamente el DVA para conseguir una pantalla «perfecta» también puede retrasar la confirmación. El instructor enseña un criterio de transición reproducible para el equipo y ejercicio utilizados.

Ejercicio original: dos tarjetas muestran el mismo número final. La primera incluye un croquis, una secuencia ordenada y la referencia del punto seleccionado. La segunda solo dice «me dio cerca». Escribe qué información necesita el compañero encargado de la sonda. Añade una interrupción: alguien entra en el espacio de trabajo dando instrucciones distintas. Propón cómo evitar órdenes incompatibles sin convertir al buscador en una persona aislada de la coordinación general. El objetivo es preservar información al repartir tareas.

En un escenario con varios integrantes no todas las personas necesitan repetir simultáneamente la búsqueda fina sobre el mismo punto. La preparación de herramientas, la atención a amenazas y la comunicación pueden ser tareas diferentes según recursos y seguridad. El análisis del grupo debe identificar qué función está cubierta y cuál está vacía. No se deduce que «más aparatos juntos» produzcan siempre un resultado mejor; tampoco se supone que haya personal suficiente para cada función.

Al registrar una práctica, anota qué equipo se empleó, qué criterio de transición enseñó el instructor, qué error fue observado y cómo se corrigió. «Encontré el mínimo» es un resultado incompleto si nadie pudo identificar la referencia después. «Mantuve referencia y expliqué qué quedaba por comprobar» muestra una evidencia más útil. No almacenes datos de personas sepultadas ni dramatices una emergencia real: se utilizan objetivos inertes y ejercicios controlados. La evaluación de esta lección es conceptual; el desempeño presencial se documenta por separado.

## Qué observo, qué significa y qué no puedo concluir

La cifra final no identifica postura, vía aérea ni condición clínica.

## Caso práctico y aplicación al guiado

Dos grupos obtienen el mismo número, pero solo uno conserva el punto para la sonda. Compara calidad de evidencia.

## Errores frecuentes y señales de alerta

Mover rápido al final; cambiar altura sin control; confundir mínimo con víctima confirmada; perder el punto al sacar herramientas.

## Autoevaluación y respuesta razonada

Describe una transferencia clara desde búsqueda fina a sondaje y enumera lo que sigue sin conocerse.

## Ejercicios y práctica supervisada

Práctica supervisada de búsqueda fina y comunicación a sondaje con objetivo protegido, sin personas enterradas.

## Evidencia requerida

- Distingue mínimo, contacto y extracción.
- Explica control de variables y transición.
- Registra una corrección observable sin declarar competencia por tiempo.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-dva-fina).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
