---
{
  "title": "Análisis de una reunión y fallos comunes",
  "description": "Aplicar ocho preguntas de revisión a un esquema de reunión.",
  "module": "M07",
  "code": "E43-17",
  "order": 316,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U43-08",
  "skills": [
    "s43-analisis-reunion"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Aplicar ocho preguntas de revisión a un esquema de reunión.",
    "Detectar causas comunes de fallo y cambios de dirección no considerados.",
    "Definir información faltante y criterios para detener una práctica."
  ],
  "prerequisites": [
    "s43-anclajes-reuniones"
  ],
  "sources": [
    "petzl-reunion-actual"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "reunion-fallos"
  ],
  "preparation": [
    "Explicar los conceptos sin confundir un modelo con una maniobra.",
    "Reconocer al menos dos errores del caso y justificar una alternativa.",
    "Identificar la documentación y las competencias prácticas que faltan."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "petzl-reunion-actual",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "ANCHORS se responde «confiables» sin observar el soporte.",
        "options": [
          "Es un dato demostrado.",
          "Es una afirmación pendiente de evidencia.",
          "Basta si el equipo es nuevo."
        ],
        "answer": 1,
        "explanation": "Debe explicarse la base de confianza.",
        "rationales": [
          "Falta observación y criterio.",
          "Debe explicarse la base de confianza.",
          "El estado del equipo no valida el soporte."
        ],
        "source": "petzl-reunion-actual",
        "kind": "errores",
        "difficulty": "intermedia"
      },
      {
        "prompt": "Un diagrama no muestra el reverso de una conexión.",
        "options": [
          "Debe inventarse su configuración.",
          "Se supone igual al anverso.",
          "Se registra información no observable."
        ],
        "answer": 2,
        "explanation": "La incertidumbre es parte del análisis.",
        "rationales": [
          "Inventar elimina trazabilidad.",
          "La simetría no está demostrada.",
          "La incertidumbre es parte del análisis."
        ],
        "source": "petzl-reunion-actual",
        "kind": "aplicación",
        "difficulty": "intermedia"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

Una revisión rigurosa produce preguntas, evidencia y límites. La lista ANCHORS–REDUNDANCY–DIRECTION–EQUALIZATION–EXTENSION–MASTER POINT–PROTECTION–COMMUNICATION se usa aquí como organizador didáctico solicitado, no como certificación, norma ni método universal atribuido a una escuela.

## Teoría y decisiones

**ANCHORS:** ¿qué sustenta la confianza en cada punto y qué no puede observarse? **REDUNDANCY:** ¿qué fallo concreto se intenta tolerar y qué dependencias comunes subsisten? **DIRECTION:** ¿se incluyen posiciones actuales, movimientos y posibles cambios? **EQUALIZATION:** ¿qué reparto se espera y con qué incertidumbre?

**EXTENSION:** ¿qué se desplazaría si un elemento fallara y qué consecuencias tendría? **MASTER POINT:** ¿dónde entran las conexiones y cómo se distingue cada función? **PROTECTION:** ¿qué protege a personas, cuerda y componentes frente a aristas, movimientos u otros fallos? **COMMUNICATION:** ¿quién opera, observa y confirma una transición?

Ninguna respuesta debe reducirse a «sí» sin explicar el escenario. Una fotografía puede mostrar orientación o cruces, pero no la calidad interna del soporte ni el historial del material. La referencia Petzl sobre vías equipadas ayuda a discutir direcciones y funciones dentro de su alcance específico; no valida el diagrama académico [Referencia: petzl-reunion-actual](#fuente-petzl-reunion-actual).

En el diagrama de fallos, dos ramas comparten un soporte S. La flecha inicial apunta abajo y una flecha hipotética indica tracción lateral. La tarea es detectar preguntas pendientes: independencia de S, cambio de dirección y continuidad de protección tras un fallo. No se presenta un sistema alternativo listo para montar.

Un informe útil distingue: dato observado, inferencia, hipótesis y acción. «Veo dos ramas» es observación. «Por tanto es redundante» es inferencia que requiere justificar fallos previstos. «El soporte resiste» sin evidencia es una hipótesis no validada. «No usar esta propuesta hasta revisión» puede ser una decisión razonada, aunque no se conozca aún la solución.

## Caso práctico y aplicación al guiado

Un compañero dice que su reunión cumple todas las siglas. Pídele explicar el efecto de un fallo de un punto y el de una tracción hacia otra dirección. Si no puede describirlos, redacta la información faltante en vez de asignar un aprobado global.

## Errores frecuentes y señales de alerta

Usar una mnemotecnia como autorización; inferir material oculto; omitir al operador en la revisión; pensar que una recomendación de una escuela es universal. «No observable» no debe convertirse en «probablemente correcto».

## Autoevaluación y respuestas explicadas

¿Completar ocho casillas acredita la reunión? **No: la calidad de la evidencia y el escenario importan.** ¿Puede la conclusión ser detener la propuesta? **Sí, cuando faltan datos críticos o competencia para evaluarla.**

## Ejercicios y práctica presencial

Resolver el diagrama sin tocar material. Preparar dos preguntas por categoría y una devolución respetuosa al diseñador. Taller presencial: instructor presenta una configuración didáctica y solicita describir funciones y límites; solo él define condiciones de prueba.

## Evidencia requerida

Informe de revisión con ocho categorías, fuentes, datos ausentes y decisiones. Evaluación por criterio y contexto, no suma de casillas.

## Relaciones con otras habilidades

Revisa los prerrequisitos y el contrato de habilidad de esta unidad en el programa. Contrasta la explicación con las fuentes indicadas: las cifras de un ejercicio no son límites de uso de un equipo. Toda transferencia a una situación con personas requiere formación y revisión presencial.
