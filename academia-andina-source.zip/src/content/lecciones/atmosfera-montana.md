---
{
  "title": "Atmósfera y meteorología de montaña",
  "description": "Relacionar presión, temperatura y humedad sin extrapolar un dato del valle.",
  "module": "M10",
  "code": "E4-06",
  "order": 206,
  "minutes": 60,
  "level": "Intermedio",
  "status": "development",
  "reviewDate": "2026-10-22",
  "unit": "U4-06",
  "skills": [
    "s4-atmosfera-montana"
  ],
  "critical": false,
  "objectives": [
    "Relacionar presión, temperatura y humedad sin extrapolar un dato del valle.",
    "Distinguir gradiente ambiental, inversión y estabilidad.",
    "Explicar consecuencias posibles para una salida sin convertir conceptos en pronóstico."
  ],
  "prerequisites": [
    "Completar estudio de Fundamentales; la práctica previa debe revisarse presencialmente.",
    "Estudiar GPS, navegación y pérdida de orientación."
  ],
  "sources": [
    "noaa-presion",
    "nws-humedad",
    "met-inversion",
    "met-frentes",
    "nws-glosario"
  ],
  "pending": [
    "Revisión pedagógica y evaluación situada por instructor competente.",
    "Condiciones, accesos, permisos y compatibilidad del equipo requieren verificación para cada actividad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Humedad relativa del 100 % significa…",
        "options": [
          "Lluvia inevitable.",
          "Ausencia de viento.",
          "Saturación, no necesariamente precipitación."
        ],
        "answer": 2,
        "explanation": "La saturación no basta para determinar precipitación."
      },
      {
        "prompt": "Una inversión térmica describe…",
        "options": [
          "Una capa con aumento de temperatura al aumentar la altura.",
          "Temperatura siempre decreciente.",
          "Una alerta de tormenta."
        ],
        "answer": 0,
        "explanation": "Es una característica del perfil, no una autorización operacional."
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

**TEORÍA.** La **presión** es fuerza por superficie y suele expresarse en hPa; disminuye con la elevación. Una presión medida en altura no se compara directamente con otra reducida al nivel del mar [Referencia: noaa-presion](#fuente-noaa-presion). La **temperatura** describe el estado térmico; su valor puntual no resume viento, humedad, radiación ni condiciones de exposición.

La **humedad relativa** expresa cercanía a saturación a la temperatura del aire. El **punto de rocío** es la temperatura a la que ese aire alcanzaría saturación al enfriarse. Un aire con humedad relativa alta no contiene necesariamente más vapor que otro más cálido con humedad relativa menor. Saturación tampoco significa necesariamente lluvia [Referencia: nws-humedad](#fuente-nws-humedad).

## Teoría: leer relaciones, no números sueltos

Para un guía, la pregunta útil es qué representa el dato: altura, ubicación del sensor, momento, unidad y método. Un barómetro que baja durante un ascenso mezcla el cambio de posición con la evolución atmosférica. No interpretes esa serie como deterioro del tiempo sin separar ambos efectos. Un termómetro expuesto al sol tampoco representa necesariamente la temperatura del aire medida con un procedimiento meteorológico adecuado.

En un ejercicio ficticio, un registro indica aire a 8 °C y punto de rocío a 7 °C, mientras otro indica 18 °C y punto de rocío a 7 °C. El primero está más cerca de saturación. La comparación no determina por sí sola cuándo lloverá, cuál será la visibilidad en una cumbre ni cómo estará cada ladera. Es una pista física que debe integrarse con más información.

## Gradiente, inversión y estabilidad

**Gradiente térmico vertical** describe cómo cambia la temperatura con altura. Distingue el perfil ambiental observado del cambio térmico de una parcela que asciende o desciende. No uses una tasa única de enfriamiento para convertir sin más la temperatura del valle en temperatura de cumbre.

Una **inversión térmica** es una capa donde aumenta la temperatura al aumentar la altura; puede limitar la mezcla y mantener aire frío cerca del suelo [Referencia: met-inversion](#fuente-met-inversion). No implica ausencia de viento o condiciones agradables en toda la montaña. Si el perfil cambia de comportamiento, una interpolación lineal pierde utilidad.

La **estabilidad atmosférica** se relaciona con la respuesta a desplazamientos verticales: un ambiente estable tiende a resistirlos y uno inestable puede favorecerlos. **Convección** implica movimientos verticales asociados a flotabilidad. Una tormenta combina actividad eléctrica con procesos atmosféricos que no se deducen de una sola lectura de humedad [Referencia: nws-glosario](#fuente-nws-glosario). El curso no enseña a diagnosticar estabilidad con una fotografía.

## Masas de aire, frentes y viento

Una masa de aire tiene propiedades características de temperatura y humedad a gran escala. Un frente delimita masas contrastantes. Las denominaciones frío, cálido, estacionario y ocluido describen configuraciones y evolución, no un horario fijo de lluvia para tu sendero [Referencia: met-frentes](#fuente-met-frentes). La montaña modifica la expresión local de esa situación.

El viento debe describirse con dirección, velocidad, rachas, altura y periodo de referencia. La dirección meteorológica indica de dónde procede. No mezcles velocidad media y racha ni km/h con m/s. En un ejercicio de unidades, 10 m/s equivalen a 36 km/h; esa equivalencia no define un umbral aceptable para ninguna actividad.

## Precipitación, niebla y visibilidad

Distingue cantidad acumulada, intensidad, intervalo y tipo de precipitación. “5 mm” sin periodo no basta para comparar productos. La niebla afecta visibilidad cerca de la superficie; nubosidad sobre una ladera puede eliminar referencias que antes resultaban útiles. El nivel de congelación y la línea de nieve no son términos intercambiables: el primero describe una condición térmica del aire; la segunda depende del contexto y del producto que la informa. No se infiere estado de una superficie solo con la isoterma.

No basta preguntar si lloverá. Pregunta qué ocurre con las referencias, el retorno, la ropa disponible y la capacidad del grupo si la situación empeora. Esta traducción del fenómeno a consecuencias es una decisión operacional, no una nueva predicción meteorológica.

## Caso práctico: perfiles ficticios

Recibes datos de temperatura de un valle y una estación de altura tomados en horas diferentes. Alguien calcula un gradiente y lo proyecta sobre toda la ruta. Describe dos errores de comparación y qué pedirías antes de usar el resultado.

Respuesta orientativa: falta simultaneidad y representatividad espacial; conviene revisar exposición de sensores, hora y perfil disponible. El cálculo puede ser aritméticamente correcto y meteorológicamente inapropiado.

## Errores frecuentes y señales de alerta

Confundir alta humedad con lluvia segura; usar presión sin referencia; extrapolar un gradiente fijo; convertir inversión en “buen tiempo”; ignorar rachas y visibilidad. Revisa cuando las unidades o el periodo no estén claros, o la observación contradiga el supuesto que sostenía el plan.

## Autoevaluación y respuestas explicadas

1. ¿100 % de humedad relativa garantiza precipitación? **No: expresa saturación; no basta para determinar producción y caída de precipitación.**
2. ¿Por qué una temperatura del valle puede no representar la cumbre? **El perfil vertical y las condiciones locales no se deducen de una única lectura.**

## Ejercicios y práctica presencial

Construye una tabla con variable, unidad, referencia y limitación para seis datos ficticios. Resuelve el ejemplo de punto de rocío y el de viento. Observa desde un sitio seguro y contrasta con una fuente oficial; no salgas a exponerte a tormentas para validar una hipótesis. La interpretación operativa se revisa con instructor.

## Evidencia requerida

Tabla anotada, explicación de dos comparaciones inválidas y una decisión que reconozca datos faltantes. Se evalúa comprensión y trazabilidad, no capacidad de emitir alertas.

## Relaciones con otras habilidades

Esta unidad se integra en la ruta estival. Consulta la ficha de habilidad y sus prerrequisitos en el programa. Registra práctica y evaluación por separado: estudiar y responder correctamente no acredita ejecución. Los ejercicios son propuestas didácticas originales; los casos no son rutas operativas.
