---
{
  "title": "Planificación alpina: una jornada, varios problemas",
  "description": "Dividir una propuesta alpina en tramos y transiciones verificables.",
  "module": "M06",
  "code": "E8-01",
  "order": 801,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U8-01",
  "skills": [
    "s8-planificacion-alpina"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Dividir una propuesta alpina en tramos y transiciones verificables.",
    "Construir márgenes de tiempo y alternativas sin convertirlos en garantías."
  ],
  "prerequisites": [
    "s7-riesgo-hielo",
    "s6-grupo-glaciar"
  ],
  "sources": [
    "e8-plan",
    "e8-decision"
  ],
  "pending": [
    "Revisión docente y práctica presencial por instructor alpino competente pendientes. No se ha observado ni aprobado una maniobra.",
    "Compatibilidad y manual del equipo personal pendientes de verificación; no se extrapolan ejemplos GRIGRI/REVERSO/RAD LINE a ATC Guide u otras cuerdas.",
    "Horario ficticio pedagógico: no es una estimación de ruta ni un criterio de salida segura."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿Cuánto suma el ejemplo antes de pausas?",
        "options": [
          "435 minutos.",
          "390 minutos.",
          "480 minutos."
        ],
        "answer": 0,
        "explanation": "90+180+45+120=435. Dividir una propuesta alpina en tramos y transiciones verificables.",
        "rationales": [
          "90+180+45+120=435.",
          "Omite las transiciones.",
          "Ocho horas es la luz disponible del caso, no su suma."
        ],
        "source": "e8-plan",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Si cuatro largos tardan 15 minutos más cada uno…",
        "options": [
          "Se añaden 15 minutos en total.",
          "Se añade una hora.",
          "El descenso compensa siempre el retraso."
        ],
        "answer": 1,
        "explanation": "4×15=60 minutos adicionales. Dividir una propuesta alpina en tramos y transiciones verificables.",
        "rationales": [
          "Hay cuatro retrasos que sumar.",
          "4×15=60 minutos adicionales.",
          "No hay evidencia de una compensación."
        ],
        "source": "e8-plan",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La alternativa sin descripción de salida se considera…",
        "options": [
          "Garantizada por ser más corta.",
          "Aprobada si lleva huellas.",
          "Pendiente de verificación."
        ],
        "answer": 2,
        "explanation": "La alternativa requiere datos propios. Dividir una propuesta alpina en tramos y transiciones verificables.",
        "rationales": [
          "La distancia no resuelve la exposición.",
          "Huellas no completan la información del retorno.",
          "La alternativa requiere datos propios."
        ],
        "source": "e8-plan",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Incluye aproximación, transiciones y descenso en el horario.",
    "Distingue tiempo calculado y margen disponible sin llamarlo seguro.",
    "Justifica cambios del objetivo cuando fallan supuestos."
  ],
  "openAssessment": {
    "prompt": "Desglosa el ejemplo en tabla de fases y recalcula si cada largo se retrasa 15 minutos. Añade dos datos que cambiarían la decisión y dos preguntas sobre el descenso.",
    "rubric": [
      "Incluye aproximación, transiciones y descenso en el horario.",
      "Distingue tiempo calculado y margen disponible sin llamarlo seguro.",
      "Justifica cambios del objetivo cuando fallan supuestos."
    ],
    "source": "e8-plan",
    "difficulty": "integración"
  },
  "diagrams": [
    "e8-transicion"
  ]
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. Lecturas y cuestionarios no acreditan ejecución técnica ni guiado.**

## Conceptos clave y propósito

Aproximación, itinerario, transición, exposición, compromiso, retirada y margen temporal.

## Teoría y toma de decisiones

Una jornada alpina puede combinar aproximación, roca, nieve, hielo y descenso con problemas distintos. La dificultad del paso más duro no resume el compromiso del recorrido. Una preparación útil descompone el objetivo y pregunta en cada tramo qué información existe, qué capacidad se necesita y cómo se puede abandonar.

La planificación debe reunir cartografía, descripción del itinerario, meteorología, capacidades y recursos. Las descripciones de ruta son información de un contexto y fecha: no confirman por sí mismas el estado actual. Una fotografía puede ayudar a reconocer formas y, al mismo tiempo, dejar sin resolver visibilidad, acceso, nieve o retirada. El estudiante conserva esas limitaciones cuando transforma la fuente en un plan. [Fuente de contraste](#fuente-e8-plan).

Un horario de trabajo incluye aproximación, escalada, transiciones, pausas y descenso. El promedio de marcha no representa bien una sección donde se organizan largos o se busca una reunión. Estimar solo los minutos de movimiento produce un plan aparentemente preciso que omite tareas necesarias. El margen se expresa junto con sus supuestos, y se revisa si esos supuestos fallan.

Ejemplo original de escritorio: se proponen 90 minutos de aproximación, cuatro largos de 45 minutos, tres transiciones de 15 minutos y 120 minutos de descenso. La suma es 435 minutos, o 7 horas y 15 minutos, antes de pausas o contingencias. Si cada largo toma 15 minutos más, se añade una hora. El cálculo no prescribe horarios de terreno: muestra qué componentes dominan la estimación.

Una alternativa exige datos propios. Una canal de descenso puede introducir amenazas distintas de la arista de subida. «Bajar por lo más corto» no es una estrategia documentada. Antes de iniciar se deben identificar puntos donde una decisión aún conserva opciones; el plan también precisa quién revisa cambios y cómo se avisa al contacto externo sin prometer una hora de rescate.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — análisis previo al taller.** Dividir una propuesta alpina en tramos y transiciones verificables. Se utiliza al preparar una tarea o revisar un cambio de contexto. Las comprobaciones se organizan por función, soporte, equipo, capacidades y continuidad de protección. La teoría y la rúbrica especifican qué observar en esta unidad.

El instructor selecciona método, protección y condiciones de parada. Si falta una condición esencial o el grupo no comprende una función, no se inicia la maniobra. Las variantes se mantienen dentro del contexto de su fuente: una página sobre vía equipada, un producto o senderismo no constituye un procedimiento universal alpino.

## Caso práctico y aplicación al guiado

**Escenario de aula:** Caso ficticio de curso: el croquis tiene fecha, pero no describe la salida de una canal. El grupo dispone de ocho horas de luz y propone el horario del ejemplo. Identifica los supuestos que faltan y explica por qué 45 minutos restantes no demuestran que el plan tenga margen suficiente.

Distingue hechos, suposiciones y preguntas antes de proponer una decisión. Los ejercicios, casos y rúbricas son propuestas pedagógicas originales de la academia pendientes de revisión docente. No se presentan como protocolos de los organismos citados.

## Errores frecuentes y puntos críticos de seguridad

Confundir duración de marcha con duración total; omitir transiciones; usar un croquis antiguo como condición presente; llamar segura a una alternativa sin verificarla; fijar la cumbre como único criterio de éxito.

Una práctica protegida tiene un alcance limitado; no valida todas las condiciones futuras. No se aprende una técnica crítica mediante una caída deliberada ni copiando una imagen en terreno expuesto.

## Material y equipo relacionado

Mapa y croquis con procedencia, previsión válida para el área, medios de navegación, comunicación y energía, equipo técnico seleccionado por tramo. InReach y VHF no sustituyen alternativas ni comprobación de cobertura.

[Consultar inventario](../../equipo/). Identifica modelo, documentación y datos pendientes. No inventes inspecciones ni atribuyas competencia a la compra de un dispositivo.

## Autoevaluación y recuperación activa

- Explica con un ejemplo: Dividir una propuesta alpina en tramos y transiciones verificables.
- ¿Qué información falta en el caso y qué decisión depende de ella?
- ¿Qué parte puedes revisar documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Desglosa el ejemplo en tabla de fases y recalcula si cada largo se retrasa 15 minutos. Añade dos datos que cambiarían la decisión y dos preguntas sobre el descenso.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Simulación de planificación con instructor. Se compara el plan con información nueva de un escenario ficticio, sin trasladarlo a una ruta real. El instructor evalúa identificación de supuestos y criterios de retorno.

## Evidencia requerida y criterios de competencia

- Incluye aproximación, transiciones y descenso en el horario.
- Distingue tiempo calculado y margen disponible sin llamarlo seguro.
- Justifica cambios del objetivo cuando fallan supuestos.

**COMPETENCIA:** la ejecución debe evaluarse presencialmente en un contexto explícito por instructor competente. Las respuestas escritas no sustituyen esa observación. Se registra qué ocurrió, qué no se evaluó y qué debe corregirse. No hay un número de repeticiones que otorgue competencia automáticamente.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s8-planificacion-alpina). Registra solo lo realizado: fecha, lugar, actividad, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Confianza, resultado y evaluación son datos diferentes. No guardar datos médicos, contraseñas ni datos privados de terceros.

## Relaciones con otros módulos

Integra [hielo](../../hielo/), [glaciar](../../glaciar/), [planificación invernal](../planificacion-invernal/) y [anclajes y reuniones](../anclajes-reuniones/). El [programa](../../programa/) muestra prerrequisitos; son académicos, no habilitaciones. [Volver al bloque alpino](../../alpina/).

[Resolver el laboratorio de tiempos](../../alpina/#laboratorio-tiempo). Modelo ficticio: no determina la viabilidad de una salida.
