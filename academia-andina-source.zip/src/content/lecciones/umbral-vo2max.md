---
{
  "title": "Umbrales y VO2max: conceptos y límites de las pruebas",
  "description": "Distinguir umbral, consumo máximo de oxígeno y rendimiento en montaña.",
  "module": "M22",
  "code": "E10-06",
  "order": 1006,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U10-06",
  "skills": [
    "s10-umbral-vo2max"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Distinguir umbral, consumo máximo de oxígeno y rendimiento en montaña.",
    "Aplicar el concepto a una decisión de preparación de montaña y reconocer sus límites."
  ],
  "prerequisites": [
    "s10-resistencia-zonas"
  ],
  "sources": [
    "e10-endurance",
    "e10-zones"
  ],
  "pending": [
    "Revisión por profesional del ejercicio e instructor de montaña pendiente. Nutrición y salud requieren revisión profesional específica; no se ha evaluado aptitud personal.",
    "Los casos y rúbricas son propuestas pedagógicas originales. La aplicación individual requiere evaluación, técnica y seguimiento.",
    "No se atribuyen requisitos de certificación, umbrales universales ni preparación técnica a los resultados físicos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "VO2max y umbral…",
        "options": [
          "Son conceptos distintos.",
          "Son siempre el mismo número.",
          "Determinan la habilidad de guía."
        ],
        "answer": 0,
        "explanation": "Describen aspectos diferentes.",
        "rationales": [
          "Describen aspectos diferentes.",
          "Dependen de definición y protocolo.",
          "No observan habilidades técnicas."
        ],
        "source": "e10-endurance",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un estudio en deportistas entrenados…",
        "options": [
          "Impone una receta universal.",
          "Debe interpretarse según población y diseño.",
          "Certifica a quien lo lee."
        ],
        "answer": 1,
        "explanation": "La evidencia tiene alcance.",
        "rationales": [
          "No permite esa extrapolación.",
          "La evidencia tiene alcance.",
          "No evalúa práctica."
        ],
        "source": "e10-endurance",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una variación de reloj requiere…",
        "options": [
          "Cambiar todo el plan inmediatamente.",
          "Hacer una prueba máxima solo.",
          "Revisar contexto y método antes de concluir."
        ],
        "answer": 2,
        "explanation": "Evita atribuciones infundadas.",
        "rationales": [
          "Puede ser ruido o cambio de tarea.",
          "No es una respuesta prudente al dato.",
          "Evita atribuciones infundadas."
        ],
        "source": "e10-endurance",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Diferencia conceptos y métodos.",
    "Reconoce límites de transferencia de un estudio.",
    "No equipara un indicador y rendimiento integral."
  ],
  "openAssessment": {
    "prompt": "Elabora tres columnas: qué dice VO2max, qué dice un umbral y qué queda sin medir para una expedición.",
    "rubric": [
      "Diferencia conceptos y métodos.",
      "Reconoce límites de transferencia de un estudio.",
      "No equipara un indicador y rendimiento integral."
    ],
    "source": "e10-endurance",
    "difficulty": "integración"
  },
  "diagrams": [
    "e10-medicion"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN PROFESIONAL PENDIENTE.** Este contenido no prescribe un programa individual ni acredita competencia técnica. Los ejercicios numéricos y casos son ficticios. No introduzcas datos médicos, mediciones corporales privadas ni antecedentes de terceros.

## Conceptos clave y propósito

VO2max, umbral ventilatorio, umbral de lactato, protocolo e intervalos.

## Teoría y toma de decisiones

VO2max describe el máximo consumo de oxígeno alcanzado bajo un protocolo adecuado. Los umbrales delimitan cambios de respuesta durante el esfuerzo; no son sinónimos de VO2max ni un único punto universal. El método utilizado debe quedar explícito.

Un estudio experimental de distribución de intensidad puede comparar adaptaciones en deportistas entrenados; no prueba que toda persona deba copiar sus sesiones. El trabajo de Stöggl y Sperlich estudió variables de resistencia bajo intervenciones específicas. [Estudio original](#fuente-e10-endurance). Su población y duración delimitan la transferencia.

El rendimiento de ascenso combina capacidad aeróbica, economía, terreno, carga y decisiones. Una estimación alta de VO2max no observa equilibrio con mochila ni aclimatación. La evaluación de laboratorio y la estimación comercial se identifican de forma distinta en el registro.

En el caso original, se propone introducir intervalos exigentes porque el reloj dejó de mejorar su número. Antes de cambiar el programa, el estudiante revisa la calidad del dato, las sesiones actuales y su recuperación. La lección no prescribe intervalos máximos ni asigna un porcentaje de frecuencia universal.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación del aprendizaje:** Pregunta qué se midió, con qué protocolo y para qué decisión. La evaluación máxima o de umbrales debe ser seleccionada y supervisada por personal competente. Si se incorpora intensidad, debe integrarse con el resto de la carga y la recuperación, no añadirse automáticamente encima de todo.

La selección real de ejercicios, cargas, pruebas y progresión corresponde a una evaluación individual con profesionales. Las técnicas críticas de montaña requieren formación práctica y supervisión de instructor competente. El acondicionamiento físico no autoriza una maniobra.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una estimación del reloj baja tras una salida con mochila y terreno blando. ¿Qué impide concluir que la condición física empeoró?

Distingue dato, interpretación y decisión. Explica qué incertidumbre permanece. Los casos no representan un protocolo del organismo citado ni un criterio oficial de habilitación para guía.

## Errores frecuentes y puntos críticos de seguridad

Confundir estimación y laboratorio; tratar lactato como único causante de fatiga; copiar intervalos de élite; buscar máximos en terreno expuesto.

## Material y equipo relacionado

Documentación del método de evaluación y equipo supervisado cuando corresponda. No se necesita instrumental clínico para el ejercicio de lectura crítica.

[Consultar inventario](../../equipo/). Ajustar o poseer el equipo no demuestra dominarlo. Las prácticas técnicas se registran por separado del acondicionamiento.

## Autoevaluación y recuperación activa

- Explica la diferencia entre la capacidad que estudias y una tarea técnica de montaña.
- ¿Qué información falta en el caso y qué decisión modificaría?
- ¿Qué parte puede analizarse en escritorio y cuál necesita observación profesional?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Elabora tres columnas: qué dice VO2max, qué dice un umbral y qué queda sin medir para una expedición.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Análisis de informes ficticios con profesional del ejercicio; pruebas reales solo tras evaluación y selección del protocolo.

## Evidencia requerida y criterios de competencia

- Diferencia conceptos y métodos.
- Reconoce límites de transferencia de un estudio.
- No equipara un indicador y rendimiento integral.

**COMPETENCIA:** estos criterios describen aprendizaje que debe observar un profesional en contexto. No acreditan aptitud médica, entrenamiento personal, guiado ni maniobra técnica. Una lectura, prueba física o quiz no otorga certificación. Marca pendiente lo que no se haya evaluado.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s10-umbral-vo2max). Registra fecha, actividad, escenario, equipo, objetivo, errores, correcciones, supervisor y evidencia de aprendizaje. No guardes datos médicos ni contraseñas. No inventes sesiones, evaluaciones o repeticiones para completar la matriz.

## Relaciones con otros módulos

[Entrenamiento](../../entrenamiento/) · [Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Programa](../../programa/). Entrenamiento general, preparación específica, aclimatación y competencia técnica se relacionan, pero no son equivalentes.
