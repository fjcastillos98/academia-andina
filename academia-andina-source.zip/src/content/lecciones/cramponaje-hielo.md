---
{
  "title": "Cramponaje en hielo: apoyo, equilibrio y compatibilidad",
  "description": "Relacionar apoyos, postura y fatiga con el control del movimiento.",
  "module": "M05",
  "code": "E7-03",
  "order": 703,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U7-03",
  "skills": [
    "s7-cramponaje-hielo"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Relacionar apoyos, postura y fatiga con el control del movimiento.",
    "Distinguir elección de puntas de compatibilidad del conjunto bota-crampón."
  ],
  "prerequisites": [
    "s7-tipos-hielo"
  ],
  "sources": [
    "e7-accessbook",
    "e7-movement"
  ],
  "pending": [
    "Revisión de instructor de hielo pendiente; no se ha observado ni aprobado ninguna práctica.",
    "Compatibilidad y manual de los modelos personales pendientes de verificación; ninguna pieza se considera apta por aparecer en el inventario.",
    "El video técnico se verificó solo por su texto introductorio; revisión audiovisual completa con instructor pendiente."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un crampón de correas…",
        "options": [
          "Se adapta de forma segura a cualquier bota.",
          "Requiere comprobar la combinación concreta.",
          "No necesita inspección."
        ],
        "answer": 1,
        "explanation": "La combinación exige documentación y ajuste. Relacionar apoyos, postura y fatiga con el control del movimiento.",
        "rationales": [
          "La universalidad no está demostrada.",
          "La combinación exige documentación y ajuste.",
          "Las fijaciones y piezas necesitan revisión."
        ],
        "source": "e7-accessbook",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Cambiar a monopunta…",
        "options": [
          "Debe responder al modelo, terreno y método de enseñanza.",
          "Certifica una técnica avanzada.",
          "Siempre mejora toda superficie."
        ],
        "answer": 0,
        "explanation": "Es una decisión contextual, no una garantía. Relacionar apoyos, postura y fatiga con el control del movimiento.",
        "rationales": [
          "Es una decisión contextual, no una garantía.",
          "Una modificación no demuestra competencia.",
          "Las configuraciones tienen compromisos."
        ],
        "source": "e7-accessbook",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un apoyo rápido roza la cuerda. ¿Qué revisar?",
        "options": [
          "Solo el cronómetro.",
          "Nada si no hubo caída.",
          "Control de movimiento, separación y organización del ejercicio."
        ],
        "answer": 2,
        "explanation": "Permite corregir la causa observada. Relacionar apoyos, postura y fatiga con el control del movimiento.",
        "rationales": [
          "La velocidad no es el criterio decisivo.",
          "La ausencia de incidente no valida el gesto.",
          "Permite corregir la causa observada."
        ],
        "source": "e7-accessbook",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Identifica piezas y límites de compatibilidad con manual.",
    "En taller supervisado conserva control de apoyos y separación de la cuerda.",
    "Comunica pérdida de fijación o fatiga y detiene la tarea."
  ],
  "openAssessment": {
    "prompt": "Compara dos manuales reales: tipo de bota admitido, fijación, ajustes y comprobaciones. Marca como desconocido cualquier dato del equipo personal que no esté confirmado.",
    "rubric": [
      "Identifica piezas y límites de compatibilidad con manual.",
      "En taller supervisado conserva control de apoyos y separación de la cuerda.",
      "Comunica pérdida de fijación o fatiga y detiene la tarea."
    ],
    "source": "e7-accessbook",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. El estudio y el quiz no acreditan una maniobra ni capacidad de guiado.**

## Conceptos clave y propósito

Apoyo frontal, equilibrio, orientación del pie, precisión, fijación y control de la fatiga.

## Teoría y toma de decisiones

En hielo empinado los apoyos de pies y la posición del cuerpo condicionan cuánto esfuerzo sostienen los brazos. La enseñanza técnica de Petzl trata el movimiento como coordinación de herramientas, pies y equilibrio. Contar golpes o memorizar una postura no sustituye una observación del alumno en terreno protegido. [Fuente de contraste](#fuente-e7-accessbook).

Las configuraciones monopunta y bipunta tienen usos y preferencias técnicas; la conversión solo procede en modelos diseñados para ello y siguiendo sus instrucciones. No son grados de experiencia ni una escala universal de seguridad. Antes de comparar rendimiento hay que establecer qué función pretende cumplir el conjunto en ese terreno. [Fuente de contraste](#fuente-e7-accessbook).

La compatibilidad incluye bota, fijación, barra, piezas y ajuste previstos por el fabricante. Una correa no convierte cualquier combinación en adecuada. El control se observa durante un taller porque el ajuste aparente y la precisión de apoyo son preguntas diferentes. El instructor debe poder detener el ejercicio cuando se detectan movimiento de la fijación, enganches o fatiga que impide control.

La evaluación educativa separa precisión y velocidad. Un alumno puede avanzar rápido y dejar de observar la posición de sus puntas cerca de la cuerda o de otra persona. Registrar ese error permite una corrección concreta. Aumentar la dificultad antes de corregirlo dificulta distinguir si el problema procede de la técnica, del equipo o de la carga del ejercicio.

## Procedimiento: función, comprobaciones y límites

**PROCEDIMIENTO — marco de análisis previo al taller.** Objetivo: Relacionar apoyos, postura y fatiga con el control del movimiento. Se utiliza para preparar el aprendizaje y detectar vacíos antes de una tarea real. Identifica la función, los componentes, la información que falta y las consecuencias de un error. Contrasta la versión de la fuente con el modelo de equipo y el método del instructor. No hay una configuración universal derivada de esta página.

Las comprobaciones relevantes se desarrollan en la teoría, el equipo y la rúbrica de esta unidad. Si el uso previsto o la protección del taller no están claros, la práctica no se inicia. Las variantes de una fuente se conservan dentro de su contexto; no se mezclan pasos de métodos distintos por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario ficticio para análisis:** Un alumno con experiencia en caminata invernal estrena crampones convertibles y pretende practicar hielo vertical sin revisar el manual. Identifica qué aprendizaje previo ayuda y qué comprobaciones y práctica siguen faltando.

Antes de responder, enumera los hechos dados y los datos que has supuesto. Propón una decisión provisional y una condición que te haría revisarla. El caso, los ejercicios y las rúbricas son propuestas pedagógicas originales de la academia, pendientes de revisión docente; no son un protocolo de un organismo citado.

## Errores frecuentes y puntos críticos de seguridad

Asumir transferencia automática desde marcha; confundir número de puntas con idoneidad; apretar una fijación incompatible; tolerar contacto de puntas con cuerda; perseguir rapidez con pérdida de precisión.

No uses la ausencia de incidentes como prueba de seguridad. Las tareas con carga, herramientas o exposición necesitan control presencial competente. Ninguna respuesta escrita autoriza a escalar, montar un anclaje ni asistir a un pasajero.

## Material y equipo relacionado

Botas y crampones compatibles del modelo exacto, sistema de fijación y manual, casco, arnés y sistema de protección dispuesto por instructor. Grivel G10/G12 o Petzl Lynx no se validan por su nombre.

[Consultar inventario](../../equipo/). Registra documento y revisión, sin inventar inspecciones realizadas. Tener material no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con tus palabras: Relacionar apoyos, postura y fatiga con el control del movimiento.
- ¿Qué observación del caso apoya tu decisión y qué dato sigue faltando?
- ¿Qué error de esta unidad podrías reconocer documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Compara dos manuales reales: tipo de bota admitido, fijación, ajustes y comprobaciones. Marca como desconocido cualquier dato del equipo personal que no esté confirmado.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** El instructor verifica el conjunto y prepara un taller protegido de apoyos y equilibrio. Observa precisión, control y comunicación antes de modificar inclinación. No se practica caída voluntaria sobre crampones.

## Evidencia requerida y criterios de competencia

- Identifica piezas y límites de compatibilidad con manual.
- En taller supervisado conserva control de apoyos y separación de la cuerda.
- Comunica pérdida de fijación o fatiga y detiene la tarea.

**COMPETENCIA:** estos criterios orientan la revisión. Cuando implican ejecución, el instructor debe observarla en un contexto definido, registrar resultado y lo que no se evaluó. No hay umbral automático de repeticiones, confianza o aciertos. La plataforma conserva una declaración personal y no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s7-cramponaje-hielo). Registra solo tareas realmente realizadas: fecha, lugar, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Mantén separados resultado observado, confianza y evaluación. No incluyas datos médicos ni datos privados de terceros.

## Relaciones con otros módulos

[Ruta invernal](../../invierno/), [formación glaciar](../../glaciar/), [encordamiento según contexto](../encordamiento-contexto/) y [anclajes y reuniones](../anclajes-reuniones/) aportan prerrequisitos. La aplicación alpina y el guiado requieren su propia formación y evaluación. [Volver a la secuencia de hielo](../../hielo/).
