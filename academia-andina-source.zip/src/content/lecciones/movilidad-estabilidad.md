---
{
  "title": "Movilidad y estabilidad: rango útil y control",
  "description": "Distinguir amplitud de movimiento, control y exigencia de la tarea.",
  "module": "M22",
  "code": "E10-10",
  "order": 1010,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U10-10",
  "skills": [
    "s10-movilidad-estabilidad"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Distinguir amplitud de movimiento, control y exigencia de la tarea.",
    "Aplicar el concepto a una decisión de preparación de montaña y reconocer sus límites."
  ],
  "prerequisites": [
    "s10-montanismo-carga"
  ],
  "sources": [
    "e10-mobility"
  ],
  "pending": [
    "Revisión por profesional del ejercicio e instructor de montaña pendiente. Nutrición y salud requieren revisión profesional específica; no se ha evaluado aptitud personal.",
    "Los casos y rúbricas son propuestas pedagógicas originales. La aplicación individual requiere evaluación, técnica y seguimiento.",
    "No se atribuyen requisitos de certificación, umbrales universales ni preparación técnica a los resultados físicos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Alcanzar un rango demuestra…",
        "options": [
          "Amplitud en esa tarea, no todo el control.",
          "Estabilidad universal.",
          "Ausencia de lesión."
        ],
        "answer": 0,
        "explanation": "El control requiere evaluación propia.",
        "rationales": [
          "El control requiere evaluación propia.",
          "Depende de carga y contexto.",
          "No es diagnóstico."
        ],
        "source": "e10-mobility",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Para practicar equilibrio…",
        "options": [
          "Se necesita un filo.",
          "Puede usarse un entorno protegido.",
          "Más altura siempre mejora la adaptación."
        ],
        "answer": 1,
        "explanation": "Permite observar con menor exposición.",
        "rationales": [
          "Añade consecuencias innecesarias.",
          "Permite observar con menor exposición.",
          "No se deduce esa ventaja."
        ],
        "source": "e10-mobility",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Dolor persistente exige…",
        "options": [
          "Forzar hasta desaparecer.",
          "Ignorarlo para terminar.",
          "Valoración y ajuste profesional."
        ],
        "answer": 2,
        "explanation": "No se resuelve con un quiz.",
        "rationales": [
          "Puede agravar el problema.",
          "La tarea debe revisarse.",
          "No se resuelve con un quiz."
        ],
        "source": "e10-mobility",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue rango y control.",
    "Selecciona entorno de práctica protegido.",
    "No diagnostica con una sola observación."
  ],
  "openAssessment": {
    "prompt": "Elige una tarea ficticia y separa rango requerido, control y consecuencia del error.",
    "rubric": [
      "Distingue rango y control.",
      "Selecciona entorno de práctica protegido.",
      "No diagnostica con una sola observación."
    ],
    "source": "e10-mobility",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN PROFESIONAL PENDIENTE.** Este contenido no prescribe un programa individual ni acredita competencia técnica. Los ejercicios numéricos y casos son ficticios. No introduzcas datos médicos, mediciones corporales privadas ni antecedentes de terceros.

## Conceptos clave y propósito

Movilidad, flexibilidad, estabilidad, equilibrio y control motor.

## Teoría y toma de decisiones

Movilidad y estabilidad describen aspectos distintos. Alcanzar un rango no demuestra controlar una carga en ese rango. El entrenamiento debe relacionar amplitud disponible, tarea y control, evitando evaluar todas las articulaciones con una sola prueba.

La preparación general puede incluir trabajo de fuerza en rangos adecuados y ejercicios de control; la específica observa apoyos y posiciones relevantes sin recrear exposición. No hay una secuencia de estiramientos que por sí sola garantice evitar lesiones. [Alcance de la evidencia sobre movilidad](#fuente-e10-mobility).

Ejercicio original: una persona puede alcanzar una posición sin carga, pero pierde control al bajar un escalón. El dato no diagnostica una estructura lesionada. Sugiere revisar demanda, variante y ejecución con un profesional antes de añadir dificultad.

El equilibrio no necesita entrenarse sobre bordes expuestos. Una tarea estable permite observar errores sin convertirlos en caídas graves. La elección de superficies inestables también depende del objetivo; más inestabilidad no equivale automáticamente a mejor preparación de montaña.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación del aprendizaje:** Define el movimiento y el propósito; elige una variante controlable con el profesional. Observa rango y ejecución por separado. No fuerces dolor ni uses rebotes o posiciones extremas como requisito para aprobar. Si hay limitación persistente, corresponde valoración específica.

La selección real de ejercicios, cargas, pruebas y progresión corresponde a una evaluación individual con profesionales. Las técnicas críticas de montaña requieren formación práctica y supervisión de instructor competente. El acondicionamiento físico no autoriza una maniobra.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Dos propuestas dicen «estabilidad»: una controla un escalón en suelo firme y otra usa un borde alto. ¿Qué diferencia de consecuencias debe orientar la práctica?

Distingue dato, interpretación y decisión. Explica qué incertidumbre permanece. Los casos no representan un protocolo del organismo citado ni un criterio oficial de habilitación para guía.

## Errores frecuentes y puntos críticos de seguridad

Confundir flexibilidad y estabilidad; usar dolor como meta; prometer prevención total; aumentar exposición para entrenar equilibrio.

## Material y equipo relacionado

Espacio despejado, apoyo y escalón estable. Material inestable no es obligatorio ni superior por definición.

[Consultar inventario](../../equipo/). Ajustar o poseer el equipo no demuestra dominarlo. Las prácticas técnicas se registran por separado del acondicionamiento.

## Autoevaluación y recuperación activa

- Explica la diferencia entre la capacidad que estudias y una tarea técnica de montaña.
- ¿Qué información falta en el caso y qué decisión modificaría?
- ¿Qué parte puede analizarse en escritorio y cuál necesita observación profesional?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Elige una tarea ficticia y separa rango requerido, control y consecuencia del error.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Observación de patrones por profesional del ejercicio o fisioterapeuta, con variantes ajustadas y sin exposición a caída.

## Evidencia requerida y criterios de competencia

- Distingue rango y control.
- Selecciona entorno de práctica protegido.
- No diagnostica con una sola observación.

**COMPETENCIA:** estos criterios describen aprendizaje que debe observar un profesional en contexto. No acreditan aptitud médica, entrenamiento personal, guiado ni maniobra técnica. Una lectura, prueba física o quiz no otorga certificación. Marca pendiente lo que no se haya evaluado.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s10-movilidad-estabilidad). Registra fecha, actividad, escenario, equipo, objetivo, errores, correcciones, supervisor y evidencia de aprendizaje. No guardes datos médicos ni contraseñas. No inventes sesiones, evaluaciones o repeticiones para completar la matriz.

## Relaciones con otros módulos

[Entrenamiento](../../entrenamiento/) · [Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Programa](../../programa/). Entrenamiento general, preparación específica, aclimatación y competencia técnica se relacionan, pero no son equivalentes.
