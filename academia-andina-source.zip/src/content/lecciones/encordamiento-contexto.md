---
{
  "title": "Encordamiento según actividad y grupo",
  "description": "Comparar la función del encordamiento en escalada, nieve, glaciar y terreno alpino.",
  "module": "M07",
  "code": "E43-14",
  "order": 313,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U43-05",
  "skills": [
    "s43-encordamiento-contexto"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Comparar la función del encordamiento en escalada, nieve, glaciar y terreno alpino.",
    "Identificar información necesaria antes de elegir una conexión al arnés.",
    "Explicar control cruzado y comunicación sin extrapolar un método a todos los terrenos."
  ],
  "prerequisites": [
    "s43-revision-nudos"
  ],
  "sources": [
    "petzl-partner",
    "petzl-nudos-435",
    "icar-tipos"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "encordamiento-decision"
  ],
  "preparation": [
    "Explicar los conceptos sin confundir un modelo con una maniobra.",
    "Reconocer al menos dos errores del caso y justificar una alternativa.",
    "Identificar la documentación y las competencias prácticas que faltan."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "petzl-partner",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una foto de cordada glaciar sirve para elegir encordamiento en roca…",
        "options": [
          "Sin cambios.",
          "Solo si hay tres personas.",
          "No; hace falta analizar tarea, terreno y competencias."
        ],
        "answer": 2,
        "explanation": "Debe justificarse el sistema completo.",
        "rationales": [
          "Los escenarios no son equivalentes.",
          "La cantidad no define protección.",
          "Debe justificarse el sistema completo."
        ],
        "source": "petzl-partner",
        "kind": "caso",
        "difficulty": "intermedia"
      },
      {
        "prompt": "La confirmación de una orden debe…",
        "options": [
          "Suponerse si nadie protesta.",
          "Ser comprendida y devuelta según el protocolo acordado.",
          "Depender solo del color de la cuerda."
        ],
        "answer": 1,
        "explanation": "Cierra el intercambio y permite detectar discrepancias.",
        "rationales": [
          "El silencio puede ser falta de comunicación.",
          "Cierra el intercambio y permite detectar discrepancias.",
          "El color no confirma comprensión."
        ],
        "source": "petzl-partner",
        "kind": "aplicación",
        "difficulty": "intermedia"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

Encordarse es integrarse a un sistema cuya función debe estar definida. La conexión individual, la organización de una cordada y la protección del terreno son problemas relacionados, pero diferentes. Una cuerda entre personas también puede transmitir una caída o dificultar el movimiento.

## Teoría y decisiones

Comienza por la finalidad: detener una caída, proteger una progresión, mantener una organización o preparar una transición. No se elige un método por el número de pasajeros solamente. La exposición, las consecuencias de una caída, el soporte, la longitud disponible, las competencias y el margen de retirada condicionan el diseño. Esta unidad no prescribe distancias ni orden universal de cordada.

La conexión al arnés exige identificar el modelo y los puntos que el fabricante destina al uso concreto. No se infiere equivalencia entre portamaterial, anillo y puntos de encordamiento. Un control cruzado útil comprueba tanto el arnés como la conexión y la organización del aseguramiento [Referencia: petzl-partner](#fuente-petzl-partner). El manual de cada arnés debe revisarse en el taller; la academia no asigna una configuración al Edelrid Skye ni a un arnés alpino por su nombre comercial.

Escalada, trekking técnico, nieve, glaciar y terreno alpino no comparten automáticamente el mismo problema. En escalada se estudia un sistema de aseguramiento asociado a la progresión; en trekking técnico debe justificarse por qué la cuerda mejora el control y qué peligros añade; en nieve y glaciar cambian soporte y escenarios de caída; en terreno alpino pueden alternarse tareas con transiciones. Estas distinciones son preguntas de diseño, no instrucciones de cuerda corta o rescate en grietas.

La comunicación debe cubrir quién decide iniciar, qué confirmación se espera, quién vigila al resto y qué significa detenerse. Una orden que no se escucha no es una confirmación. Para guiado, considera también al pasajero que no comprende el vocabulario técnico y al guía que necesita atender una incidencia sin dejar sin control a los demás.

## Caso práctico y aplicación al guiado

Un grupo propone usar la misma cuerda y separación de una foto de glaciar para un paso rocoso. Lista cinco diferencias que deben examinarse antes de decidir. Si no puedes justificar el método o garantizar supervisión competente, la alternativa formativa es no iniciar ese tramo, no copiar la fotografía.

## Errores frecuentes y señales de alerta

Confundir estar conectado con estar protegido; ignorar el riesgo colectivo; copiar distancias; asumir que el pasajero sabe usar el arnés; cambiar de tarea sin comunicarlo. La ausencia de caída en una salida previa no valida la configuración.

## Autoevaluación y respuestas explicadas

¿Se deduce el método por el número de personas? **No: falta actividad, terreno y sistema.** ¿Por qué una transición requiere revisión? **Cambian funciones, direcciones y controles que antes podían ser válidos.**

## Ejercicios y práctica presencial

En mesa, construir una matriz de cinco actividades con finalidad, información faltante y competencias necesarias. En presencial, un instructor demuestra conexiones sobre arnés y organiza una revisión cruzada en entorno controlado. No practicar movimiento encordado en terreno expuesto sin esa formación.

## Evidencia requerida

Matriz comparativa, guion de comunicación y revisión del arnés documentada. Evaluación contextual presencial separada para cada técnica enseñada.

## Relaciones con otras habilidades

Revisa los prerrequisitos y el contrato de habilidad de esta unidad en el programa. Contrasta la explicación con las fuentes indicadas: las cifras de un ejercicio no son límites de uso de un equipo. Toda transferencia a una situación con personas requiere formación y revisión presencial.
