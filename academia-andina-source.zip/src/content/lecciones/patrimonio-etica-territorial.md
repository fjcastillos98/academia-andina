---
{
  "title": "Patrimonio y cultura: interpretar con responsabilidad",
  "description": "Distinguir patrimonio natural, cultural y conocimientos comunitarios.",
  "module": "M16",
  "code": "E45-31",
  "order": 330,
  "minutes": 35,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U45-07",
  "skills": [
    "s45-patrimonio-etica-territorial"
  ],
  "critical": false,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir patrimonio natural, cultural y conocimientos comunitarios.",
    "Atribuir relatos y reconocer límites de representación.",
    "Preparar una interpretación respetuosa sin etimologías inventadas."
  ],
  "prerequisites": [
    "s45-historia-montanismo-documentos"
  ],
  "sources": [
    "patrimonio-futahuillimapu",
    "museo-ancud-huilliche",
    "conaf-parque-centenario"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente.",
    "PENDIENTE DE VERIFICACIÓN TERRITORIAL: accesos, límites administrativos, rutas y condiciones actuales."
  ],
  "diagrams": [
    "territorio-evidencia"
  ],
  "preparation": [
    "Distinguir hechos atribuidos, inferencias y datos pendientes.",
    "Explicar por qué la ficha no valida acceso, ruta ni condiciones.",
    "Preparar una observación sin extracción ni alteración del entorno."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "patrimonio-futahuillimapu",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una traducción de un topónimo aparece en varios blogs que se copian. ¿Cuál es su estado?",
        "options": [
          "Verificada por repetición.",
          "Pendiente hasta contrastar fuentes lingüísticas y territoriales pertinentes.",
          "Se convierte en hecho si gusta a los pasajeros."
        ],
        "answer": 1,
        "explanation": "La repetición de un mismo origen no equivale a corroboración independiente.",
        "source": "museo-ancud-huilliche",
        "difficulty": "intermedia",
        "rationales": [
          "No aumenta independencia.",
          "Declara el trabajo de verificación necesario.",
          "Preferencia no determina verdad."
        ],
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué permite una cita de un estudio sobre Futahuillimapu?",
        "options": [
          "Atribuir lo que el estudio documenta dentro de su alcance.",
          "Hablar en nombre de todas las comunidades.",
          "Publicar cualquier conocimiento ceremonial recibido."
        ],
        "answer": 0,
        "explanation": "La atribución documental no concede representación ni autorización de divulgación.",
        "source": "patrimonio-futahuillimapu",
        "difficulty": "intermedia",
        "rationales": [
          "Mantiene alcance y autoría.",
          "Excede la fuente.",
          "Requiere acuerdos específicos y respeto de restricciones."
        ],
        "kind": "aplicación"
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

Patrimonio natural comprende valores y procesos del medio; patrimonio cultural incluye prácticas, memorias, objetos y lugares significativos para personas y comunidades. No son categorías necesariamente separadas en la experiencia territorial. Toponimia estudia nombres de lugar: una traducción difundida no queda verificada por ser atractiva. Cosmovisión no es una colección de frases que un guía externo puede atribuir indistintamente a un pueblo.

## Teoría: quién habla sobre el territorio

El estudio del censo de 1907–1908 en Futahuillimapu sitúa documentación de población mapuche-huilliche entre río Bueno y seno de Reloncaví dentro de procesos de colonización y desposesión [Referencia: patrimonio-futahuillimapu](#fuente-patrimonio-futahuillimapu). El aprendizaje no consiste en adoptar una voz ajena, sino en reconocer que un mapa administrativo y un territorio vivido no son equivalentes.

El Museo Regional de Ancud presentó testimonios huilliche sobre espiritualidad, usos del territorio e historia comunitaria [Referencia: museo-ancud-huilliche](#fuente-museo-ancud-huilliche). Son voces situadas, no una autorización para resumir “lo que todos creen”. Antes de incorporar una historia a una salida, identifica autoría, contexto, permiso de uso y quién puede presentarla. Si esa información no existe, declara el límite y busca colaboración local.

Para Filo Austral, la interpretación puede organizarse alrededor de una pregunta observable: cómo se relacionan bosque, agua, ocupación y cuidado. Evita llenar cada silencio con una leyenda. Se puede reconocer que un topónimo tiene interpretaciones pendientes y dedicar el momento a explicar cómo se investigaría con fuentes lingüísticas y portadores de conocimiento.

La relación con comunidades no se reduce a pedir permiso de paso ni a conseguir una frase para el folleto. Una colaboración requiere acordar alcance, participación y reconocimiento. No se publican ubicaciones sensibles, prácticas ceremoniales o información privada por estar mencionadas en una conversación. La academia no registra identidades de entrevistados ni acredita consentimiento.

Un parque es además un espacio de conservación y uso con historia institucional. Su creación no borra ocupaciones anteriores; su categoría tampoco convierte cada actividad turística en aceptable. Revisa responsable actual, restricciones y contexto antes de ofrecer una experiencia. La conmemoración de Vicente Pérez Rosales de 2026 recuerda una transición institucional que hace especialmente importante fechar las fuentes [Referencia: conaf-parque-centenario](#fuente-conaf-parque-centenario).

## Caso práctico: una etimología conveniente

El equipo quiere explicar que el nombre de una montaña significa una frase llamativa, pero solo dispone de publicaciones que se copian entre sí. Clasifica la afirmación como pendiente de verificación. Propón retirarla del guion factual, consultar fuente lingüística pertinente y acordar con representantes locales si corresponde incluir otras interpretaciones. No atribuyas una historia a toda una comunidad para darle autoridad.

## Errores frecuentes y señales de alerta

Hablar de pueblos como si solo pertenecieran al pasado, usar “leyenda” para cualquier conocimiento local, presentar lugares como vacíos antes de una expedición, fotografiar personas o rituales sin acuerdo y confundir disponibilidad en internet con permiso de reutilización.

## Autoevaluación y respuestas explicadas

¿Citar una fuente permite representar a una comunidad? No: atribución documental y representación son cosas distintas. ¿Es menos profesional decir “no lo he verificado”? No: evita transmitir como hecho una interpretación sin respaldo.

## Ejercicios y práctica presencial

Redacta un guion de cinco minutos con etiquetas internas: observación, hecho documentado, relato atribuido e inferencia. Revísalo con una persona competente y, cuando trate conocimiento comunitario, con interlocutores pertinentes mediante acuerdos claros.

## Evidencia requerida

Guion con fuentes, límites y preguntas pendientes; registro de revisión sin datos privados. Se evalúa precisión, respeto y capacidad para corregir una afirmación.

## Relaciones con otras habilidades

Conecta historia, conservación, liderazgo y operación turística. La interpretación responsable se desarrolla mediante relación territorial; no se completa con un quiz.
