---
{
  "title": "Evaluación inicial y pruebas físicas: medir para decidir",
  "description": "Diseñar una comparación repetible sin convertir una prueba en habilitación.",
  "module": "M22",
  "code": "E10-01",
  "order": 1001,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U10-01",
  "skills": [
    "s10-evaluacion-entrenamiento"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Diseñar una comparación repetible sin convertir una prueba en habilitación.",
    "Aplicar el concepto a una decisión de preparación de montaña y reconocer sus límites."
  ],
  "prerequisites": [
    "s9-emergencias-altitud"
  ],
  "sources": [
    "e10-monitoring"
  ],
  "pending": [
    "Revisión por profesional del ejercicio e instructor de montaña pendiente. Nutrición y salud requieren revisión profesional específica; no se ha evaluado aptitud personal.",
    "Los casos y rúbricas son propuestas pedagógicas originales. La aplicación individual requiere evaluación, técnica y seguimiento.",
    "No se atribuyen requisitos de certificación, umbrales universales ni preparación técnica a los resultados físicos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Dos tiempos con distinto tratamiento de pausas…",
        "options": [
          "No son directamente comparables.",
          "Demuestran adaptación sin dudas.",
          "Certifican guiado."
        ],
        "answer": 0,
        "explanation": "El protocolo cambió.",
        "rationales": [
          "El protocolo cambió.",
          "Hay una explicación alternativa.",
          "Una marca no evalúa guiado."
        ],
        "source": "e10-monitoring",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Antes de una prueba máxima corresponde…",
        "options": [
          "Copiarla de un video.",
          "Revisar idoneidad y supervisión profesional.",
          "Ignorar antecedentes relevantes."
        ],
        "answer": 1,
        "explanation": "La exigencia requiere contexto y preparación.",
        "rationales": [
          "No aporta evaluación individual.",
          "La exigencia requiere contexto y preparación.",
          "La revisión clínica no se sustituye por el quiz."
        ],
        "source": "e10-monitoring",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una evaluación útil informa…",
        "options": [
          "Solo el mejor número.",
          "Una garantía de cumbre.",
          "Resultado, condiciones y límites."
        ],
        "answer": 2,
        "explanation": "Permite interpretar y repetir.",
        "rationales": [
          "Oculta información necesaria.",
          "No mide todas las demandas.",
          "Permite interpretar y repetir."
        ],
        "source": "e10-monitoring",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Explicita qué mide la prueba.",
    "Conserva protocolo y pausas.",
    "Separa rendimiento físico y competencia técnica."
  ],
  "openAssessment": {
    "prompt": "Diseña una ficha ficticia con pregunta, protocolo, resultado, incertidumbre y próxima decisión. No uses antecedentes médicos personales.",
    "rubric": [
      "Explicita qué mide la prueba.",
      "Conserva protocolo y pausas.",
      "Separa rendimiento físico y competencia técnica."
    ],
    "source": "e10-monitoring",
    "difficulty": "integración"
  },
  "diagrams": [
    "e10-general-especifico"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN PROFESIONAL PENDIENTE.** Este contenido no prescribe un programa individual ni acredita competencia técnica. Los ejercicios numéricos y casos son ficticios. No introduzcas datos médicos, mediciones corporales privadas ni antecedentes de terceros.

## Conceptos clave y propósito

Validez, fiabilidad, familiarización, error de medición, rendimiento y especificidad.

## Teoría y toma de decisiones

Una prueba sirve cuando responde una pregunta concreta. Tiempo en una subida, repeticiones con una carga conocida y estimación de VO2max no miden la misma capacidad. Antes de elegir un indicador, escribe qué decisión cambiarías con el resultado. La evaluación de salud previa y las pruebas máximas corresponden a profesionales; esta unidad propone análisis y mediciones submáximas supervisadas, no pruebas al límite por cuenta propia.

Comparar requiere conservar el protocolo: recorrido, duración, mochila, instrumento, pausas y condiciones. Una mejora puede reflejar familiarización o viento favorable y no solo adaptación. El seguimiento combina tarea realizada, respuesta percibida y contexto. Un dato aislado no describe toda la preparación. [Seguimiento deportivo](#fuente-e10-monitoring).

En el ejemplo original, dos tiempos de 45 y 42 minutos parecen una mejora. Si el segundo recorrido tiene menos desnivel o elimina una pausa, la conclusión cambia. El registro debe conservar esas diferencias antes de calcular porcentajes.

La práctica de montaña añade capacidades que una prueba física no observa: navegación, técnica, decisiones y gestión del grupo. Por eso no se fija una marca que habilite para guiar ni se atribuye un requisito ANGM sin documentación específica. Un buen informe describe el resultado y también aquello que no fue evaluado.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación del aprendizaje:** Define pregunta y protocolo, ensaya su comprensión, revisa con el profesional la idoneidad y condiciones de parada. Conserva unidades y datos del escenario. Si cambia el procedimiento, no compares como si fuera idéntico. Síntomas como dolor torácico, desmayo o dificultad respiratoria inusual requieren detener la actividad y atención; no se completa una prueba para obtener un número.

La selección real de ejercicios, cargas, pruebas y progresión corresponde a una evaluación individual con profesionales. Las técnicas críticas de montaña requieren formación práctica y supervisión de instructor competente. El acondicionamiento físico no autoriza una maniobra.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Dos registros ficticios dicen 600 m en 90 minutos y 600 m en 80 minutos, pero uno excluye descansos. ¿Es una comparación válida?

Distingue dato, interpretación y decisión. Explica qué incertidumbre permanece. Los casos no representan un protocolo del organismo citado ni un criterio oficial de habilitación para guía.

## Errores frecuentes y puntos críticos de seguridad

Comparar protocolos distintos; hacer un máximo sin preparación; confiar en un reloj como diagnóstico; convertir una marca en competencia técnica.

## Material y equipo relacionado

Cronómetro, recorrido conocido y ficha de protocolo. Un reloj aporta estimaciones; anota qué mide y cómo.

[Consultar inventario](../../equipo/). Ajustar o poseer el equipo no demuestra dominarlo. Las prácticas técnicas se registran por separado del acondicionamiento.

## Autoevaluación y recuperación activa

- Explica la diferencia entre la capacidad que estudias y una tarea técnica de montaña.
- ¿Qué información falta en el caso y qué decisión modificaría?
- ¿Qué parte puede analizarse en escritorio y cuál necesita observación profesional?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Diseña una ficha ficticia con pregunta, protocolo, resultado, incertidumbre y próxima decisión. No uses antecedentes médicos personales.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Revisión de un protocolo submáximo por profesional del ejercicio; familiarización en espacio controlado y observación de técnica, sin esfuerzo máximo obligatorio.

## Evidencia requerida y criterios de competencia

- Explicita qué mide la prueba.
- Conserva protocolo y pausas.
- Separa rendimiento físico y competencia técnica.

**COMPETENCIA:** estos criterios describen aprendizaje que debe observar un profesional en contexto. No acreditan aptitud médica, entrenamiento personal, guiado ni maniobra técnica. Una lectura, prueba física o quiz no otorga certificación. Marca pendiente lo que no se haya evaluado.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s10-evaluacion-entrenamiento). Registra fecha, actividad, escenario, equipo, objetivo, errores, correcciones, supervisor y evidencia de aprendizaje. No guardes datos médicos ni contraseñas. No inventes sesiones, evaluaciones o repeticiones para completar la matriz.

## Relaciones con otros módulos

[Entrenamiento](../../entrenamiento/) · [Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Programa](../../programa/). Entrenamiento general, preparación específica, aclimatación y competencia técnica se relacionan, pero no son equivalentes.
