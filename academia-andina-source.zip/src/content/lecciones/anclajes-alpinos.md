---
{
  "title": "Anclajes alpinos: soporte, dirección y función",
  "description": "Analizar una reunión como sistema dependiente del soporte y de sus tareas.",
  "module": "M06",
  "code": "E8-02",
  "order": 802,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U8-02",
  "skills": [
    "s8-anclajes-alpinos"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Analizar una reunión como sistema dependiente del soporte y de sus tareas.",
    "Reconocer fallos comunes que no desaparecen al añadir puntos."
  ],
  "prerequisites": [
    "s8-planificacion-alpina"
  ],
  "sources": [
    "e8-inspection",
    "e8-anchor"
  ],
  "pending": [
    "Revisión docente y práctica presencial por instructor alpino competente pendientes. No se ha observado ni aprobado una maniobra.",
    "Compatibilidad y manual del equipo personal pendientes de verificación; no se extrapolan ejemplos GRIGRI/REVERSO/RAD LINE a ATC Guide u otras cuerdas."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Dos piezas en el mismo bloque…",
        "options": [
          "Pueden compartir el fallo del soporte.",
          "Son siempre independientes.",
          "Tienen resistencia igual a la suma nominal."
        ],
        "answer": 0,
        "explanation": "El soporte común es una dependencia. Analizar una reunión como sistema dependiente del soporte y de sus tareas.",
        "rationales": [
          "El soporte común es una dependencia.",
          "La cantidad no demuestra independencia.",
          "El sistema no se calcula con esa suma."
        ],
        "source": "e8-inspection",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un textil parcialmente oculto exige…",
        "options": [
          "Aceptar que la parte visible representa todo.",
          "Reconocer el límite de inspección y revisar el conjunto.",
          "Tirar fuerte para certificarlo."
        ],
        "answer": 1,
        "explanation": "La inspección no debe ocultar lo desconocido. Analizar una reunión como sistema dependiente del soporte y de sus tareas.",
        "rationales": [
          "Lo oculto puede tener otra condición.",
          "La inspección no debe ocultar lo desconocido.",
          "Un tirón no es certificación."
        ],
        "source": "e8-inspection",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un cambio de líder puede requerir…",
        "options": [
          "Ninguna revisión si hubo dos puntos.",
          "Solo comprobar la hora.",
          "Revisar tareas, direcciones y organización del sistema."
        ],
        "answer": 2,
        "explanation": "La transición modifica lo que se pide a la reunión. Analizar una reunión como sistema dependiente del soporte y de sus tareas.",
        "rationales": [
          "El número no cubre el cambio de función.",
          "El horario no describe el sistema.",
          "La transición modifica lo que se pide a la reunión."
        ],
        "source": "e8-inspection",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Separa soporte, colocación y conexión al explicar un sistema.",
    "Identifica al menos un modo de fallo compartido pertinente al caso.",
    "Revisa las funciones y direcciones de una transición bajo supervisión."
  ],
  "openAssessment": {
    "prompt": "Dibuja tres capas: soporte, colocaciones y conexiones. Añade un fallo compartido y una tarea que cambie la dirección prevista. No asignes cargas numéricas a soportes desconocidos.",
    "rubric": [
      "Separa soporte, colocación y conexión al explicar un sistema.",
      "Identifica al menos un modo de fallo compartido pertinente al caso.",
      "Revisa las funciones y direcciones de una transición bajo supervisión."
    ],
    "source": "e8-inspection",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. Lecturas y cuestionarios no acreditan ejecución técnica ni guiado.**

## Conceptos clave y propósito

Soporte natural, colocación, dirección de carga, redundancia, extensión y revisión de instalación.

## Teoría y toma de decisiones

Una reunión organiza funciones: proteger a quienes llegan o permanecen, asegurar el siguiente movimiento y permitir una transición. Cada función introduce posibles direcciones y cambios de carga. Un dibujo estático de dos puntos no describe todo lo que ocurrirá cuando cambien las personas o las tareas.

La inspección de una instalación existente distingue elementos visibles, zonas ocultas y soporte. La documentación de Petzl trata deterioro de metales y textiles, y advierte de la necesidad de revisar lo que no se ve a primera vista. Encontrar material en una pared no demuestra que conserve su función ni que corresponda al sistema que el grupo necesita. [Fuente de contraste](#fuente-e8-inspection).

Los puntos pueden fallar por causas compartidas. Dos elementos en el mismo bloque no son independientes si el bloque se mueve; dos piezas conectadas de manera semejante pueden compartir un error de uso. Contar elementos es insuficiente para describir redundancia. Hay que preguntar qué falla, qué queda y qué cambio experimenta el resto del sistema.

La dirección importa también al cambiar de líder o pasar de asegurar a descender. No se suman resistencias nominales como si el conjunto fuera una colección de piezas independientes. El comportamiento depende del soporte, las conexiones y la tarea. La inspección visual tiene límites y un tirón informal no mide capacidad fiable del conjunto.

La formación práctica aborda selección, construcción, revisión y transiciones bajo observación competente. Esta lección prepara el vocabulario para justificar y cuestionar una propuesta. No proporciona una receta universal de reunión, ángulos o número de puntos. El instructor debe relacionar el método con terreno, recursos y capacidades reales.

Petzl compara montajes en vías equipadas con anclajes fijos sólidos. Ese supuesto se conserva aquí: sus ejemplos no demuestran la calidad de un bloque natural ni se trasladan automáticamente a nieve o hielo. Es un contraste de funciones, no una recomendación de montaje para todo terreno. [Ámbito del ejemplo](#fuente-e8-anchor).

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — análisis previo al taller.** Analizar una reunión como sistema dependiente del soporte y de sus tareas. Se utiliza al preparar una tarea o revisar un cambio de contexto. Las comprobaciones se organizan por función, soporte, equipo, capacidades y continuidad de protección. La teoría y la rúbrica especifican qué observar en esta unidad.

El instructor selecciona método, protección y condiciones de parada. Si falta una condición esencial o el grupo no comprende una función, no se inicia la maniobra. Las variantes se mantienen dentro del contexto de su fuente: una página sobre vía equipada, un producto o senderismo no constituye un procedimiento universal alpino.

## Caso práctico y aplicación al guiado

**Escenario de aula:** Un croquis ficticio muestra dos piezas en un bloque y un textil envejecido parcialmente oculto. El grupo se dispone a cambiar de líder. Describe qué preguntas corresponden al soporte, cuáles al material y cuáles a la transición.

Distingue hechos, suposiciones y preguntas antes de proponer una decisión. Los ejercicios, casos y rúbricas son propuestas pedagógicas originales de la academia pendientes de revisión docente. No se presentan como protocolos de los organismos citados.

## Errores frecuentes y puntos críticos de seguridad

Contar puntos como garantía; no observar el soporte común; asumir que la instalación anterior está validada; cambiar dirección sin revisar; sumar resistencias del catálogo.

Una práctica protegida tiene un alcance limitado; no valida todas las condiciones futuras. No se aprende una técnica crítica mediante una caída deliberada ni copiando una imagen en terreno expuesto.

## Material y equipo relacionado

Conectores, cintas, cuerda y protecciones del sistema exacto, documentación e inspección. Tornillos, estacas y protecciones de roca responden a soportes diferentes; no son sustitutos por disponibilidad.

[Consultar inventario](../../equipo/). Identifica modelo, documentación y datos pendientes. No inventes inspecciones ni atribuyas competencia a la compra de un dispositivo.

## Autoevaluación y recuperación activa

- Explica con un ejemplo: Analizar una reunión como sistema dependiente del soporte y de sus tareas.
- ¿Qué información falta en el caso y qué decisión depende de ella?
- ¿Qué parte puedes revisar documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Dibuja tres capas: soporte, colocaciones y conexiones. Añade un fallo compartido y una tarea que cambie la dirección prevista. No asignes cargas numéricas a soportes desconocidos.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** En entorno protegido, el instructor presenta sistemas didácticos y defectos que puedan observarse sin exposición. El alumno explica funciones y límites antes de construir o modificar un sistema real supervisado.

## Evidencia requerida y criterios de competencia

- Separa soporte, colocación y conexión al explicar un sistema.
- Identifica al menos un modo de fallo compartido pertinente al caso.
- Revisa las funciones y direcciones de una transición bajo supervisión.

**COMPETENCIA:** la ejecución debe evaluarse presencialmente en un contexto explícito por instructor competente. Las respuestas escritas no sustituyen esa observación. Se registra qué ocurrió, qué no se evaluó y qué debe corregirse. No hay un número de repeticiones que otorgue competencia automáticamente.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s8-anclajes-alpinos). Registra solo lo realizado: fecha, lugar, actividad, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Confianza, resultado y evaluación son datos diferentes. No guardar datos médicos, contraseñas ni datos privados de terceros.

## Relaciones con otros módulos

Integra [hielo](../../hielo/), [glaciar](../../glaciar/), [planificación invernal](../planificacion-invernal/) y [anclajes y reuniones](../anclajes-reuniones/). El [programa](../../programa/) muestra prerrequisitos; son académicos, no habilitaciones. [Volver al bloque alpino](../../alpina/).
