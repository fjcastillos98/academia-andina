---
{
  "title": "Riesgo alpino: integrar información y revisar decisiones",
  "description": "Integrar terreno, personas, meteorología, protección y retorno.",
  "module": "M06",
  "code": "E8-08",
  "order": 808,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U8-08",
  "skills": [
    "s8-riesgo-alpino"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Integrar terreno, personas, meteorología, protección y retorno.",
    "Evaluar el proceso de decisión sin confundir resultado y competencia."
  ],
  "prerequisites": [
    "s8-autorescate-alpino"
  ],
  "sources": [
    "e8-decision",
    "e8-plan",
    "e8-scramble"
  ],
  "pending": [
    "Revisión docente y práctica presencial por instructor alpino competente pendientes. No se ha observado ni aprobado una maniobra.",
    "Compatibilidad y manual del equipo personal pendientes de verificación; no se extrapolan ejemplos GRIGRI/REVERSO/RAD LINE a ATC Guide u otras cuerdas."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un supuesto del plan deja de cumplirse. Conviene…",
        "options": [
          "Revisar las decisiones que dependían de él.",
          "Anotarlo y mantener todo siempre.",
          "Esperar a un accidente."
        ],
        "answer": 0,
        "explanation": "El dato tiene consecuencias sobre la propuesta. Integrar terreno, personas, meteorología, protección y retorno.",
        "rationales": [
          "El dato tiene consecuencias sobre la propuesta.",
          "Registrar sin revisar puede mantener una conclusión inválida.",
          "La reevaluación es previa al daño."
        ],
        "source": "e8-decision",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La cumbre está cerca, pero se pierden alternativas. Eso…",
        "options": [
          "Compensa toda dificultad.",
          "Exige revisar compromiso y opciones disponibles.",
          "No importa si hay GPS."
        ],
        "answer": 1,
        "explanation": "La decisión integra retorno y capacidad. Integrar terreno, personas, meteorología, protección y retorno.",
        "rationales": [
          "La cercanía no restaura opciones.",
          "La decisión integra retorno y capacidad.",
          "El GPS no crea vías de retirada."
        ],
        "source": "e8-decision",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "El resultado sin accidente…",
        "options": [
          "Valida toda técnica empleada.",
          "Certifica guiado.",
          "Debe analizarse separado de la calidad del proceso."
        ],
        "answer": 2,
        "explanation": "Permite aprender sin sesgo de resultado. Integrar terreno, personas, meteorología, protección y retorno.",
        "rationales": [
          "Un resultado favorable no prueba cada decisión.",
          "No hubo evaluación profesional acreditante.",
          "Permite aprender sin sesgo de resultado."
        ],
        "source": "e8-decision",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Relaciona un cambio observado con el supuesto y decisión afectados.",
    "Considera retorno y alternativas sin calificarlos por su nombre.",
    "Evalúa proceso y resultado por separado, sin declarar certificación."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso con cinco columnas: hecho, supuesto afectado, consecuencia, opción y condición de revisión. Añade un debriefing de retirada que identifique una mejora concreta para la próxima preparación.",
    "rubric": [
      "Relaciona un cambio observado con el supuesto y decisión afectados.",
      "Considera retorno y alternativas sin calificarlos por su nombre.",
      "Evalúa proceso y resultado por separado, sin declarar certificación."
    ],
    "source": "e8-decision",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. Lecturas y cuestionarios no acreditan ejecución técnica ni guiado.**

## Conceptos clave y propósito

Incertidumbre, señales, alternativas, compromiso, sesgo de resultado y aprendizaje.

## Teoría y toma de decisiones

El criterio alpino integra información incompleta. No se trata de eliminar toda incertidumbre con una lista, sino de reconocer cuál puede cambiar las consecuencias o la viabilidad del objetivo. La dificultad técnica, el tiempo, el estado del grupo y el retorno se influyen mutuamente.

El grupo debe contrastar lo previsto con lo observado a lo largo de la salida. Si un supuesto deja de cumplirse, no basta anotarlo: se revisa qué decisión dependía de él. Una previsión meteorológica favorable no invalida una observación local adversa; un track registrado no garantiza soporte actual ni retorno disponible. [Fuente de contraste](#fuente-e8-decision).

El compromiso puede aumentar cuando se pierden alternativas, luz o capacidad para retroceder. Acercarse a la cumbre no compensa automáticamente esos cambios. En el análisis de aula conviene identificar qué opciones se conservan ahora y cuáles se perderían después del siguiente tramo, sin inventar probabilidades numéricas.

La presión por terminar puede proceder del viaje, una reserva o expectativas de otras personas. Esos motivos explican una preferencia, pero no aportan evidencia sobre protección o terreno. Una decisión revisable deja claro qué dato la sostiene y qué cambio la invalidaría. El grupo necesita poder expresar una duda antes de que ocurra un incidente.

El debriefing compara decisión e información disponible en ese momento. Un buen resultado puede coexistir con un proceso débil; una retirada puede reflejar reconocimiento oportuno de límites. La competencia requiere observaciones repetidas y contextualizadas por un instructor, no una conclusión de «salió bien». Esta academia registra aprendizaje y declaraciones, sin emitir acreditaciones de guía.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — análisis previo al taller.** Integrar terreno, personas, meteorología, protección y retorno. Se utiliza al preparar una tarea o revisar un cambio de contexto. Las comprobaciones se organizan por función, soporte, equipo, capacidades y continuidad de protección. La teoría y la rúbrica especifican qué observar en esta unidad.

El instructor selecciona método, protección y condiciones de parada. Si falta una condición esencial o el grupo no comprende una función, no se inicia la maniobra. Las variantes se mantienen dentro del contexto de su fuente: una página sobre vía equipada, un producto o senderismo no constituye un procedimiento universal alpino.

## Caso práctico y aplicación al guiado

**Escenario de aula:** Caso ficticio integrador: la aproximación tarda más, la cuerda roza en un tramo, una persona no entiende una señal y el descenso alternativo no tiene fuente. La cumbre parece cerca. Selecciona qué decisiones deben revisarse, qué información falta y cómo comunicarías un cambio de objetivo.

Distingue hechos, suposiciones y preguntas antes de proponer una decisión. Los ejercicios, casos y rúbricas son propuestas pedagógicas originales de la academia pendientes de revisión docente. No se presentan como protocolos de los organismos citados.

## Errores frecuentes y puntos críticos de seguridad

Tratar el checklist como garantía; ignorar un dato adverso por el pronóstico; decidir por cercanía a cumbre; justificar todo porque no hubo accidente; registrar un quiz como competencia.

Una práctica protegida tiene un alcance limitado; no valida todas las condiciones futuras. No se aprende una técnica crítica mediante una caída deliberada ni copiando una imagen en terreno expuesto.

## Material y equipo relacionado

Plan documentado por tramos, observaciones con hora, navegación, comunicaciones y equipo ajustado al método. El equipo es un recurso del sistema, no un argumento para asumir exposición adicional.

[Consultar inventario](../../equipo/). Identifica modelo, documentación y datos pendientes. No inventes inspecciones ni atribuyas competencia a la compra de un dispositivo.

## Autoevaluación y recuperación activa

- Explica con un ejemplo: Integrar terreno, personas, meteorología, protección y retorno.
- ¿Qué información falta en el caso y qué decisión depende de ella?
- ¿Qué parte puedes revisar documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Resuelve el caso con cinco columnas: hecho, supuesto afectado, consecuencia, opción y condición de revisión. Añade un debriefing de retirada que identifique una mejora concreta para la próxima preparación.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Simulación con instructor e información gradual. Se revisan razonamiento, comunicación y límites. No se induce exposición real para demostrar criterio ni se simula una emergencia mediante daño o pérdida deliberada de protección.

## Evidencia requerida y criterios de competencia

- Relaciona un cambio observado con el supuesto y decisión afectados.
- Considera retorno y alternativas sin calificarlos por su nombre.
- Evalúa proceso y resultado por separado, sin declarar certificación.

**COMPETENCIA:** la ejecución debe evaluarse presencialmente en un contexto explícito por instructor competente. Las respuestas escritas no sustituyen esa observación. Se registra qué ocurrió, qué no se evaluó y qué debe corregirse. No hay un número de repeticiones que otorgue competencia automáticamente.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s8-riesgo-alpino). Registra solo lo realizado: fecha, lugar, actividad, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Confianza, resultado y evaluación son datos diferentes. No guardar datos médicos, contraseñas ni datos privados de terceros.

## Relaciones con otros módulos

Integra [hielo](../../hielo/), [glaciar](../../glaciar/), [planificación invernal](../planificacion-invernal/) y [anclajes y reuniones](../anclajes-reuniones/). El [programa](../../programa/) muestra prerrequisitos; son académicos, no habilitaciones. [Volver al bloque alpino](../../alpina/).
