---
{
  "title": "Planificación invernal: convertir información en límites",
  "description": "Construir un plan trazable por tramos y ventanas temporales.",
  "module": "M02",
  "code": "E5-22",
  "order": 521,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-19",
  "skills": [
    "s5-planificacion-invernal"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Construir un plan trazable por tramos y ventanas temporales.",
    "Distinguir datos confirmados, hipótesis y condiciones que obligan a cambiar el plan.",
    "Integrar terreno, grupo, horarios y contingencias en una decisión revisable."
  ],
  "prerequisites": [
    "s5-esqui-introduccion"
  ],
  "sources": [
    "e5-decision",
    "e5-daily",
    "e5-senapred-invierno"
  ],
  "pending": [
    "Revisión del plan y rúbrica por instructor; fuentes territoriales y condiciones de cualquier salida real pendientes de verificación."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "El horario usa una velocidad medida en verano. ¿Qué falta?",
        "options": [
          "Solo redondear la hora.",
          "Revisar supuestos de nieve, grupo y retorno.",
          "Añadir equipo y mantener la hora."
        ],
        "answer": 1,
        "explanation": "El cálculo depende de supuestos que cambiaron.",
        "rationales": [
          "Redondear no cambia los supuestos.",
          "Relaciona cálculo y condiciones.",
          "Poseer equipo no fija la velocidad."
        ],
        "source": "e5-decision",
        "difficulty": "integración",
        "kind": "decisiones"
      },
      {
        "prompt": "No hay boletín verificado para el lugar. ¿Qué registrar?",
        "options": [
          "Peligro bajo.",
          "El nivel de un boletín extranjero.",
          "Ausencia de información y límites de la decisión."
        ],
        "answer": 2,
        "explanation": "Falta de información no significa ausencia de peligro.",
        "rationales": [
          "No hay evidencia para ese nivel.",
          "La cobertura no se puede trasladar.",
          "Hace explícita la incertidumbre."
        ],
        "source": "e5-decision",
        "difficulty": "integración",
        "kind": "decisiones"
      },
      {
        "prompt": "Un plan B es más corto. ¿Basta para adoptarlo?",
        "options": [
          "No: requiere analizar su terreno y accesos.",
          "Sí, siempre reduce riesgo.",
          "Sí, si el grupo lo prefiere."
        ],
        "answer": 0,
        "explanation": "Distancia no representa todos los peligros.",
        "rationales": [
          "Revisa la exposición de la alternativa.",
          "Omite terreno y condiciones.",
          "Preferencia no verifica viabilidad."
        ],
        "source": "e5-decision",
        "difficulty": "integración",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Separa fuentes de supuestos y vacíos.",
    "Explica qué cambio obliga a revisar el horario o cancelar.",
    "Justifica alternativa y comunicación sin introducir exposición no evaluada."
  ],
  "openAssessment": {
    "prompt": "Entrega un plan ficticio por tramos y defiende una cancelación: identifica tres datos que faltan y qué decisión bloquea cada ausencia.",
    "rubric": [
      "Separa fuentes de supuestos y vacíos.",
      "Explica qué cambio obliga a revisar el horario o cancelar.",
      "Justifica alternativa y comunicación sin introducir exposición no evaluada."
    ],
    "source": "e5-decision",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-retirada"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Una planificación trazable permite localizar la fuente de una hora, un mapa o una restricción. Una frase sin fecha ni alcance es una hipótesis que debe identificarse.

## Teoría y toma de decisiones

Un plan invernal es una hipótesis de actividad con límites explícitos. Debe poder responder quién decide, con qué información, en qué punto se reevalúa y qué se hará si la hipótesis falla. La ficha de Etapa 4 aporta el marco antes/durante/después; aquí se añade el manto nivoso y la posibilidad de recibir una avalancha desde terreno situado por encima. El objetivo de aprendizaje es argumentar una salida, incluida la decisión de no iniciarla.

Avalanche.org propone revisar peligros, identificar incertidumbres, establecer terreno excluido y disponer de alternativas antes de que aumente la presión del grupo [fuente](#fuente-e5-decision). Esta plantilla traduce ese principio en un ejercicio propio: cada afirmación del plan debe acompañarse de fuente, fecha o una etiqueta de hipótesis. «Tenemos mapa» no demuestra que el mapa permita distinguir una quebrada bajo nieve. «Conocemos la ruta» no responde cómo cambia su exposición en invierno.

Divide el itinerario propuesto en tramos y registra distancia horizontal, desnivel positivo, cambios de orientación, obstáculos, puntos de escape y zonas de decisión. No traslades automáticamente velocidad estival a nieve. Una estimación de tiempo necesita supuestos explícitos sobre grupo, carga, profundidad, huella, pausas y visibilidad; el laboratorio permite comprobar aritmética, no estimar una velocidad universal. Contrasta las horas de luz con fecha y lugar, y reserva márgenes sin presentarlos como garantía. El punto de retorno tiene que permitir una retirada practicable; no sirve una hora que se alcanza después de entrar en un tramo comprometido.

Distingue pronóstico meteorológico, boletín de avalanchas y observación local. Anota emisor, emisión, validez, cobertura espacial y altura; un boletín de otra región solo sirve como ejercicio de interpretación. Si no se dispone de información nivológica verificada, escribe esa ausencia, describe qué decisión impide tomar y reduce el alcance del proyecto. La recomendación general de SENAPRED incluye evitar actividades de montaña con pronóstico desfavorable de lluvia, nieve o viento [fuente](#fuente-e5-senapred-invierno). No se puede convertir una aplicación con un icono favorable en evaluación de estabilidad.

La parte humana del plan incluye experiencia demostrada, capacidades observadas, expectativas y recursos. No se necesitan nombres ni datos clínicos para este ejercicio. Describe cómo se comprobará comprensión del briefing, quién controlará el tiempo y cómo se comunicarán cambios. El contacto externo se registra por función y referencia a un sistema protegido, no por teléfono privado en el navegador. Deja acordado qué información recibe y qué hacer si falla el aviso.

Un plan B necesita verificación propia: un valle alternativo puede tener más exposición que el objetivo inicial. Finaliza con tres decisiones posibles: continuar dentro de las condiciones declaradas, reducir el objetivo o cancelar/retirar. Para cada una exige un indicador observable, un responsable y un momento. Después de una simulación o práctica, compara lo previsto con lo observado y corrige el razonamiento, aunque el resultado haya sido favorable.

## Qué observo, qué significa y qué no puedo concluir

Completar campos no valida permisos, estabilidad, capacidad del grupo ni viabilidad de rescate. La ficha no genera una autorización automática.

## Caso práctico y aplicación al guiado

Caso ficticio: se calculan 3 h para 6 km, pero la velocidad proviene de una caminata estival. Señala qué supuestos faltan antes de conservar ese horario.

## Errores frecuentes y señales de alerta

Confundir desnivel neto con acumulado; olvidar el regreso; ubicar un retorno después del punto sin escape; copiar un boletín de otra región; tratar el plan B como seguro por ser más corto.

## Autoevaluación y respuesta razonada

Entrega un plan ficticio por tramos y defiende una cancelación: identifica tres datos que faltan y qué decisión bloquea cada ausencia.

## Ejercicios y práctica supervisada

Completa la plantilla imprimible con un mapa didáctico y fuentes fechadas. Otro alumno debe intentar encontrar cada supuesto. Una revisión de escritorio no sustituye reconocimiento con instructor.

## Evidencia requerida

- Separa fuentes de supuestos y vacíos.
- Explica qué cambio obliga a revisar el horario o cancelar.
- Justifica alternativa y comunicación sin introducir exposición no evaluada.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-planificacion-invernal).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).

[Plantilla de planificación](../../invierno/planificacion/) · [Casos de esta etapa](../../invierno/#casos) · [Laboratorio de cálculos](../../invierno/ejercicios/).
