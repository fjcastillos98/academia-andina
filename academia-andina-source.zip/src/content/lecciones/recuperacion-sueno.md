---
{
  "title": "Recuperación y sueño: parte del programa",
  "description": "Planificar recuperación sin reducirla a una puntuación de reloj.",
  "module": "M22",
  "code": "E10-12",
  "order": 1012,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U10-12",
  "skills": [
    "s10-recuperacion-sueno"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Planificar recuperación sin reducirla a una puntuación de reloj.",
    "Aplicar el concepto a una decisión de preparación de montaña y reconocer sus límites."
  ],
  "prerequisites": [
    "s10-prevencion-lesiones"
  ],
  "sources": [
    "e10-sleep"
  ],
  "pending": [
    "Revisión por profesional del ejercicio e instructor de montaña pendiente. Nutrición y salud requieren revisión profesional específica; no se ha evaluado aptitud personal.",
    "Los casos y rúbricas son propuestas pedagógicas originales. La aplicación individual requiere evaluación, técnica y seguimiento.",
    "No se atribuyen requisitos de certificación, umbrales universales ni preparación técnica a los resultados físicos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "El sueño pertenece…",
        "options": [
          "A la planificación del entrenamiento.",
          "Solo a los días sin ejercicio.",
          "A una puntuación universal."
        ],
        "answer": 0,
        "explanation": "Debe tener espacio real.",
        "rationales": [
          "Debe tener espacio real.",
          "La recuperación es continua.",
          "Hay diferencias individuales."
        ],
        "source": "e10-sleep",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un reloj de sueño…",
        "options": [
          "Diagnostica cualquier trastorno.",
          "Aporta una estimación con límites.",
          "Reemplaza consulta profesional."
        ],
        "answer": 1,
        "explanation": "Debe interpretarse con contexto.",
        "rationales": [
          "No basta para diagnóstico.",
          "Debe interpretarse con contexto.",
          "No cumple esa función."
        ],
        "source": "e10-sleep",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una agenda sin descanso suficiente requiere…",
        "options": [
          "Añadir más sesiones.",
          "Ignorar traslados.",
          "Revisar distribución y exigencia."
        ],
        "answer": 2,
        "explanation": "Permite hacer viable el programa.",
        "rationales": [
          "No resuelve la limitación.",
          "También consumen tiempo.",
          "Permite hacer viable el programa."
        ],
        "source": "e10-sleep",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Incluye oportunidad de sueño en el plan.",
    "Reconoce límites del reloj.",
    "Ajusta tareas sin diagnosticar."
  ],
  "openAssessment": {
    "prompt": "Reorganiza una agenda ficticia para crear oportunidad de descanso; explica qué sesión cambiarías y por qué.",
    "rubric": [
      "Incluye oportunidad de sueño en el plan.",
      "Reconoce límites del reloj.",
      "Ajusta tareas sin diagnosticar."
    ],
    "source": "e10-sleep",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN PROFESIONAL PENDIENTE.** Este contenido no prescribe un programa individual ni acredita competencia técnica. Los ejercicios numéricos y casos son ficticios. No introduzcas datos médicos, mediciones corporales privadas ni antecedentes de terceros.

## Conceptos clave y propósito

Sueño, oportunidad de descanso, fatiga, recuperación, viaje y continuidad.

## Teoría y toma de decisiones

La adaptación requiere alternar estímulo y recuperación. Dormir no es un suplemento que se añade al final de la planificación; su oportunidad debe existir en la agenda. El consenso sobre sueño del deportista subraya necesidades individuales y factores del entrenamiento y viaje. [Consenso de sueño](#fuente-e10-sleep).

Horas disponibles y calidad percibida no son lo mismo. Tampoco una estimación comercial de fases de sueño constituye un diagnóstico. En el ejercicio se analiza el horario sin solicitar datos personales de salud.

Ejemplo original: una sesión termina tarde, el traslado es largo y la siguiente empieza temprano. Aunque cada sesión aislada parezca razonable, la combinación reduce la oportunidad de recuperación. La decisión puede ser cambiar horario, volumen o distribución, no añadir automáticamente otra estrategia de recuperación.

Una mala noche no se convierte aquí en prohibición automática ni se ignora por cumplir el calendario. Se revisan tarea, contexto y respuesta. Problemas persistentes de sueño o somnolencia importante merecen evaluación profesional; la academia no diagnostica trastornos ni recomienda medicamentos.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación del aprendizaje:** En el plan ficticio, reserva ventanas de descanso antes de distribuir sesiones. Revisa viajes y jornadas laborales como parte del contexto. Ajusta la exigencia con el profesional cuando la recuperación no es suficiente, sin perseguir una puntuación perfecta de dispositivo.

La selección real de ejercicios, cargas, pruebas y progresión corresponde a una evaluación individual con profesionales. Las técnicas críticas de montaña requieren formación práctica y supervisión de instructor competente. El acondicionamiento físico no autoriza una maniobra.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** El programa deja seis horas entre llegada a casa y salida de la mañana, pero exige dos sesiones duras. ¿Qué limitación logística aparece?

Distingue dato, interpretación y decisión. Explica qué incertidumbre permanece. Los casos no representan un protocolo del organismo citado ni un criterio oficial de habilitación para guía.

## Errores frecuentes y puntos críticos de seguridad

Confundir tiempo en cama y sueño real; tratar el reloj como diagnóstico; compensar cada cansancio con estimulantes; separar recuperación de planificación.

## Material y equipo relacionado

Agenda y entorno de descanso. El seguimiento tecnológico es opcional y tiene límites.

[Consultar inventario](../../equipo/). Ajustar o poseer el equipo no demuestra dominarlo. Las prácticas técnicas se registran por separado del acondicionamiento.

## Autoevaluación y recuperación activa

- Explica la diferencia entre la capacidad que estudias y una tarea técnica de montaña.
- ¿Qué información falta en el caso y qué decisión modificaría?
- ¿Qué parte puede analizarse en escritorio y cuál necesita observación profesional?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Reorganiza una agenda ficticia para crear oportunidad de descanso; explica qué sesión cambiarías y por qué.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Taller con profesional del ejercicio sobre distribución de carga y descanso; problemas reales se derivan al ámbito sanitario.

## Evidencia requerida y criterios de competencia

- Incluye oportunidad de sueño en el plan.
- Reconoce límites del reloj.
- Ajusta tareas sin diagnosticar.

**COMPETENCIA:** estos criterios describen aprendizaje que debe observar un profesional en contexto. No acreditan aptitud médica, entrenamiento personal, guiado ni maniobra técnica. Una lectura, prueba física o quiz no otorga certificación. Marca pendiente lo que no se haya evaluado.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s10-recuperacion-sueno). Registra fecha, actividad, escenario, equipo, objetivo, errores, correcciones, supervisor y evidencia de aprendizaje. No guardes datos médicos ni contraseñas. No inventes sesiones, evaluaciones o repeticiones para completar la matriz.

## Relaciones con otros módulos

[Entrenamiento](../../entrenamiento/) · [Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Programa](../../programa/). Entrenamiento general, preparación específica, aclimatación y competencia técnica se relacionan, pero no son equivalentes.
