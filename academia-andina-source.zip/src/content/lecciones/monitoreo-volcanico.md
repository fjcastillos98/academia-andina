---
{
  "title": "Monitoreo y reportes: integrar señales sin improvisar pronósticos",
  "description": "Distingue mediciones, interpretación técnica y decisión administrativa.",
  "module": "M11",
  "code": "E12-08",
  "order": 1208,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U12-08",
  "skills": [
    "s12-monitoreo-volcanico"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Distingue mediciones, interpretación técnica y decisión administrativa.",
    "Registra fecha y periodo de un documento sin inventar vigencia."
  ],
  "prerequisites": [
    "s12-relieve-volcanico-glaciar"
  ],
  "sources": [
    "e12-sensors",
    "e12-monitoring"
  ],
  "pending": [
    "Revisión por especialista en geología y vulcanología e instructor de montaña pendiente. No valida una ruta, acceso ni evacuación.",
    "Alertas actuales, restricciones, cotas discrepantes y condiciones de terreno requieren verificación independiente; no hay datos operativos en tiempo real.",
    "Casos, rúbricas y ejercicios originales. Las descripciones científicas no acreditan competencia técnica ni un protocolo universal de seguridad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "El monitoreo se apoya en…",
        "options": [
          "Una fotografía aislada como diagnóstico suficiente.",
          "Líneas de observación complementarias.",
          "El olor como medidor universal."
        ],
        "answer": 1,
        "explanation": "Integra señales con interpretación especializada.",
        "rationales": [
          "Carece de información instrumental y contexto.",
          "Integra señales con interpretación especializada.",
          "No es un método seguro ni fiable para ello."
        ],
        "source": "e12-sensors",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un balance de 2021…",
        "options": [
          "Es la alerta vigente de hoy.",
          "Confirma todos los accesos abiertos.",
          "Sirve como antecedente histórico con su fecha."
        ],
        "answer": 2,
        "explanation": "Conserva su alcance documental.",
        "rationales": [
          "No informa automáticamente el presente.",
          "Su propósito es diferente.",
          "Conserva su alcance documental."
        ],
        "source": "e12-sensors",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un reporte técnico…",
        "options": [
          "No sustituye comprobar restricciones de acceso.",
          "Equivale a permiso de ingreso.",
          "Elimina otros riesgos del terreno."
        ],
        "answer": 0,
        "explanation": "Son ámbitos distintos.",
        "rationales": [
          "Son ámbitos distintos.",
          "No cumple esa función por sí solo.",
          "No evalúa todas las condiciones."
        ],
        "source": "e12-sensors",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue mediciones, interpretación técnica y decisión administrativa.",
    "Registra fecha y periodo de un documento sin inventar vigencia.",
    "Explica por qué un reporte no autoriza por sí solo el acceso."
  ],
  "openAssessment": {
    "prompt": "Completa una ficha de lectura con emisor, fecha, periodo, ámbito, conclusión respaldada y dos decisiones que ese documento no autoriza.",
    "rubric": [
      "Distingue mediciones, interpretación técnica y decisión administrativa.",
      "Registra fecha y periodo de un documento sin inventar vigencia.",
      "Explica por qué un reporte no autoriza por sí solo el acceso."
    ],
    "source": "e12-sensors",
    "difficulty": "integración"
  },
  "diagrams": [
    "e12-documentos"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ESPECIALISTA PENDIENTE.** Estudio documental: no autoriza aproximación a fenómenos volcánicos ni acredita competencia de guía. No se publican alertas actuales. No guardes datos médicos ni contraseñas.

## Conceptos clave y propósito

Sismicidad, deformación, gases, línea de base, serie temporal, incertidumbre, reporte y fecha de emisión. Alerta técnica, medidas de protección civil y restricciones de acceso responden a funciones diferentes.

## Teoría y toma de decisiones

USGS presenta mediciones sísmicas, de deformación y gases como líneas complementarias de monitoreo. Una variación debe interpretarse en contexto, con calidad de datos, antecedentes y otras observaciones. La frecuencia de medición y cobertura instrumental pueden variar entre sistemas; no se supone vigilancia idéntica de cada volcán.

El balance institucional de SERNAGEOMIN de 2021 documenta reportes RAV, REAV y minutas excepcionales. Se usa aquí como referencia histórica de productos y funciones, no como nivel de alerta vigente. Antes de usar información en una salida hay que consultar la publicación oficial aplicable y sus actualizaciones. La plataforma no entrega alertas en tiempo real.

Un reporte puede describir un periodo anterior a su fecha de publicación. Conserva ambos datos y no llames actual a una captura sin contexto. La ausencia de noticia no equivale a una medida de ausencia de actividad. Tampoco una etiqueta técnica resuelve por sí sola el permiso del administrador, el estado del sendero o las condiciones meteorológicas. La competencia de estudio es saber formular preguntas y reconocer cuándo falta información decisiva.

Fuentes de esta unidad: [Referencia 1](#fuente-e12-sensors) · [Referencia 2](#fuente-e12-monitoring). Las aplicaciones de estudio y casos siguientes son elaboración pedagógica original, no protocolos de esas organizaciones.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — lectura y análisis documental:** Identifica emisor, volcán, fecha de publicación, periodo analizado y tipo de documento. Distingue medición de interpretación y decisión administrativa. Variante: reporte regular frente a especial; consultar su alcance concreto, sin inferir plazos universales de validez.

El ejercicio se realiza en escritorio o lugar autorizado. No expongas al grupo para comprobar actividad, gases, temperatura o estabilidad. Las maniobras críticas de montaña requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un mensaje comparte una captura de color de alerta sin encabezado ni fecha. Una persona dice que prueba que el parque está abierto. Redacta una respuesta que separe los ámbitos.

## Errores frecuentes y puntos críticos de seguridad

Interpretar olor o color de una emisión como análisis de gases; leer un sismo como erupción inevitable; usar documentos históricos como avisos vigentes; equiparar alerta y acceso.

## Material y equipo relacionado

Acceso a canales oficiales y una copia fechada para estudio. InReach o VHF apoyan comunicación según disponibilidad y preparación, pero no son sensores volcánicos.

[Consultar inventario](../../equipo/). Poseer un dispositivo o equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Justifica con un ejemplo y un límite: Distingue mediciones, interpretación técnica y decisión administrativa.
- Justifica con un ejemplo y un límite: Registra fecha y periodo de un documento sin inventar vigencia.
- Justifica con un ejemplo y un límite: Explica por qué un reporte no autoriza por sí solo el acceso.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Completa una ficha de lectura con emisor, fecha, periodo, ámbito, conclusión respaldada y dos decisiones que ese documento no autoriza.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Taller de lectura con especialista e instructor usando documentos históricos etiquetados; sin observaciones cercanas para validar emisiones.

## Evidencia requerida y criterios de competencia

- Distingue mediciones, interpretación técnica y decisión administrativa.
- Registra fecha y periodo de un documento sin inventar vigencia.
- Explica por qué un reporte no autoriza por sí solo el acceso.

**COMPETENCIA:** estos criterios requieren revisión humana contextual. Leer, resolver un quiz o presentar un documento no certifica guiado ni ejecución de maniobras. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s12-monitoreo-volcanico). Registra fecha, escenario, fuente, errores, correcciones, supervisor y evidencia de aprendizaje. Separa ejercicio ficticio de actividad real. No inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Geología y vulcanología](../../geologia/) · [Fichas territoriales](../../territorio/) · [Ecología](../../ecologia/) · [Glaciar](../../glaciar/) · [Planificación](../../planificacion/) · [Programa](../../programa/). El conocimiento del origen del relieve complementa la planificación; no reemplaza información actual ni evaluación de terreno.
