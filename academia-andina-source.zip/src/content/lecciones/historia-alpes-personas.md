---
{
  "title": "Alpinismo: hitos, ciencia y personas visibles",
  "description": "Atribuye los hitos a la fuente que realmente consultó.",
  "module": "M17",
  "code": "E13-02",
  "order": 1302,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U13-02",
  "skills": [
    "s13-historia-alpes-personas"
  ],
  "critical": false,
  "reviewDate": "2026-10-27",
  "objectives": [
    "Atribuye los hitos a la fuente que realmente consultó.",
    "Evita convertir historia europea en historia humana universal."
  ],
  "prerequisites": [
    "s13-historia-evidencia"
  ],
  "sources": [
    "e13-chamonix",
    "e13-mujeres"
  ],
  "pending": [
    "Revisión por historiador o especialista de patrimonio e instructor de montaña pendiente.",
    "Primeras ascensiones de Los Lagos, historia completa de escuelas técnicas y testimonios comunitarios requieren investigación y revisión adicionales.",
    "Casos y rúbricas son propuestas pedagógicas originales; no certifican guiado ni competencia práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "La reseña de Chamonix es…",
        "options": [
          "El diario original de Paccard.",
          "Una prueba de toda actividad previa mundial.",
          "Una narración institucional posterior de hitos locales."
        ],
        "answer": 2,
        "explanation": "Identifica el tipo y alcance de la fuente.",
        "rationales": [
          "No es un documento contemporáneo al ascenso.",
          "Su alcance es local y selectivo.",
          "Identifica el tipo y alcance de la fuente."
        ],
        "source": "e13-chamonix",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "El dato del AAC en 1902 permite…",
        "options": [
          "Negar que hubiera barreras en otros clubes.",
          "Cuestionar que nunca participaron mujeres.",
          "Conocer toda la historia femenina mundial."
        ],
        "answer": 1,
        "explanation": "Un contraejemplo documentado refuta esa generalización.",
        "rationales": [
          "La inclusión en un club no describe todos los demás.",
          "Un contraejemplo documentado refuta esa generalización.",
          "La exposición no agota todas las experiencias."
        ],
        "source": "e13-mujeres",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Si una fuente omite un acompañante…",
        "options": [
          "Se investiga; no se concluye automáticamente que no existió.",
          "Se inventa un nombre plausible.",
          "Se demuestra que la expedición fue solitaria."
        ],
        "answer": 0,
        "explanation": "Distingue silencio documental de ausencia histórica.",
        "rationales": [
          "Distingue silencio documental de ausencia histórica.",
          "Fabricar nombres destruye la trazabilidad.",
          "La omisión no demuestra soledad."
        ],
        "source": "e13-chamonix",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Atribuye los hitos a la fuente que realmente consultó.",
    "Evita convertir historia europea en historia humana universal.",
    "Detecta ausencias de representación sin inventar participantes."
  ],
  "openAssessment": {
    "prompt": "Escribe una explicación de 150 palabras con dos hechos atribuidos y dos preguntas sobre actores o perspectivas que faltan.",
    "rubric": [
      "Atribuye los hitos a la fuente que realmente consultó.",
      "Evita convertir historia europea en historia humana universal.",
      "Detecta ausencias de representación sin inventar participantes."
    ],
    "source": "e13-chamonix",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ACADÉMICA PENDIENTE.** Historia documental e interpretación: no es formación para ejecutar maniobras. No guardes datos médicos, contraseñas, datos privados de terceros ni conocimientos de acceso restringido.

## Conceptos clave y propósito

Hito documentado, ciencia, trabajo local, relato institucional, participación y selección del archivo. Una historia del alpinismo europeo no representa toda la relación humana con las montañas.

## Teoría y toma de decisiones

La reseña patrimonial de Chamonix sitúa a Jacques Balmat y al doctor Paccard en la cumbre del Mont Blanc el 8 de agosto de 1786, y describe las mediciones de Saussure allí en 1787. Es un ejemplo de conexión entre ascensión y observación científica, narrado por una institución actual; no es un parte contemporáneo de la expedición. Atribuir correctamente este hito no requiere llamarlo inicio de toda actividad humana en montaña.

El archivo del American Alpine Club dedica una exposición a mujeres montañistas entre 1880 y 1950. Señala que cuatro mujeres integraban sus 45 miembros iniciales en 1902 y contrasta posibilidades de afiliación entre clubes. Ese dato obliga a revisar un relato compuesto exclusivamente por hombres, sin convertir a todas las instituciones ni épocas en equivalentes.

En una exposición para visitantes, distribuye la atención entre la meta deportiva, el propósito de la salida, las personas nombradas y las que la fuente no identifica. «No figura en este texto» es distinto de «no participó». Una cronología selectiva sirve como puerta de entrada; sus vacíos deben generar preguntas de archivo, no personajes o contribuciones inventadas.

Fuentes de esta unidad: [Referencia 1](#fuente-e13-chamonix) · [Referencia 2](#fuente-e13-mujeres). Los ejercicios y criterios siguientes son diseño educativo original, no protocolos de las organizaciones citadas.

## Procedimiento: lectura, comprobaciones y variantes

**PROCEDIMIENTO — análisis documental:** Ubica los dos episodios del Mont Blanc y el dato de membresía del AAC en líneas separadas. Etiqueta fuente retrospectiva, objeto del evento y actores mencionados. Variante: analizar un retrato o pie de fotografía del archivo sin atribuirle una cumbre que no identifica.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un guion afirma que el montañismo fue exclusivamente masculino hasta mediados del siglo XX. Usa el dato institucional del AAC para corregir la generalización y conserva los límites de una sola institución.

## Errores frecuentes y puntos críticos de seguridad

Convertir un hito europeo en origen universal; borrar participantes; deducir ausencia por silencio; usar una gesta histórica para justificar riesgos presentes.

Las maniobras críticas requieren formación práctica y supervisión de instructor competente. Estudiar cómo se actuaba antiguamente no habilita a reproducirlo. Este taller no requiere exposición en terreno.

## Material y equipo relacionado

Cronología, fichas de archivo y proyector opcional. Una foto de equipo antiguo no indica cómo utilizar el equipo actual.

[Inventario educativo](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con una evidencia y un límite: Atribuye los hitos a la fuente que realmente consultó.
- Explica con una evidencia y un límite: Evita convertir historia europea en historia humana universal.
- Explica con una evidencia y un límite: Detecta ausencias de representación sin inventar participantes.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Escribe una explicación de 150 palabras con dos hechos atribuidos y dos preguntas sobre actores o perspectivas que faltan.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Revisión de un guion por docente de historia; comparar atribuciones y generalizaciones, sin representar maniobras antiguas.

## Evidencia requerida y criterios de competencia

- Atribuye los hitos a la fuente que realmente consultó.
- Evita convertir historia europea en historia humana universal.
- Detecta ausencias de representación sin inventar participantes.

**COMPETENCIA:** se requiere revisión humana contextual del trabajo. Una lectura, quiz o guion no certifica guiado, interpretación profesional ni maniobras técnicas. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s13-historia-alpes-personas). Registra fecha, lugar de estudio, documentos, habilidad, repeticiones, errores, correcciones, supervisor y evidencia textual no sensible. Diferencia taller ficticio y actividad real; no inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Historia y patrimonio](../../historia/) · [Territorio](../../territorio/) · [Geología](../../geologia/) · [Ecología](../../ecologia/) · [Programa](../../programa/). La interpretación histórica complementa la formación técnica; no sustituye condiciones ni permisos actuales.
