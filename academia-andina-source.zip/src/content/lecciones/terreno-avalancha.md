---
{
  "title": "Leer terreno: pendiente, conexión y exposición",
  "description": "Separar geometría, estado del manto y exposición del grupo.",
  "module": "M09",
  "code": "E5-05",
  "order": 504,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-05",
  "skills": [
    "s5-terreno-avalancha"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Separar geometría, estado del manto y exposición del grupo.",
    "Identificar posibles trampas y peligro desde arriba en diagramas.",
    "Comparar alternativas sin declarar una línea automáticamente segura."
  ],
  "prerequisites": [
    "s5-avalancha-tipos"
  ],
  "sources": [
    "e5-ates",
    "e5-exposure",
    "e5-terrain-traps"
  ],
  "pending": [
    "Revisión pedagógica y de instructor. Condiciones, cobertura de boletines y aplicación territorial real: PENDIENTE DE VERIFICACIÓN."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "El grupo está en el depósito potencial. ¿Está fuera del problema?",
        "options": [
          "No necesariamente: puede recibir nieve desde arriba.",
          "Sí, por estar abajo.",
          "Sí, si no hay grietas visibles."
        ],
        "answer": 0,
        "explanation": "La trayectoria conecta zonas.",
        "rationales": [
          "Considera conexión.",
          "Confunde salida con toda exposición.",
          "Las grietas no son condición necesaria."
        ],
        "source": "e5-exposure",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "Una depresión puede aumentar…",
        "options": [
          "La resistencia de la placa.",
          "La acumulación sobre una persona.",
          "La calidad del pronóstico."
        ],
        "answer": 1,
        "explanation": "La forma puede concentrar depósito.",
        "rationales": [
          "No describe unión de capas.",
          "Relaciona terreno y consecuencia.",
          "No modifica información meteorológica."
        ],
        "source": "e5-terrain-traps",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "¿Qué permite asignar ATES a una ruta?",
        "options": [
          "Solo su altitud.",
          "Una impresión desde una foto.",
          "Una evaluación apropiada con el método y evidencia."
        ],
        "answer": 2,
        "explanation": "La clasificación exige análisis especializado.",
        "rationales": [
          "Insuficiente.",
          "No muestra todo el recorrido.",
          "Respeta el método."
        ],
        "source": "e5-ates",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Distingue terreno, manto y exposición.",
    "Identifica conexiones y consecuencias.",
    "Formula una alternativa condicionada o justifica no entrar."
  ],
  "openAssessment": {
    "prompt": "Anota el diagrama con salida, trayectorias y trampas. Compara dos opciones y explica qué dato impide llamarlas seguras.",
    "rubric": [
      "Distingue terreno, manto y exposición.",
      "Identifica conexiones y consecuencias.",
      "Formula una alternativa condicionada o justifica no entrar."
    ],
    "source": "e5-ates",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-trampas",
    "e5-pendiente"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Reconoce formas y conexiones; las palabras lomo, canal o bosque describen rasgos, no una valoración final.

## Teoría y toma de decisiones

El terreno organiza dónde puede iniciarse, desplazarse y acumularse nieve. La pendiente es una variable relevante, pero una cifra no resume el problema. Hay que considerar el tamaño de la ladera, cambios de inclinación, forma, orientación, obstáculos y conexión con terreno superior. Un mapa o modelo digital permite preguntas útiles; su resolución y la nieve que oculta detalles limitan lo que puede concluirse. El marco ATES trata la exposición del terreno como un análisis especializado, no una categoría que se asigne por el nombre de una montaña [estudio](#fuente-e5-ates).

Una convexidad cambia la geometría de la superficie; una concavidad puede relacionarse con acumulación o convergencia. Canales, quebradas y depresiones merecen atención por sus posibles consecuencias. Un lomo puede separar cuencas o estar conectado a zonas cargadas; llamarlo «lomo» no resuelve su exposición. Vegetación y ausencia de árboles son información que debe interpretarse con contexto, no sellos automáticos de seguridad. Cornisas y zonas superiores pueden afectar a quienes transitan debajo sin pisar directamente una placa.

Distingue tres preguntas. La primera es qué permite la geometría: posibles salidas, trayectorias, acumulaciones y trampas. La segunda es qué sugiere la información del manto: problemas, distribución y evolución. La tercera es dónde y durante cuánto tiempo se sitúa el grupo. Esta última es exposición [fuente](#fuente-e5-exposure). Si mezclas las tres, puedes concluir erróneamente que un tramo poco inclinado es seguro aunque reciba una trayectoria superior.

La orientación no debe reducirse a «norte malo» o «sur bueno». Su relevancia depende de radiación, temperatura, viento y estado previo. El transporte de nieve puede cargar sectores relacionados con la dirección del viento y con la topografía; una descripción regional no muestra todos los depósitos locales. Los cambios de pendiente y acumulación se contrastan desde posiciones apropiadas, sin entrar a una zona peligrosa para resolver una duda de aula.

En el ejercicio visual, marca A en una ladera potencial de salida, B en una trayectoria y C en una depresión de depósito. Añade una posición del grupo y pregunta qué trayectorias podrían alcanzarla. Luego compara dos alternativas: una es más corta pero cruza un canal; otra requiere más tiempo y pasa por un terreno cuya conexión superior aún no se conoce. No elijas solo por distancia ni por apariencia. Explica qué dato falta para comparar exposición y qué harías si no puedes obtenerlo.

Una respuesta competente en teoría puede concluir que ninguna alternativa está suficientemente caracterizada. En ese caso, la decisión se orienta a reducir el objetivo, buscar información o no entrar. El ejercicio no pide dibujar una línea «segura» con certeza falsa. Las trampas de terreno modifican consecuencias [fuente](#fuente-e5-terrain-traps); por eso el análisis debe incluir qué sucede si la hipótesis sobre el manto falla. El trabajo real de reconocimiento requiere instructor y condiciones apropiadas.

## Qué observo, qué significa y qué no puedo concluir

No se asigna categoría ATES, ruta segura ni umbral de pendiente operativo a ningún lugar de Los Lagos.

## Caso práctico y aplicación al guiado

Una alternativa evita la pendiente principal, pero pasa por su depósito. ¿Qué exposición persiste?

## Errores frecuentes y señales de alerta

Mirar solo bajo los pies; confundir grados y porcentaje; ignorar terreno superior; elegir una alternativa por ser más corta.

## Autoevaluación y respuesta razonada

Anota el diagrama con salida, trayectorias y trampas. Compara dos opciones y explica qué dato impide llamarlas seguras.

## Ejercicios y práctica supervisada

Anotar diagramas y mapas didácticos. Revisión presencial del razonamiento antes de reconocimiento real.

## Evidencia requerida

- Distingue terreno, manto y exposición.
- Identifica conexiones y consecuencias.
- Formula una alternativa condicionada o justifica no entrar.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-terreno-avalancha).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
