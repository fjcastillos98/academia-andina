---
{
  "title": "Autorrescate: prioridades y límites de actuación",
  "description": "Distinguir autorrescate, rescate organizado, evacuación y primeros auxilios.",
  "module": "M23",
  "code": "E44-22",
  "order": 321,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U44-04",
  "skills": [
    "s44-autorrescate-prioridades"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir autorrescate, rescate organizado, evacuación y primeros auxilios.",
    "Priorizar evaluación de escena, autoprotección y comunicación.",
    "Justificar cuándo los recursos del grupo no permiten una intervención técnica."
  ],
  "prerequisites": [
    "s44-izado-conceptual"
  ],
  "sources": [
    "petzl-rescate-principios",
    "nps-emergencia"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "rescate-decision"
  ],
  "preparation": [
    "Explicar los conceptos sin confundir un modelo con una maniobra.",
    "Reconocer al menos dos errores del caso y justificar una alternativa.",
    "Identificar la documentación y las competencias prácticas que faltan."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "petzl-rescate-principios",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Autorrescate y rescate organizado…",
        "options": [
          "Implican siempre los mismos recursos.",
          "Se distinguen por organización, recursos y capacidades.",
          "Se eligen según orgullo personal."
        ],
        "answer": 1,
        "explanation": "El análisis debe reconocer capacidades reales.",
        "rationales": [
          "El alcance puede ser muy distinto.",
          "El análisis debe reconocer capacidades reales.",
          "La decisión debe basarse en la situación."
        ],
        "source": "petzl-rescate-principios",
        "kind": "conocimiento",
        "difficulty": "intermedia"
      },
      {
        "prompt": "Un guía sin formación en transferencia de carga…",
        "options": [
          "Puede aprenderla durante el incidente leyendo un esquema.",
          "Debe priorizar ayuda y acciones dentro de su capacidad.",
          "Debe intentar cualquier maniobra antes de comunicar."
        ],
        "answer": 1,
        "explanation": "Reconocer límites evita añadir afectados.",
        "rationales": [
          "El esquema no acredita ejecución.",
          "Reconocer límites evita añadir afectados.",
          "Retrasar apoyo no resuelve falta de competencia."
        ],
        "source": "petzl-rescate-principios",
        "kind": "decisiones",
        "difficulty": "intermedia"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

En esta ruta, autorrescate alude a la respuesta del grupo con sus recursos; rescate organizado incorpora equipos con organización y capacidades específicas; evacuación es el traslado hacia una atención o destino apropiado; primeros auxilios es atención inicial dentro de la formación disponible. No son cuatro nombres de una misma maniobra.

## Teoría y decisiones

La primera pregunta es qué situación existe y qué puede empeorarla. Evaluar escena y autoprotección significa reconocer amenazas para afectado, grupo y respondientes. «Estabilizar» se usa aquí para describir el objetivo de reducir deterioro y mantener control, no un protocolo médico ni una técnica de inmovilización.

La comunicación temprana y útil puede ser una intervención decisiva del grupo. Separa hechos observados de diagnósticos supuestos; identifica localización y referencia, acceso conocido, cantidad de personas, recursos y restricciones. El plan de emergencia preparado reduce improvisación, pero debe actualizarse ante hechos nuevos.

Acceder a la persona, liberar una situación, transferir carga, descender, izar y recuperar son objetivos diferentes. Cada uno puede requerir competencias y materiales que no están disponibles. El marco de rescate de Petzl distingue fases y exige entrenamiento; su contexto profesional no constituye un protocolo para un guía aislado [Referencia: petzl-rescate-principios](#fuente-petzl-rescate-principios).

Una persona suspendida o una escena de deterioro requiere atención urgente, pero la urgencia no convierte una técnica desconocida en una opción competente. Pedir rescate organizado no significa dejar de ayudar: permite comunicar, organizar al resto y actuar dentro de capacidades mientras se sigue el plan y las indicaciones apropiadas. Tampoco se promete disponibilidad, tiempo de llegada o acceso de helicóptero.

La decisión debe contemplar qué ocurriría si el respondiente queda también incapacitado. Un intento que deja al grupo sin comunicación, sin control o sin salida puede aumentar el número de afectados. El objetivo de esta unidad es preparar decisiones y reconocer límites antes del incidente, no aprender una liberación bajo presión.

## Caso práctico y aplicación al guiado

Un guía aislado tiene un pasajero que no puede continuar y un grupo inquieto. No se conoce todavía la causa ni la viabilidad del descenso. Define qué información recopilar, cómo proteger al resto y qué apoyo solicitar. No asignes tratamiento ni una maniobra de cuerda por defecto.

## Errores frecuentes y señales de alerta

Confundir urgencia con permiso para improvisar; retrasar solicitud de ayuda por orgullo; asumir acceso externo; llamar evacuación a cualquier descenso; copiar rescate industrial a montaña; perder control del grupo al concentrarse en una sola tarea.

## Autoevaluación y respuestas explicadas

¿Pedir apoyo elimina la función del guía? **No: mantiene tareas compatibles con su formación y la situación.** ¿Toda evacuación necesita cuerda? **No; el medio depende de evaluación y recursos.**

## Ejercicios y práctica presencial

Juego de roles de escritorio: responsable, observador, comunicador y apoyo externo simulado. Redactar mensaje, preguntas y límites; no emitir llamadas reales de emergencia. Taller presencial de respuesta con profesionales competentes y formación de primeros auxilios independiente.

## Evidencia requerida

Línea temporal de decisiones, mensaje factual, recursos faltantes y criterios para no iniciar una maniobra. No se evalúan diagnósticos médicos con este ejercicio.

## Relaciones con otras habilidades

Revisa los prerrequisitos y el contrato de habilidad de esta unidad en el programa. Contrasta la explicación con las fuentes indicadas: las cifras de un ejercicio no son límites de uso de un equipo. Toda transferencia a una situación con personas requiere formación y revisión presencial.
