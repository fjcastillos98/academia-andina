---
{
  "title": "HACE: alteración neurológica y respuesta urgente",
  "description": "Reconocer señales de alarma neurológica en un contexto de altitud.",
  "module": "M03",
  "code": "E9-04",
  "order": 904,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U9-04",
  "skills": [
    "s9-hace-altitud"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Reconocer señales de alarma neurológica en un contexto de altitud.",
    "Explicar por qué la sospecha exige respuesta urgente y acompañamiento."
  ],
  "prerequisites": [
    "s9-mam-altitud"
  ],
  "sources": [
    "e9-cdc",
    "e9-wms"
  ],
  "pending": [
    "Revisión médica por profesional de medicina de montaña y revisión docente por instructor pendientes. No se ha evaluado atención clínica ni rescate.",
    "Casos, ejercicios y criterios son propuestas pedagógicas originales; no autorizan decisiones clínicas individuales.",
    "Condiciones de rutas, comunicaciones y recursos de atención locales requieren verificación antes de cada salida."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿Qué cambio exige especial alarma?",
        "options": [
          "Confusión nueva y pérdida de coordinación.",
          "Que una fotografía salga borrosa.",
          "No querer posar en cumbre."
        ],
        "answer": 0,
        "explanation": "Son signos neurológicos que requieren respuesta urgente.",
        "rationales": [
          "Son signos neurológicos que requieren respuesta urgente.",
          "No describe el estado clínico.",
          "No es por sí solo una señal neurológica."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "En el caso, dejar a la persona sola…",
        "options": [
          "Reduce siempre el riesgo.",
          "No es una respuesta adecuada.",
          "Permite al grupo completar el programa."
        ],
        "answer": 1,
        "explanation": "Necesita acompañamiento y asistencia.",
        "rationales": [
          "Puede impedir ayuda y vigilancia.",
          "Necesita acompañamiento y asistencia.",
          "La cumbre no prevalece sobre la emergencia."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una sospecha de HACE en terreno remoto exige…",
        "options": [
          "Esperar confirmación del quiz.",
          "Subir para encontrar señal a cualquier coste.",
          "Ayuda y descenso/evacuación urgente según seguridad del terreno."
        ],
        "answer": 2,
        "explanation": "La respuesta no debe esperar certeza académica.",
        "rationales": [
          "La aplicación no diagnostica.",
          "Podría agravar exposición y retrasar atención.",
          "La respuesta no debe esperar certeza académica."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Identifica alteración mental y coordinación como alarmas.",
    "Activa respuesta urgente sin exigir certeza diagnóstica.",
    "Mantiene acompañamiento y contempla protección del grupo."
  ],
  "openAssessment": {
    "prompt": "Asigna cuatro funciones al grupo ficticio y escribe un mensaje que describa cambios observados y ayuda requerida, sin inventar signos.",
    "rubric": [
      "Identifica alteración mental y coordinación como alarmas.",
      "Activa respuesta urgente sin exigir certeza diagnóstica.",
      "Mantiene acompañamiento y contempla protección del grupo."
    ],
    "source": "e9-cdc",
    "difficulty": "integración"
  },
  "diagrams": [
    "e9-observar"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN MÉDICA Y DE INSTRUCTOR PENDIENTES.** No es una herramienta de diagnóstico ni prescripción. Los casos son ficticios; no introduzcas datos médicos personales. Una emergencia real requiere asistencia urgente, no completar esta lección.

## Conceptos clave y propósito

HACE, edema cerebral de altitud, ataxia, alteración mental, sospecha y evacuación.

## Teoría y toma de decisiones

HACE significa edema cerebral de altitud. La pérdida de coordinación o ataxia y la alteración del estado mental son señales de alarma; puede haber confusión o somnolencia. No es simplemente «más cansancio». En terreno remoto, su sospecha exige descenso urgente y asistencia; oxígeno y otros tratamientos corresponden a personal formado y al plan médico. [CDC, HACE](#fuente-e9-cdc).

La palabra sospecha es importante. Un estudiante no necesita demostrar el mecanismo para reconocer que la persona no puede continuar como si nada. Al mismo tiempo, debe evitar afirmar que toda confusión en montaña es HACE: existen causas alternativas que también pueden ser graves.

En el caso de aula, la coordinación del grupo se evalúa por las tareas que quedan cubiertas: quién acompaña, quién comunica, quién revisa la ruta y qué apoyo hace falta. No se considera aceptable enviar sola a una persona con alteración neurológica. La capacidad de caminar una parte no garantiza que pueda bajar sin ayuda.

El aprendizaje de reconocimiento se hace mediante tarjetas y narraciones. No se pide caminar sobre un filo ni provocar agotamiento para probar coordinación. Las técnicas de movilización y transporte se aprenden en prácticas protegidas, separadas de esta lectura.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación y análisis de aula.** Para el escenario ficticio, suspende el objetivo, activa ayuda y organiza descenso/evacuación con acompañamiento y protección frente al terreno. Si la evacuación inmediata no es viable, comunica esa limitación y solicita apoyo médico urgente; no conviertas la espera en observación pasiva. Oxígeno o cámara hiperbárica requieren recursos, entrenamiento y supervisión; no sustituyen la evacuación definitiva.

Las indicaciones clínicas dependen del paciente y los recursos. Las maniobras de movilización, oxigenoterapia y rescate requieren formación práctica y supervisión competente. No extrapolar un caso de escritorio a una actuación real ni elegir fármacos a partir de un quiz.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** A 4300 m ficticios, un integrante se muestra confuso y tropieza de una forma nueva. Otro propone dejarlo dormir solo y continuar a cumbre. Explica los fallos de esa propuesta sin diagnosticar con certeza.

Identifica hechos, incertidumbres y decisiones. Explica qué información podría modificar tu propuesta. La rúbrica es docente, no un protocolo avalado por las instituciones citadas.

## Errores frecuentes y puntos críticos de seguridad

Interpretar confusión como falta de voluntad; dejar sola a la persona; esperar una cifra del oxímetro; convertir una prueba de marcha en exposición a caída.

## Material y equipo relacionado

Comunicación, abrigo y medios de evacuación planificados. Oxígeno y cámara hiperbárica se estudian como recursos de equipos capacitados, no como compras que otorgan competencia.

[Inventario educativo](../../equipo/). Tener el recurso no demuestra saber utilizarlo. El diario no es una ficha clínica.

## Autoevaluación y recuperación activa

- ¿Puedes explicar el concepto central sin confundirlo con una autorización de salida?
- ¿Qué dato falta en el escenario y qué decisión depende de él?
- ¿Qué tarea exige formación sanitaria o técnica y no se evalúa aquí?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Asigna cuatro funciones al grupo ficticio y escribe un mensaje que describa cambios observados y ayuda requerida, sin inventar signos.

**PRÁCTICA SUPERVISADA — propuesta:** Simulación protegida de coordinación de evacuación con instructor de primeros auxilios y rescate. Sin hipoxia inducida, sin fármacos y sin persona desatendida.

## Evidencia requerida y criterios de competencia

- Identifica alteración mental y coordinación como alarmas.
- Activa respuesta urgente sin exigir certeza diagnóstica.
- Mantiene acompañamiento y contempla protección del grupo.

**COMPETENCIA:** requiere observación contextual por instructor competente y revisión sanitaria cuando corresponda. Estos criterios evalúan preparación, comunicación y límites de actuación; no habilitan como profesional sanitario ni guía. La plataforma no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de la habilidad](../../practicas/?habilidad=s9-hace-altitud). Registra fecha, actividad, escenario ficticio, equipo, errores, correcciones, supervisor y evidencia del aprendizaje. No incluyas diagnósticos, recetas, mediciones personales ni datos de pacientes. Marca pendiente toda evaluación no realizada.

## Relaciones con otros módulos

[Volver a Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Escalada alpina](../../alpina/) · [Programa](../../programa/). La secuencia académica conecta planificación, comunicación y riesgo; no acredita aptitud clínica ni práctica.
