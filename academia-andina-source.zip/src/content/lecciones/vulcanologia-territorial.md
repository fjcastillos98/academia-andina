---
{
  "title": "Vulcanología: procesos, señales y decisiones territoriales",
  "description": "Distinguir materiales, estructuras y procesos volcánicos.",
  "module": "M11",
  "code": "E45-26",
  "order": 325,
  "minutes": 35,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U45-02",
  "skills": [
    "s45-vulcanologia-territorial"
  ],
  "critical": false,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir materiales, estructuras y procesos volcánicos.",
    "Separar mapa de peligro, observación y alerta actual.",
    "Identificar qué decisiones exigen información oficial vigente."
  ],
  "prerequisites": [
    "s45-territorio-nombres"
  ],
  "sources": [
    "usgs-volcanes-glosario",
    "nps-anatomia-volcan",
    "sernageomin-alertas-portal"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente.",
    "PENDIENTE DE VERIFICACIÓN TERRITORIAL: accesos, límites administrativos, rutas y condiciones actuales."
  ],
  "diagrams": [
    "volcan-estructura"
  ],
  "preparation": [
    "Distinguir hechos atribuidos, inferencias y datos pendientes.",
    "Explicar por qué la ficha no valida acceso, ruta ni condiciones.",
    "Preparar una observación sin extracción ni alteración del entorno."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "usgs-volcanes-glosario",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una alerta histórica aparece en una captura sin fecha. ¿Puedes usarla como nivel vigente?",
        "options": [
          "Sí, si el color es verde.",
          "No; hay que recuperar el reporte actual y comprobar su alcance.",
          "Sí, si coincide con la opinión del grupo."
        ],
        "answer": 1,
        "explanation": "Una captura sin validez confirmada no permite afirmar el estado actual.",
        "source": "sernageomin-alertas-portal",
        "difficulty": "intermedia",
        "rationales": [
          "El color no resuelve vigencia.",
          "La información decisiva requiere fuente y fecha.",
          "Consenso no actualiza un reporte."
        ],
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué distingue a un lahar de una corriente piroclástica?",
        "options": [
          "Son sinónimos.",
          "El primero implica agua y material; la segunda mezcla caliente de partículas y gases.",
          "Ambos son únicamente lava líquida."
        ],
        "answer": 1,
        "explanation": "Los mecanismos y materiales difieren; nombrarlos correctamente ayuda a interpretar fuentes.",
        "source": "usgs-volcanes-glosario",
        "difficulty": "intermedia",
        "rationales": [
          "Confunde procesos distintos.",
          "Describe la distinción conceptual.",
          "Excluye componentes esenciales."
        ],
        "kind": "aplicación"
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

Magma es material fundido bajo superficie; lava es magma emitido. Un conducto o chimenea comunica partes del sistema con una salida. Reservorio magmático no significa necesariamente una cavidad única llena de líquido. Cono es una forma construida por acumulación; caldera, una depresión de colapso; domo, acumulación de lava viscosa. Estratovolcán describe un edificio compuesto por sucesivas unidades [Referencia: nps-anatomia-volcan](#fuente-nps-anatomia-volcan).

La tefra reúne fragmentos expulsados. Ceniza, lapilli y bombas distinguen tamaños y, en el caso de bombas, características de emisión. Un lahar es una corriente de agua y material volcánico; una corriente piroclástica transporta mezcla caliente de partículas y gases. Gases, lava y ceniza no son peligros equivalentes [Referencia: usgs-volcanes-glosario](#fuente-usgs-volcanes-glosario).

## Teoría: reconocer procesos sin pronosticar por intuición

Una erupción puede combinar fases explosivas y efusivas. La estructura visible resulta de construcción y destrucción; un perfil aparentemente regular no revela el estado del sistema. Dibuja un esquema y escribe sus límites: simplifica profundidad, geometría, escalas y ubicación de conductos. No lo conviertas en corte real del Calbuco.

El guía necesita separar cuatro preguntas: qué procesos han ocurrido, dónde podrían producir efectos, qué se observa ahora y qué decisión corresponde. Un estudio antiguo puede respaldar la primera; un mapa oficial de peligros, la segunda dentro de sus hipótesis; los reportes actuales aportan a la tercera. La decisión incluye además instrucciones de autoridades, restricciones, grupo, movilidad y comunicaciones. Ninguna fotografía de “humo” permite resolver las cuatro.

El monitoreo estudia distintos indicadores mediante instrumentos y análisis especializado. Una persona en terreno no reemplaza esa integración por olor, color o un temblor percibido. Incluso llamar “humo” a una emisión puede mezclar vapor, gases y partículas. Registra una descripción sin diagnosticar y consulta canales oficiales desde una situación que no aumente la exposición.

El portal de alertas SERNAGEOMIN está identificado, pero su apertura no pudo verificarse en esta revisión. Por ello no se publica aquí ningún nivel vigente [Referencia: sernageomin-alertas-portal](#fuente-sernageomin-alertas-portal). Tampoco se convierten reportes históricos en autorización de acceso.

## Caso práctico: información antigua que parece actual

Una captura sin fecha muestra color verde y un mapa con una zona coloreada. El grupo propone usarla para decidir una salida. Pide fecha de emisión, organismo, volcán, propósito y vigencia. Distingue alerta técnica, medidas de protección civil y restricciones del administrador. Si no puedes confirmar información decisiva, no rellenes el vacío con la ausencia de noticias.

## Errores frecuentes y señales de alerta

Interpretar ausencia de lava como ausencia de amenaza, seguir un cauce como escape sin evaluación oficial, usar una máscara como permiso para exponerse o tratar una erupción pasada como pronóstico de la siguiente.

## Autoevaluación y respuestas explicadas

¿Una zona fuera de un polígono garantiza seguridad? No: importa qué proceso y escenario modela el mapa. ¿Una alerta baja acredita un sendero abierto? No: son información y decisiones de ámbitos diferentes.

## Ejercicios y práctica presencial

Analiza en aula un reporte fechado y una leyenda de mapa, con instructor. Identifica las preguntas que el documento responde y las que no. No realices una visita para “comprobar” gases o actividad.

## Evidencia requerida

Ficha de fuente, validez, interpretación limitada y decisión revisable. Revisión humana del razonamiento, sin certificación operacional.

## Relaciones con otras habilidades

Integra navegación, logística, gestión del riesgo y comunicación. El reconocimiento de peligro no equivale a formación para aproximarse a un volcán en actividad.
