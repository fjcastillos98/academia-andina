---
{
  "title": "Objetivos y evidencia de aprendizaje",
  "description": "Define una conducta observable.",
  "module": "M19",
  "code": "E16-01",
  "order": 1601,
  "minutes": 30,
  "level": "Intermedio",
  "status": "development",
  "unit": "U16-01",
  "skills": [
    "s16-objetivos-aprendizaje"
  ],
  "critical": false,
  "reviewDate": "2026-10-28",
  "objectives": [
    "Define una conducta observable.",
    "Distingue respuesta teórica y ejecución contextual."
  ],
  "prerequisites": [
    "s4-grupo-liderazgo"
  ],
  "sources": [
    "e16-feedback"
  ],
  "pending": [
    "Revisión por docente e instructor competente pendiente.",
    "Casos y rúbricas originales; no certifican guiado ni sustituyen formación técnica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿Qué objetivo permite comprobar aprendizaje en mesa?",
        "options": [
          "Comprender todo sobre orientación.",
          "Localizar dos referencias en una carta y justificar la elección.",
          "Sentirse preparado para guiar."
        ],
        "answer": 1,
        "explanation": "Es una tarea observable y acotada.",
        "rationales": [
          "No concreta una observación.",
          "Es una tarea observable y acotada.",
          "La confianza no demuestra la habilidad."
        ],
        "source": "e16-feedback",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un quiz correcto permite registrar…",
        "options": [
          "Competencia de guiado.",
          "Práctica realizada.",
          "Resultado teórico de ese quiz."
        ],
        "answer": 2,
        "explanation": "El alcance coincide con la evidencia.",
        "rationales": [
          "No se observó guiado.",
          "No se realizó una práctica por contestar.",
          "El alcance coincide con la evidencia."
        ],
        "source": "e16-feedback",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué evidencia corresponde al ejercicio propuesto en esta unidad?",
        "options": [
          "Un registro de la tarea, errores y correcciones observados.",
          "Una declaración automática de competencia por leer.",
          "Una valoración del carácter de la persona."
        ],
        "answer": 0,
        "explanation": "La rúbrica pide observaciones de una tarea concreta; su evaluación sigue siendo humana.",
        "rationales": [
          "Es evidencia contextual del taller.",
          "Leer no demuestra ejecución.",
          "Se evalúan actuaciones, no etiquetas personales."
        ],
        "source": "e16-feedback",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Define una conducta observable.",
    "Distingue respuesta teórica y ejecución contextual.",
    "Identifica una limitación de la evidencia."
  ],
  "openAssessment": {
    "prompt": "Redacta un objetivo, una tarea de mesa y dos indicadores observables. Explica qué no podrás evaluar sin terreno e instructor.",
    "rubric": [
      "Define una conducta observable.",
      "Distingue respuesta teórica y ejecución contextual.",
      "Identifica una limitación de la evidencia."
    ],
    "source": "e16-feedback",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**BLOQUE EN DESARROLLO · REVISIÓN DOCENTE E INSTRUCTORA PENDIENTE.** Talleres de mesa con personajes ficticios, sin exposición en terreno ni datos personales.

## Conceptos clave y propósito

Un objetivo observable permite diseñar una comprobación concreta. En este taller distinguimos explicar una decisión, ensayar una conducta y demostrarla en un contexto evaluado.

## Teoría y alcance de la fuente

La EEF describe la retroalimentación como apoyo para reducir la distancia entre el aprendizaje observado y el esperado, pero advierte que no toda retroalimentación mejora el progreso. Su guía se dirige a escolares de 5 a 18 años; trasladar ideas a adultos en montaña es una adaptación por revisar.

[Fuente conceptual y límites](#fuente-e16-feedback). El diseño de tareas, preguntas y criterios siguiente es una propuesta original de la academia; no se atribuye a la organización citada ni constituye un estándar de acreditación.

## Aplicación docente propuesta

Propuesta docente: sustituye «aprender orientación» por «en una carta de práctica, localizar dos referencias y explicar qué dato falta para elegir un itinerario». Define primero la tarea, después la evidencia y finalmente el criterio. Así puedes detectar un error de comprensión sin atribuirlo automáticamente a falta de esfuerzo. Un objetivo demasiado amplio oculta qué parte requiere apoyo.

La dificultad no tiene que ser idéntica para todos, pero el criterio debe ser comprensible. Pregunta qué experiencia tiene la persona con la tarea, sin pedir diagnósticos ni información privada. Si no hay una oportunidad de observar la conducta, registra preparación teórica pendiente de práctica, no competencia.

## Caso práctico

**Escenario ficticio:** Un alumno reconoce todos los símbolos de una diapositiva, pero no explica por qué una referencia no coincide con la carta.

Explica qué observación necesitas antes de concluir y qué parte de tu respuesta es todavía una hipótesis.

## Errores frecuentes

Confundir confianza con evidencia, registrar como realizada una práctica solo preparada y trasladar el resultado de una simulación a terreno real. Revisa también si describiste un hecho o una interpretación.

## Material y equipo

Cuaderno, tarjetas con roles ficticios y una ficha territorial de la academia. No se requieren cuerdas, anclajes ni exposición al terreno para estos ejercicios.

## Autoevaluación

- Define una conducta observable.
- Distingue respuesta teórica y ejecución contextual.
- Identifica una limitación de la evidencia.

## Ejercicios y práctica supervisada

Redacta un objetivo, una tarea de mesa y dos indicadores observables. Explica qué no podrás evaluar sin terreno e instructor.

En un taller con docente o instructor, alterna participante, facilitador y observador. Define antes el criterio y recoge después una corrección. El instructor decide si corresponde otra práctica; no aumentes exposición para producir evidencia.

## Evidencia requerida

Conserva objetivo, tarea, observación, error, corrección y próxima práctica. La revisión humana debe indicar contexto y límites; no basta una etiqueta de «logrado». El quiz registra conocimiento teórico y no cambia competencias prácticas.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s16-objetivos-aprendizaje). Solo registra el taller después de realizarlo. No inventes supervisor, evaluación ni repeticiones.

## Relaciones con otros módulos

[Pedagogía y liderazgo](../../liderazgo/) · [Fundamentos de grupo](../../lecciones/grupo-liderazgo/) · [Programa](../../programa/). Las maniobras y decisiones técnicas requieren sus propias competencias y supervisión.
