---
{
  "title": "Aclimatación: dar tiempo y revisar la respuesta",
  "description": "Comparar ganancia de pernocta y altitud máxima diurna.",
  "module": "M03",
  "code": "E9-02",
  "order": 902,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U9-02",
  "skills": [
    "s9-aclimatacion-altitud"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Comparar ganancia de pernocta y altitud máxima diurna.",
    "Leer recomendaciones de ascenso como orientación contextual."
  ],
  "prerequisites": [
    "s9-fisiologia-altitud"
  ],
  "sources": [
    "e9-cdc",
    "e9-wms"
  ],
  "pending": [
    "Revisión médica por profesional de medicina de montaña y revisión docente por instructor pendientes. No se ha evaluado atención clínica ni rescate.",
    "Casos, ejercicios y criterios son propuestas pedagógicas originales; no autorizan decisiones clínicas individuales.",
    "Condiciones de rutas, comunicaciones y recursos de atención locales requieren verificación antes de cada salida."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Dormir de nuevo a 3600 m después de dormir a 3600 m supone…",
        "options": [
          "0 m de incremento de pernocta.",
          "3600 m de ganancia.",
          "Aclimatación completa garantizada."
        ],
        "answer": 0,
        "explanation": "La diferencia entre noches es cero.",
        "rationales": [
          "La diferencia entre noches es cero.",
          "Es la altitud absoluta, no la diferencia.",
          "La aritmética no demuestra adaptación."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué dato falta si solo conocemos la cumbre de cada día?",
        "options": [
          "El color de la mochila.",
          "La altitud donde se duerme.",
          "El número de fotografías."
        ],
        "answer": 1,
        "explanation": "Es una variable central del itinerario.",
        "rationales": [
          "No describe la exposición nocturna.",
          "Es una variable central del itinerario.",
          "No determina el perfil de pernocta."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una recomendación de incremento diario…",
        "options": [
          "Autoriza subir con síntomas.",
          "Garantiza tolerancia universal.",
          "No reemplaza la respuesta individual."
        ],
        "answer": 2,
        "explanation": "Debe conservarse el contexto clínico y logístico.",
        "rationales": [
          "Los síntomas cambian la decisión.",
          "No existe tal garantía.",
          "Debe conservarse el contexto clínico y logístico."
        ],
        "source": "e9-cdc",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue pernocta y máximo diurno.",
    "Cita por separado las formulaciones CDC y WMS.",
    "No convierte el cálculo en un permiso de ascenso."
  ],
  "openAssessment": {
    "prompt": "Anota las tres diferencias del ejemplo. Escribe por qué ninguna suma determina que una persona esté aclimatada.",
    "rubric": [
      "Distingue pernocta y máximo diurno.",
      "Cita por separado las formulaciones CDC y WMS.",
      "No convierte el cálculo en un permiso de ascenso."
    ],
    "source": "e9-cdc",
    "difficulty": "integración"
  },
  "diagrams": [
    "e9-pernocta"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN MÉDICA Y DE INSTRUCTOR PENDIENTES.** No es una herramienta de diagnóstico ni prescripción. Los casos son ficticios; no introduzcas datos médicos personales. Una emergencia real requiere asistencia urgente, no completar esta lección.

## Conceptos clave y propósito

Altitud de pernocta, exposición previa, ascenso gradual, descanso y variación individual.

## Teoría y toma de decisiones

La aclimatación necesita tiempo y no se compra acumulando metros de desnivel en una sola jornada. Para estudiar un itinerario, la columna de pernocta debe estar separada de la cumbre o punto más alto visitado. El descenso nocturno y la permanencia a mayor elevación no representan la misma exposición.

Por encima de 3000 m, CDC presenta aumentos de pernocta de no más de 500 m diarios y una noche adicional por cada 1000 m ganados. WMS 2024 expresa el descanso sin aumento de pernocta cada tres o cuatro días, junto al mismo límite diario. Son recomendaciones generales: no garantizan tolerancia individual ni autorizan ascender con síntomas. [CDC](#fuente-e9-cdc) · [WMS](#fuente-e9-wms).

En el ejercicio original, las pernoctas son 2800, 3200, 3600 y 3600 m. Las diferencias consecutivas son +400, +400 y 0 m. Esa aritmética describe el plan, pero no conoce exposición previa, respuesta individual, transporte inicial o posibilidades de evacuación. Un programa que solo coloree esos números en verde estaría afirmando más de lo que calcula.

Al revisar el itinerario, escribe qué haría cambiar la jornada siguiente. Una reserva de calendario sirve para modificar el plan, no para exigir que todos toleren la misma velocidad. No uses hipoxia deliberada, apnea o restricciones de respiración como ejercicio de esta academia.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación y análisis de aula.** Construye una tabla de noches con su fuente y una columna separada para el máximo del día. Calcula diferencias, identifica los días sin incremento y enumera datos faltantes. Contrasta el itinerario con el asesoramiento médico previo. Si aparecen síntomas compatibles, no ganar altitud para dormir; un empeoramiento exige descenso y asistencia según el contexto.

Las indicaciones clínicas dependen del paciente y los recursos. Las maniobras de movilización, oxigenoterapia y rescate requieren formación práctica y supervisión competente. No extrapolar un caso de escritorio a una actuación real ni elegir fármacos a partir de un quiz.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un programa anuncia «400 m por día, seguro para todos», pero el primer traslado desde la costa termina a 3600 m. ¿Qué información oculta el promedio?

Identifica hechos, incertidumbres y decisiones. Explica qué información podría modificar tu propuesta. La rúbrica es docente, no un protocolo avalado por las instituciones citadas.

## Errores frecuentes y puntos críticos de seguridad

Confundir un promedio con cada incremento; omitir el primer traslado; hacer del descanso una fecha rígida; interpretar una noche sin ascenso como garantía de recuperación.

## Material y equipo relacionado

Tabla de pernoctas, cartografía y horarios de transporte. La documentación de un viaje no reemplaza la evaluación individual.

[Inventario educativo](../../equipo/). Tener el recurso no demuestra saber utilizarlo. El diario no es una ficha clínica.

## Autoevaluación y recuperación activa

- ¿Puedes explicar el concepto central sin confundirlo con una autorización de salida?
- ¿Qué dato falta en el escenario y qué decisión depende de él?
- ¿Qué tarea exige formación sanitaria o técnica y no se evalúa aquí?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Anota las tres diferencias del ejemplo. Escribe por qué ninguna suma determina que una persona esté aclimatada.

**PRÁCTICA SUPERVISADA — propuesta:** Simulación de revisión de itinerarios con instructor y asesor médico. Introducir un día de retraso ficticio y reorganizar las opciones sin comprimir automáticamente el ascenso.

## Evidencia requerida y criterios de competencia

- Distingue pernocta y máximo diurno.
- Cita por separado las formulaciones CDC y WMS.
- No convierte el cálculo en un permiso de ascenso.

**COMPETENCIA:** requiere observación contextual por instructor competente y revisión sanitaria cuando corresponda. Estos criterios evalúan preparación, comunicación y límites de actuación; no habilitan como profesional sanitario ni guía. La plataforma no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de la habilidad](../../practicas/?habilidad=s9-aclimatacion-altitud). Registra fecha, actividad, escenario ficticio, equipo, errores, correcciones, supervisor y evidencia del aprendizaje. No incluyas diagnósticos, recetas, mediciones personales ni datos de pacientes. Marca pendiente toda evaluación no realizada.

## Relaciones con otros módulos

[Volver a Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Escalada alpina](../../alpina/) · [Programa](../../programa/). La secuencia académica conecta planificación, comunicación y riesgo; no acredita aptitud clínica ni práctica.
