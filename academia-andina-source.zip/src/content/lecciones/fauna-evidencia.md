---
{
  "title": "Fauna regional: presencia, señales y detectabilidad",
  "description": "Distingue presencia documental de encuentro verificado.",
  "module": "M15",
  "code": "E11-05",
  "order": 1105,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U11-05",
  "skills": [
    "s11-fauna-evidencia"
  ],
  "critical": false,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Distingue presencia documental de encuentro verificado.",
    "Explica por qué no detectar no prueba ausencia."
  ],
  "prerequisites": [
    "s11-flora-identificacion"
  ],
  "sources": [
    "e11-vpr",
    "e11-puyehue"
  ],
  "pending": [
    "Revisión por especialista en ecología e instructor territorial pendiente. Los ejercicios no autorizan acceso, colecta o manejo de fauna.",
    "Categorías legales vigentes, protocolos de encuentro específicos y claves taxonómicas completas: requieren verificación.",
    "Casos, rúbricas y propuestas de práctica originales; no constituyen un protocolo oficial ni una certificación."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "No observar un animal en una salida significa…",
        "options": [
          "Que no existe en el parque.",
          "Que no fue detectado en esas condiciones.",
          "Que está extinto."
        ],
        "answer": 1,
        "explanation": "Es la conclusión compatible con el registro.",
        "rationales": [
          "La observación fue limitada.",
          "Es la conclusión compatible con el registro.",
          "No hay evidencia suficiente."
        ],
        "source": "e11-vpr",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Dos registros podrían ser…",
        "options": [
          "Necesariamente dos poblaciones.",
          "Siempre dos individuos.",
          "El mismo individuo observado nuevamente."
        ],
        "answer": 2,
        "explanation": "Es una alternativa que se debe considerar.",
        "rationales": [
          "El dato no sostiene esa escala.",
          "Hace falta distinguir individuos.",
          "Es una alternativa que se debe considerar."
        ],
        "source": "e11-vpr",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una lista del parque…",
        "options": [
          "No garantiza un encuentro en el sendero.",
          "Confirma cualquier huella.",
          "Predice el horario de todos los animales."
        ],
        "answer": 0,
        "explanation": "Separa escala y observación.",
        "rationales": [
          "Separa escala y observación.",
          "La señal requiere identificación.",
          "No es una predicción de encuentros."
        ],
        "source": "e11-vpr",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue presencia documental de encuentro verificado.",
    "Explica por qué no detectar no prueba ausencia.",
    "Registra evidencia y esfuerzo sin inflar abundancia."
  ],
  "openAssessment": {
    "prompt": "Compara tres registros ficticios: ave vista, sonido no identificado y recorrido sin detecciones. Escribe la conclusión máxima admisible para cada uno.",
    "rubric": [
      "Distingue presencia documental de encuentro verificado.",
      "Explica por qué no detectar no prueba ausencia.",
      "Registra evidencia y esfuerzo sin inflar abundancia."
    ],
    "source": "e11-vpr",
    "difficulty": "integración"
  },
  "diagrams": [
    "e11-evidencia"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ECOLÓGICA PENDIENTE.** Observación responsable para estudio personal. No acredita identificación taxonómica, competencia profesional ni autorización de acceso. No guardes datos médicos ni localizaciones precisas de especies sensibles.

## Conceptos clave y propósito

Presencia documentada, detección, ausencia de detección, comportamiento, señales indirectas y esfuerzo de observación. La probabilidad de observar no equivale a abundancia.

## Teoría y toma de decisiones

CONAF incluye pudú, güiña, huillín y monito del monte en la descripción de Vicente Pérez Rosales. La lista documenta el ámbito del parque, no promete que un visitante los verá ni confirma una observación particular. Las fichas de especies existentes en la academia sirven como material de consulta, no como inventario exhaustivo.

El registro debe distinguir encuentro visual, vocalización atribuida e indicio sin autor confirmado. Una huella o sonido necesita contexto y alternativas. Si un recorrido no produce observaciones, la conclusión es que no detectaste fauna bajo ese esfuerzo y esas condiciones; no que el sitio carece de animales. Del mismo modo, varias observaciones podrían corresponder al mismo individuo.

Para practicar define duración, sector general y método no perturbador. Escribe lo visto antes de interpretar una conducta como curiosidad, agresión o tranquilidad. El guía debe conservar expectativas honestas: la calidad de una salida no depende de provocar encuentros. La explicación puede centrarse en hábitat y conservación sin perseguir a un animal para completar una lista.

Referencias de esta unidad: [Fuente 1](#fuente-e11-vpr) · [Fuente 2](#fuente-e11-puyehue). Los casos y las aplicaciones pedagógicas que siguen son elaboración original; no se atribuyen como protocolos de las fuentes.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — observación y decisión:** Registra tipo de evidencia y esfuerzo; describe rasgos y conducta visible; diferencia individuo observado de número de registros; consulta fuentes sin modificar el encuentro. Variante: observación directa frente a señal indirecta; la segunda suele requerir más cautela.

No manipules fauna, no recolectes material y no salgas del itinerario autorizado para completar el ejercicio. La conducción real y las maniobras técnicas requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** En veinte minutos se ven dos veces aves parecidas en el mismo árbol. Un participante anota dos individuos y afirma que el lugar tiene una población abundante. Revisa ambas inferencias.

## Errores frecuentes y puntos críticos de seguridad

Convertir no detección en ausencia; contar registros como individuos; garantizar avistamientos; usar vocalizaciones para obtener una foto. No tocar animales ni señales biológicas.

## Material y equipo relacionado

Prismáticos, cámara con zoom, reloj y cuaderno. Mantener equipo preparado evita acercamientos innecesarios; no usar alimento como accesorio de observación.

[Revisar inventario](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica cómo comprobarías este criterio: Distingue presencia documental de encuentro verificado.
- Explica cómo comprobarías este criterio: Explica por qué no detectar no prueba ausencia.
- Explica cómo comprobarías este criterio: Registra evidencia y esfuerzo sin inflar abundancia.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Compara tres registros ficticios: ave vista, sonido no identificado y recorrido sin detecciones. Escribe la conclusión máxima admisible para cada uno.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Revisión con especialista de registros y esfuerzo desde un recorrido permitido; sin captura, cebos ni acercamiento a refugios.

## Evidencia requerida y criterios de competencia

- Distingue presencia documental de encuentro verificado.
- Explica por qué no detectar no prueba ausencia.
- Registra evidencia y esfuerzo sin inflar abundancia.

**COMPETENCIA:** requiere observación y revisión humana en contexto. Una lectura, registro o quiz no certifica guiado, identificación experta ni maniobras. La plataforma no verifica credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s11-fauna-evidencia) y [cuaderno de observación](../../ecologia/#observaciones). Separa ejercicio ficticio, observación real y práctica evaluada. Registra errores, correcciones, supervisor y evidencia sin inventar resultados. Mantén áreas generales; el texto libre no filtra automáticamente ubicaciones sensibles.

## Relaciones con otros módulos

[Ecología](../../ecologia/) · [Fichas de especies](../../especies/) · [Territorio](../../territorio/) · [Planificación](../../planificacion/) · [Programa](../../programa/). La interpretación ambiental se relaciona con geología, cartografía, gestión de grupos y patrimonio, sin sustituir su formación específica.
