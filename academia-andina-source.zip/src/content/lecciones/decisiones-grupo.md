---
{
  "title": "Decisiones, roles y presión del grupo",
  "description": "Distingue preferencia y evidencia.",
  "module": "M19",
  "code": "E16-05",
  "order": 1605,
  "minutes": 30,
  "level": "Intermedio",
  "status": "development",
  "unit": "U16-05",
  "skills": [
    "s16-decisiones-grupo"
  ],
  "critical": false,
  "reviewDate": "2026-10-28",
  "objectives": [
    "Distingue preferencia y evidencia.",
    "Identifica responsable y límite de la decisión."
  ],
  "prerequisites": [
    "s16-comunicacion-conflictos"
  ],
  "sources": [
    "e16-nols"
  ],
  "pending": [
    "Revisión por docente e instructor competente pendiente.",
    "Casos y rúbricas originales; no certifican guiado ni sustituyen formación técnica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una mayoría prefiere continuar pese a un dato crítico faltante. ¿Qué demuestra?",
        "options": [
          "Que la opción es técnicamente válida.",
          "Que el dato ya no importa.",
          "Una preferencia, no la resolución de la incertidumbre."
        ],
        "answer": 2,
        "explanation": "Separa opinión y conocimiento.",
        "rationales": [
          "La votación no verifica condiciones.",
          "La presión social no aporta evidencia.",
          "Separa opinión y conocimiento."
        ],
        "source": "e16-nols",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La persona con menos experiencia aporta una observación relevante. ¿Cómo tratarla?",
        "options": [
          "Descartarla por antigüedad.",
          "Examinar el dato y su alcance.",
          "Delegarle toda la decisión."
        ],
        "answer": 1,
        "explanation": "Permite incorporar evidencia sin inventar competencia.",
        "rationales": [
          "El rango no refuta un dato.",
          "Permite incorporar evidencia sin inventar competencia.",
          "Aportar un dato no acredita toda la función."
        ],
        "source": "e16-nols",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué evidencia corresponde al ejercicio propuesto en esta unidad?",
        "options": [
          "Un registro de la tarea, errores y correcciones observados.",
          "Una declaración automática de competencia por leer.",
          "Una valoración del carácter de la persona."
        ],
        "answer": 0,
        "explanation": "La rúbrica pide observaciones de una tarea concreta; su evaluación sigue siendo humana.",
        "rationales": [
          "Es evidencia contextual del taller.",
          "Leer no demuestra ejecución.",
          "Se evalúan actuaciones, no etiquetas personales."
        ],
        "source": "e16-nols",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue preferencia y evidencia.",
    "Identifica responsable y límite de la decisión.",
    "Incluye una alternativa y condición de revisión."
  ],
  "openAssessment": {
    "prompt": "Construye una matriz de tres opciones con hechos, incertidumbres, responsable y condición de revisión. No puntúes seguridad ni atribuyas condiciones a una ruta real.",
    "rubric": [
      "Distingue preferencia y evidencia.",
      "Identifica responsable y límite de la decisión.",
      "Incluye una alternativa y condición de revisión."
    ],
    "source": "e16-nols",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**BLOQUE EN DESARROLLO · REVISIÓN DOCENTE E INSTRUCTORA PENDIENTE.** Talleres de mesa con personajes ficticios, sin exposición en terreno ni datos personales.

## Conceptos clave y propósito

Una decisión de grupo necesita hacer explícitos el propósito, los datos, las incertidumbres y la responsabilidad de decidir. Participar no equivale a votar cualquier límite técnico.

## Teoría y alcance de la fuente

NOLS vincula los objetivos personales con los del grupo y destaca asumir responsabilidades y colaborar. Los casos de este taller son adaptaciones originales, no protocolos operativos de NOLS.

[Fuente conceptual y límites](#fuente-e16-nols). El diseño de tareas, preguntas y criterios siguiente es una propuesta original de la academia; no se atribuye a la organización citada ni constituye un estándar de acreditación.

## Aplicación docente propuesta

En una reunión ficticia, separa lo observado de lo supuesto y pide primero la información que falta. Asigna a una persona el registro y a otra la tarea de preguntar qué podría invalidar la opción preferida. Esa función de contraste no convierte a quien la ejerce en experto técnico. Documenta quién tiene autoridad para modificar el plan y cuándo será revisado.

No uses una mayoría como sustituto de conocimiento o autorización. Un participante puede aportar un dato decisivo aunque sea nuevo. Explica por qué una opción se descarta y qué alternativa permite mantener un objetivo legítimo del grupo. Si el ejercicio exige valorar un peligro que nadie sabe evaluar, el resultado útil es reconocer el límite y formular una consulta, no inventar una respuesta segura.

## Caso práctico

**Escenario ficticio:** En una planificación ficticia, cuatro personas quieren mantener el objetivo anunciado y una señala que falta información del descenso.

Explica qué observación necesitas antes de concluir y qué parte de tu respuesta es todavía una hipótesis.

## Errores frecuentes

Confundir confianza con evidencia, registrar como realizada una práctica solo preparada y trasladar el resultado de una simulación a terreno real. Revisa también si describiste un hecho o una interpretación.

## Material y equipo

Cuaderno, tarjetas con roles ficticios y una ficha territorial de la academia. No se requieren cuerdas, anclajes ni exposición al terreno para estos ejercicios.

## Autoevaluación

- Distingue preferencia y evidencia.
- Identifica responsable y límite de la decisión.
- Incluye una alternativa y condición de revisión.

## Ejercicios y práctica supervisada

Construye una matriz de tres opciones con hechos, incertidumbres, responsable y condición de revisión. No puntúes seguridad ni atribuyas condiciones a una ruta real.

En un taller con docente o instructor, alterna participante, facilitador y observador. Define antes el criterio y recoge después una corrección. El instructor decide si corresponde otra práctica; no aumentes exposición para producir evidencia.

## Evidencia requerida

Conserva objetivo, tarea, observación, error, corrección y próxima práctica. La revisión humana debe indicar contexto y límites; no basta una etiqueta de «logrado». El quiz registra conocimiento teórico y no cambia competencias prácticas.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s16-decisiones-grupo). Solo registra el taller después de realizarlo. No inventes supervisor, evaluación ni repeticiones.

## Relaciones con otros módulos

[Pedagogía y liderazgo](../../liderazgo/) · [Fundamentos de grupo](../../lecciones/grupo-liderazgo/) · [Programa](../../programa/). Las maniobras y decisiones técnicas requieren sus propias competencias y supervisión.
