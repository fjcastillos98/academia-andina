---
{
  "title": "Ocho reconstituido",
  "description": "Identificar nombre, variante y función de ocho reconstituido.",
  "module": "M07",
  "code": "E43-06",
  "order": 305,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U43-03",
  "skills": [
    "s43-ocho-reconstituido"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Identificar nombre, variante y función de ocho reconstituido.",
    "Distinguir límites de uso, errores y compatibilidades pendientes.",
    "Preparar una revisión presencial con evidencia."
  ],
  "prerequisites": [
    "s43-ocho-doble-gaza"
  ],
  "sources": [
    "petzl-nudos-435",
    "petzl-partner"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "familias-ocho"
  ],
  "preparation": [
    "Función: encordamiento descrito en la fuente.",
    "Error: detener confección para conversar y asumir después que estaba terminada.",
    "Compatibilidad: manual del arnés y cuerda identificados."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "petzl-nudos-435",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "En el estudio de ocho reconstituido, ¿qué afirmación es defendible?",
        "options": [
          "Una figura reconocible nunca está incompleta.",
          "Función: encordamiento descrito en la fuente.",
          "El lugar de conexión al arnés es indiferente."
        ],
        "answer": 1,
        "explanation": "La función debe identificarse dentro del alcance descrito; no implica aptitud del conjunto.",
        "rationales": [
          "La afirmación omite contexto o atribuye una función no demostrada.",
          "Función: encordamiento descrito en la fuente. Se mantiene su alcance específico.",
          "No permite evaluar el sistema completo ni sus límites."
        ],
        "source": "petzl-nudos-435",
        "difficulty": "básica",
        "kind": "conocimiento"
      },
      {
        "prompt": "El nudo parece correcto, pero no se ve su conexión. ¿Qué concluyes?",
        "options": [
          "El sistema ya está revisado.",
          "La conexión es necesariamente incorrecta.",
          "Falta información; no aprobar el conjunto por una sola parte."
        ],
        "answer": 2,
        "explanation": "La revisión debe distinguir lo observado de lo que aún no se puede comprobar.",
        "rationales": [
          "Extrapola una parte al conjunto.",
          "La falta de imagen no prueba un defecto.",
          "Conserva incertidumbre y pide una comprobación concreta."
        ],
        "source": "petzl-nudos-435",
        "difficulty": "intermedia",
        "kind": "errores"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

Nombre: ocho reconstituido/reseguido, según terminología acordada. Característica: debe relacionarse con el punto de conexión prescrito para el arnés.

## Teoría: función, aplicación y límites

- Función: encordamiento descrito en la fuente.

- Uso: aprendizaje de una conexión mediante seguimiento de recorrido.

- No uso: no elegir un punto del arnés por semejanza visual.

- Ventaja: permite una inspección sistemática de continuidad.

- Limitación: una figura reconocible puede estar incompleta.

- Característica: debe relacionarse con el punto de conexión prescrito para el arnés.

La pregunta de estudio no termina al reconocer el nombre. Explica qué se pretende conectar, cuál es el recorrido de la carga y qué información falta para evaluar el conjunto. Distingue la observación directa de una suposición: no ver un defecto en una imagen no equivale a revisar todas las caras. En una sesión de guiado, pide al alumno describir la función con sus palabras antes de discutir rapidez o destreza.

[Referencia técnica: petzl-nudos-435](#fuente-petzl-nudos-435). Consulta los diagramas del fabricante para la configuración exacta; las láminas de esta academia analizan funciones y errores, no sustituyen esos diagramas ni el taller.

## Caso práctico y aplicación al guiado

Ejercicio: describir qué se revisa después de una interrupción. Respuesta: retomar una revisión completa en vez de confiar en memoria. No se fija longitud de chicote universal.

- Montaña: preparación para encordamiento según actividad.

- Guiado: controlar a cada persona sin reemplazar el control propio.

## Errores frecuentes y señales de alerta

Error: detener confección para conversar y asumir después que estaba terminada.

## Inspección y compatibilidades

Inspección: nudo terminado, vestido, ajustado y encordamiento en lugar previsto.

Compatibilidad: manual del arnés y cuerda identificados.

Se debe detener la propuesta si no se identifica la variante o el lugar de conexión. La revisión de extremos se hace según referencia aplicable; no se añade una cifra universal. La condición del material también necesita documentación e inspección, incluso cuando el recorrido del nudo parece correcto.

## Autoevaluación y respuestas explicadas

¿Reconocer una forma demuestra ejecución en terreno? **No: faltan selección, conexión, inspección, comunicación y desempeño bajo las condiciones evaluadas.**

¿Qué debes registrar si dos personas no coinciden en la variante? **Los nombres y diagramas utilizados, la fuente de cada uno y la discrepancia; resolverla con instructor antes de una aplicación.**

## Ejercicios y práctica presencial

Práctica: taller con instructor, errores preparados únicamente en material de demostración.

Prepara una ficha de comparación entre la función prevista y una función que este estudio no autoriza. Explica un error posible sin introducirlo en material en uso. En taller, el instructor observa identificación, confección, vestido, ajuste y revisión cruzada con material didáctico y condiciones controladas. No se carga una persona ni se improvisa una maniobra durante el estudio individual.

## Evidencia requerida

Nombre y variante, fuente, combinación de material, observación del instructor, error detectado, corrección y nueva práctica. La evaluación presencial debe declarar contexto y límites; un cuestionario solo registra comprensión.

## Relaciones con otras habilidades

Este tema precede a revisión de nudos y encordamiento. No se utiliza el resultado del quiz como habilitación para asegurar, descender o rescatar.
