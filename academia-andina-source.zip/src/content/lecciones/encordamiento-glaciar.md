---
{
  "title": "Encordamiento: conexión y gestión de cuerda",
  "description": "Distinguir conexión al arnés, reserva y control de longitud.",
  "module": "M04",
  "code": "E6-06",
  "order": 606,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U6-06",
  "skills": [
    "s6-encordamiento-glaciar"
  ],
  "critical": true,
  "reviewDate": "2026-10-23",
  "objectives": [
    "Distinguir conexión al arnés, reserva y control de longitud.",
    "Explicar que existen variantes con compromisos distintos."
  ],
  "prerequisites": [
    "s6-configuracion-cordada"
  ],
  "sources": [
    "e6-petzl-tie",
    "e6-petzl-team"
  ],
  "pending": [
    "Modelos, revisiones de manual y montaje supervisado. No afirmar compatibilidad por diámetro nominal solamente. PENDIENTE DE VERIFICACIÓN.",
    "Revisión presencial por instructor competente pendiente. No se ha realizado ni aprobado ninguna práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿Basta conocer un nudo para validar encordamiento?",
        "options": [
          "No: deben revisarse funciones y conjunto.",
          "Sí, siempre.",
          "Sí, si se hizo rápido."
        ],
        "answer": 0,
        "explanation": "Un nudo no cubre todas las relaciones del sistema.",
        "rationales": [
          "Correcta: Un nudo no cubre todas las relaciones del sistema.",
          "No se justifica: Un nudo no cubre todas las relaciones del sistema.",
          "No se justifica: Un nudo no cubre todas las relaciones del sistema."
        ],
        "source": "e6-petzl-tie",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Dos variantes documentadas por separado…",
        "options": [
          "Se mezclan sin revisión.",
          "Necesitan análisis del conjunto antes de combinar detalles.",
          "Son idénticas por usar cuerda."
        ],
        "answer": 1,
        "explanation": "Cada variante tiene propósito y condiciones.",
        "rationales": [
          "No se justifica: Cada variante tiene propósito y condiciones.",
          "Correcta: Cada variante tiene propósito y condiciones.",
          "No se justifica: Cada variante tiene propósito y condiciones."
        ],
        "source": "e6-petzl-tie",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "El diámetro nominal permite…",
        "options": [
          "Garantizar toda compatibilidad.",
          "Omitir el manual.",
          "Aportar un dato, insuficiente por sí solo."
        ],
        "answer": 2,
        "explanation": "La combinación exacta requiere documentación y comprobación.",
        "rationales": [
          "No se justifica: La combinación exacta requiere documentación y comprobación.",
          "No se justifica: La combinación exacta requiere documentación y comprobación.",
          "Correcta: La combinación exacta requiere documentación y comprobación."
        ],
        "source": "e6-petzl-tie",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "Declara variantes y su fuente.",
    "No mezcla instrucciones de sistemas distintos.",
    "Identifica qué comprobará presencialmente el instructor."
  ],
  "openAssessment": {
    "prompt": "Asocia cada función con una comprobación documental: arnés, cuerda, conexión, reserva y posibilidad de rescate. Deja en blanco la especificación que no figure en el manual exacto.",
    "rubric": [
      "Declara variantes y su fuente.",
      "No mezcla instrucciones de sistemas distintos.",
      "Identifica qué comprobará presencialmente el instructor."
    ],
    "source": "e6-petzl-tie",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**CONTENIDO TEÓRICO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Conexión, Reserva, Bloqueo y ajuste, Comprobación cruzada. Petzl muestra variantes con y sin anillos de busto: se estudia el propósito y las restricciones, sin reconstruir un montaje desde un esquema incompleto.

## Teoría y toma de decisiones

Encordamiento es la conexión de personas al sistema de cuerda; configuración de cordada incluye además recursos, separación y estrategia. No son sinónimos. Petzl compara variantes con y sin anillos de busto, con compromisos en gestión de reserva y ajuste. [Variantes documentadas](#fuente-e6-petzl-tie). Estudiar la función de cada elemento evita copiar un detalle visual mientras se omite la condición para la que fue diseñado.

La comprobación conceptual distingue arnés, conexión, tramo operativo y reserva. Para cada función pregunta qué documento la respalda y qué debe observar una persona competente. Conocer un ocho reconstituido de la etapa de nudos no demuestra que el conjunto esté correctamente organizado. Tampoco el diámetro nominal de la cuerda basta para confirmar todos los dispositivos del sistema: modelo, construcción, estado y uso previsto requieren sus manuales exactos.

Petzl muestra que la reserva de cuerda y su gestión forman parte de la preparación, no un sobrante sin función. [Cordada de ejemplo](#fuente-e6-petzl-team). Ajustar una parte puede cambiar otra y afectar al rescate posterior. La revisión cruzada debe poder explicar qué se verifica; mirar un compañero unos segundos sin conocer el sistema no es una comprobación técnica suficiente.

El ejercicio consiste en una tabla de funciones, documento, observación requerida y limitación. En vez de dibujar un montaje para personas, utiliza etiquetas sueltas: «conexión», «reserva», «ajuste» y «recuperación». Relaciona qué cambios obligarían a revisar varias etiquetas a la vez. Deja explícitamente pendiente el dato que no figura en el manual. El taller posterior exige montaje observado y protegido por instructor; no se utiliza este texto para reconstruir una maniobra durante una salida.

## Procedimiento conceptual: objetivo, uso y límites

Distinguir conexión al arnés, reserva y control de longitud. Esta unidad se utiliza para preparar el análisis y un taller, no para ejecutar una maniobra sin entrenamiento. Los nudos de frenado pueden ayudar en ciertas nieves y complican la etapa posterior; la elección obliga a revisar el conjunto del sistema.

Las variantes técnicas mantienen el ámbito de la fuente citada. Antes de cambiar una configuración se deben revisar sus funciones, comprobaciones y límites con instructor; no se combinan pasos de escuelas distintas por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario hipotético de aula.** Una persona combina una conexión vista en un vídeo con la reserva de otro sistema. Ambos ejemplos parecen correctos por separado. ¿Qué relaciones faltan verificar en el conjunto?

## Errores frecuentes y puntos críticos

Mezclar escuelas sin comprender funciones; validar por apariencia; omitir reserva; asumir compatibilidad por marca o diámetro.

No se atribuye una garantía de seguridad al equipo, al quiz ni a una práctica en condiciones diferentes. Si falta un dato esencial para justificar el objetivo, declarar ese vacío es parte del aprendizaje.

## Material y equipo relacionado

Arnés exacto, cuerda identificada, conectores y manuales de las piezas. Cualquier bloqueador requiere su propia revisión de compatibilidad.

[Inventario personal](../../equipo/): conserva referencia del manual y observaciones de inspección. El registro no declara aptitud de una pieza ni competencia de quien la porta.

## Autoevaluación y recuperación activa

- ¿Qué función tiene la reserva además de evitar cuerda suelta?
- ¿Qué diferencia hay entre conocer un nudo y revisar un sistema?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL de escritorio:** Asocia cada función con una comprobación documental: arnés, cuerda, conexión, reserva y posibilidad de rescate. Deja en blanco la especificación que no figure en el manual exacto.

**PRÁCTICA SUPERVISADA:** el instructor adapta un taller con objetivos observables, protección y criterios de parada. No provocar caídas reales ni entrar a terreno expuesto para comprobar esta página. La evaluación presencial es independiente de la respuesta teórica.

## Evidencia requerida y criterios de competencia

- Declara variantes y su fuente.
- No mezcla instrucciones de sistemas distintos.
- Identifica qué comprobará presencialmente el instructor.

Estos criterios valoran razonamiento; para una competencia práctica, el instructor debe definir y observar la ejecución en un contexto explícito. No se preasigna una evaluación por estudiar.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s6-encordamiento-glaciar). Registrar únicamente lo realizado: fecha, lugar, condiciones, objetivo, equipo, supervisor, resultado, errores, correcciones, evidencia, autonomía observada y próxima práctica. No guardar datos médicos ni información privada de pasajeros.

## Relaciones con etapas anteriores

[Glaciología introductoria](../glaciologia-intro/), [planificación invernal](../planificacion-invernal/), [encordamiento según contexto](../encordamiento-contexto/), [anclajes](../anclajes-reuniones/) y [ventaja mecánica](../ventaja-mecanica/). Estas dependencias orientan el estudio; no autorizan la aplicación técnica. [Ruta glaciar](../../glaciar/).
