---
{
  "title": "Pescador doble",
  "description": "Identificar nombre, variante y función de pescador doble.",
  "module": "M07",
  "code": "E43-07",
  "order": 306,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U43-03",
  "skills": [
    "s43-pescador-doble"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Identificar nombre, variante y función de pescador doble.",
    "Distinguir límites de uso, errores y compatibilidades pendientes.",
    "Preparar una revisión presencial con evidencia."
  ],
  "prerequisites": [
    "s43-ocho-reconstituido"
  ],
  "sources": [
    "cmc-pescador"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "revision-visual"
  ],
  "preparation": [
    "Función: unión; la fuente CMC lo muestra para cerrar un anillo de cordino usado en un Prusik.",
    "Error: evaluar solo el lado visible.",
    "Compatibilidad: no presumir equivalencia entre fibras, diámetros o cintas."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "cmc-pescador",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "En el estudio de pescador doble, ¿qué afirmación es defendible?",
        "options": [
          "Es lo mismo que el Prusik alrededor de la cuerda.",
          "Función: unión; la fuente CMC lo muestra para cerrar un anillo de cordino usado en un Prusik.",
          "Se aplica igual a cualquier cinta."
        ],
        "answer": 1,
        "explanation": "La función debe identificarse dentro del alcance descrito; no implica aptitud del conjunto.",
        "rationales": [
          "La afirmación omite contexto o atribuye una función no demostrada.",
          "Función: unión; la fuente CMC lo muestra para cerrar un anillo de cordino usado en un Prusik. Se mantiene su alcance específico.",
          "No permite evaluar el sistema completo ni sus límites."
        ],
        "source": "cmc-pescador",
        "difficulty": "básica",
        "kind": "conocimiento"
      },
      {
        "prompt": "El nudo parece correcto, pero no se ve su conexión. ¿Qué concluyes?",
        "options": [
          "El sistema ya está revisado.",
          "La conexión es necesariamente incorrecta.",
          "Falta información; no aprobar el conjunto por una sola parte."
        ],
        "answer": 2,
        "explanation": "La revisión debe distinguir lo observado de lo que aún no se puede comprobar.",
        "rationales": [
          "Extrapola una parte al conjunto.",
          "La falta de imagen no prueba un defecto.",
          "Conserva incertidumbre y pide una comprobación concreta."
        ],
        "source": "cmc-pescador",
        "difficulty": "intermedia",
        "kind": "errores"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

Nombre: pescador doble. Característica: dos partes de unión que deben inspeccionarse.

## Teoría: función, aplicación y límites

- Función: unión; la fuente CMC lo muestra para cerrar un anillo de cordino usado en un Prusik.

- Uso: estudiar la unión del anillo con material apropiado.

- No uso: no confundir esa unión con el nudo de fricción que enlaza el anillo a otra cuerda.

- Ventaja: una unión compacta según la fuente.

- Limitación: puede dificultar el desatado tras carga.

- Característica: dos partes de unión que deben inspeccionarse.

La pregunta de estudio no termina al reconocer el nombre. Explica qué se pretende conectar, cuál es el recorrido de la carga y qué información falta para evaluar el conjunto. Distingue la observación directa de una suposición: no ver un defecto en una imagen no equivale a revisar todas las caras. En una sesión de guiado, pide al alumno describir la función con sus palabras antes de discutir rapidez o destreza.

[Referencia técnica: cmc-pescador](#fuente-cmc-pescador). Consulta los diagramas del fabricante para la configuración exacta; las láminas de esta academia analizan funciones y errores, no sustituyen esos diagramas ni el taller.

## Caso práctico y aplicación al guiado

Ejercicio: señalar unión y nudo de fricción en un esquema separado. Evidencia: diferencia sus funciones y reconoce compatibilidades pendientes.

- Montaña: comprender formación del anillo.

- Guiado: identificar qué componente corresponde a unión y cuál a fricción.

## Errores frecuentes y señales de alerta

Error: evaluar solo el lado visible.

## Inspección y compatibilidades

Inspección: ambos lados, extremos y ajuste según referencia aplicable.

Compatibilidad: no presumir equivalencia entre fibras, diámetros o cintas.

Se debe detener la propuesta si no se identifica la variante o el lugar de conexión. La revisión de extremos se hace según referencia aplicable; no se añade una cifra universal. La condición del material también necesita documentación e inspección, incluso cuando el recorrido del nudo parece correcto.

## Autoevaluación y respuestas explicadas

¿Reconocer una forma demuestra ejecución en terreno? **No: faltan selección, conexión, inspección, comunicación y desempeño bajo las condiciones evaluadas.**

¿Qué debes registrar si dos personas no coinciden en la variante? **Los nombres y diagramas utilizados, la fuente de cada uno y la discrepancia; resolverla con instructor antes de una aplicación.**

## Ejercicios y práctica presencial

Práctica: taller supervisado, sin suspensión.

Prepara una ficha de comparación entre la función prevista y una función que este estudio no autoriza. Explica un error posible sin introducirlo en material en uso. En taller, el instructor observa identificación, confección, vestido, ajuste y revisión cruzada con material didáctico y condiciones controladas. No se carga una persona ni se improvisa una maniobra durante el estudio individual.

## Evidencia requerida

Nombre y variante, fuente, combinación de material, observación del instructor, error detectado, corrección y nueva práctica. La evaluación presencial debe declarar contexto y límites; un cuestionario solo registra comprensión.

## Relaciones con otras habilidades

Este tema precede a revisión de nudos y encordamiento. No se utiliza el resultado del quiz como habilitación para asegurar, descender o rescatar.
