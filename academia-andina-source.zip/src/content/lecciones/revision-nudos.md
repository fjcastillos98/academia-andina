---
{
  "title": "Revisión de nudos: observar, describir y detener",
  "description": "Distinguir configuración, vestido, ajuste e inspección de un nudo.",
  "module": "M07",
  "code": "E43-13",
  "order": 312,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U43-04",
  "skills": [
    "s43-revision-nudos"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir configuración, vestido, ajuste e inspección de un nudo.",
    "Detectar errores visibles y explicar qué no puede verificarse en una fotografía.",
    "Preparar un control cruzado sin inventar longitudes universales de extremos."
  ],
  "prerequisites": [
    "s43-fuga-liberacion"
  ],
  "sources": [
    "petzl-partner",
    "petzl-nudos-435",
    "dmm-inspeccion"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "revision-visual"
  ],
  "preparation": [
    "Explicar los conceptos sin confundir un modelo con una maniobra.",
    "Reconocer al menos dos errores del caso y justificar una alternativa.",
    "Identificar la documentación y las competencias prácticas que faltan."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "petzl-partner",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "No se ve el chicote en una fotografía. ¿Qué registrar?",
        "options": [
          "Extremo suficiente.",
          "No observable; falta revisar.",
          "El nudo está necesariamente mal."
        ],
        "answer": 1,
        "explanation": "Distingue incertidumbre de defecto confirmado.",
        "rationales": [
          "No hay evidencia para afirmarlo.",
          "Distingue incertidumbre de defecto confirmado.",
          "La falta de imagen no demuestra un defecto."
        ],
        "source": "petzl-partner",
        "kind": "errores",
        "difficulty": "intermedia"
      },
      {
        "prompt": "Una segunda persona dice «sí» sin mirar la conexión.",
        "options": [
          "Completa la revisión.",
          "Sustituye al manual.",
          "No constituye una comprobación independiente suficiente."
        ],
        "answer": 2,
        "explanation": "Debe examinarse el sistema, no confirmar una sugerencia.",
        "rationales": [
          "La conexión quedó sin observar.",
          "La revisión no modifica requisitos.",
          "Debe examinarse el sistema, no confirmar una sugerencia."
        ],
        "source": "petzl-partner",
        "kind": "aplicación",
        "difficulty": "intermedia"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

Configurar es formar la estructura prevista; vestir es ordenar sus ramales según el modelo; ajustar es eliminar holguras conforme a esa técnica. Una silueta reconocible no demuestra que el recorrido interno, la conexión o la carga sean correctos.

## Teoría y decisiones

La revisión comienza antes del nudo: identificar la tarea, el material y el modelo de referencia. Después se contrasta el recorrido completo y se distingue el error observado de la información que no puede verse. Una fotografía de una sola cara puede ocultar el cruce decisivo. El control cruzado descrito por Petzl forma parte de una comprobación entre compañeros, no de una delegación ciega [Referencia: petzl-partner](#fuente-petzl-partner).

Checklist de aprendizaje: configuración identificada; vestido completo; extremos cuya suficiencia se ha contrastado con la fuente y el instructor; ausencia de cruces no previstos; dirección de carga definida; compatibilidad con cuerda, conector y sistema; segunda revisión cuando corresponda. Añade «no observable» como respuesta posible. No se usa un número universal para los extremos ni se supone que todo cruce es un defecto: hay que comparar con el nudo específico.

La independencia de la segunda revisión importa. Decir «mira qué bien está» orienta al compañero a confirmar. Pide describir el recorrido y la conexión antes de conocer tu conclusión. Si aparecen discrepancias, el resultado es detener el ejercicio y resolverlas; no votar por mayoría. El objetivo del registro es dejar claro qué se revisó y qué quedó fuera de alcance.

El diagrama presenta tarjetas de observación, no nudos listos para copiar. La primera muestra un extremo oculto: no puede aprobarse por la parte visible. La segunda muestra una flecha de carga no acordada: falta contexto incluso si el vestido parece correcto. La tercera reconoce incertidumbre y solicita revisión. No demuestra que el conjunto sea apto, pero sí una respuesta de aprendizaje defendible.

## Caso práctico y aplicación al guiado

Un alumno reconoce un ocho y marca todas las casillas en pocos segundos. En la imagen no se ve el punto de conexión al arnés. Explica por qué «nudo reconocido» y «sistema revisado» son afirmaciones distintas, y redacta una devolución que especifique qué falta sin inventar un fallo oculto.

## Errores frecuentes y señales de alerta

Aprobar por rapidez; inspeccionar solo la forma; tocar un sistema cargado para «corregirlo»; asignar un extremo suficiente por intuición; no registrar discrepancias. La inspección de material y la del montaje son controles relacionados, pero ninguno sustituye al otro.

## Autoevaluación y respuestas explicadas

¿Debe responderse sí o no a un extremo fuera de imagen? **No observable; hace falta examinarlo.** ¿Una revisión entre dos personas elimina fallos comunes? **No; pueden compartir la misma idea equivocada.**

## Ejercicios y práctica presencial

En mesa: comparar fotografías autorizadas o muestras preparadas por instructor; clasificar cada hallazgo como error confirmado, incertidumbre o criterio cumplido. Nunca introducir defectos en un sistema en uso. Luego realizar revisión cruzada presencial sin carga de personas.

## Evidencia requerida

Checklist fechada, configuración y fuente identificadas, desacuerdos y correcciones. El instructor observa el método de inspección y la decisión de parar, además del resultado.

## Relaciones con otras habilidades

Revisa los prerrequisitos y el contrato de habilidad de esta unidad en el programa. Contrasta la explicación con las fuentes indicadas: las cifras de un ejercicio no son límites de uso de un equipo. Toda transferencia a una situación con personas requiere formación y revisión presencial.
