---
{
  "title": "Glaciología introductoria: hielo que cambia",
  "description": "Explicar acumulación, ablación y balance de masa.",
  "module": "M04",
  "code": "E45-28",
  "order": 327,
  "minutes": 35,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U45-04",
  "skills": [
    "s45-glaciologia-intro"
  ],
  "critical": false,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Explicar acumulación, ablación y balance de masa.",
    "Reconocer vocabulario de grietas, seracs y rimaya sin inferir transitabilidad.",
    "Distinguir inventario glaciar de evaluación actual del terreno."
  ],
  "prerequisites": [
    "s45-geologia-lectura-terreno"
  ],
  "sources": [
    "usgs-glaciar-glosario",
    "dga-inventario-2022",
    "nps-grietas"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente.",
    "PENDIENTE DE VERIFICACIÓN TERRITORIAL: accesos, límites administrativos, rutas y condiciones actuales."
  ],
  "diagrams": [
    "glaciar-balance"
  ],
  "preparation": [
    "Distinguir hechos atribuidos, inferencias y datos pendientes.",
    "Explicar por qué la ficha no valida acceso, ruta ni condiciones.",
    "Preparar una observación sin extracción ni alteración del entorno."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "usgs-glaciar-glosario",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un inventario de 2022 delimita hielo. ¿Qué no permite concluir?",
        "options": [
          "Que existe información cartográfica fechada.",
          "Dónde están hoy todas las grietas y cuáles puentes soportan personas.",
          "Qué año identifica el catastro."
        ],
        "answer": 1,
        "explanation": "El inventario no es una evaluación mecánica o de transitabilidad actual.",
        "source": "dga-inventario-2022",
        "difficulty": "intermedia",
        "rationales": [
          "Sí permite reconocer una referencia documental.",
          "Es la inferencia que no está respaldada.",
          "La fecha es parte de los metadatos."
        ],
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué significa un balance de masa negativo?",
        "options": [
          "Pérdidas mayores que ganancias en el período considerado.",
          "El hielo no puede moverse.",
          "La superficie quedó sin grietas."
        ],
        "answer": 0,
        "explanation": "El balance compara masa; no certifica inmovilidad ni ausencia de peligros.",
        "source": "usgs-glaciar-glosario",
        "difficulty": "intermedia",
        "rationales": [
          "Corresponde a la definición.",
          "Movimiento y balance no son lo mismo.",
          "La fracturación no desaparece por una cifra de balance."
        ],
        "kind": "aplicación"
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

Un glaciar es una masa de hielo persistente formada en tierra y que fluye bajo su propio peso. Acumulación añade masa; ablación la pierde. El balance de masa compara entradas y salidas en un período y dominio definidos. Nieve transformada o firn representa etapas de compactación y transformación hacia hielo glaciar. Un balance negativo no implica que todo el hielo deje inmediatamente de moverse [Referencia: usgs-glaciar-glosario](#fuente-usgs-glaciar-glosario).

Grieta es una fractura; rimaya designa una abertura en la cabecera del glaciar; serac, un bloque o torre de hielo asociado a fracturación. Un puente de nieve puede ocultar una abertura. “Hielo vivo” es una expresión que necesita aclaración: no es una categoría operativa suficiente para decidir tránsito.

## Teoría: cuatro escalas de tiempo

Para interpretar un glaciar distingue la historia del relieve, la evolución de años o décadas, el cambio estacional y las condiciones de la jornada. Un inventario puede describir superficie y ubicación en una fecha de referencia; no muestra necesariamente una grieta abierta hoy. La DGA ofrece el Inventario Público de Glaciares 2022 como catastro [Referencia: dga-inventario-2022](#fuente-dga-inventario-2022). El año forma parte del dato y no debe desaparecer al copiarlo.

Las zonas de acumulación y ablación son conceptos de balance; no equivalen a “zona transitable” y “zona peligrosa”. La nieve puede ocultar grietas en la zona de acumulación [Referencia: nps-grietas](#fuente-nps-grietas). Una superficie blanca continua no demuestra continuidad mecánica. Una huella previa tampoco revela qué soporte queda bajo ella ni si el grupo anterior tenía las mismas condiciones.

La forma visible del hielo responde a flujo, lecho y fracturación. El guía debe aprender a reconocer cuándo la información excede su capacidad de evaluación. Esta unidad no proporciona distancias de cordada, método de encordamiento ni rescate en grietas. Tampoco propone acercarse a un serac para observar su estructura.

La comunicación con pasajeros requiere evitar dos extremos: banalizar el paisaje por ser turístico o describir cada forma como desastre inevitable. Explica el proceso, el límite del conocimiento y la decisión del grupo dentro del alcance profesional. Un cambio de objetivo puede ser una decisión competente aunque se conserve el interés educativo desde otro lugar.

## Caso práctico: una huella en Tronador

Una imagen antigua muestra un track sobre hielo. Alguien afirma que sirve como ruta porque “los glaciares solo retroceden lentamente”. Enumera lo que falta: fecha y contexto, cambios del recorrido, formación del equipo, información actual y alternativas. Explica por qué el inventario y el track cumplen funciones diferentes. No diseñes un rescate improvisado para compensar la falta de preparación.

## Errores frecuentes y señales de alerta

Confundir nieve con glaciar, retroceso con inmovilidad, mapa de hielo con mapa de grietas o ausencia de grietas visibles con ausencia de aberturas. Un dato sin fecha no debe ganar precisión al convertirse en relato.

## Autoevaluación y respuestas explicadas

¿Balance de masa y posición del frente son idénticos? No: son medidas relacionadas pero distintas. ¿Una huella permite evaluar un puente? No: no entrega su resistencia ni las condiciones futuras.

## Ejercicios y práctica presencial

En aula, compara dos mapas con fechas distintas y describe solo los cambios que permiten sus escalas. Cualquier reconocimiento en ambiente glaciar requiere formación presencial, supervisión competente y evaluación de condiciones; no es ejercicio individual.

## Evidencia requerida

Esquema acumulación/ablación, tres límites de un inventario y una decisión de no avanzar correctamente argumentada. El quiz acredita únicamente comprensión.

## Relaciones con otras habilidades

Prerrequisitos para futura progresión glaciar: navegación, meteorología, cuerda, evaluación de terreno y práctica supervisada. Esta materia requiere formación presencial; no acredita rescate en grietas.
