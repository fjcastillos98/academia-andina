---
{
  "title": "Autorrescate en cuerda: siete escenarios de análisis",
  "description": "Comparar siete escenarios de fallo o incapacidad en sistemas de cuerda.",
  "module": "M23",
  "code": "E44-23",
  "order": 322,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U44-05",
  "skills": [
    "s44-autorrescate-escenarios"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Comparar siete escenarios de fallo o incapacidad en sistemas de cuerda.",
    "Identificar información, riesgos y alternativas antes de plantear una transferencia de carga.",
    "Definir criterios de abandono y necesidades de formación presencial para cada caso."
  ],
  "prerequisites": [
    "s44-autorrescate-prioridades"
  ],
  "sources": [
    "petzl-transferencia",
    "petzl-rescate-principios"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "rescate-decision",
    "izado-bloques"
  ],
  "preparation": [
    "Explicar los conceptos sin confundir un modelo con una maniobra.",
    "Reconocer al menos dos errores del caso y justificar una alternativa.",
    "Identificar la documentación y las competencias prácticas que faltan."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "petzl-transferencia",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un sistema bloqueado debe liberarse…",
        "options": [
          "Por ensayo y error.",
          "Comprendiendo función, control y transición con formación específica.",
          "Cortando primero el elemento que parece sobrante."
        ],
        "answer": 1,
        "explanation": "La liberación necesita continuidad de protección.",
        "rationales": [
          "Puede perderse control.",
          "La liberación necesita continuidad de protección.",
          "No se deduce qué sostiene la carga por apariencia."
        ],
        "source": "petzl-transferencia",
        "kind": "caso",
        "difficulty": "intermedia"
      },
      {
        "prompt": "Al analizar una transferencia importa…",
        "options": [
          "Solo el estado final.",
          "Solo la rapidez.",
          "Qué sostiene la carga en cada fase."
        ],
        "answer": 2,
        "explanation": "Cada estado debe mantener la función prevista.",
        "rationales": [
          "La transición puede introducir un fallo.",
          "La rapidez no prueba control.",
          "Cada estado debe mantener la función prevista."
        ],
        "source": "petzl-transferencia",
        "kind": "aplicación",
        "difficulty": "intermedia"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

Un escenario académico permite analizar decisiones sin ejecutar maniobras. Transferencia de carga es un cambio de qué sistema sostiene la carga; no significa abrir conexiones. Persona suspendida, asegurador incapacitado y componente dañado plantean problemas distintos.

## Teoría y decisiones

1. **Persona suspendida:** falta conocer estado, localización, trayectoria, sistema y acceso. Riesgo: deterioro y exposición del respondiente. Alternativa: activar apoyo y organizar protección dentro de capacidad; no improvisar acceso. Recursos: comunicación, personal formado y plan. Abandonar un intento propio si no se puede mantener control; no abandonar la atención ni la solicitud de ayuda.

2. **Incapacidad del asegurador:** identificar quién mantiene la función de control y qué recursos formados existen. Riesgo: dejar una función crítica sin responsable. Error: asumir que cualquier pasajero puede sustituirlo. La sustitución se estudia presencialmente, nunca se deduce de un dibujo.

3. **Descenso controlado:** comprobar destino, recorrido, longitud, soporte y comunicación. Alternativa: esperar apoyo o revisar otro objetivo si el movimiento añade exposición. El criterio de no inicio es la falta de una función crítica demostrada, no la incomodidad de esperar.

4. **Transferencia de carga:** identificar estado inicial, final y quién sostiene cada fase. La elasticidad y los cambios de posición pueden complicarla [Referencia: petzl-transferencia](#fuente-petzl-transferencia). Error: abrir antes de demostrar el nuevo control. Requiere taller avanzado y equipo específico; aquí solo se analiza información.

5. **Rescate desde reunión:** además del afectado, considerar operador y resto del grupo. ¿Qué recursos quedan para quien permanece arriba? No asumir que la reunión diseñada para asegurar admite otra tarea. Alternativa: apoyo especializado y conservación del control disponible.

6. **Sistema bloqueado:** diferenciar retención prevista de atasco o función desconocida. Error: forzar, cortar o liberar por intuición. Se necesita diagnóstico por personal competente, continuidad de protección y un plan alternativo. Criterio de parada: no poder explicar el estado actual.

7. **Fallo de componente:** identificar consecuencias y causas comunes sin manipular apresuradamente. Un segundo componente puede depender del mismo soporte. Recursos: medios y personal capaces de evaluar y estabilizar; práctica mediante fallos simulados en mesa, jamás provocados sobre personas.

## Caso práctico y aplicación al guiado

El instructor entrega tarjetas con información incompleta y cambia un dato a mitad del análisis. Para cada tarjeta, prepara información/peligros/decisión/alternativas/error/criterio de no inicio/recursos/práctica. Debes poder explicar qué dato cambió tu decisión, no recitar una secuencia única.

## Errores frecuentes y señales de alerta

Tratar los siete casos como la misma maniobra; introducir un dispositivo que no está disponible; prometer que un respaldo soportará cualquier fallo; confundir simulación con autorización; incluir tiempos médicos inventados.

## Autoevaluación y respuestas explicadas

¿Qué comparten los escenarios? **Necesidad de control, información y límites de capacidad.** ¿Por qué no basta conocer el estado final? **La fase intermedia puede perder protección o cambiar cargas.**

## Ejercicios y práctica presencial

Resolución individual en papel y debate supervisado. Simulaciones físicas únicamente en taller dirigido con diseño y respaldo definidos por instructor competente. No realizar pruebas de fallos con personas ni ejercicios de suspensión prolongada.

## Evidencia requerida

Siete fichas analíticas, revisiones tras datos nuevos y devolución de instructor. La competencia de cada maniobra se evalúa separadamente en formación presencial.

## Relaciones con otras habilidades

Revisa los prerrequisitos y el contrato de habilidad de esta unidad en el programa. Contrasta la explicación con las fuentes indicadas: las cifras de un ejercicio no son límites de uso de un equipo. Toda transferencia a una situación con personas requiere formación y revisión presencial.
