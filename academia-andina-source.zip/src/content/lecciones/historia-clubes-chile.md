---
{
  "title": "Andinismo chileno: clubes y archivos de expediciones",
  "description": "Distingue historia institucional de historia completa del andinismo.",
  "module": "M17",
  "code": "E13-03",
  "order": 1303,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U13-03",
  "skills": [
    "s13-historia-clubes-chile"
  ],
  "critical": false,
  "reviewDate": "2026-10-27",
  "objectives": [
    "Distingue historia institucional de historia completa del andinismo.",
    "Define qué significa primera ascensión en una afirmación concreta."
  ],
  "prerequisites": [
    "s13-historia-alpes-personas"
  ],
  "sources": [
    "e13-dav",
    "e13-andina"
  ],
  "pending": [
    "Revisión por historiador o especialista de patrimonio e instructor de montaña pendiente.",
    "Primeras ascensiones de Los Lagos, historia completa de escuelas técnicas y testimonios comunitarios requieren investigación y revisión adicionales.",
    "Casos y rúbricas son propuestas pedagógicas originales; no certifican guiado ni competencia práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Dos páginas copian la misma crónica. Son…",
        "options": [
          "Dos comprobaciones independientes.",
          "Dos reproducciones de una misma cadena documental.",
          "Prueba de una nueva ruta."
        ],
        "answer": 1,
        "explanation": "Identifica la dependencia entre testimonios.",
        "rationales": [
          "La copia no añade independencia.",
          "Identifica la dependencia entre testimonios.",
          "No documentan por ello una ruta nueva."
        ],
        "source": "e13-dav",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "El boletín de un club demuestra…",
        "options": [
          "Que antes no hubo presencia en los Andes.",
          "Que toda actividad chilena pertenecía a ese club.",
          "Una práctica de registro de esa institución."
        ],
        "answer": 2,
        "explanation": "Es una conclusión delimitada.",
        "rationales": [
          "El archivo no determina el inicio del poblamiento.",
          "La institución no representa toda actividad.",
          "Es una conclusión delimitada."
        ],
        "source": "e13-dav",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Primera ascensión invernal y primera absoluta…",
        "options": [
          "Son afirmaciones distintas que requieren definir alcance.",
          "Son siempre lo mismo.",
          "Se resuelven con el año de publicación."
        ],
        "answer": 0,
        "explanation": "Distingue categorías de primicia.",
        "rationales": [
          "Distingue categorías de primicia.",
          "La estación modifica el alcance.",
          "El año editorial no define la actividad."
        ],
        "source": "e13-dav",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue historia institucional de historia completa del andinismo.",
    "Define qué significa primera ascensión en una afirmación concreta.",
    "Reconoce dependencia entre fuentes que se copian."
  ],
  "openAssessment": {
    "prompt": "Construye un expediente ficticio de primera ascensión con campos vacíos explícitos. Incluye tres documentos que buscarías y qué dato debería aportar cada uno.",
    "rubric": [
      "Distingue historia institucional de historia completa del andinismo.",
      "Define qué significa primera ascensión en una afirmación concreta.",
      "Reconoce dependencia entre fuentes que se copian."
    ],
    "source": "e13-dav",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ACADÉMICA PENDIENTE.** Historia documental e interpretación: no es formación para ejecutar maniobras. No guardes datos médicos, contraseñas, datos privados de terceros ni conocimientos de acceso restringido.

## Conceptos clave y propósito

Asociacionismo, boletín, revista, archivo incompleto y primera ascensión documentada. Diferenciar una cumbre, una vía y una variante estacional.

## Teoría y toma de decisiones

La historia institucional del DAV sitúa la creación del Club Excursionista Concón en 1909 y el cambio de nombre a Deutscher Ausflugverein Valparaíso en 1910. También menciona boletines desde 1919 y Revista Andina desde 1924. Su archivo digital presenta números tempranos que permiten formular investigaciones específicas sobre excursiones, imágenes y relatos.

Estos registros muestran una forma de organización y publicación del montañismo chileno. No prueban que la relación con los Andes comenzara con esos clubes. Tampoco una historia institucional representa por sí sola a todos los clubes, regiones o grupos sociales. La denominación «primer registro» que aparece en un portal necesita una comparación documental más amplia antes de adoptarla como afirmación universal.

Para investigar una primera ascensión prepara un expediente: montaña identificada, fecha del evento, vía, temporada, participantes y documento que los vincule. Pregunta si el texto afirma cumbre principal, antecumbre o solo intento. Compara documentos independientes; dos sitios que copian el mismo relato constituyen una cadena de transmisión, no dos corroboraciones. Para Los Lagos, las primeras ascensiones de las fichas existentes continúan pendientes cuando no se dispone de evidencia suficiente.

Fuentes de esta unidad: [Referencia 1](#fuente-e13-dav) · [Referencia 2](#fuente-e13-andina). Los ejercicios y criterios siguientes son diseño educativo original, no protocolos de las organizaciones citadas.

## Procedimiento: lectura, comprobaciones y variantes

**PROCEDIMIENTO — análisis documental:** Parte del índice de Revista Andina y selecciona un número. Registra qué se puede saber del índice y qué exige abrir el ejemplar. Después prepara una solicitud de consulta con pregunta acotada, sin contactar ni publicar datos de terceros como parte del ejercicio.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Dos blogs repiten la misma fecha de una primera cumbre sin identificar el documento original. Diseña un expediente de comprobación y una formulación provisional para el visitante.

## Errores frecuentes y puntos críticos de seguridad

Confundir inicio de un club con inicio de actividad; duplicar fuentes copiadas; omitir vía o temporada; equiparar un relato de intento con cumbre.

Las maniobras críticas requieren formación práctica y supervisión de instructor competente. Estudiar cómo se actuaba antiguamente no habilita a reproducirlo. Este taller no requiere exposición en terreno.

## Material y equipo relacionado

Índice de archivo, ficha bibliográfica y mapa para identificar topónimos, sin convertirlo en trazado de navegación.

[Inventario educativo](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con una evidencia y un límite: Distingue historia institucional de historia completa del andinismo.
- Explica con una evidencia y un límite: Define qué significa primera ascensión en una afirmación concreta.
- Explica con una evidencia y un límite: Reconoce dependencia entre fuentes que se copian.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Construye un expediente ficticio de primera ascensión con campos vacíos explícitos. Incluye tres documentos que buscarías y qué dato debería aportar cada uno.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Taller con historiador o archivero para evaluar procedencia y suficiencia de un expediente, sin declarar una primicia nueva.

## Evidencia requerida y criterios de competencia

- Distingue historia institucional de historia completa del andinismo.
- Define qué significa primera ascensión en una afirmación concreta.
- Reconoce dependencia entre fuentes que se copian.

**COMPETENCIA:** se requiere revisión humana contextual del trabajo. Una lectura, quiz o guion no certifica guiado, interpretación profesional ni maniobras técnicas. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s13-historia-clubes-chile). Registra fecha, lugar de estudio, documentos, habilidad, repeticiones, errores, correcciones, supervisor y evidencia textual no sensible. Diferencia taller ficticio y actividad real; no inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Historia y patrimonio](../../historia/) · [Territorio](../../territorio/) · [Geología](../../geologia/) · [Ecología](../../ecologia/) · [Programa](../../programa/). La interpretación histórica complementa la formación técnica; no sustituye condiciones ni permisos actuales.
