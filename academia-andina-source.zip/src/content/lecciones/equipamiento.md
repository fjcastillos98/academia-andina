---
{
  "title": "Equipamiento personal y colectivo",
  "description": "Seleccionar recursos por función, compatibilidad y capacidad de uso; no por acumulación.",
  "module": "M00",
  "code": "P1-G",
  "order": 107,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "pilot",
  "reviewDate": "2026-10-22",
  "objectives": [
    "Separar equipo personal y funciones colectivas.",
    "Relacionar cada pieza técnica con su manual y formación necesaria.",
    "Detectar un recurso compartido sin responsable o respaldo."
  ],
  "prerequisites": [
    "Estudiar Cartografía, orientación y navegación y explicar sus límites."
  ],
  "sources": [
    "nps-equipo",
    "petzl-anclajes"
  ],
  "pending": [
    "Revisión pedagógica y validación de criterios por instructor competente.",
    "Aplicación territorial en Los Lagos: requiere verificación situada."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Tener una Micro Traxion demuestra…",
        "options": [
          "Que sabes rescatar una caída.",
          "Disponibilidad de una pieza, no competencia de uso.",
          "Que cualquier cuerda es compatible."
        ],
        "answer": 1,
        "explanation": "Propiedad, compatibilidad y competencia son cuestiones diferentes; las últimas requieren verificación y práctica."
      },
      {
        "prompt": "Para asignar equipo colectivo conviene…",
        "options": [
          "Contarlo y repartirlo sin más.",
          "Darlo siempre al más fuerte.",
          "Definir función, responsable y dependencias."
        ],
        "answer": 2,
        "explanation": "La distribución debe sostener las funciones del grupo, no solo equilibrar cantidades."
      }
    ]
  },
  "pilot": {
    "position": 7,
    "requires": [
      "cartografia-orientacion"
    ],
    "critical": false,
    "classifications": [
      "TEORÍA",
      "PROCEDIMIENTO",
      "PRÁCTICA INDIVIDUAL",
      "PRÁCTICA SUPERVISADA",
      "COMPETENCIA"
    ],
    "relatedModules": [
      "M00"
    ],
    "criteria": [
      "Justifica la selección por funciones, identifica una dependencia compartida y no declara compatibilidad ni aptitud cuando falta evidencia documental o práctica."
    ]
  }
}
---
## Conceptos

**TEORÍA.** El NPS organiza recursos esenciales por funciones como navegación, iluminación, abrigo, hidratación, alimentación y refugio de emergencia [National Park Service](#fuente-nps-equipo). Es un punto de partida, no una lista universal para toda montaña ni una autorización para hacer fuego. Restricciones locales y actividad determinan qué corresponde llevar.

En este curso distinguimos disponibilidad («lo tengo»), preparación («he comprobado su estado y función») y capacidad («puedo demostrar su uso en el contexto evaluado»). Comprar equipo solo modifica la primera columna.

## Desarrollo teórico y toma de decisiones

**PROCEDIMIENTO · análisis y preparación.** Construye un inventario con pieza y modelo exacto, función prevista, propietario, persona responsable, manual localizado, estado de inspección y formación pendiente. Un equipo colectivo necesita saber quién lo lleva y qué ocurre si esa persona se separa.

| Equipo de Filo Austral | Pregunta de formación antes de usarlo |
| --- | --- |
| Casco y arnés | ¿Ajuste, uso previsto e inspección según su fabricante? |
| Piolet y crampones | ¿Compatibilidad con bota y terreno? ¿Práctica supervisada? |
| Cuerda, mosquetones y cintas | ¿Identificación, estado y compatibilidad del sistema? |
| Tornillos de hielo y estacas | ¿Sustrato y colocación evaluados por instructor? |
| ATC Guide | ¿Modelo y manual correctos? ¿Modo de uso enseñado y evaluado? |
| Micro Traxion, poleas y rescate | ¿Función y límites específicos comprobados en el manual? |
| InReach Mini 2 y VHF | ¿Servicio, energía, operación y comunicaciones preparadas? |

Esta tabla es una agenda de revisión, no especifica diámetros, cargas, modos de montaje ni compatibilidades. Los manuales concretos de tus unidades y su historial **requieren verificación**. No se asume que ATC Guide y otros aparatos funcionen igual ni que una polea sea un asegurador intercambiable.

## Ejemplo

Actividad didáctica original, no descripción de una ruta operativa.

## Caso de estudio

Caso ficticio: el grupo lleva dos teléfonos, pero ambos dependen de un único cargador y solo uno tiene el mapa. ¿Hay verdadera redundancia de navegación? Dibuja las dependencias de energía, mapas y usuarios.

Respuesta orientativa: contar objetos no basta; hay fallos comunes. Propón una distribución y comprueba que quien asume una función sabe operarla. No prescribas un número universal de dispositivos.

## Errores frecuentes

Confundir cantidad con redundancia; estrenar equipo crítico en una salida exigente; transportar material sin saber qué función cumple; ignorar el historial de una pieza prestada.

## Límites y puntos críticos de seguridad

No probar sistemas de protección de caídas mediante cargas improvisadas. Aislar material dudoso para revisión competente conforme al fabricante.

## Material y equipo relacionado

Inventario completo de Filo Austral y manuales específicos. No registrar números sensibles de cuentas, contraseñas ni datos médicos.

## Recuperación activa

- ¿Por qué dos dispositivos pueden compartir un único fallo?
- ¿Qué dato falta cuando solo conoces el nombre comercial de una pieza?

Responde antes de consultar el texto. Luego anota qué cambiaste y por qué; el recuerdo sin justificación no basta.

## Ejercicio y práctica

**PRÁCTICA INDIVIDUAL** limitada a análisis en mesa u observación segura. En casa, audita cinco piezas propias sin ponerlas en carga. Completa función, modelo, manual y estado de formación. Deja explícito cualquier dato desconocido.

**PRÁCTICA SUPERVISADA.** Un instructor competente selecciona el contexto y observa la ejecución pertinente; este texto no autoriza a realizar maniobras técnicas sin esa formación. Antes de la sesión, acuerda objetivo, límites y cómo se interrumpirá el ejercicio.

## Registro de práctica

Abre el Diario de prácticas desde la navegación y selecciona esta habilidad. Registra fecha, lugar, condiciones, actividad, equipo, repeticiones, errores, correcciones y evidencia. Identifica al supervisor solo cuando estuvo presente. La confianza es una percepción, no un resultado de competencia. No incluyas datos médicos, contraseñas ni información privada de terceros.

## Criterios de revisión y competencia

**COMPETENCIA · evaluación pendiente.** Justifica la selección por funciones, identifica una dependencia compartida y no declara compatibilidad ni aptitud cuando falta evidencia documental o práctica.

La evaluación debe indicar quién observó, qué contexto y evidencia revisó, qué criterio aplicó y cuál fue el resultado. El diario conserva una declaración del usuario: no verifica identidad ni credenciales del evaluador y no emite certificaciones. Una lectura o quiz nunca demuestra ejecución técnica.

## Próximos pasos y relación con otros módulos

Continúa con **Nudos fundamentales**.

Relación con el currículo original: M00. Esta secuencia pertenece al bloque piloto **Módulo 1 — Fundamentales**; no renumera las 376 entradas pendientes del mapa original. Meteorología, navegación y decisiones se revisitan en montaña estival, invernal y glaciar; no son prerrequisitos prácticos ya acreditados.
