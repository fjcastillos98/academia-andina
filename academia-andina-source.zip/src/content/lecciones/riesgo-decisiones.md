---
{
  "title": "Gestión dinámica del riesgo y decisiones 3×3",
  "description": "Relacionar peligro, exposición, vulnerabilidad y consecuencias.",
  "module": "M13",
  "code": "E4-03",
  "order": 203,
  "minutes": 45,
  "level": "Intermedio",
  "status": "development",
  "reviewDate": "2026-10-22",
  "unit": "U4-03",
  "skills": [
    "s4-riesgo-decisiones"
  ],
  "critical": false,
  "objectives": [
    "Relacionar peligro, exposición, vulnerabilidad y consecuencias.",
    "Usar 3×3 como estructura de revisión y distinguir otras herramientas.",
    "Definir criterios observables para continuar, modificar o abandonar."
  ],
  "prerequisites": [
    "Completar estudio de Fundamentales; la práctica previa debe revisarse presencialmente.",
    "Estudiar Planificación y operación de una salida."
  ],
  "sources": [
    "slf-3x3",
    "nps-plan"
  ],
  "pending": [
    "Revisión pedagógica y evaluación situada por instructor competente.",
    "Condiciones, accesos, permisos y compatibilidad del equipo requieren verificación para cada actividad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una medida deja riesgo residual. ¿Qué corresponde?",
        "options": [
          "Declarar riesgo cero.",
          "Identificar lo que permanece y revisar alternativas.",
          "Ignorarlo si no hubo incidentes."
        ],
        "answer": 1,
        "explanation": "Los controles no eliminan automáticamente todos los escenarios adversos."
      },
      {
        "prompt": "¿Qué hace una matriz de colores?",
        "options": [
          "Ordena una valoración; no convierte supuestos en probabilidades medidas.",
          "Certifica una ruta.",
          "Reemplaza la revisión del grupo."
        ],
        "answer": 0,
        "explanation": "La herramienta necesita evidencia y límites explícitos."
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

**TEORÍA.** Recupera la distinción de peligro, exposición y consecuencia del piloto. Añadimos **vulnerabilidad**: condiciones del grupo o sistema que pueden aumentar el daño ante el peligro; **probabilidad**: posibilidad de un resultado en un contexto definido; **control**: medida para reducir exposición o consecuencias; **riesgo residual**: lo que permanece tras aplicar controles. No confundas incertidumbre con probabilidad baja.

Ejemplo original: una superficie resbaladiza es una condición peligrosa; atravesarla crea exposición; fatiga y escasa destreza pueden aumentar vulnerabilidad; una caída tiene consecuencias distintas según dónde ocurra. Un apoyo o cambio de calzado no elimina automáticamente todas las consecuencias. El control debe estar disponible, funcionar y ser usado por personas capaces.

## Teoría: decidir con evidencia incompleta

Una matriz cualitativa ayuda a conversar, pero sus colores no son mediciones. Multiplicar números asignados sin fundamento puede producir una apariencia de precisión. Escribe qué evidencia sostiene tu valoración y qué información podría modificarla. No sumes seguridad por tener más objetos en la mochila.

Para el taller utilizamos una **ficha editorial de decisión**, no un estándar validado: situación → peligros → personas expuestas → controles disponibles → incertidumbres → alternativas → decisión → revisión. Evita una lista ilimitada de peligros sin relación con acciones: selecciona los que podrían cambiar el plan y explica por qué.

## 3×3 y otras herramientas: no son equivalentes

El marco SLF/KAT del piloto organiza condiciones, terreno y personas en preparación, evaluación local y punto concreto [Referencia: slf-3x3](#fuente-slf-3x3). Aquí lo reutilizamos como adaptación pedagógica estival; no enseña a decidir estabilidad de pendientes nevadas ni aplica automáticamente un método de reducción de avalanchas.

En casa pregunta por datos y supuestos. Al inicio compara lo observado con el expediente. Ante un tramo revisa la exposición concreta y la capacidad actual del grupo. Las nueve casillas se comunican: una persona fatigada cambia el tiempo necesario y la exposición a un cambio meteorológico. No cierres “personas” al terminar el briefing.

Un **checklist** reduce omisiones de tareas conocidas; no resuelve una situación nueva. Un **premortem didáctico** pregunta “si el plan fracasara, ¿qué supuesto pudo fallar?”; produce hipótesis que deben contrastarse. Un **registro de decisiones** permite revisar qué se sabía en ese momento. Estas herramientas cumplen funciones distintas y ninguna autoriza por sí sola a continuar.

## Factores humanos y comunicación

En los casos del curso, **sesgo de confirmación** significa seleccionar los datos que apoyan el plan preferido; **exceso de confianza**, trasladar éxitos previos a un contexto no comprobado; **presión de objetivo**, tratar llegar como obligación; **normalización de la desviación**, aceptar repetidamente una desviación porque aún no tuvo consecuencias. Son lentes de análisis del caso, no diagnósticos de personas.

La presión de grupo, cliente o tiempo puede silenciar objeciones. Establece una pregunta explícita: “¿qué estamos suponiendo que no sabemos?”. Pide primero la observación de quien tiene menos voz. El responsable explica la decisión; escuchar no exige someter la seguridad a votación. Un pasajero puede señalar un problema aunque no tenga vocabulario técnico.

## Criterios de continuación y aborto

Formula condiciones observables: una referencia necesaria no puede confirmarse; el retorno deja de ser compatible con la reserva prevista; un control esencial no está disponible; el terreno requiere una técnica que no está evaluada; el grupo no puede mantener la comunicación acordada. Los valores numéricos concretos, si se usan, necesitan fundamento, contexto y responsable; no hay un umbral universal para todas las rutas.

Un plan A/B/C debe considerar efectos secundarios. Abandonar un objetivo no significa tomar la bajada más corta si introduce una exposición nueva. Compara las alternativas desde la situación actual y evita que la prisa por salir produzca otro problema.

## Caso práctico: Osorno, escenario ficticio

El grupo se retrasa, el viento dificulta escuchar y una persona resta importancia a tropiezos recientes. El cliente recuerda que “ya falta poco”. No se afirma ninguna condición actual del volcán.

Identifica: hechos observados, información faltante, presión comercial y alternativas. Respuesta orientativa: no tratar los tres cambios de forma aislada; revisar capacidad de retorno y comunicación antes de comprometerse más. La decisión justificada puede ser detener el avance y reorganizar la retirada; el destino concreto requiere información del lugar.

## Errores frecuentes y señales de alerta

Usar ausencia de accidentes como prueba; negociar un límite después de cruzarlo; hacer una revisión sin escuchar; esconder incertidumbres para parecer competente. Revisa especialmente la frase “siempre lo hacemos así” cuando han cambiado grupo o condiciones.

## Autoevaluación y respuestas explicadas

1. ¿El riesgo residual desaparece al completar controles? **No: hay que identificar lo que queda y decidir si el plan sigue siendo defendible.**
2. ¿El 3×3 y una lista de equipo son intercambiables? **No: uno organiza revisión contextual; la otra comprueba tareas o recursos.**

## Ejercicios y práctica presencial

En mesa, aplica la ficha a cambio meteorológico, pasajero fatigado, lesión hipotética, retraso, pérdida de ruta y deterioro del descenso. Para cada caso aporta una razón para revisar tu primera respuesta. En práctica supervisada, un instructor introduce un cambio simulado sin crear una exposición real y observa comunicación y decisión.

## Evidencia requerida

Dos versiones fechadas de una decisión, el dato que cambió y una alternativa descartada con motivo. Explicar límites y detenerse ante información insuficiente puede ser evidencia más útil que una decisión rápida.

## Relaciones con otras habilidades

Esta unidad se integra en la ruta estival. Consulta la ficha de habilidad y sus prerrequisitos en el programa. Registra práctica y evaluación por separado: estudiar y responder correctamente no acredita ejecución. Los ejercicios son propuestas didácticas originales; los casos no son rutas operativas.
