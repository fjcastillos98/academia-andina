---
{
  "title": "Mal agudo de montaña: reconocer y detener la progresión",
  "description": "Reconocer un patrón compatible tras ascenso reciente sin diagnosticar por quiz.",
  "module": "M03",
  "code": "E9-03",
  "order": 903,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U9-03",
  "skills": [
    "s9-mam-altitud"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Reconocer un patrón compatible tras ascenso reciente sin diagnosticar por quiz.",
    "Distinguir observación, deterioro y decisión de no continuar ascendiendo."
  ],
  "prerequisites": [
    "s9-aclimatacion-altitud"
  ],
  "sources": [
    "e9-wms",
    "e9-cdc"
  ],
  "pending": [
    "Revisión médica por profesional de medicina de montaña y revisión docente por instructor pendientes. No se ha evaluado atención clínica ni rescate.",
    "Casos, ejercicios y criterios son propuestas pedagógicas originales; no autorizan decisiones clínicas individuales.",
    "Condiciones de rutas, comunicaciones y recursos de atención locales requieren verificación antes de cada salida."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "El patrón cefalea y náuseas tras ascenso reciente…",
        "options": [
          "Es compatible y necesita valoración contextual.",
          "Demuestra una causa única.",
          "Se descarta si la persona es deportista."
        ],
        "answer": 0,
        "explanation": "Los síntomas y su cronología orientan, pero no son exclusivos.",
        "rationales": [
          "Los síntomas y su cronología orientan, pero no son exclusivos.",
          "Existen otras causas posibles.",
          "La condición física no descarta enfermedad."
        ],
        "source": "e9-wms",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Mientras persisten síntomas compatibles, la siguiente pernocta…",
        "options": [
          "Debe ser más alta para acelerar adaptación.",
          "No debe ganarse en altitud.",
          "Depende solo del dinero pagado."
        ],
        "answer": 1,
        "explanation": "Evitar seguir ascendiendo es esencial.",
        "rationales": [
          "No es una estrategia de tratamiento.",
          "Evitar seguir ascendiendo es esencial.",
          "El coste no determina la condición de la persona."
        ],
        "source": "e9-wms",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Si empeora a la misma altura…",
        "options": [
          "Esperar hasta cumplir el horario.",
          "Ocultarlo para no preocupar.",
          "Priorizar descenso y atención."
        ],
        "answer": 2,
        "explanation": "El deterioro cambia la prioridad.",
        "rationales": [
          "El horario debe revisarse.",
          "Impide una respuesta oportuna.",
          "El deterioro cambia la prioridad."
        ],
        "source": "e9-wms",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Relaciona el cambio con ascenso reciente sin asegurar diagnóstico.",
    "Evita mayor pernocta mientras hay síntomas compatibles.",
    "Identifica deterioro y señales que requieren emergencia."
  ],
  "openAssessment": {
    "prompt": "Redacta un briefing de 60 segundos que normalice avisar del malestar y permita cambiar el objetivo sin culpabilizar.",
    "rubric": [
      "Relaciona el cambio con ascenso reciente sin asegurar diagnóstico.",
      "Evita mayor pernocta mientras hay síntomas compatibles.",
      "Identifica deterioro y señales que requieren emergencia."
    ],
    "source": "e9-wms",
    "difficulty": "integración"
  },
  "diagrams": [
    "e9-observar"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN MÉDICA Y DE INSTRUCTOR PENDIENTES.** No es una herramienta de diagnóstico ni prescripción. Los casos son ficticios; no introduzcas datos médicos personales. Una emergencia real requiere asistencia urgente, no completar esta lección.

## Conceptos clave y propósito

MAM/AMS, cronología, síntomas, función, evolución y diagnósticos alternativos.

## Teoría y toma de decisiones

MAM es la sigla española de mal agudo de montaña; AMS es su sigla inglesa. Tras ascenso reciente, cefalea acompañada de náuseas, pérdida de apetito, mareo o fatiga es un patrón compatible. La cronología y la capacidad de desenvolverse importan; los síntomas no son exclusivos de esta enfermedad. [WMS, diagnóstico](#fuente-e9-wms).

La decisión educativa clave no es elegir una etiqueta con seguridad. Es evitar que una persona enferma continúe ganando altitud para dormir. Si empeora a la misma elevación, el descenso y la atención tienen prioridad. Confusión, dificultad de coordinación o disnea en reposo requieren una respuesta de emergencia, no seguir trabajando este ejercicio. [CDC, prevención de enfermedad grave](#fuente-e9-cdc).

En una conversación de grupo, «no quiero retrasarlos» es información sobre presión social, no sobre recuperación. Un buen briefing permite comunicar malestar sin asociarlo a debilidad. La propuesta de formación consiste en preguntar qué cambió y cuándo, repetir lo entendido y comunicar el cambio de plan.

No se implementa una puntuación diagnóstica ni una pantalla de aptitud. La revisión de un caso puede identificar información ausente sin solicitarla al estudiante como dato personal. Los cuadros reales necesitan valoración; atribuir toda cefalea a altitud también puede ocultar otro problema.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación y análisis de aula.** En una simulación, detén la propuesta de ganar pernocta y transmite la cronología del caso al responsable sanitario. Distingue estabilidad de empeoramiento. Comprueba alternativas de descenso y acompañamiento. No prescribas fármacos para sostener el programa ni interpretes alivio transitorio como permiso para seguir.

Las indicaciones clínicas dependen del paciente y los recursos. Las maniobras de movilización, oxigenoterapia y rescate requieren formación práctica y supervisión competente. No extrapolar un caso de escritorio a una actuación real ni elegir fármacos a partir de un quiz.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Tras una noche más alta, un personaje ficticio presenta cefalea y náuseas, y propone subir porque ya pagó el transporte. El caso no aporta evaluación médica. Identifica una decisión que sí puede tomarse sin cerrar el diagnóstico.

Identifica hechos, incertidumbres y decisiones. Explica qué información podría modificar tu propuesta. La rúbrica es docente, no un protocolo avalado por las instituciones citadas.

## Errores frecuentes y puntos críticos de seguridad

Banalizar síntomas por buena forma física; esperar al quiz para actuar; presionar para continuar; dar por curado a quien deja de mencionar molestias.

## Material y equipo relacionado

Medios de comunicación, información de acceso a atención y material de primeros auxilios según formación. No se configura aquí un botiquín farmacológico personal.

[Inventario educativo](../../equipo/). Tener el recurso no demuestra saber utilizarlo. El diario no es una ficha clínica.

## Autoevaluación y recuperación activa

- ¿Puedes explicar el concepto central sin confundirlo con una autorización de salida?
- ¿Qué dato falta en el escenario y qué decisión depende de él?
- ¿Qué tarea exige formación sanitaria o técnica y no se evalúa aquí?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Redacta un briefing de 60 segundos que normalice avisar del malestar y permita cambiar el objetivo sin culpabilizar.

**PRÁCTICA SUPERVISADA — propuesta:** Role-play con instructor de primeros auxilios remotos: observador, participante y coordinador. Solo síntomas ficticios; revisar escucha y decisiones, no realizar pruebas médicas.

## Evidencia requerida y criterios de competencia

- Relaciona el cambio con ascenso reciente sin asegurar diagnóstico.
- Evita mayor pernocta mientras hay síntomas compatibles.
- Identifica deterioro y señales que requieren emergencia.

**COMPETENCIA:** requiere observación contextual por instructor competente y revisión sanitaria cuando corresponda. Estos criterios evalúan preparación, comunicación y límites de actuación; no habilitan como profesional sanitario ni guía. La plataforma no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de la habilidad](../../practicas/?habilidad=s9-mam-altitud). Registra fecha, actividad, escenario ficticio, equipo, errores, correcciones, supervisor y evidencia del aprendizaje. No incluyas diagnósticos, recetas, mediciones personales ni datos de pacientes. Marca pendiente toda evaluación no realizada.

## Relaciones con otros módulos

[Volver a Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Escalada alpina](../../alpina/) · [Programa](../../programa/). La secuencia académica conecta planificación, comunicación y riesgo; no acredita aptitud clínica ni práctica.
