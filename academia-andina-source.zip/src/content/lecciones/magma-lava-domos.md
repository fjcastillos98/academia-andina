---
{
  "title": "Magma, lava y domos: materiales que construyen relieve",
  "description": "Distingue magma, lava, colada y domo.",
  "module": "M11",
  "code": "E12-03",
  "order": 1203,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U12-03",
  "skills": [
    "s12-magma-lava-domos"
  ],
  "critical": false,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Distingue magma, lava, colada y domo.",
    "Relaciona viscosidad con factores sin convertirlos en regla universal."
  ],
  "prerequisites": [
    "s12-edificios-volcanicos"
  ],
  "sources": [
    "e12-glossary",
    "e12-pdc",
    "e12-viscosity"
  ],
  "pending": [
    "Revisión por especialista en geología y vulcanología e instructor de montaña pendiente. No valida una ruta, acceso ni evacuación.",
    "Alertas actuales, restricciones, cotas discrepantes y condiciones de terreno requieren verificación independiente; no hay datos operativos en tiempo real.",
    "Casos, rúbricas y ejercicios originales. Las descripciones científicas no acreditan competencia técnica ni un protocolo universal de seguridad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un domo de lava…",
        "options": [
          "Es una acumulación de lava viscosa próxima a una salida.",
          "Es cualquier hoyo circular.",
          "Demuestra actividad sin peligro."
        ],
        "answer": 0,
        "explanation": "Describe el concepto.",
        "rationales": [
          "Describe el concepto.",
          "Confunde relieve positivo y depresión.",
          "No evalúa mecanismos de peligro."
        ],
        "source": "e12-glossary",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La palabra efusivo…",
        "options": [
          "Elimina riesgo de colapso.",
          "No garantiza ausencia de otros procesos peligrosos.",
          "Autoriza aproximación."
        ],
        "answer": 1,
        "explanation": "No es una calificación de seguridad.",
        "rationales": [
          "Un frente o domo puede colapsar.",
          "No es una calificación de seguridad.",
          "No otorga permisos ni evalúa exposición."
        ],
        "source": "e12-glossary",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "El color de una roca aislada…",
        "options": [
          "Mide gases actuales.",
          "Predice la siguiente erupción.",
          "No basta para describir todo el sistema magmático."
        ],
        "answer": 2,
        "explanation": "Separa indicio y explicación completa.",
        "rationales": [
          "No es una medición de gases.",
          "No contiene información suficiente.",
          "Separa indicio y explicación completa."
        ],
        "source": "e12-glossary",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue magma, lava, colada y domo.",
    "Relaciona viscosidad con factores sin convertirlos en regla universal.",
    "Explica por qué efusión no excluye otros peligros."
  ],
  "openAssessment": {
    "prompt": "Clasifica seis expresiones en material, proceso o forma y redacta dos límites de lo que una foto permite saber.",
    "rubric": [
      "Distingue magma, lava, colada y domo.",
      "Relaciona viscosidad con factores sin convertirlos en regla universal.",
      "Explica por qué efusión no excluye otros peligros."
    ],
    "source": "e12-glossary",
    "difficulty": "integración"
  },
  "diagrams": [
    "e12-procesos"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ESPECIALISTA PENDIENTE.** Estudio documental: no autoriza aproximación a fenómenos volcánicos ni acredita competencia de guía. No se publican alertas actuales. No guardes datos médicos ni contraseñas.

## Conceptos clave y propósito

Magma bajo superficie, lava emitida, viscosidad, gases, agua disuelta, colada y domo. Una roca solidificada conserva información del proceso, pero no equivale al material fundido ni a un indicador actual.

## Teoría y toma de decisiones

El glosario USGS distingue magma bajo superficie de lava emitida. Un domo se forma por acumulación de lava viscosa próxima a una salida; una colada describe su desplazamiento y depósito. Son formas de construcción y pueden coexistir con episodios explosivos. Un domo no es simplemente un volcán pequeño y redondo.

La viscosidad expresa resistencia a fluir. Temperatura, composición y agua disuelta intervienen en el comportamiento de la lava. El escape o retención de gases también importa para la dinámica eruptiva. Estas relaciones no permiten predecir una erupción solo por el color de una roca o una etiqueta como basalto. La descripción exige distinguir tendencia general y comportamiento observado de un sistema.

Un depósito que hoy parece inmóvil puede corresponder a un episodio antiguo; observarlo no informa la estabilidad de un frente activo. Las fuentes sobre corrientes piroclásticas incluyen el colapso de domos como mecanismo de origen. Por eso “efusivo” no significa una actividad sin peligros. El ejercicio consiste en interpretar procesos con documentos y modelos, no aproximarse a lava, fumarolas o domos.

Fuentes de esta unidad: [Referencia 1](#fuente-e12-glossary) · [Referencia 2](#fuente-e12-pdc) · [Referencia 3](#fuente-e12-viscosity). Las aplicaciones de estudio y casos siguientes son elaboración pedagógica original, no protocolos de esas organizaciones.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — lectura y análisis documental:** Diferencia material, proceso y forma: magma/lava, emisión, colada/domo. Indica qué evidencia respalda cada palabra. Variante: fotografía de depósito antiguo frente a reporte de crecimiento activo; no tratar ambas como información temporal equivalente.

El ejercicio se realiza en escritorio o lugar autorizado. No expongas al grupo para comprobar actividad, gases, temperatura o estabilidad. Las maniobras críticas de montaña requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un visitante propone que un domo, por crecer lentamente, es seguro de observar desde cerca. Explica por qué la velocidad de crecimiento no resume sus peligros.

## Errores frecuentes y puntos críticos de seguridad

Confundir domo y caldera; afirmar que toda lava fluye igual; considerar “efusivo” sinónimo de seguro; usar color para identificar composición.

## Material y equipo relacionado

Esquemas y fotografías documentadas, sin experimentos de calentamiento. Equipo de protección no se presenta como permiso de exposición.

[Consultar inventario](../../equipo/). Poseer un dispositivo o equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Justifica con un ejemplo y un límite: Distingue magma, lava, colada y domo.
- Justifica con un ejemplo y un límite: Relaciona viscosidad con factores sin convertirlos en regla universal.
- Justifica con un ejemplo y un límite: Explica por qué efusión no excluye otros peligros.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Clasifica seis expresiones en material, proceso o forma y redacta dos límites de lo que una foto permite saber.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Interpretación de imágenes fechadas con especialista, diferenciando depósitos y actividad; sin demostración sobre un frente real.

## Evidencia requerida y criterios de competencia

- Distingue magma, lava, colada y domo.
- Relaciona viscosidad con factores sin convertirlos en regla universal.
- Explica por qué efusión no excluye otros peligros.

**COMPETENCIA:** estos criterios requieren revisión humana contextual. Leer, resolver un quiz o presentar un documento no certifica guiado ni ejecución de maniobras. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s12-magma-lava-domos). Registra fecha, escenario, fuente, errores, correcciones, supervisor y evidencia de aprendizaje. Separa ejercicio ficticio de actividad real. No inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Geología y vulcanología](../../geologia/) · [Fichas territoriales](../../territorio/) · [Ecología](../../ecologia/) · [Glaciar](../../glaciar/) · [Planificación](../../planificacion/) · [Programa](../../programa/). El conocimiento del origen del relieve complementa la planificación; no reemplaza información actual ni evaluación de terreno.
