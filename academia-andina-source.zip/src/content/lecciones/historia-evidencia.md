---
{
  "title": "Leer historia: testimonio, archivo y afirmación",
  "description": "Distingue fecha del hecho y fecha de publicación.",
  "module": "M17",
  "code": "E13-01",
  "order": 1301,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U13-01",
  "skills": [
    "s13-historia-evidencia"
  ],
  "critical": false,
  "reviewDate": "2026-10-27",
  "objectives": [
    "Distingue fecha del hecho y fecha de publicación.",
    "Explica por qué fuente primaria no equivale a verdad automática."
  ],
  "prerequisites": [
    "s45-historia-montanismo-documentos"
  ],
  "sources": [
    "e13-recuerdos-ficha",
    "e13-recuerdos-critica"
  ],
  "pending": [
    "Revisión por historiador o especialista de patrimonio e instructor de montaña pendiente.",
    "Primeras ascensiones de Los Lagos, historia completa de escuelas técnicas y testimonios comunitarios requieren investigación y revisión adicionales.",
    "Casos y rúbricas son propuestas pedagógicas originales; no certifican guiado ni competencia práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una ficha que fecha un libro en 1882 permite afirmar…",
        "options": [
          "Que toda excursión relatada ocurrió en 1882.",
          "Que esa edición está catalogada con ese año.",
          "Que el autor nunca se equivoca."
        ],
        "answer": 1,
        "explanation": "Es el alcance del metadato bibliográfico.",
        "rationales": [
          "Confunde evento con edición.",
          "Es el alcance del metadato bibliográfico.",
          "La ficha no garantiza la exactitud del relato."
        ],
        "source": "e13-recuerdos-ficha",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una memoria personal sirve para…",
        "options": [
          "Estudiar un testimonio situado y contrastarlo.",
          "Eliminar la necesidad de otras fuentes.",
          "Autorizar una ruta actual."
        ],
        "answer": 0,
        "explanation": "Relaciona testimonio y pregunta.",
        "rationales": [
          "Relaciona testimonio y pregunta.",
          "La perspectiva del autor exige crítica.",
          "Un documento histórico no evalúa condiciones presentes."
        ],
        "source": "e13-recuerdos-critica",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Solo consultaste el catálogo. Debes escribir…",
        "options": [
          "Leí y verifiqué todo el libro.",
          "No existe información útil.",
          "Consulté los metadatos; el contenido requiere revisión."
        ],
        "answer": 2,
        "explanation": "Declara con precisión el nivel de acceso.",
        "rationales": [
          "Atribuye una lectura no realizada.",
          "Los metadatos tienen utilidad limitada.",
          "Declara con precisión el nivel de acceso."
        ],
        "source": "e13-recuerdos-ficha",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue fecha del hecho y fecha de publicación.",
    "Explica por qué fuente primaria no equivale a verdad automática.",
    "Declara si leyó el documento o solo sus metadatos."
  ],
  "openAssessment": {
    "prompt": "Entrega dos fichas: una sobre la edición catalogada y otra sobre la reseña. Escribe qué pregunta responde cada una y cuál deja abierta.",
    "rubric": [
      "Distingue fecha del hecho y fecha de publicación.",
      "Explica por qué fuente primaria no equivale a verdad automática.",
      "Declara si leyó el documento o solo sus metadatos."
    ],
    "source": "e13-recuerdos-ficha",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ACADÉMICA PENDIENTE.** Historia documental e interpretación: no es formación para ejecutar maniobras. No guardes datos médicos, contraseñas, datos privados de terceros ni conocimientos de acceso restringido.

## Conceptos clave y propósito

Fuente primaria, síntesis, testimonio, edición, fecha del hecho, fecha de publicación y procedencia. Primaria describe la relación de una fuente con la pregunta: no es un sello de exactitud.

## Teoría y toma de decisiones

La ficha de Biblioteca Nacional identifica una edición de Recuerdos del pasado de Vicente Pérez Rosales de 1882 y un fragmento que abarca los capítulos XIX–XXIII. Esa ficha permite citar un objeto documental concreto. Por sí sola no demuestra cada episodio que contiene ni convierte el año de impresión en fecha de una excursión. La reseña crítica de Memoria Chilena advierte que la obra mezcla memoria y autobiografía y que hay episodios difíciles de comprobar.

Para trabajar históricamente separa tres capas: lo que el documento dice, lo que otra evidencia permite sostener y lo que tú infieres. Una memoria puede ser primaria para estudiar cómo alguien quiso presentarse, aunque resulte insuficiente para reconstruir una fecha de cumbre. Una síntesis posterior puede ayudarte a ubicar otras fuentes; registra esa mediación en vez de atribuirle haber presenciado los hechos.

Construye una ficha con autoría, título, edición, localización del pasaje, fecha del evento si consta, fecha de publicación y afirmación limitada. Si solo viste una ficha de catálogo, escribe «consulta de metadatos». Si no leíste el facsímil, no digas que lo consultaste. Este hábito evita convertir referencias decorativas en supuesta evidencia.

Fuentes de esta unidad: [Referencia 1](#fuente-e13-recuerdos-ficha) · [Referencia 2](#fuente-e13-recuerdos-critica). Los ejercicios y criterios siguientes son diseño educativo original, no protocolos de las organizaciones citadas.

## Procedimiento: lectura, comprobaciones y variantes

**PROCEDIMIENTO — análisis documental:** Elige una afirmación y divide una hoja en documento, pasaje, interpretación y duda. Comprueba que la edición citada sea la consultada; si cambia la paginación, localiza de nuevo el pasaje. Variante: comparar fotografía y texto sin suponer que ambos fueron creados al mismo tiempo.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un cartel atribuye al año 1882 una salida que aparece en un libro impreso ese año. Redacta una corrección que conserve la fecha bibliográfica y deje la fecha del evento pendiente.

## Errores frecuentes y puntos críticos de seguridad

Copiar fechas de publicación como fechas de hechos; citar un libro no leído; considerar neutral todo texto antiguo. No reconstruir rutas actuales desde relatos históricos.

Las maniobras críticas requieren formación práctica y supervisión de instructor competente. Estudiar cómo se actuaba antiguamente no habilita a reproducirlo. Este taller no requiere exposición en terreno.

## Material y equipo relacionado

Catálogo, cuaderno y copia autorizada del documento. No hace falta equipo técnico de progresión para esta práctica.

[Inventario educativo](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con una evidencia y un límite: Distingue fecha del hecho y fecha de publicación.
- Explica con una evidencia y un límite: Explica por qué fuente primaria no equivale a verdad automática.
- Explica con una evidencia y un límite: Declara si leyó el documento o solo sus metadatos.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Entrega dos fichas: una sobre la edición catalogada y otra sobre la reseña. Escribe qué pregunta responde cada una y cuál deja abierta.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Taller de crítica documental con docente: revisar procedencia, edición y relación entre evidencia y afirmación.

## Evidencia requerida y criterios de competencia

- Distingue fecha del hecho y fecha de publicación.
- Explica por qué fuente primaria no equivale a verdad automática.
- Declara si leyó el documento o solo sus metadatos.

**COMPETENCIA:** se requiere revisión humana contextual del trabajo. Una lectura, quiz o guion no certifica guiado, interpretación profesional ni maniobras técnicas. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s13-historia-evidencia). Registra fecha, lugar de estudio, documentos, habilidad, repeticiones, errores, correcciones, supervisor y evidencia textual no sensible. Diferencia taller ficticio y actividad real; no inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Historia y patrimonio](../../historia/) · [Territorio](../../territorio/) · [Geología](../../geologia/) · [Ecología](../../ecologia/) · [Programa](../../programa/). La interpretación histórica complementa la formación técnica; no sustituye condiciones ni permisos actuales.
