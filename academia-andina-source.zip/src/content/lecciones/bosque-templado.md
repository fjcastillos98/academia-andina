---
{
  "title": "Bosque templado lluvioso y siempreverde: estructura y procesos",
  "description": "Diferencia contexto climático, fisonomía y composición.",
  "module": "M15",
  "code": "E11-02",
  "order": 1102,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U11-02",
  "skills": [
    "s11-bosque-templado"
  ],
  "critical": false,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Diferencia contexto climático, fisonomía y composición.",
    "Describe estructura sin inventar identificación de especies."
  ],
  "prerequisites": [
    "s11-ecosistemas-los-lagos"
  ],
  "sources": [
    "e11-puyehue",
    "e11-vpr"
  ],
  "pending": [
    "Revisión por especialista en ecología e instructor territorial pendiente. Los ejercicios no autorizan acceso, colecta o manejo de fauna.",
    "Categorías legales vigentes, protocolos de encuentro específicos y claves taxonómicas completas: requieren verificación.",
    "Casos, rúbricas y propuestas de práctica originales; no constituyen un protocolo oficial ni una certificación."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Siempreverde se refiere principalmente a…",
        "options": [
          "Persistencia del follaje.",
          "Una altura exacta.",
          "Un bosque sin procesos de cambio."
        ],
        "answer": 0,
        "explanation": "Es un descriptor de la vegetación.",
        "rationales": [
          "Es un descriptor de la vegetación.",
          "La cota no define el término.",
          "El bosque mantiene dinámica."
        ],
        "source": "e11-puyehue",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un tronco caído debe…",
        "options": [
          "Retirarse siempre.",
          "Evaluarse dentro del ambiente sin asumir que es basura.",
          "Usarse como souvenir."
        ],
        "answer": 1,
        "explanation": "Permite una lectura ecológica.",
        "rationales": [
          "No corresponde intervenir por apariencia.",
          "Permite una lectura ecológica.",
          "Extraer altera el lugar."
        ],
        "source": "e11-puyehue",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Dos fotos de estaciones diferentes…",
        "options": [
          "Demuestran deterioro.",
          "Son una prueba idéntica.",
          "Necesitan contexto antes de compararse."
        ],
        "answer": 2,
        "explanation": "Evita inferencias injustificadas.",
        "rationales": [
          "La diferencia puede ser estacional.",
          "Las condiciones cambiaron.",
          "Evita inferencias injustificadas."
        ],
        "source": "e11-puyehue",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Diferencia contexto climático, fisonomía y composición.",
    "Describe estructura sin inventar identificación de especies.",
    "Justifica una observación que no altera el sustrato."
  ],
  "openAssessment": {
    "prompt": "Dibuja un perfil de bosque con cuatro estratos o componentes observables y dos relaciones que mantendrás como hipótesis.",
    "rubric": [
      "Diferencia contexto climático, fisonomía y composición.",
      "Describe estructura sin inventar identificación de especies.",
      "Justifica una observación que no altera el sustrato."
    ],
    "source": "e11-puyehue",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ECOLÓGICA PENDIENTE.** Observación responsable para estudio personal. No acredita identificación taxonómica, competencia profesional ni autorización de acceso. No guardes datos médicos ni localizaciones precisas de especies sensibles.

## Conceptos clave y propósito

Templado lluvioso describe un contexto climático; siempreverde describe persistencia del follaje. Dosel, sotobosque, epífitas, hojarasca y madera muerta permiten describir estructura sin asignar especies automáticamente.

## Teoría y toma de decisiones

Los términos bosque templado lluvioso y bosque siempreverde se relacionan, pero no expresan exactamente lo mismo. En una descripción de terreno conviene decir si hablas de clima, fisonomía o composición. CONAF describe en Puyehue un bosque siempreverde con varios estratos; menciona ulmo, coigüe, olivillo y tineo en sectores bajos. En Vicente Pérez Rosales cita coigüe y otras especies del bosque húmedo. No extrapoles una lista a toda la región.

La estructura se observa de arriba hacia abajo: continuidad de copas, vegetación intermedia, cobertura cercana al suelo y material caído. Esa mirada permite formular preguntas sobre luz, humedad, refugios y renovación. Un tronco caído puede ser parte del funcionamiento del bosque; su presencia no demuestra abandono. No se propone retirar madera, arrancar musgos ni abrir paso para mejorar una fotografía.

Para comparar sectores utiliza la misma pregunta y un método reproducible, como describir cobertura visual desde el sendero y registrar condiciones de luz. Si cambias la hora, estación o punto de observación, consígnalo. No conviertas una diferencia de verdor en una medición de salud del ecosistema. La evaluación ecológica requiere indicadores definidos y series de observación más amplias.

Referencias de esta unidad: [Fuente 1](#fuente-e11-puyehue) · [Fuente 2](#fuente-e11-vpr). Los casos y las aplicaciones pedagógicas que siguen son elaboración original; no se atribuyen como protocolos de las fuentes.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — observación y decisión:** Recorre visualmente dosel, sotobosque y suelo desde un punto permitido. Anota qué puedes y no puedes observar. Compara una descripción oficial sin forzar coincidencias. Variante documental: fotografías de distintas estaciones; no tratarlas como si fueran simultáneas.

No manipules fauna, no recolectes material y no salgas del itinerario autorizado para completar el ejercicio. La conducción real y las maniobras técnicas requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** El grupo pide retirar un tronco para despejar una vista. Explica por qué una preferencia estética no permite decidir una intervención en el bosque.

## Errores frecuentes y puntos críticos de seguridad

Confundir siempreverde con ausencia total de caída de hojas; considerar madera muerta como basura; reconocer un árbol solo por el tamaño. Suelo húmedo y raíces también exigen gestión de marcha.

## Material y equipo relacionado

Lupa de observación sin extracción, prismáticos, cámara y calzado adecuado al recorrido. Limpiar calzado antes y después reduce transporte de material entre sitios.

[Revisar inventario](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica cómo comprobarías este criterio: Diferencia contexto climático, fisonomía y composición.
- Explica cómo comprobarías este criterio: Describe estructura sin inventar identificación de especies.
- Explica cómo comprobarías este criterio: Justifica una observación que no altera el sustrato.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Dibuja un perfil de bosque con cuatro estratos o componentes observables y dos relaciones que mantendrás como hipótesis.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Lectura de estructura de bosque junto a especialista, desde sendero autorizado, sin remoción ni colecta.

## Evidencia requerida y criterios de competencia

- Diferencia contexto climático, fisonomía y composición.
- Describe estructura sin inventar identificación de especies.
- Justifica una observación que no altera el sustrato.

**COMPETENCIA:** requiere observación y revisión humana en contexto. Una lectura, registro o quiz no certifica guiado, identificación experta ni maniobras. La plataforma no verifica credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s11-bosque-templado) y [cuaderno de observación](../../ecologia/#observaciones). Separa ejercicio ficticio, observación real y práctica evaluada. Registra errores, correcciones, supervisor y evidencia sin inventar resultados. Mantén áreas generales; el texto libre no filtra automáticamente ubicaciones sensibles.

## Relaciones con otros módulos

[Ecología](../../ecologia/) · [Fichas de especies](../../especies/) · [Territorio](../../territorio/) · [Planificación](../../planificacion/) · [Programa](../../programa/). La interpretación ambiental se relaciona con geología, cartografía, gestión de grupos y patrimonio, sin sustituir su formación específica.
