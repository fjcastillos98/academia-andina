---
{
  "title": "Cramponaje: compatibilidad y elección de apoyos",
  "description": "Distinguir fijación, estructura y función de las puntas.",
  "module": "M02",
  "code": "E5-17",
  "order": 516,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-14",
  "skills": [
    "s5-cramponaje"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir fijación, estructura y función de las puntas.",
    "Comparar marcha plana, frontal y mixta sin tratarlas como recetas universales.",
    "Identificar qué debe comprobarse antes de una práctica supervisada."
  ],
  "prerequisites": [
    "s5-factores-humanos-invierno"
  ],
  "sources": [
    "e5-ms-crampon",
    "e5-petzl-lynx",
    "e5-ms-winter"
  ],
  "pending": [
    "Revisión de instructor y contraste con manuales exactos del equipo disponible. Cualquier aplicación territorial permanece pendiente de reconocimiento y condiciones actuales."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un crampón de correas cabe en una bota. ¿Está verificada la compatibilidad?",
        "options": [
          "Sí, basta con que cierre.",
          "No, hay que comprobar conjunto y uso previsto.",
          "Sí, si tiene muchas puntas."
        ],
        "answer": 1,
        "explanation": "Ajuste aparente no demuestra compatibilidad.",
        "rationales": [
          "El cierre es solo una parte.",
          "Incluye forma, rigidez y documentación.",
          "El número de puntas no valida la interfaz."
        ],
        "source": "e5-ms-crampon",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué aporta un sistema antiacumulación?",
        "options": [
          "Elimina toda acumulación.",
          "Permite omitir inspecciones.",
          "Ayuda a limitar acumulación según diseño."
        ],
        "answer": 2,
        "explanation": "No es garantía absoluta.",
        "rationales": [
          "Afirmación universal falsa.",
          "No sustituye comprobaciones.",
          "Respeta el alcance del fabricante."
        ],
        "source": "e5-petzl-lynx",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué acredita explicar marcha plana y frontal?",
        "options": [
          "Comprensión conceptual.",
          "Competencia en descenso.",
          "Capacidad para guiar en hielo."
        ],
        "answer": 0,
        "explanation": "La ejecución se observa presencialmente.",
        "rationales": [
          "Es el alcance del estudio.",
          "Falta demostración en contexto.",
          "No equivale a formación de guiado."
        ],
        "source": "e5-ms-winter",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "Identifica interfaces y documentación.",
    "Distingue apoyos y límites sin fijar umbrales universales.",
    "Reconoce una incompatibilidad o incertidumbre que impide empezar."
  ],
  "openAssessment": {
    "prompt": "Compara dos conjuntos bota-crampón hipotéticos y prepara una lista de evidencias antes de autorizar su uso en un taller.",
    "rubric": [
      "Identifica interfaces y documentación.",
      "Distingue apoyos y límites sin fijar umbrales universales.",
      "Reconoce una incompatibilidad o incertidumbre que impide empezar."
    ],
    "source": "e5-ms-crampon",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-crampon"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Reconoce el conjunto bota-fijación-estructura; describe qué puntas participan en un apoyo sin deducir que una foto muestra competencia.

## Teoría y toma de decisiones

El crampón añade puntos de contacto y tracción a una bota, pero modifica la forma de caminar y puede introducir enganches. Mountaineering Scotland distingue diseños orientados a marcha y a terreno técnico, y subraya su compatibilidad con las botas [fuente](#fuente-e5-ms-crampon). Un modelo de correas no queda validado para cualquier calzado por carecer de palanca trasera: hay que comprobar forma, rigidez, regulación y uso previsto del conjunto real.

Separa tres preguntas: cómo se fija, cómo se articula y qué apoyo busca. Correas, fijación semiautomática y automática describen sistemas que necesitan interfaces concretas. Número y orientación de puntas no son una clasificación completa de dificultad. Petzl presenta LYNX como equipo técnico y describe su sistema para limitar acumulación de nieve [fuente](#fuente-e5-petzl-lynx). Ese ejemplo no demuestra que sea necesario para una montaña nombrada: la decisión exige condiciones, recorrido, bota, formación y límites del grupo.

En el vocabulario de esta unidad, marcha plana significa buscar apoyo de las puntas inferiores con el pie adaptado al relieve; frontal, usar especialmente puntas delanteras al enfrentar terreno que exige esa técnica; mixta, combinar apoyos distintos. Estas denominaciones orientan la observación de una demostración. No determinan por sí solas inclinación máxima ni secuencia de pasos. Ascenso, descenso, travesía y giro cambian equilibrio, visibilidad de apoyos y consecuencias de un enganche. La técnica que una persona mantiene unos metros puede dejar de ser sostenible con fatiga o mochila.

Para preparar el taller, identifica estructura delantera y trasera, unión o barra, regulación, correas, cierre y sistema antiacumulación cuando lo incorpora. La inspección es una comparación con el manual: describe deformaciones, fisuras, desgaste o piezas ausentes sin decidir que son aceptables por su apariencia. No inventes reparaciones o combinaciones de piezas. La presencia de antiballing reduce un problema, no elimina la necesidad de observar el equipo. El mantenimiento y afilado dependen del fabricante y material; no se da aquí un ángulo universal ni una pauta para modificar puntas.

El ejercicio de selección usa tres botas ficticias con información incompleta. El alumno debe escribir qué evidencia necesita para evaluar cada combinación. Una respuesta correcta puede ser «no puedo validar este conjunto». En terreno, cambiar calzado o crampón de un pasajero obliga a repetir comprobaciones, aunque ambas piezas hayan sido utilizadas antes. La ficha de inventario registra identidad e historial; no realiza la comprobación física.

La progresión se aprende presencialmente, como señala el material formativo de Mountaineering Scotland [fuente](#fuente-e5-ms-winter). El instructor elige un entorno apropiado y observa marcha, cambios de dirección y control del equipo. La autodetención se estudia en su propia unidad: los crampones no convierten una caída en un evento controlable. El objetivo preventivo es reconocer cuándo el apoyo, la capacidad o las consecuencias dejan de ser compatibles con el plan.

## Qué observo, qué significa y qué no puedo concluir

Toda marcha real con crampones requiere práctica presencial supervisada. No se establece una inclinación segura ni compatibilidad por talla o nombre comercial.

## Caso práctico y aplicación al guiado

Un pasajero trae una bota flexible y afirma que las correas solucionan cualquier incompatibilidad. Explica qué datos faltan y por qué detener la selección no es un fallo del aprendizaje.

## Errores frecuentes y señales de alerta

Confundir más puntas con mejor elección; olvidar enganches; usar una configuración ajena al manual; interpretar antiballing como inmunidad a acumulación.

## Autoevaluación y respuesta razonada

Compara dos conjuntos bota-crampón hipotéticos y prepara una lista de evidencias antes de autorizar su uso en un taller.

## Ejercicios y práctica supervisada

Identificación y ajuste de mesa con manual, seguidos de taller presencial escogido por instructor. No iniciar una pendiente real para probar un conjunto incierto.

## Evidencia requerida

- Identifica interfaces y documentación.
- Distingue apoyos y límites sin fijar umbrales universales.
- Reconoce una incompatibilidad o incertidumbre que impide empezar.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-cramponaje).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
