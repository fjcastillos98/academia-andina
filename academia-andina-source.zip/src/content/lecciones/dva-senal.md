---
{
  "title": "Búsqueda de señal: cobertura y lectura de escena",
  "description": "Distinguir ausencia de recepción de ausencia de víctimas.",
  "module": "M09",
  "code": "E5-09",
  "order": 508,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-09",
  "skills": [
    "s5-dva-senal"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir ausencia de recepción de ausencia de víctimas.",
    "Relacionar último punto visto, indicios y cobertura de búsqueda.",
    "Reconocer errores de modo e interferencia antes de interpretar una pantalla vacía."
  ],
  "prerequisites": [
    "s5-dva-fundamentos"
  ],
  "sources": [
    "e5-senal-aaa",
    "e5-bd-interferencia",
    "e5-icar-dva"
  ],
  "pending": [
    "Ancho de búsqueda y gestión exacta de interferencias del modelo personal: PENDIENTE DE VERIFICACIÓN."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "No aparece señal. ¿Qué conclusión es válida?",
        "options": [
          "No hay víctimas.",
          "Falta investigar causas y cobertura.",
          "La pala ya no es necesaria."
        ],
        "answer": 1,
        "explanation": "La ausencia de recepción no identifica por sí sola la causa.",
        "rationales": [
          "Excede lo observado.",
          "Mantiene abiertas hipótesis comprobables.",
          "El equipo de excavación sigue siendo parte del rescate."
        ],
        "source": "e5-senal-aaa",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "Un guante visible es…",
        "options": [
          "Un indicio que debe documentarse.",
          "Confirmación de la profundidad.",
          "Prueba de que hay una sola víctima."
        ],
        "answer": 0,
        "explanation": "Un objeto aporta información sin demostrar posición o número de personas.",
        "rationales": [
          "Evidencia limitada bien clasificada.",
          "No mide profundidad.",
          "No cuenta víctimas."
        ],
        "source": "e5-senal-aaa",
        "difficulty": "intermedia",
        "kind": "conocimiento"
      },
      {
        "prompt": "Otro compañero llega en emisión a la zona de búsqueda. ¿Qué problema plantea?",
        "options": [
          "Ninguno si usa otra marca.",
          "Mejora automáticamente la precisión.",
          "Añade una señal ajena que exige coordinación de modos."
        ],
        "answer": 2,
        "explanation": "Los modos del grupo forman parte de la organización.",
        "rationales": [
          "La marca no evita recibir señales compatibles.",
          "Más señales no equivalen a precisión.",
          "Reconoce una fuente de confusión."
        ],
        "source": "e5-icar-dva",
        "difficulty": "intermedia",
        "kind": "errores"
      }
    ]
  },
  "preparation": [
    "Explica tres hipótesis para ausencia de señal.",
    "Distingue indicio de confirmación y señala huecos de cobertura.",
    "Comunica sectores pendientes y límites del ejercicio."
  ],
  "openAssessment": {
    "prompt": "Dibuja un área ficticia y explica qué diferencia un sector recorrido de un sector efectivamente comprobado.",
    "rubric": [
      "Explica tres hipótesis para ausencia de señal.",
      "Distingue indicio de confirmación y señala huecos de cobertura.",
      "Comunica sectores pendientes y límites del ejercicio."
    ],
    "source": "e5-senal-aaa",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-dva-flujo"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

En croquis distinguir último punto visto, indicio, sector recorrido y sector no comprobado.

## Teoría y toma de decisiones

Buscar señal significa intentar adquirir una transmisión cuando todavía no existe una indicación útil para aproximarse a un objetivo. La pregunta es «¿dónde y cómo buscar con los medios disponibles?», no «¿qué flecha seguir?». Avalanche.org destaca el último punto donde se vio a la persona, los indicios de superficie y una cobertura sistemática. También distingue el trabajo de una persona del de varios buscadores. [Búsqueda de señal](#fuente-e5-senal-aaa). Esta organización no convierte el depósito en un lugar seguro: la evaluación de amenazas por encima y alrededor sigue condicionando toda entrada.

El último punto visto es una observación atribuida a alguien y puede ser incierta. Una descripción como «cerca de la roca oscura» necesita relacionarse con un croquis; no equivale a coordenadas exactas. Un guante o un esquí puede orientar la atención, pero no prueba que una persona esté justo debajo. En un ejercicio, separa el hecho visible, la hipótesis y la acción que justificaría. Registrar «objeto azul observado por Ana desde ese punto» permite discutir la evidencia; registrar «víctima localizada» antes de confirmarla cambia indebidamente su significado.

Una búsqueda sistemática procura cubrir el área sin dejar huecos que el equipo no puede comprobar. Los anchos de búsqueda dependen del manual y de las condiciones; la cifra que otro grupo utiliza no debe copiarse sin saber por qué. En papel, dibuja un depósito ficticio, su borde y dos zonas que no se pueden alcanzar desde una posición protegida. La cobertura dibujada termina donde terminan los datos: no marques como revisado un sector inaccesible. Esa distinción sirve para comunicar a apoyo externo lo hecho y lo pendiente.

La ausencia de señal admite distintas explicaciones: el emisor puede estar fuera de alcance, apagado, dañado o ausente; el receptor puede estar en modo equivocado; puede haber interferencia o una zona sin cubrir. Es un problema de hipótesis, no una prueba de que no existe nadie. La revisión de funcionamiento recomendada por ICAR reduce incertidumbre antes de salir, pero no elimina todas las posibilidades de fallo en un incidente. [Revisión del dispositivo](#fuente-e5-icar-dva). Reconocer esta limitación evita detener un análisis solo porque una pantalla no cambia.

Los buscadores también modifican el entorno de señales. Un integrante que permanece en emisión cerca del buscador puede producir una señal que no corresponde a una víctima; una radio u otra electrónica puede afectar la recepción. [Interferencias documentadas](#fuente-e5-bd-interferencia). Por eso un plan de entrenamiento debe incluir quién está buscando, qué modo utiliza cada participante y cómo se incorporan personas que llegan después. No basta con gritar «busquen»: hay que comprobar comprensión de tareas y límites.

Ejercicio original: en una simulación, tres participantes dibujan sus recorridos. Uno deja un hueco junto a un borde porque creyó que otro ya había pasado; el segundo sigue una señal que resulta ser el instructor; el tercero ignora un indicio visible. Sin proponer una trayectoria real, identifica qué evidencia habría evitado cada error: reparto de sectores, control de modos y atención a indicios. Después redacta un parte con área no cubierta, señal obtenida o no, número de personas conocidas y amenazas observadas. Evalúa la coherencia del relato antes que la velocidad de llenar el croquis. Un tiempo corto con cobertura incompleta no demuestra una búsqueda competente.

## Qué observo, qué significa y qué no puedo concluir

Sin señal no puede declararse ausencia; sin seguridad de escena no se justifica la entrada.

## Caso práctico y aplicación al guiado

Tres buscadores suponen que otro revisó el borde. Explica cómo el registro de sectores cambia el diagnóstico.

## Errores frecuentes y señales de alerta

Pantalla como única evidencia; olvidar modo búsqueda; copiar ancho comercial; perder referencias del área cubierta.

## Autoevaluación y respuesta razonada

Dibuja un área ficticia y explica qué diferencia un sector recorrido de un sector efectivamente comprobado.

## Ejercicios y práctica supervisada

Práctica de cobertura con objetivos inertes y radios bajo control del instructor, sin exposición a avalanchas.

## Evidencia requerida

- Explica tres hipótesis para ausencia de señal.
- Distingue indicio de confirmación y señala huecos de cobertura.
- Comunica sectores pendientes y límites del ejercicio.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-dva-senal).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
