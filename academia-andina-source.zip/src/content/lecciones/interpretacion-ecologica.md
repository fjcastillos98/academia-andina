---
{
  "title": "Interpretación ambiental y cuaderno de observación",
  "description": "Construye una interpretación con dato, límite y acción de cuidado.",
  "module": "M15",
  "code": "E11-10",
  "order": 1110,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U11-10",
  "skills": [
    "s11-interpretacion-ecologica"
  ],
  "critical": false,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Construye una interpretación con dato, límite y acción de cuidado.",
    "Registra incertidumbre sin publicar localizaciones sensibles."
  ],
  "prerequisites": [
    "s11-impactos-no-deje-rastro"
  ],
  "sources": [
    "e11-fauna",
    "e11-regional"
  ],
  "pending": [
    "Revisión por especialista en ecología e instructor territorial pendiente. Los ejercicios no autorizan acceso, colecta o manejo de fauna.",
    "Categorías legales vigentes, protocolos de encuentro específicos y claves taxonómicas completas: requieren verificación.",
    "Casos, rúbricas y propuestas de práctica originales; no constituyen un protocolo oficial ni una certificación."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Guardar una observación en la academia…",
        "options": [
          "Certifica la especie.",
          "Crea una práctica supervisada.",
          "Conserva una declaración de estudio con sus límites."
        ],
        "answer": 2,
        "explanation": "Es el alcance real del cuaderno.",
        "rationales": [
          "No existe verificación taxonómica automática.",
          "Los sistemas son distintos.",
          "Es el alcance real del cuaderno."
        ],
        "source": "e11-fauna",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Para una especie sensible conviene…",
        "options": [
          "Evitar detalles que permitan localizar individuos.",
          "Publicar el nido exacto.",
          "Inventar otra ubicación precisa."
        ],
        "answer": 0,
        "explanation": "Reduce riesgo de perturbación.",
        "rationales": [
          "Reduce riesgo de perturbación.",
          "Puede atraer visitas al sitio.",
          "Fabricaría datos."
        ],
        "source": "e11-fauna",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una interpretación honesta puede…",
        "options": [
          "Eliminar toda incertidumbre por estilo.",
          "Explicar lo que no se sabe y cómo cuidarlo.",
          "Prometer un avistamiento."
        ],
        "answer": 1,
        "explanation": "La incertidumbre también enseña.",
        "rationales": [
          "Oculta límites relevantes.",
          "La incertidumbre también enseña.",
          "No puede garantizarse."
        ],
        "source": "e11-fauna",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Construye una interpretación con dato, límite y acción de cuidado.",
    "Registra incertidumbre sin publicar localizaciones sensibles.",
    "Separa observación, revisión declarada y competencia evaluada."
  ],
  "openAssessment": {
    "prompt": "Escribe un relato interpretativo de 120 palabras con dato atribuido, incertidumbre, pregunta al visitante y acción de cuidado. Revisa cada afirmación.",
    "rubric": [
      "Construye una interpretación con dato, límite y acción de cuidado.",
      "Registra incertidumbre sin publicar localizaciones sensibles.",
      "Separa observación, revisión declarada y competencia evaluada."
    ],
    "source": "e11-fauna",
    "difficulty": "integración"
  },
  "diagrams": [
    "e11-evidencia"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ECOLÓGICA PENDIENTE.** Observación responsable para estudio personal. No acredita identificación taxonómica, competencia profesional ni autorización de acceso. No guardes datos médicos ni localizaciones precisas de especies sensibles.

## Conceptos clave y propósito

Interpretación: conectar una evidencia con una pregunta significativa sin fabricar certezas. Trazabilidad: poder reconstruir fuente y revisión. Observación, hipótesis y revisión declarada son estados distintos.

## Teoría y toma de decisiones

El cuaderno de esta academia registra fecha, área general, ambiente, rasgos, hipótesis, evidencia, revisión declarada y acción de cuidado. No solicita coordenadas, archivos de fotografía ni datos médicos. Las referencias a evidencias son texto: no demuestran por sí mismas que una foto existe ni verifican la identidad de un revisor.

La interpretación para visitantes puede seguir tres pasos: describir un rasgo visible, explicar qué pregunta permite explorar y conectar con una acción de cuidado. Por ejemplo, un registro incierto de un ave permite hablar de límites de identificación y de por qué no acercarse más. No hace falta inventar una especie emblemática para producir una experiencia significativa.

La información también puede causar perturbación si revela sitios sensibles. Registra un área amplia y evita introducir nidos, refugios, coordenadas o instrucciones para encontrar individuos amenazados. La plataforma no detecta automáticamente esos datos dentro del texto: revisa lo escrito antes de guardar y antes de compartir cualquier respaldo. No atribuyas relatos culturales a comunidades sin fuente y participación pertinentes; el conocimiento territorial no se reduce a una ficha naturalista.

Una identificación revisada sigue siendo una declaración local, no una certificación. Corregir un registro es parte del aprendizaje: conserva en la evidencia el motivo de la revisión y las referencias. El diario de prácticas y la evaluación de competencia permanecen separados del cuaderno de observaciones.

Referencias de esta unidad: [Fuente 1](#fuente-e11-fauna) · [Fuente 2](#fuente-e11-regional). Los casos y las aplicaciones pedagógicas que siguen son elaboración original; no se atribuyen como protocolos de las fuentes.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — observación y decisión:** Completa la observación desde evidencia; indica sin identificar o hipótesis; para revisión declarada consigna persona o entidad y referencia; comprueba que no expones ubicaciones sensibles; guarda y respalda. Variante: ejercicio ficticio claramente marcado frente a observación real; nunca mezclar ambos como evidencia de práctica.

No manipules fauna, no recolectes material y no salgas del itinerario autorizado para completar el ejercicio. La conducción real y las maniobras técnicas requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una foto podría mostrar una especie sensible y conserva coordenadas. Redacta una explicación pública y un registro de estudio que mantengan valor educativo sin revelar el punto ni afirmar certeza.

## Errores frecuentes y puntos críticos de seguridad

Usar confianza personal como validación; guardar datos sensibles en texto; convertir observaciones en prácticas supervisadas; inventar testimonios o patrimonio cultural.

## Material y equipo relacionado

Cuaderno local y fichas atribuidas. Fotos fuera de la plataforma: revisar metadatos antes de compartir; aquí no se almacenan imágenes ni se eliminan metadatos de archivos externos.

[Revisar inventario](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica cómo comprobarías este criterio: Construye una interpretación con dato, límite y acción de cuidado.
- Explica cómo comprobarías este criterio: Registra incertidumbre sin publicar localizaciones sensibles.
- Explica cómo comprobarías este criterio: Separa observación, revisión declarada y competencia evaluada.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Escribe un relato interpretativo de 120 palabras con dato atribuido, incertidumbre, pregunta al visitante y acción de cuidado. Revisa cada afirmación.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Microactividad interpretativa con especialista y grupo simulado; evaluar precisión, respeto, comunicación y adaptación sin prometer certificación.

## Evidencia requerida y criterios de competencia

- Construye una interpretación con dato, límite y acción de cuidado.
- Registra incertidumbre sin publicar localizaciones sensibles.
- Separa observación, revisión declarada y competencia evaluada.

**COMPETENCIA:** requiere observación y revisión humana en contexto. Una lectura, registro o quiz no certifica guiado, identificación experta ni maniobras. La plataforma no verifica credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s11-interpretacion-ecologica) y [cuaderno de observación](../../ecologia/#observaciones). Separa ejercicio ficticio, observación real y práctica evaluada. Registra errores, correcciones, supervisor y evidencia sin inventar resultados. Mantén áreas generales; el texto libre no filtra automáticamente ubicaciones sensibles.

## Relaciones con otros módulos

[Ecología](../../ecologia/) · [Fichas de especies](../../especies/) · [Territorio](../../territorio/) · [Planificación](../../planificacion/) · [Programa](../../programa/). La interpretación ambiental se relaciona con geología, cartografía, gestión de grupos y patrimonio, sin sustituir su formación específica.
