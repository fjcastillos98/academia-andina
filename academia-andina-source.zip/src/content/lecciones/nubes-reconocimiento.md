---
{
  "title": "Nubes y reconocimiento atmosférico",
  "description": "Observar forma y evolución sin convertir una identificación visual en certeza meteorológica.",
  "module": "M01",
  "code": "P1-E",
  "order": 105,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "pilot",
  "reviewDate": "2026-10-22",
  "objectives": [
    "Registrar rasgos observables antes de nombrar una nube.",
    "Distinguir género y especie en la clasificación.",
    "Expresar incertidumbre y consultar una referencia visual."
  ],
  "prerequisites": [
    "Estudiar Meteorología de montaña y explicar sus límites."
  ],
  "sources": [
    "omm-lenticularis",
    "omm-guia"
  ],
  "pending": [
    "Revisión pedagógica y validación de criterios por instructor competente.",
    "Aplicación territorial en Los Lagos: requiere verificación situada."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Lenticularis es…",
        "options": [
          "Una forma o especie aplicable a varios géneros.",
          "Una medición de velocidad del viento.",
          "Un permiso para ascender."
        ],
        "answer": 0,
        "explanation": "La OMM describe rasgos de forma y su asociación con varios géneros, no un umbral operativo."
      },
      {
        "prompt": "No reconoces una nube. ¿Cuál es el registro más útil?",
        "options": [
          "Inventar un nombre para completar la ficha.",
          "Eliminar la observación.",
          "Describir rasgos y dejar explícita la incertidumbre."
        ],
        "answer": 2,
        "explanation": "Un registro descriptivo verificable es más útil que una etiqueta injustificada."
      }
    ]
  },
  "pilot": {
    "position": 5,
    "requires": [
      "meteorologia-montana"
    ],
    "critical": false,
    "classifications": [
      "TEORÍA",
      "PROCEDIMIENTO",
      "PRÁCTICA INDIVIDUAL",
      "PRÁCTICA SUPERVISADA",
      "COMPETENCIA"
    ],
    "relatedModules": [
      "M01",
      "M00"
    ],
    "criteria": [
      "Diferencia observación e interpretación, registra contexto y evita inferencias no sustentadas; justifica una identificación tentativa con rasgos y acepta dejarla sin resolver."
    ]
  }
}
---
## Conceptos

**TEORÍA.** El Atlas Internacional de Nubes de la OMM es la referencia de clasificación [Organización Meteorológica Mundial](#fuente-omm-lenticularis). La denominación **lenticularis** describe nubes con forma de lente o almendra, a menudo alargadas y de bordes definidos. Puede asociarse a distintos géneros, principalmente Cirrocumulus, Altocumulus y Stratocumulus. Es frecuente su origen orográfico, pero no exclusivo.

Por tanto, ver una forma lenticular no permite deducir por sí solo una velocidad del viento en tu posición, una altitud exacta o una ventana segura. La identificación se sostiene en rasgos y comparación, no en la semejanza con una sola fotografía.

### Primeras familias para comparar

La guía visual OMM [Organización Meteorológica Mundial](#fuente-omm-guia) permite empezar con estos contrastes, sin asignar alturas exactas a una observación:

| Género | Rasgo para contrastar con el atlas |
| --- | --- |
| Cirrus | Filamentos o trazos de aspecto sedoso. |
| Cirrostratus | Velo fino; puede producir halo. |
| Cirrocumulus | Pequeños granos u ondulaciones blanquecinas. |
| Altostratus | Capa extensa con el sol, si se ve, difuso. |
| Altocumulus | Bancos o capas con elementos estructurados. |
| Nimbostratus | Capa asociada habitualmente a precipitación continua. |
| Stratocumulus | Elementos bajos redondeados, grises o blancos. |
| Stratus | Capa baja que puede presentarse fragmentada. |
| Cumulus | Elementos separados de bordes definidos y aspecto abultado. |
| Cumulonimbus | Gran desarrollo vertical, a veces con yunque; posibilidad de tormenta. |

Usa la guía completa para contrastar hipótesis. No deduzcas «buen tiempo» de un solo género ni esperes a reconocer un yunque para consultar el pronóstico.

## Desarrollo teórico y toma de decisiones

**PROCEDIMIENTO · análisis y preparación.** En este primer ejercicio separa cuatro columnas: **observación**, **hipótesis**, **confianza**, **dato pendiente**. Describe forma, continuidad, borde, distribución y evolución visible. Si no puedes identificar el género, conserva una descripción en lenguaje común y marca «requiere verificación».

Para avanzar, abre la fuente visual original y compara sus rasgos diagnósticos. No uses la altura aparente sobre una montaña como medición de la base de la nube. Una imagen aislada tampoco demuestra la tendencia de las próximas horas.

La observación complementa el tema anterior: si se pierde visibilidad, importa qué ocurre con las referencias de navegación del grupo aunque todavía no sepas el nombre de la nube. La decisión no debe esperar a que completes una taxonomía.

## Ejemplo

Actividad didáctica original, no descripción de una ruta operativa.

## Caso de estudio

Caso ficticio: una fotografía muestra una nube alargada sobre un relieve; otra, veinte minutos después, está tomada desde un lugar distinto. Un compañero asegura que la nube creció rápidamente. ¿Qué problema hay en la comparación?

Respuesta orientativa: cambió el punto de observación; sin escala ni condiciones comparables no puede atribuirse toda la diferencia a evolución real. Puede formularse una hipótesis, no una medición. Registra ubicación aproximada y hora, sin exponer datos personales innecesarios.

## Errores frecuentes

Adivinar la altura con una foto; confundir especie con género; atribuir un pronóstico fijo a una forma; omitir cambios de posición del observador.

## Límites y puntos críticos de seguridad

Observar desde un lugar seguro. No exponerse a tormentas para obtener imágenes ni usar una clasificación tentativa para entrar en terreno comprometido.

## Material y equipo relacionado

Cuaderno, reloj y cámara opcional. La cámara registra evidencia visual, no mide viento ni convierte una observación en pronóstico.

## Recuperación activa

- ¿Puede lenticularis describir más de un género?
- ¿Qué no permite concluir una fotografía aislada?

Responde antes de consultar el texto. Luego anota qué cambiaste y por qué; el recuerdo sin justificación no basta.

## Ejercicio y práctica

**PRÁCTICA INDIVIDUAL** limitada a análisis en mesa u observación segura. Desde casa o un lugar urbano seguro registra tres observaciones en momentos distintos. Anota rasgos, una hipótesis y su incertidumbre. Usa la OMM para revisar una sola identificación.

**PRÁCTICA SUPERVISADA.** Un instructor competente selecciona el contexto y observa la ejecución pertinente; este texto no autoriza a realizar maniobras técnicas sin esa formación. Antes de la sesión, acuerda objetivo, límites y cómo se interrumpirá el ejercicio.

## Registro de práctica

Abre el Diario de prácticas desde la navegación y selecciona esta habilidad. Registra fecha, lugar, condiciones, actividad, equipo, repeticiones, errores, correcciones y evidencia. Identifica al supervisor solo cuando estuvo presente. La confianza es una percepción, no un resultado de competencia. No incluyas datos médicos, contraseñas ni información privada de terceros.

## Criterios de revisión y competencia

**COMPETENCIA · evaluación pendiente.** Diferencia observación e interpretación, registra contexto y evita inferencias no sustentadas; justifica una identificación tentativa con rasgos y acepta dejarla sin resolver.

La evaluación debe indicar quién observó, qué contexto y evidencia revisó, qué criterio aplicó y cuál fue el resultado. El diario conserva una declaración del usuario: no verifica identidad ni credenciales del evaluador y no emite certificaciones. Una lectura o quiz nunca demuestra ejecución técnica.

## Próximos pasos y relación con otros módulos

Continúa con **Cartografía, orientación y navegación**.

Relación con el currículo original: M01. Esta secuencia pertenece al bloque piloto **Módulo 1 — Fundamentales**; no renumera las 376 entradas pendientes del mapa original. Meteorología, navegación y decisiones se revisitan en montaña estival, invernal y glaciar; no son prerrequisitos prácticos ya acreditados.
