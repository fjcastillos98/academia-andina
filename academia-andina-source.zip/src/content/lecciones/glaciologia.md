---
{
  "title": "Glaciología: hielo en movimiento",
  "description": "Distinguir nieve estacional, firn y hielo glaciar.",
  "module": "M04",
  "code": "E6-01",
  "order": 601,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U6-01",
  "skills": [
    "s6-glaciologia"
  ],
  "critical": true,
  "reviewDate": "2026-10-23",
  "objectives": [
    "Distinguir nieve estacional, firn y hielo glaciar.",
    "Explicar balance de masa y posición del frente sin confundirlos con dirección del flujo."
  ],
  "prerequisites": [
    "s5-planificacion-invernal",
    "s5-cramponaje",
    "s5-piolet"
  ],
  "sources": [
    "e6-nsidc-science",
    "e6-dga-inventory"
  ],
  "pending": [
    "Identificación y datos actuales de glaciares de Los Lagos, con revisión de ficha y metodología DGA. PENDIENTE DE VERIFICACIÓN.",
    "Revisión presencial por instructor competente pendiente. No se ha realizado ni aprobado ninguna práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un frente retrocede. ¿Qué NO se deduce?",
        "options": [
          "Que se modificó su posición.",
          "Que el hielo fluye cuesta arriba.",
          "Que se necesitan fechas para comparar."
        ],
        "answer": 1,
        "explanation": "Posición frontal y dirección del flujo son magnitudes distintas.",
        "rationales": [
          "No se justifica: Posición frontal y dirección del flujo son magnitudes distintas.",
          "Correcta: Posición frontal y dirección del flujo son magnitudes distintas.",
          "No se justifica: Posición frontal y dirección del flujo son magnitudes distintas."
        ],
        "source": "e6-nsidc-science",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué aporta el inventario DGA?",
        "options": [
          "Un mapa de grietas de hoy.",
          "Permiso de entrada.",
          "Delimitación e información según versión y método."
        ],
        "answer": 2,
        "explanation": "El inventario tiene un ámbito documental, no operativo.",
        "rationales": [
          "No se justifica: El inventario tiene un ámbito documental, no operativo.",
          "No se justifica: El inventario tiene un ámbito documental, no operativo.",
          "Correcta: El inventario tiene un ámbito documental, no operativo."
        ],
        "source": "e6-dga-inventory",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Faltan escala y fecha en una imagen. ¿Qué hacer?",
        "options": [
          "Declarar la limitación y recuperar metadatos.",
          "Asignar la fecha de hoy.",
          "Estimar seguridad por el color."
        ],
        "answer": 0,
        "explanation": "El dato debe conservar trazabilidad y límites.",
        "rationales": [
          "Correcta: El dato debe conservar trazabilidad y límites.",
          "No se justifica: El dato debe conservar trazabilidad y límites.",
          "No se justifica: El dato debe conservar trazabilidad y límites."
        ],
        "source": "e6-nsidc-science",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "Separa balance de masa y posición frontal.",
    "Identifica fecha y alcance espacial del dato.",
    "No infiere transitabilidad de una tendencia."
  ],
  "openAssessment": {
    "prompt": "Dibuja un balance ficticio con entradas y salidas y explica por qué un frente en retroceso no demuestra que el hielo se mueva cuesta arriba.",
    "rubric": [
      "Separa balance de masa y posición frontal.",
      "Identifica fecha y alcance espacial del dato.",
      "No infiere transitabilidad de una tendencia."
    ],
    "source": "e6-nsidc-science",
    "difficulty": "integración"
  },
  "diagrams": [
    "glaciar-balance"
  ]
}
---

**CONTENIDO TEÓRICO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Acumulación y ablación, Flujo y deformación, Escalas temporales y datos de inventario. Relacionar un cambio de balance con una evolución, sin convertirlo en pronóstico de seguridad de una salida.

## Teoría y toma de decisiones

Un glaciar es un cuerpo de hielo formado por acumulación y transformación de nieve que se deforma y se desplaza bajo su peso. La nieve que sobrevive a la estación de ablación puede transformarse en firn y después en hielo. Estos estados no son nombres intercambiables para cualquier superficie blanca. NSIDC explica los procesos de formación y movimiento; una observación visual aislada no mide edad, espesor o velocidad. [Base científica](#fuente-e6-nsidc-science).

El balance de masa compara ganancias y pérdidas en un intervalo y dominio definidos. Acumulación y ablación no se reducen respectivamente a una sola nevada y a la temperatura de una tarde. La posición del frente expresa otra variable: un frente puede retroceder mientras el hielo continúa fluyendo hacia cotas inferiores. Confundir estas magnitudes produce explicaciones falsas sobre cómo cambia el terreno. Distingue también una tendencia climática de las condiciones que afectarán a una cordada en un día concreto.

Para estudiar datos chilenos, la DGA ofrece el Inventario Público de Glaciares. Una geometría del inventario representa una delimitación según versión, fecha y metodología; no es un levantamiento de grietas de hoy. [Inventario oficial](#fuente-e6-dga-inventory). Antes de incorporar una ficha local registra identificador, versión, fecha de las imágenes y sistema de coordenadas. Esta unidad no completa esos campos para Tronador ni asigna un itinerario a partir del polígono.

En el cuaderno dibuja una cuenca ficticia con dos periodos de observación. Escribe tres registros separados: cambio en masa, cambio de posición del frente y desplazamiento de una marca superficial. Si un dato no está disponible, anota «no medido». Después explica a un compañero por qué esos tres registros pueden evolucionar de manera diferente. El aprendizaje consiste en no sustituir una variable por otra cuando falta información.

## Procedimiento conceptual: objetivo, uso y límites

Distinguir nieve estacional, firn y hielo glaciar. Esta unidad se utiliza para preparar el análisis y un taller, no para ejecutar una maniobra sin entrenamiento. Separar observaciones con fecha de inferencias y de lagunas del registro.

Las variantes técnicas mantienen el ámbito de la fuente citada. Antes de cambiar una configuración se deben revisar sus funciones, comprobaciones y límites con instructor; no se combinan pasos de escuelas distintas por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario hipotético de aula.** Un alumno observa dos fotografías con un frente más corto y afirma que el glaciar subió ladera arriba. Las fechas están disponibles, pero faltan escala, masa y seguimiento de movimiento. Corrige la inferencia y propone qué dato distinguiría flujo de cambio frontal.

## Errores frecuentes y puntos críticos

Confundir nieve estacional con glaciar; inferir estabilidad de la tendencia de masa; trasladar polígonos antiguos como límites operativos.

No se atribuye una garantía de seguridad al equipo, al quiz ni a una práctica en condiciones diferentes. Si falta un dato esencial para justificar el objetivo, declarar ese vacío es parte del aprendizaje.

## Material y equipo relacionado

Mapas e imágenes fechadas, metadatos de inventario y cuaderno. GPS y altímetro no miden por sí solos la estabilidad del hielo.

[Inventario personal](../../equipo/): conserva referencia del manual y observaciones de inspección. El registro no declara aptitud de una pieza ni competencia de quien la porta.

## Autoevaluación y recuperación activa

- ¿Por qué un frente en retroceso no demuestra flujo cuesta arriba?
- ¿Qué fecha y variable faltan cuando alguien muestra una fotografía como prueba?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL de escritorio:** Dibuja un balance ficticio con entradas y salidas y explica por qué un frente en retroceso no demuestra que el hielo se mueva cuesta arriba.

**PRÁCTICA SUPERVISADA:** el instructor adapta un taller con objetivos observables, protección y criterios de parada. No provocar caídas reales ni entrar a terreno expuesto para comprobar esta página. La evaluación presencial es independiente de la respuesta teórica.

## Evidencia requerida y criterios de competencia

- Separa balance de masa y posición frontal.
- Identifica fecha y alcance espacial del dato.
- No infiere transitabilidad de una tendencia.

Estos criterios valoran razonamiento; para una competencia práctica, el instructor debe definir y observar la ejecución en un contexto explícito. No se preasigna una evaluación por estudiar.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s6-glaciologia). Registrar únicamente lo realizado: fecha, lugar, condiciones, objetivo, equipo, supervisor, resultado, errores, correcciones, evidencia, autonomía observada y próxima práctica. No guardar datos médicos ni información privada de pasajeros.

## Relaciones con etapas anteriores

[Glaciología introductoria](../glaciologia-intro/), [planificación invernal](../planificacion-invernal/), [encordamiento según contexto](../encordamiento-contexto/), [anclajes](../anclajes-reuniones/) y [ventaja mecánica](../ventaja-mecanica/). Estas dependencias orientan el estudio; no autorizan la aplicación técnica. [Ruta glaciar](../../glaciar/).
