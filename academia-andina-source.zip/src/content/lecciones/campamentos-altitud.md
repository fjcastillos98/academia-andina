---
{
  "title": "Campamentos: descanso, cocina y posibilidad de retirada",
  "description": "Relacionar la ubicación del campamento con exposición y evacuación.",
  "module": "M03",
  "code": "E9-07",
  "order": 907,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U9-07",
  "skills": [
    "s9-campamentos-altitud"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Relacionar la ubicación del campamento con exposición y evacuación.",
    "Reconocer el riesgo de combustión en espacios cerrados."
  ],
  "prerequisites": [
    "s9-planificacion-altitud"
  ],
  "sources": [
    "e9-co",
    "e9-cdc"
  ],
  "pending": [
    "Revisión médica por profesional de medicina de montaña y revisión docente por instructor pendientes. No se ha evaluado atención clínica ni rescate.",
    "Casos, ejercicios y criterios son propuestas pedagógicas originales; no autorizan decisiones clínicas individuales.",
    "Condiciones de rutas, comunicaciones y recursos de atención locales requieren verificación antes de cada salida."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Dos campamentos a la misma cota…",
        "options": [
          "Pueden tener peligros y accesos distintos.",
          "Son equivalentes en todo.",
          "Garantizan el mismo resultado."
        ],
        "answer": 0,
        "explanation": "La elevación no describe terreno ni logística.",
        "rationales": [
          "La elevación no describe terreno ni logística.",
          "Faltan características del emplazamiento.",
          "No existe esa garantía."
        ],
        "source": "e9-co",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Usar un hornillo dentro de la carpa…",
        "options": [
          "Es seguro con una abertura pequeña.",
          "Debe evitarse por el peligro de CO e incendio.",
          "Aclimata al grupo."
        ],
        "answer": 1,
        "explanation": "No es un lugar apropiado para combustión.",
        "rationales": [
          "No convierte el espacio en seguro.",
          "No es un lugar apropiado para combustión.",
          "No es una práctica de aclimatación."
        ],
        "source": "e9-co",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una salida sin información suficiente se registra como…",
        "options": [
          "Evacuación garantizada.",
          "Detalle irrelevante.",
          "Pendiente de verificación."
        ],
        "answer": 2,
        "explanation": "La incertidumbre debe permanecer visible.",
        "rationales": [
          "Faltan datos para sostenerlo.",
          "Afecta la respuesta ante una emergencia.",
          "La incertidumbre debe permanecer visible."
        ],
        "source": "e9-co",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue altitud y seguridad del emplazamiento.",
    "Identifica combustión en carpa como peligro.",
    "Describe una retirada y sus datos pendientes."
  ],
  "openAssessment": {
    "prompt": "Dibuja un croquis ficticio con zona de descanso, cocina exterior, acceso y salida. Marca las comprobaciones de terreno que no puedes resolver desde el dibujo.",
    "rubric": [
      "Distingue altitud y seguridad del emplazamiento.",
      "Identifica combustión en carpa como peligro.",
      "Describe una retirada y sus datos pendientes."
    ],
    "source": "e9-co",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN MÉDICA Y DE INSTRUCTOR PENDIENTES.** No es una herramienta de diagnóstico ni prescripción. Los casos son ficticios; no introduzcas datos médicos personales. Una emergencia real requiere asistencia urgente, no completar esta lección.

## Conceptos clave y propósito

Pernocta, habitabilidad, exposición, cocina, monóxido de carbono y acceso.

## Teoría y toma de decisiones

El campamento no es solo una cota en un gráfico. Es el lugar donde se duerme, se prepara agua y comida, se distribuye trabajo y se decide el día siguiente. El ejercicio separa dos planos: el perfil de altitud y la habitabilidad del emplazamiento. La mejor cifra de pernocta no elimina riesgos de caída de piedras, avalancha u otros peligros del terreno.

El monóxido de carbono puede producirse en equipos de combustión y es especialmente peligroso en espacios cerrados. No usar hornillos de combustible dentro de una carpa. Abrir un poco una entrada no convierte ese uso en seguro. Ante sospecha de exposición, salir a aire libre sin poner a otro en peligro y solicitar asistencia. [Prevención de CO](#fuente-e9-co).

La fatiga y la presión por terminar tareas pueden dejar sin responsable el agua o el acompañamiento de quien se siente mal. En el modelo docente se asignan funciones y se confirma su ejecución. Una lista marcada antes de instalar el campamento no demuestra que la situación haya permanecido igual.

La elección real del lugar y la operación del hornillo requieren entrenamiento y documentación específica. Aquí se comparan croquis ficticios. No se invita a probar cuánto puede cerrarse una carpa ni a reproducir un incidente.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación y análisis de aula.** Revisa acceso, peligros y salida antes de elegir el punto; distribuye tareas y conserva cocina fuera del espacio de descanso, conforme al manual del equipo. En el escenario, pregunta cómo se evacúa a una persona que no puede cargar mochila. Una alternativa que cruza terreno no evaluado se marca pendiente, no disponible.

Las indicaciones clínicas dependen del paciente y los recursos. Las maniobras de movilización, oxigenoterapia y rescate requieren formación práctica y supervisión competente. No extrapolar un caso de escritorio a una actuación real ni elegir fármacos a partir de un quiz.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Dos campamentos ficticios tienen la misma cota. Uno dispone de salida documentada y el otro exige remontar un collado sin información. El grupo además quiere cocinar dentro de la carpa por el viento. Identifica problemas independientes.

Identifica hechos, incertidumbres y decisiones. Explica qué información podría modificar tu propuesta. La rúbrica es docente, no un protocolo avalado por las instituciones citadas.

## Errores frecuentes y puntos críticos de seguridad

Elegir solo por altitud; confundir carpa con cocina segura; asumir que ventilar parcialmente elimina CO; dejar agua y evacuación sin responsable.

## Material y equipo relacionado

Carpa, aislamiento, abrigo, iluminación y hornillo con su manual. Casco, arnés o cuerda responden al terreno y la formación, no a la palabra campamento.

[Inventario educativo](../../equipo/). Tener el recurso no demuestra saber utilizarlo. El diario no es una ficha clínica.

## Autoevaluación y recuperación activa

- ¿Puedes explicar el concepto central sin confundirlo con una autorización de salida?
- ¿Qué dato falta en el escenario y qué decisión depende de él?
- ¿Qué tarea exige formación sanitaria o técnica y no se evalúa aquí?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Dibuja un croquis ficticio con zona de descanso, cocina exterior, acceso y salida. Marca las comprobaciones de terreno que no puedes resolver desde el dibujo.

**PRÁCTICA SUPERVISADA — propuesta:** Práctica de montaje y organización en entorno protegido con instructor. Demostración de hornillo exclusivamente donde su manual permita, nunca dentro de la carpa.

## Evidencia requerida y criterios de competencia

- Distingue altitud y seguridad del emplazamiento.
- Identifica combustión en carpa como peligro.
- Describe una retirada y sus datos pendientes.

**COMPETENCIA:** requiere observación contextual por instructor competente y revisión sanitaria cuando corresponda. Estos criterios evalúan preparación, comunicación y límites de actuación; no habilitan como profesional sanitario ni guía. La plataforma no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de la habilidad](../../practicas/?habilidad=s9-campamentos-altitud). Registra fecha, actividad, escenario ficticio, equipo, errores, correcciones, supervisor y evidencia del aprendizaje. No incluyas diagnósticos, recetas, mediciones personales ni datos de pacientes. Marca pendiente toda evaluación no realizada.

## Relaciones con otros módulos

[Volver a Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Escalada alpina](../../alpina/) · [Programa](../../programa/). La secuencia académica conecta planificación, comunicación y riesgo; no acredita aptitud clínica ni práctica.
