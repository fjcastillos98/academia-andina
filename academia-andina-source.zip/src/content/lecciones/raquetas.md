---
{
  "title": "Raquetas: flotación, tracción y límites de terreno",
  "description": "Comparar raquetas, botas con crampones y esquíes por función.",
  "module": "M02",
  "code": "E5-20",
  "order": 519,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-17",
  "skills": [
    "s5-raquetas"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Comparar raquetas, botas con crampones y esquíes por función.",
    "Relacionar carga total, nieve y terreno con elección de raqueta.",
    "Reconocer límites en travesías, ascenso y descenso."
  ],
  "prerequisites": [
    "s5-autodetencion"
  ],
  "sources": [
    "e5-msr-raquetas",
    "e5-sac-raquetas"
  ],
  "pending": [
    "Revisión de instructor y contraste con manuales exactos del equipo disponible. Cualquier aplicación territorial permanece pendiente de reconocimiento y condiciones actuales."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿Qué masa importa en la selección por flotación?",
        "options": [
          "Solo la bota.",
          "Persona más ropa y equipo transportado.",
          "Solo la mochila."
        ],
        "answer": 1,
        "explanation": "La carga total participa en el apoyo.",
        "rationales": [
          "Omite la mayor parte de la carga.",
          "Incluye el sistema transportado.",
          "Omite a la persona."
        ],
        "source": "e5-msr-raquetas",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Los dientes de una raqueta implican…",
        "options": [
          "Equivalencia con cualquier crampón.",
          "Ausencia de avalanchas.",
          "Tracción dentro de límites del diseño."
        ],
        "answer": 2,
        "explanation": "La función depende del producto y terreno.",
        "rationales": [
          "No son equipos intercambiables.",
          "No modifican estabilidad regional.",
          "Expresa el alcance correcto."
        ],
        "source": "e5-msr-raquetas",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una excursión con raquetas en nieve exige…",
        "options": [
          "Planificación y evaluación de exposición.",
          "Solo aprender a cerrar las fijaciones.",
          "Seguir cualquier huella previa."
        ],
        "answer": 0,
        "explanation": "La actividad sigue ocurriendo en terreno invernal.",
        "rationales": [
          "Incluye terreno y grupo.",
          "El ajuste es solo una parte.",
          "Una huella no valida condiciones."
        ],
        "source": "e5-sac-raquetas",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "Distingue flotación y tracción.",
    "Solicita datos de bota, carga y terreno.",
    "Reconoce cambio de condiciones que requiere reevaluar."
  ],
  "openAssessment": {
    "prompt": "Compara botas con crampones, raquetas y esquíes para dos superficies hipotéticas; identifica información faltante y límites de cada opción.",
    "rubric": [
      "Distingue flotación y tracción.",
      "Solicita datos de bota, carga y terreno.",
      "Reconoce cambio de condiciones que requiere reevaluar."
    ],
    "source": "e5-msr-raquetas",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Reconoce superficie de flotación y elementos de tracción por separado; compara con nieve y tarea, no solo con peso corporal.

## Teoría y toma de decisiones

Las raquetas aumentan la superficie de apoyo para ayudar a reducir hundimiento y añaden tracción según su diseño. Flotación y tracción son funciones diferentes: una plataforma amplia puede sostener mejor en determinada nieve y aun así no resolver un paso de hielo. MSR relaciona la elección con peso total de persona y equipo, nieve y terreno [fuente](#fuente-e5-msr-raquetas). No se convierte esa guía de producto en una talla universal ni en garantía de progresión.

Compara tres sistemas. Botas con crampones priorizan apoyo y agarre mediante puntas dentro de su uso previsto; no aportan la superficie de flotación de una raqueta. La raqueta facilita marcha en nieve adecuada, con una huella más amplia y limitaciones propias de maniobra. Los esquíes permiten ascenso con equipo específico y desplazamiento deslizante en descenso, pero exigen otra técnica. Ninguno elimina peligro de avalanchas. Una decisión sobre flotación no es una decisión sobre estabilidad del manto.

Los elementos habituales incluyen plataforma, fijación, articulación y componentes de tracción; algunos diseños tienen alza de talón. Identifica qué incorpora el modelo, cómo se ajusta a la bota y qué límites indica el fabricante. Los dientes integrados no hacen equivalente una raqueta a un crampón de montañismo. No uses una denominación comercial de terreno como sustituto de observar la superficie real. Una travesía puede exigir apoyos laterales que difieren de los de una marcha directa.

Ascender, descender, girar y atravesar requieren práctica. Al analizar un escenario, considera anchura disponible, pendiente, consistencia de nieve, obstáculos, carga y posibilidad de retirada. Evita convertir un dibujo en una instrucción de paso: el instructor debe observar equilibrio y manejo del conjunto. Un cambio de nieve puede exigir cambiar el plan antes de que el usuario se encuentre en un lugar donde no puede maniobrar. Llevar raquetas y crampones no demuestra habilidad para decidir ni ejecutar la transición.

El SAC incluye planificación, formación y evaluación de condiciones dentro de la seguridad en raquetas [fuente](#fuente-e5-sac-raquetas). La percepción de actividad recreativa puede ocultar terreno conectado con laderas de avalancha. El caso de aula pide identificar tanto la superficie pisada como lo que hay por encima y debajo. No se asigna un corredor seguro con una sola fotografía ni se concluye que un bosque elimina exposición.

En Filo Austral, comprueba que cada pasajero comprende la marcha y las limitaciones; no presupongas que el ajuste de una persona sirve para otra. El registro de equipo debe conservar modelo, manual e inspección de fijaciones y estructura. La ficha de práctica puede documentar cambios de dirección, control y errores observados por instructor en un lugar apropiado. La evidencia útil describe condiciones y tareas; «caminó con raquetas» es demasiado general para afirmar competencia en cualquier terreno.

## Qué observo, qué significa y qué no puedo concluir

No hay pendiente máxima universal. El uso real y las transiciones requieren práctica presencial supervisada; raquetas no sustituyen formación en avalanchas.

## Caso práctico y aplicación al guiado

Un grupo elige una raqueta grande para nieve profunda y después encuentra una travesía helada. Explica por qué la elección inicial no resuelve el nuevo problema.

## Errores frecuentes y señales de alerta

Confundir dientes integrados con crampones; olvidar masa de mochila; escoger solo por talla; asumir que raquetas implican terreno fácil.

## Autoevaluación y respuesta razonada

Compara botas con crampones, raquetas y esquíes para dos superficies hipotéticas; identifica información faltante y límites de cada opción.

## Ejercicios y práctica supervisada

Taller supervisado de ajuste y desplazamiento, con comparación de funciones en aula. Registrar terreno y condiciones del ejercicio sin extrapolarlos.

## Evidencia requerida

- Distingue flotación y tracción.
- Solicita datos de bota, carga y terreno.
- Reconoce cambio de condiciones que requiere reevaluar.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-raquetas).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
