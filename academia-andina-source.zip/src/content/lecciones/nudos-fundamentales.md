---
{
  "title": "Nudos fundamentales",
  "description": "Reconocer funciones y preparar un taller supervisado de confección, inspección y selección.",
  "module": "M01",
  "code": "P1-H",
  "order": 108,
  "minutes": 35,
  "level": "Fundamentos",
  "status": "pilot",
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir nombre, función y configuración de un nudo.",
    "Explicar por qué identificar una forma no demuestra ejecución competente.",
    "Preparar una comprobación basada en una referencia técnica."
  ],
  "prerequisites": [
    "Estudiar Equipamiento personal y colectivo y explicar sus límites."
  ],
  "sources": [
    "petzl-nudos"
  ],
  "pending": [
    "Revisión pedagógica y validación de criterios por instructor competente.",
    "Aplicación territorial en Los Lagos: requiere verificación situada.",
    "Demostración, variantes, comprobaciones y evaluación práctica por instructor."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "El nudo dinámico descrito por Petzl…",
        "options": [
          "Genera fricción y no bloquea por sí solo.",
          "Bloquea siempre sin intervención.",
          "Sustituye cualquier sistema de aseguramiento."
        ],
        "answer": 0,
        "explanation": "La ficha distingue fricción de bloqueo. Su uso real exige técnica, supervisión y control adecuados."
      },
      {
        "prompt": "Tras acertar el quiz de nudos, tu estado es…",
        "options": [
          "Competencia de encordamiento certificada.",
          "Comprensión teórica registrada; ejecución aún por evaluar.",
          "Autorización para enseñar el montaje."
        ],
        "answer": 1,
        "explanation": "El cuestionario no observa confección, inspección ni uso en contexto."
      }
    ]
  },
  "pilot": {
    "position": 8,
    "requires": [
      "equipamiento"
    ],
    "critical": true,
    "classifications": [
      "TEORÍA",
      "PROCEDIMIENTO",
      "PRÁCTICA INDIVIDUAL",
      "PRÁCTICA SUPERVISADA",
      "COMPETENCIA"
    ],
    "relatedModules": [
      "M01",
      "M00"
    ],
    "criteria": [
      "En evaluación presencial, el instructor define contexto y variante; observa selección, ejecución, explicación, comprobación y capacidad de detenerse ante una duda. El quiz solo evalúa distinciones teóricas."
    ]
  }
}
---
## Conceptos

**TEORÍA.** Un nudo es parte de un sistema: importa la función, el material, la configuración y la carga prevista. La ficha de Petzl distingue el ocho para encordamiento o anclaje, el ballestrinque para ajuste y el dinámico como dispositivo de fricción que no bloquea por sí solo [Petzl](#fuente-petzl-nudos). También señala requisitos particulares para variantes como el as de guía; las técnicas no deben mezclarse de memoria.

Este tema introduce vocabulario y criterios. La confección operativa, remates, longitudes y conexiones se enseñan con demostración y corrección presencial según la técnica elegida. No se ofrece una secuencia textual de encordamiento para usar sin formación.

## Desarrollo teórico y toma de decisiones

**PROCEDIMIENTO · preparación para taller, no instrucciones de ejecución.** **Objetivo de la maniobra:** conectar o gestionar una cuerda mediante una configuración adecuada a una función definida. **Cuándo se utiliza:** depende de la técnica; encordarse, ajustar una conexión y generar fricción son funciones distintas. **Principios:** identificación inequívoca, configuración coherente y comprobación antes de uso. **Componentes:** cuerda o cordino permitido y, cuando corresponda, elementos de conexión compatibles; deben seleccionarse con el instructor.

**Comprobaciones del taller:** decir qué función se busca; nombrar la referencia empleada; comparar la pieza completa con la demostración; señalar dudas y pedir revisión. No basta reconocer un dibujo de frente. **Variantes:** se estudian por separado con su fuente; no mezclar un remate de una técnica con otra. **Limitaciones:** reconocer nombres en pantalla no evalúa memoria motora, inspección bajo presión ni compatibilidad. **Supervisión:** toda aplicación a protección de personas requiere formación práctica y evaluación de un instructor competente.

## Ejemplo

Actividad didáctica original, no descripción de una ruta operativa.

## Caso de estudio

Caso ficticio: un alumno puede nombrar cuatro nudos pero no explicar qué función busca en un montaje. Otro detecta una diferencia con la referencia y detiene la comprobación. ¿Quién aporta evidencia útil y de qué tipo?

Respuesta orientativa: nombrar demuestra una parte del vocabulario; detenerse ante una diferencia demuestra un hábito de revisión. Ninguno de los dos queda habilitado para encordarse por esa observación aislada.

## Errores frecuentes

Reconocer solo la silueta; llamar “autobloqueante” a cualquier montaje con fricción; copiar un vídeo sin verificar contexto; convertir repeticiones en acreditación.

## Límites y puntos críticos de seguridad

Práctica exclusivamente en suelo y sin personas ni cargas suspendidas hasta la progresión dirigida por instructor. Un error puede tener consecuencias graves. No usar estas notas como instrucciones de montaje.

## Material y equipo relacionado

Cuerda de práctica, referencia Petzl y material seleccionado por el instructor. Arnés y mosquetones se incorporan únicamente en el taller correspondiente.

## Recuperación activa

- ¿Por qué un nombre no basta para especificar una configuración?
- ¿Qué diferencia hay entre generar fricción y bloquear?

Responde antes de consultar el texto. Luego anota qué cambiaste y por qué; el recuerdo sin justificación no basta.

## Ejercicio y práctica

**PRÁCTICA INDIVIDUAL** limitada a análisis en mesa u observación segura. Primero clasifica tarjetas con nombre y función a partir de la fuente. En taller supervisado, el instructor selecciona una técnica y demuestra ejecución e inspección; registra errores reales y correcciones sin inventar un aprobado.

**PRÁCTICA SUPERVISADA.** Un instructor competente selecciona el contexto y observa la ejecución pertinente; este texto no autoriza a realizar maniobras técnicas sin esa formación. Antes de la sesión, acuerda objetivo, límites y cómo se interrumpirá el ejercicio.

## Registro de práctica

Abre el Diario de prácticas desde la navegación y selecciona esta habilidad. Registra fecha, lugar, condiciones, actividad, equipo, repeticiones, errores, correcciones y evidencia. Identifica al supervisor solo cuando estuvo presente. La confianza es una percepción, no un resultado de competencia. No incluyas datos médicos, contraseñas ni información privada de terceros.

## Criterios de revisión y competencia

**COMPETENCIA · evaluación pendiente.** En evaluación presencial, el instructor define contexto y variante; observa selección, ejecución, explicación, comprobación y capacidad de detenerse ante una duda. El quiz solo evalúa distinciones teóricas.

La evaluación debe indicar quién observó, qué contexto y evidencia revisó, qué criterio aplicó y cuál fue el resultado. El diario conserva una declaración del usuario: no verifica identidad ni credenciales del evaluador y no emite certificaciones. Una lectura o quiz nunca demuestra ejecución técnica.

## Próximos pasos y relación con otros módulos

Continúa con **Cuerdas y conceptos básicos de anclaje**.

Relación con el currículo original: M01. Esta secuencia pertenece al bloque piloto **Módulo 1 — Fundamentales**; no renumera las 376 entradas pendientes del mapa original. Meteorología, navegación y decisiones se revisitan en montaña estival, invernal y glaciar; no son prerrequisitos prácticos ya acreditados.
