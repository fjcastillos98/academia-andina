---
{
  "title": "Pronósticos y decisiones operacionales",
  "description": "Separar modelo, pronóstico, alerta, observación y decisión.",
  "module": "M10",
  "code": "E4-07",
  "order": 207,
  "minutes": 45,
  "level": "Intermedio",
  "status": "development",
  "reviewDate": "2026-10-22",
  "unit": "U4-07",
  "skills": [
    "s4-pronostico-decision"
  ],
  "critical": false,
  "objectives": [
    "Separar modelo, pronóstico, alerta, observación y decisión.",
    "Comparar productos por variable, altura y periodo.",
    "Transformar incertidumbre en alternativas y puntos de revisión."
  ],
  "prerequisites": [
    "Completar estudio de Fundamentales; la práctica previa debe revisarse presencialmente.",
    "Estudiar Atmósfera y meteorología de montaña."
  ],
  "sources": [
    "ecmwf-incertidumbre",
    "dmc",
    "nws-rayos"
  ],
  "pending": [
    "Revisión pedagógica y evaluación situada por instructor competente.",
    "Condiciones, accesos, permisos y compatibilidad del equipo requieren verificación para cada actividad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Falta la hora de validez de una captura. ¿Qué corresponde?",
        "options": [
          "Usarla como vigente.",
          "Recuperar el producto y contexto antes de basar la decisión en él.",
          "Elegir la captura más soleada."
        ],
        "answer": 1,
        "explanation": "Sin periodo no se puede vincular razonablemente el producto al itinerario."
      },
      {
        "prompt": "Un conjunto de pronósticos ayuda a…",
        "options": [
          "Explorar incertidumbre, sin garantizar un resultado.",
          "Eliminar toda incertidumbre.",
          "Certificar competencia de guía."
        ],
        "answer": 0,
        "explanation": "Sus realizaciones muestran escenarios; no constituyen certeza del terreno."
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

**TEORÍA.** Un **modelo numérico** calcula una evolución posible a partir de datos y aproximaciones. Un **pronóstico** comunica una previsión que puede incorporar modelos y análisis. Una **alerta meteorológica** es un producto oficial con alcance y criterios propios. Una **observación del cielo** describe lo que alguien ve; las **condiciones locales** incluyen lo que ocurre en el terreno; la **decisión operacional** elige qué hará el grupo. Ninguna de esas categorías debe presentarse como sinónimo de las demás.

ECMWF explica que errores de condiciones iniciales y aproximaciones del modelo contribuyen a incertidumbre, que puede crecer con el plazo. Los conjuntos exploran distintas realizaciones para representar esa incertidumbre [Referencia: ecmwf-incertidumbre](#fuente-ecmwf-incertidumbre). La dispersión es información, no un defecto que deba ocultarse escogiendo la curva preferida.

## Teoría: protocolo de lectura documental

Primero identifica emisor, emisión y validez. Después determina área, elevación o nivel, variables, unidades y periodo de acumulación. Separa viento medio de rachas, temperatura de sensación térmica y probabilidad de precipitación de cantidad. No compares cifras antes de comprobar que representan lo mismo.

Anota la hora con zona horaria: una captura sin contexto puede desplazar el fenómeno respecto del itinerario. Comprueba la fecha y evita interpretar un producto archivado como actual. El curso usa ejercicios ficticios y fuentes fechadas; no contiene un servicio de alertas en tiempo real.

Consulta la Dirección Meteorológica de Chile para los productos oficiales pertinentes [Referencia: dmc](#fuente-dmc). El portal fue localizado; aquí no se ha validado un boletín específico de ruta ni se reproducen los umbrales de sus categorías. La ausencia de una alerta aplicable no demuestra que una actividad concreta sea apropiada para un grupo determinado.

## Comparar sin convertir marcas en certezas

Distingue instituciones/modelos como ECMWF, GFS o ICON de interfaces y proveedores como Windy, Meteoblue y Mountain-Forecast. Antes de comparar cualquiera de ellos verifica qué modelo o combinación usa el producto concreto, actualización, altura y posprocesamiento. **La configuración vigente de esas plataformas requiere verificación; esta lección no ofrece un ranking ni atribuye precisión superior universal.**

Una tabla útil contiene producto, modelo declarado, emisión, validez, coordenada/sector, altura, viento/rachas, precipitación, temperatura, visibilidad y limitaciones. Dos aplicaciones pueden mostrar información dependiente de una misma fuente: contar pantallas no equivale a tener observaciones independientes.

## Del pronóstico a la decisión

En la ficha del recorrido, escribe qué variables podrían comprometer cada etapa. La pregunta no es “¿me gusta el pronóstico?”, sino “¿qué supuesto del plan deja de sostenerse si ocurre este escenario?”. Identifica cuándo debes decidir para conservar una alternativa. Un plan que exige esperar a que llegue el fenómeno al punto más comprometido necesita revisión.

El NWS subraya que no existe un lugar exterior completamente seguro durante una tormenta eléctrica [Referencia: nws-rayos](#fuente-nws-rayos). Este principio orienta a evitar exposición y planificar con anticipación; no convierte un árbol, una carpa o una depresión del terreno en refugio garantizado. No se enseña aquí una maniobra de protección improvisada.

## Caso práctico: tabla ficticia de dos productos

| Dato comparable | Producto A | Producto B |
| --- | --- | --- |
| Emisión | 06:00, misma zona horaria | 06:00, misma zona horaria |
| Periodo | 12:00–18:00 | 12:00–18:00 |
| Sector/elevación | Iguales, hipotéticos | Iguales, hipotéticos |
| Visibilidad | Posible reducción | Dato ausente |
| Viento | Aumento en la tarde | Evolución incierta |

No se aportan cifras ni umbrales reales. El grupo planea permanecer en un sector sin alternativa clara de retorno durante la tarde. La respuesta orientativa reconoce que el dato ausente no es una previsión favorable, adelanta la revisión y estudia un objetivo con salida más robusta. No “promedia” visibilidad con un vacío.

## Errores frecuentes y señales de alerta

Elegir la aplicación más optimista; comparar acumulados distintos; confundir hora UTC y local; ignorar altura; usar el color de un mapa sin leer leyenda; convertir una observación de buen tiempo al inicio en garantía para la tarde. La falta de fecha o de correspondencia espacial es motivo para limitar el uso del producto.

## Autoevaluación y respuestas explicadas

1. ¿Cinco aplicaciones que usan el mismo modelo son cinco comprobaciones independientes? **No necesariamente: pueden compartir errores y datos de origen.**
2. ¿Qué haces si dos productos difieren? **Compruebas comparabilidad, describes la discrepancia y evalúas alternativas que no dependan de acertar una única evolución.**

## Ejercicios y práctica presencial

Archiva manualmente un producto oficial con fecha y contexto, sin declararlo vigente después. Completa la tabla de lectura y plantea dos escenarios. En mesa, otro alumno cambia un dato; revisa qué decisión se modifica. Para llevarlo a una salida, solicita revisión de la interpretación y del itinerario por una persona competente.

## Evidencia requerida

Ficha de comparación, enlace y fecha, incertidumbres, decisión y momento de revisión. No se evalúa acertar el tiempo a posteriori, sino la calidad de la interpretación con la información disponible.

## Relaciones con otras habilidades

Esta unidad se integra en la ruta estival. Consulta la ficha de habilidad y sus prerrequisitos en el programa. Registra práctica y evaluación por separado: estudiar y responder correctamente no acredita ejecución. Los ejercicios son propuestas didácticas originales; los casos no son rutas operativas.
