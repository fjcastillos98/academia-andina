---
{
  "title": "Anclajes en hielo: soporte, tornillos y sistemas",
  "description": "Distinguir resistencia del producto y comportamiento de una colocación.",
  "module": "M05",
  "code": "E7-07",
  "order": 707,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U7-07",
  "skills": [
    "s7-anclajes-hielo"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Distinguir resistencia del producto y comportamiento de una colocación.",
    "Explicar redundancia y fallos compartidos sin dimensionar un anclaje por intuición."
  ],
  "prerequisites": [
    "s7-aseguramiento-hielo"
  ],
  "sources": [
    "e7-uiaa-standards",
    "e7-screws",
    "e7-rebore",
    "e7-inspection"
  ],
  "pending": [
    "Revisión de instructor de hielo pendiente; no se ha observado ni aprobado ninguna práctica.",
    "Compatibilidad y manual de los modelos personales pendientes de verificación; ninguna pieza se considera apta por aparecer en el inventario."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "El marcado de un tornillo demuestra…",
        "options": [
          "Capacidad de toda colocación natural.",
          "Estabilidad de la columna.",
          "Cumplimiento declarado del producto, no del soporte real."
        ],
        "answer": 2,
        "explanation": "Hay que distinguir niveles del sistema. Distinguir resistencia del producto y comportamiento de una colocación.",
        "rationales": [
          "El ensayo y la colocación difieren.",
          "El marcado no evalúa una estructura natural.",
          "Hay que distinguir niveles del sistema."
        ],
        "source": "e7-uiaa-standards",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Dos puntos en el mismo soporte…",
        "options": [
          "Pueden compartir un modo de fallo.",
          "Duplican siempre la resistencia.",
          "Eliminan la necesidad de inspección."
        ],
        "answer": 0,
        "explanation": "La redundancia requiere analizar dependencias. Distinguir resistencia del producto y comportamiento de una colocación.",
        "rationales": [
          "La redundancia requiere analizar dependencias.",
          "No es una suma automática.",
          "La inspección sigue siendo necesaria."
        ],
        "source": "e7-inspection",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un ensayo publicado sirve para…",
        "options": [
          "Copiar una carga límite a cualquier hielo.",
          "Comprender resultados bajo las condiciones ensayadas.",
          "Omitir al instructor."
        ],
        "answer": 1,
        "explanation": "El alcance pertenece al experimento. Distinguir resistencia del producto y comportamiento de una colocación.",
        "rationales": [
          "No se transfieren condiciones sin justificación.",
          "El alcance pertenece al experimento.",
          "Un texto no acredita ejecución."
        ],
        "source": "e7-rebore",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Separa producto, colocación y soporte al justificar una decisión.",
    "Identifica fallos compartidos y límites de inspección.",
    "En taller realiza comprobaciones del método enseñado y comunica duda o defecto."
  ],
  "openAssessment": {
    "prompt": "Dibuja un árbol de fallos conceptual con tres niveles: producto, colocación y soporte. Añade un fallo que afecte a dos puntos a la vez y una pregunta de verificación por nivel.",
    "rubric": [
      "Separa producto, colocación y soporte al justificar una decisión.",
      "Identifica fallos compartidos y límites de inspección.",
      "En taller realiza comprobaciones del método enseñado y comunica duda o defecto."
    ],
    "source": "e7-uiaa-standards",
    "difficulty": "integración"
  },
  "diagrams": [
    "e7-sistema"
  ]
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. El estudio y el quiz no acreditan una maniobra ni capacidad de guiado.**

## Conceptos clave y propósito

Soporte, colocación, tornillo, dirección de carga, redundancia y fallo común.

## Teoría y toma de decisiones

El ensayo normalizado de un producto y el comportamiento de una colocación real responden a preguntas diferentes. La UIAA publica estándares para anclajes de hielo; sus condiciones de ensayo no son una promesa sobre cualquier estructura natural. La selección del soporte, colocación y sistema completo exige criterio técnico entrenado. [Fuente de contraste](#fuente-e7-uiaa-standards).

Los análisis de fabricantes muestran por qué calidad del hielo y condiciones de colocación importan. Un tornillo reconocible o largo no valida por sí mismo el soporte. Una cifra de laboratorio sin material, geometría y método no sirve como capacidad de una reunión real. Esta unidad no asigna una resistencia a hielo observado en fotografías. [Fuente de contraste](#fuente-e7-screws).

Dos elementos pueden compartir el mismo fallo si dependen de una masa de hielo que se desprende. La redundancia se evalúa por funciones y modos de fallo, no solo contando piezas. La dirección de las fuerzas, cambios de posición y tareas previstas también pertenecen al análisis del conjunto.

Un abalakov o puente de hielo emplea el propio hielo como parte del anclaje. Sus variantes, inspección y uso se estudian con la fuente y el método del instructor. No se incluyen aquí dimensiones ni una secuencia de perforación para ejecutar una maniobra. Confundir comprensión del principio con capacidad de construcción sería una conclusión que el contenido no respalda.

En la preparación académica plantea qué debe saberse antes de elegir: soporte disponible, función, cargas previstas, compatibilidad, posibilidad de comprobación y retirada. Cuando no puedes responder una pregunta esencial, el resultado del análisis es un límite, no una autorización condicionada a «tener cuidado».

Black Diamond estudió reutilización de agujeros y reconoce un solo dato por ensayo. La diferencia entre agujero y tornillo puede afectar a la colocación; las cargas publicadas no se adoptan como capacidad de un anclaje real. [Alcance del ensayo](#fuente-e7-rebore).

## Procedimiento: función, comprobaciones y límites

**PROCEDIMIENTO — marco de análisis previo al taller.** Objetivo: Distinguir resistencia del producto y comportamiento de una colocación. Se utiliza para preparar el aprendizaje y detectar vacíos antes de una tarea real. Identifica la función, los componentes, la información que falta y las consecuencias de un error. Contrasta la versión de la fuente con el modelo de equipo y el método del instructor. No hay una configuración universal derivada de esta página.

Las comprobaciones relevantes se desarrollan en la teoría, el equipo y la rúbrica de esta unidad. Si el uso previsto o la protección del taller no están claros, la práctica no se inicia. Las variantes de una fuente se conservan dentro de su contexto; no se mezclan pasos de métodos distintos por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario ficticio para análisis:** Un croquis muestra dos tornillos en una misma columna. El autor lo llama redundante sin estudiar la columna. Enumera modos de fallo compartidos y qué evidencia falta, sin asignar kilonewtons.

Antes de responder, enumera los hechos dados y los datos que has supuesto. Propón una decisión provisional y una condición que te haría revisarla. El caso, los ejercicios y las rúbricas son propuestas pedagógicas originales de la academia, pendientes de revisión docente; no son un protocolo de un organismo citado.

## Errores frecuentes y puntos críticos de seguridad

Confundir marcado con resistencia de colocación; sumar resistencias nominales; contar puntos sin examinar soporte común; extrapolar un ensayo; reutilizar un puente de hielo sin revisión.

No uses la ausencia de incidentes como prueba de seguridad. Las tareas con carga, herramientas o exposición necesitan control presencial competente. Ninguna respuesta escrita autoriza a escalar, montar un anclaje ni asistir a un pasajero.

## Material y equipo relacionado

Tornillos inspeccionados, conectores, cintas y cuerda compatibles, herramientas auxiliares y manuales. Marca, longitud y cantidad son datos, no una aprobación del sistema.

[Consultar inventario](../../equipo/). Registra documento y revisión, sin inventar inspecciones realizadas. Tener material no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con tus palabras: Distinguir resistencia del producto y comportamiento de una colocación.
- ¿Qué observación del caso apoya tu decisión y qué dato sigue faltando?
- ¿Qué error de esta unidad podrías reconocer documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Dibuja un árbol de fallos conceptual con tres niveles: producto, colocación y soporte. Añade un fallo que afecte a dos puntos a la vez y una pregunta de verificación por nivel.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Instructor selecciona entorno, protección independiente y método de enseñanza. Se practican identificación, colocaciones y revisión según su programa; una prueba informal de tracción no certifica el anclaje.

## Evidencia requerida y criterios de competencia

- Separa producto, colocación y soporte al justificar una decisión.
- Identifica fallos compartidos y límites de inspección.
- En taller realiza comprobaciones del método enseñado y comunica duda o defecto.

**COMPETENCIA:** estos criterios orientan la revisión. Cuando implican ejecución, el instructor debe observarla en un contexto definido, registrar resultado y lo que no se evaluó. No hay umbral automático de repeticiones, confianza o aciertos. La plataforma conserva una declaración personal y no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s7-anclajes-hielo). Registra solo tareas realmente realizadas: fecha, lugar, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Mantén separados resultado observado, confianza y evaluación. No incluyas datos médicos ni datos privados de terceros.

## Relaciones con otros módulos

[Ruta invernal](../../invierno/), [formación glaciar](../../glaciar/), [encordamiento según contexto](../encordamiento-contexto/) y [anclajes y reuniones](../anclajes-reuniones/) aportan prerrequisitos. La aplicación alpina y el guiado requieren su propia formación y evaluación. [Volver a la secuencia de hielo](../../hielo/).
