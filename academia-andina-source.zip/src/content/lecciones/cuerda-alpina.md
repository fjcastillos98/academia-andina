---
{
  "title": "Manejo de cuerda: trayectoria, orden y transiciones",
  "description": "Relacionar recorrido de cuerda, rozamiento y exposición.",
  "module": "M06",
  "code": "E8-04",
  "order": 804,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U8-04",
  "skills": [
    "s8-cuerda-alpina"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Relacionar recorrido de cuerda, rozamiento y exposición.",
    "Preparar transiciones que mantengan funciones y comunicación claras."
  ],
  "prerequisites": [
    "s8-encordamiento-alpino"
  ],
  "sources": [
    "e8-rope-cuts",
    "e8-rope",
    "e8-single"
  ],
  "pending": [
    "Revisión docente y práctica presencial por instructor alpino competente pendientes. No se ha observado ni aprobado una maniobra.",
    "Compatibilidad y manual del equipo personal pendientes de verificación; no se extrapolan ejemplos GRIGRI/REVERSO/RAD LINE a ATC Guide u otras cuerdas."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "La cuerda tiene marcado reconocido. Ante una arista…",
        "options": [
          "No existe riesgo de corte.",
          "Solo importa el color de la funda.",
          "Sigue siendo necesario evaluar trayectoria y contacto."
        ],
        "answer": 2,
        "explanation": "El sistema real conserva ese peligro. Relacionar recorrido de cuerda, rozamiento y exposición.",
        "rationales": [
          "El marcado no cubre toda situación de borde.",
          "El color no evalúa la interacción.",
          "El sistema real conserva ese peligro."
        ],
        "source": "e8-rope-cuts",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Aumenta el rozamiento. ¿Qué interpretar?",
        "options": [
          "Puede haber varias causas que deben revisarse.",
          "Siempre falta fuerza del asegurador.",
          "Siempre falta cuerda."
        ],
        "answer": 0,
        "explanation": "Trayectoria y enganches son hipótesis distintas. Relacionar recorrido de cuerda, rozamiento y exposición.",
        "rationales": [
          "Trayectoria y enganches son hipótesis distintas.",
          "No se justifica esa causa única.",
          "No es la única explicación posible."
        ],
        "source": "e8-rope",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "En una transición se debe poder explicar…",
        "options": [
          "Solo qué pieza se retira primero.",
          "Qué función permanece y cómo se confirma cada cambio.",
          "Solo el tiempo ahorrado."
        ],
        "answer": 1,
        "explanation": "La organización mantiene el propósito del sistema. Relacionar recorrido de cuerda, rozamiento y exposición.",
        "rationales": [
          "Una acción aislada no describe continuidad.",
          "La organización mantiene el propósito del sistema.",
          "El ahorro no demuestra control."
        ],
        "source": "e8-rope-cuts",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Reconoce contactos y límites de visibilidad en la trayectoria.",
    "Mantiene identificadas funciones y extremos en el ejercicio.",
    "Comunica una anomalía antes de alterar el sistema bajo supervisión."
  ],
  "openAssessment": {
    "prompt": "Sobre un croquis de aula marca recorrido, posibles contactos y zonas no visibles. Para cada transición escribe función que debe mantenerse, responsable y confirmación, sin dibujar un montaje operativo.",
    "rubric": [
      "Reconoce contactos y límites de visibilidad en la trayectoria.",
      "Mantiene identificadas funciones y extremos en el ejercicio.",
      "Comunica una anomalía antes de alterar el sistema bajo supervisión."
    ],
    "source": "e8-rope-cuts",
    "difficulty": "integración"
  },
  "diagrams": [
    "e8-transicion"
  ]
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. Lecturas y cuestionarios no acreditan ejecución técnica ni guiado.**

## Conceptos clave y propósito

Trayectoria, arista, rozamiento, bucles, extremos, organización y continuidad de protección.

## Teoría y toma de decisiones

La cuerda conecta un sistema, pero también recorre el terreno. Una línea sobre aristas, bloques o zonas de caída de objetos puede introducir problemas aunque cada pieza se haya identificado correctamente. El informe UIAA sobre cortes explica que la interacción de cuerda cargada y borde debe tomarse en serio; un marcado no garantiza resistencia a cualquier corte. [Fuente de contraste](#fuente-e8-rope-cuts).

El rozamiento altera la facilidad de movimiento y la información que recibe el asegurador. Una dificultad para dar o recuperar cuerda no debe atribuirse de inmediato a falta de fuerza. Puede deberse a trayectoria, enganches o desorden. La respuesta necesita reconocer la causa sin soltar funciones de protección para resolver solo la molestia. [Fuente de contraste](#fuente-e8-rope).

Organizar la cuerda significa prever qué tramo se utiliza, qué extremo corresponde a cada función y qué ocurrirá en la siguiente transición. Un conjunto ordenado al inicio puede dejar de serlo al cambiar de líder o de dirección. El orden es funcional: debe permitir comprender y controlar el sistema, no solo verse limpio.

Los sistemas con una, dos cuerdas o técnicas distintas se eligen según diseño, instrucciones y aprendizaje. No se mezclan métodos de mosquetoneo o dispositivos por semejanza. El diámetro nominal y la disponibilidad en el inventario no bastan para validar combinaciones. La decisión debe poder explicarse sin inventar propiedades del material. [Fuente de contraste](#fuente-e8-single).

Una transición se prepara con tareas explícitas: qué función debe seguir activa, quién la controla, qué cambio se verifica y cómo se confirma el resultado. Es una pauta de análisis, no una secuencia de desconexión. El montaje y sus cambios necesitan enseñanza práctica del método correspondiente.

El ensayo Petzl sobre rozamiento ilustra que una trayectoria desfavorable puede limitar la participación de la cuerda en la absorción de energía. El montaje exagera el rozamiento para estudiar el mecanismo; sus resultados no predicen fuerzas de una caída real ni fijan longitudes universales de cintas. [Alcance del ensayo](#fuente-e8-rope).

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — análisis previo al taller.** Relacionar recorrido de cuerda, rozamiento y exposición. Se utiliza al preparar una tarea o revisar un cambio de contexto. Las comprobaciones se organizan por función, soporte, equipo, capacidades y continuidad de protección. La teoría y la rúbrica especifican qué observar en esta unidad.

El instructor selecciona método, protección y condiciones de parada. Si falta una condición esencial o el grupo no comprende una función, no se inicia la maniobra. Las variantes se mantienen dentro del contexto de su fuente: una página sobre vía equipada, un producto o senderismo no constituye un procedimiento universal alpino.

## Caso práctico y aplicación al guiado

**Escenario de aula:** Un asegurador ficticio nota resistencia creciente y el líder pide rapidez. El croquis muestra un cambio de dirección sobre un borde y no se sabe dónde están los bucles. Enumera hipótesis y qué no debe sacrificarse para acelerar.

Distingue hechos, suposiciones y preguntas antes de proponer una decisión. Los ejercicios, casos y rúbricas son propuestas pedagógicas originales de la academia pendientes de revisión docente. No se presentan como protocolos de los organismos citados.

## Errores frecuentes y puntos críticos de seguridad

Ignorar la trayectoria; interpretar todo roce como fatiga; dejar bucles cerca de puntas o bloques; mezclar sistemas de cuerda sin instrucciones; resolver una transición antes de acordar funciones.

Una práctica protegida tiene un alcance limitado; no valida todas las condiciones futuras. No se aprende una técnica crítica mediante una caída deliberada ni copiando una imagen en terreno expuesto.

## Material y equipo relacionado

Cuerda o cuerdas del sistema enseñado, conectores y dispositivo compatibles, documentación de uso y revisión. Crampones y herramientas añaden posibles contactos que deben considerarse.

[Consultar inventario](../../equipo/). Identifica modelo, documentación y datos pendientes. No inventes inspecciones ni atribuyas competencia a la compra de un dispositivo.

## Autoevaluación y recuperación activa

- Explica con un ejemplo: Relacionar recorrido de cuerda, rozamiento y exposición.
- ¿Qué información falta en el caso y qué decisión depende de ella?
- ¿Qué parte puedes revisar documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Sobre un croquis de aula marca recorrido, posibles contactos y zonas no visibles. Para cada transición escribe función que debe mantenerse, responsable y confirmación, sin dibujar un montaje operativo.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Instructor organiza un ejercicio de cuerda sin exposición y después, si procede, un sistema protegido. Observa orden, identificación de extremos, comunicación y detección de enganches; no se carga una cuerda contra un borde para probar resistencia.

## Evidencia requerida y criterios de competencia

- Reconoce contactos y límites de visibilidad en la trayectoria.
- Mantiene identificadas funciones y extremos en el ejercicio.
- Comunica una anomalía antes de alterar el sistema bajo supervisión.

**COMPETENCIA:** la ejecución debe evaluarse presencialmente en un contexto explícito por instructor competente. Las respuestas escritas no sustituyen esa observación. Se registra qué ocurrió, qué no se evaluó y qué debe corregirse. No hay un número de repeticiones que otorgue competencia automáticamente.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s8-cuerda-alpina). Registra solo lo realizado: fecha, lugar, actividad, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Confianza, resultado y evaluación son datos diferentes. No guardar datos médicos, contraseñas ni datos privados de terceros.

## Relaciones con otros módulos

Integra [hielo](../../hielo/), [glaciar](../../glaciar/), [planificación invernal](../planificacion-invernal/) y [anclajes y reuniones](../anclajes-reuniones/). El [programa](../../programa/) muestra prerrequisitos; son académicos, no habilitaciones. [Volver al bloque alpino](../../alpina/).
