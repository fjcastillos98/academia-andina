---
{
  "title": "Nutrición en altitud: planificar lo que se puede comer",
  "description": "Relacionar disponibilidad, preparación y consumo real de alimentos.",
  "module": "M03",
  "code": "E9-08",
  "order": 908,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U9-08",
  "skills": [
    "s9-nutricion-altitud"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Relacionar disponibilidad, preparación y consumo real de alimentos.",
    "Separar una lista logística de una prescripción nutricional individual."
  ],
  "prerequisites": [
    "s9-campamentos-altitud"
  ],
  "sources": [
    "e9-nutrition"
  ],
  "pending": [
    "Revisión médica por profesional de medicina de montaña y revisión docente por instructor pendientes. No se ha evaluado atención clínica ni rescate.",
    "Casos, ejercicios y criterios son propuestas pedagógicas originales; no autorizan decisiones clínicas individuales.",
    "Condiciones de rutas, comunicaciones y recursos de atención locales requieren verificación antes de cada salida."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Tener todas las raciones compradas demuestra…",
        "options": [
          "Disponibilidad prevista, no consumo real.",
          "Que la persona ya comió suficiente.",
          "Que todas sirven sin agua."
        ],
        "answer": 0,
        "explanation": "Compra y consumo son distintos.",
        "rationales": [
          "Compra y consumo son distintos.",
          "No describe la ingesta.",
          "Depende de cada producto."
        ],
        "source": "e9-nutrition",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Antes de una expedición conviene…",
        "options": [
          "Estrenar todos los alimentos allí.",
          "Ensayar preparación y aceptación.",
          "Eliminar toda variedad por defecto."
        ],
        "answer": 1,
        "explanation": "Permite detectar problemas logísticos.",
        "rationales": [
          "Añade incertidumbre evitable.",
          "Permite detectar problemas logísticos.",
          "No es una regla nutricional universal."
        ],
        "source": "e9-nutrition",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "El plan individual de ingesta debe…",
        "options": [
          "Copiarse de cualquier expedicionario.",
          "Usar solo calorías de una pulsera.",
          "Revisarse con un profesional según necesidades."
        ],
        "answer": 2,
        "explanation": "Requiere contexto individual.",
        "rationales": [
          "Las necesidades varían.",
          "Una medición aislada no define el plan.",
          "Requiere contexto individual."
        ],
        "source": "e9-nutrition",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Separa alimento transportado de consumido.",
    "Identifica dependencias de agua y cocina.",
    "Propone alternativas sin prescribir necesidades individuales."
  ],
  "openAssessment": {
    "prompt": "Compara tres alimentos ficticios por preparación, agua, acceso y alternativa. No incluyas peso corporal, diagnósticos ni macros personales.",
    "rubric": [
      "Separa alimento transportado de consumido.",
      "Identifica dependencias de agua y cocina.",
      "Propone alternativas sin prescribir necesidades individuales."
    ],
    "source": "e9-nutrition",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN MÉDICA Y DE INSTRUCTOR PENDIENTES.** No es una herramienta de diagnóstico ni prescripción. Los casos son ficticios; no introduzcas datos médicos personales. Una emergencia real requiere asistencia urgente, no completar esta lección.

## Conceptos clave y propósito

Disponibilidad energética, apetito, palatabilidad, acceso y preparación.

## Teoría y toma de decisiones

Llevar comida y consumirla son problemas distintos. El apetito puede reducirse en altitud, y el frío, el cansancio o la dificultad de preparación pueden disminuir el consumo efectivo. UIAA propone ensayar los alimentos antes del viaje y favorecer opciones aceptadas, variadas y fáciles de preparar. [UIAA MedCom, nutrición](#fuente-e9-nutrition).

El ejercicio de esta unidad no calcula necesidades personales: compara dos planes logísticos ficticios. El primero concentra toda la comida en una preparación larga al final del día; el segundo distribuye accesos y contempla una alternativa que no requiere cocción. El estudiante debe explicar qué pasaría si falta agua o falla el sistema de cocina.

Las calorías del envase no indican cuánto se comió. Tampoco permiten evaluar por sí solas tolerancia, conservación o facilidad de manipulación con guantes. Una revisión útil anota producto, tarea de preparación, agua necesaria, acceso durante la marcha y alternativa; evita declarar una dieta universal por kilogramo de peso.

Los objetivos de composición corporal se trabajan por separado con el profesional adecuado. El propósito del módulo es sostener una actividad exigente y reconocer problemas, no usar la expedición como estrategia de restricción alimentaria. El diseño individual de ingesta y las situaciones clínicas requieren evaluación profesional.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación y análisis de aula.** Ensaya una comida habitual en condiciones domésticas seguras, registra tiempo y recursos de preparación y diseña una alternativa. En el ejercicio de grupo, comprueba quién transporta cada ración y cuándo se puede acceder a ella. No experimentes con privación de comida para simular altitud ni interpretes pérdida de apetito como algo que deba ignorarse.

Las indicaciones clínicas dependen del paciente y los recursos. Las maniobras de movilización, oxigenoterapia y rescate requieren formación práctica y supervisión competente. No extrapolar un caso de escritorio a una actuación real ni elegir fármacos a partir de un quiz.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** La mochila contiene suficientes envases según la compra, pero casi todos exigen agua caliente y la cocina queda en otra cordada. Construye una solución logística para una simulación futura.

Identifica hechos, incertidumbres y decisiones. Explica qué información podría modificar tu propuesta. La rúbrica es docente, no un protocolo avalado por las instituciones citadas.

## Errores frecuentes y puntos críticos de seguridad

Contar solo envases; estrenar toda la dieta en expedición; depender de una sola cocina; usar una cifra de otro deportista como prescripción propia.

## Material y equipo relacionado

Raciones etiquetadas, recipientes, utensilios y sistema de cocina conforme al manual. La reserva debe poder usarse con los recursos realmente disponibles.

[Inventario educativo](../../equipo/). Tener el recurso no demuestra saber utilizarlo. El diario no es una ficha clínica.

## Autoevaluación y recuperación activa

- ¿Puedes explicar el concepto central sin confundirlo con una autorización de salida?
- ¿Qué dato falta en el escenario y qué decisión depende de él?
- ¿Qué tarea exige formación sanitaria o técnica y no se evalúa aquí?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Compara tres alimentos ficticios por preparación, agua, acceso y alternativa. No incluyas peso corporal, diagnósticos ni macros personales.

**PRÁCTICA SUPERVISADA — propuesta:** Taller de logística alimentaria con instructor y revisión de nutricionista para cualquier plan individual. La evaluación docente observa preparación y contingencias.

## Evidencia requerida y criterios de competencia

- Separa alimento transportado de consumido.
- Identifica dependencias de agua y cocina.
- Propone alternativas sin prescribir necesidades individuales.

**COMPETENCIA:** requiere observación contextual por instructor competente y revisión sanitaria cuando corresponda. Estos criterios evalúan preparación, comunicación y límites de actuación; no habilitan como profesional sanitario ni guía. La plataforma no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de la habilidad](../../practicas/?habilidad=s9-nutricion-altitud). Registra fecha, actividad, escenario ficticio, equipo, errores, correcciones, supervisor y evidencia del aprendizaje. No incluyas diagnósticos, recetas, mediciones personales ni datos de pacientes. Marca pendiente toda evaluación no realizada.

## Relaciones con otros módulos

[Volver a Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Escalada alpina](../../alpina/) · [Programa](../../programa/). La secuencia académica conecta planificación, comunicación y riesgo; no acredita aptitud clínica ni práctica.
