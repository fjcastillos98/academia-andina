---
{
  "title": "Formación del hielo: proceso y evolución",
  "description": "Distinguir congelación de agua y transformación de nieve.",
  "module": "M05",
  "code": "E7-01",
  "order": 701,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U7-01",
  "skills": [
    "s7-formacion-hielo"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Distinguir congelación de agua y transformación de nieve.",
    "Relacionar historia térmica, aporte de agua y geometría con incertidumbre."
  ],
  "prerequisites": [
    "s6-grupo-glaciar",
    "s5-cramponaje",
    "s5-piolet"
  ],
  "sources": [
    "e7-waterfall",
    "e7-nsidc"
  ],
  "pending": [
    "Revisión de instructor de hielo pendiente; no se ha observado ni aprobado ninguna práctica.",
    "Compatibilidad y manual de los modelos personales pendientes de verificación; ninguna pieza se considera apta por aparecer en el inventario."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una noche mucho más fría permite afirmar…",
        "options": [
          "Que toda la estructura es más segura.",
          "Que hubo un cambio térmico cuyo efecto debe contextualizarse.",
          "Que ya no hace falta observar agua."
        ],
        "answer": 1,
        "explanation": "La historia térmica necesita contexto geométrico y local. Distinguir congelación de agua y transformación de nieve.",
        "rationales": [
          "El frío no garantiza estabilidad global.",
          "La historia térmica necesita contexto geométrico y local.",
          "El aporte de agua sigue siendo relevante."
        ],
        "source": "e7-waterfall",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una foto muestra hielo continuo. ¿Qué falta?",
        "options": [
          "Solo elegir un filtro de color.",
          "Nada si se tomó hoy.",
          "Información sobre soporte, evolución y sectores no visibles."
        ],
        "answer": 2,
        "explanation": "La imagen conserva límites espaciales y mecánicos. Distinguir congelación de agua y transformación de nieve.",
        "rationales": [
          "El color no mide soporte.",
          "La fecha ayuda, pero no completa la observación.",
          "La imagen conserva límites espaciales y mecánicos."
        ],
        "source": "e7-waterfall",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué registro permite aprender mejor?",
        "options": [
          "Dato, interpretación, vacío y decisión separados.",
          "Una nota: se veía bien.",
          "Solo la temperatura máxima."
        ],
        "answer": 0,
        "explanation": "Hace explícita la incertidumbre. Distinguir congelación de agua y transformación de nieve.",
        "rationales": [
          "Hace explícita la incertidumbre.",
          "No permite reconstruir el razonamiento.",
          "Un único valor pierde contexto."
        ],
        "source": "e7-waterfall",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Diferencia origen glaciar y congelación de agua sin atribuir seguridad al nombre.",
    "Explica por qué un enfriamiento no ofrece una garantía.",
    "Identifica datos ausentes y propone una decisión que no dependa de inventarlos."
  ],
  "openAssessment": {
    "prompt": "Construye una cronología ficticia con tres momentos. Separa datos de estación, observaciones locales e hipótesis; señala dos decisiones que aún no puedes justificar.",
    "rubric": [
      "Diferencia origen glaciar y congelación de agua sin atribuir seguridad al nombre.",
      "Explica por qué un enfriamiento no ofrece una garantía.",
      "Identifica datos ausentes y propone una decisión que no dependa de inventarlos."
    ],
    "source": "e7-waterfall",
    "difficulty": "integración"
  },
  "diagrams": [
    "e7-describir"
  ]
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. El estudio y el quiz no acreditan una maniobra ni capacidad de guiado.**

## Conceptos clave y propósito

Congelación, intercambio térmico, alimentación de agua, contracción, deformación y escala temporal.

## Teoría y toma de decisiones

El hielo de una cascada se forma por congelación de agua; el hielo glaciar se origina principalmente por transformación de nieve acumulada. Que ambos admitan herramientas de escalada no hace equivalentes sus procesos, soportes o cambios. Un nombre identifica un origen, no la resistencia de una estructura concreta. [Fuente de contraste](#fuente-e7-nsidc).

El estudio de cascadas de hielo difundido por Petzl relaciona cambios térmicos con su comportamiento mecánico. El enfriamiento rápido puede introducir tensiones; por ello «más frío» no significa automáticamente «más estable». El historial importa, además del valor instantáneo de temperatura. La geometría y el contacto con el sustrato condicionan la interpretación: una columna libre no se analiza como una lámina apoyada. [Fuente de contraste](#fuente-e7-waterfall).

Una observación educativa debe distinguir tres escalas: el proceso de formación durante días o semanas; las variaciones durante la jornada; y lo que ocurre al actuar sobre un punto. Una herramienta que parece asentarse no mide la estabilidad del conjunto. Tampoco una fotografía de la mañana permite conocer el efecto de un cambio posterior de agua o radiación. No se ofrece aquí una fórmula de temperatura para autorizar escalar.

Para convertir teoría en decisión escribe una cadena explícita: dato observado, interpretación provisional, incertidumbre y acción propuesta. «La estación marca temperatura negativa» es un dato de una estación y un momento. «Toda la cascada permanece sólida» es otra afirmación que exige evidencia adicional. Una buena explicación conserva esa diferencia incluso cuando el grupo desea continuar.

## Procedimiento: función, comprobaciones y límites

**PROCEDIMIENTO — marco de análisis previo al taller.** Objetivo: Distinguir congelación de agua y transformación de nieve. Se utiliza para preparar el aprendizaje y detectar vacíos antes de una tarea real. Identifica la función, los componentes, la información que falta y las consecuencias de un error. Contrasta la versión de la fuente con el modelo de equipo y el método del instructor. No hay una configuración universal derivada de esta página.

Las comprobaciones relevantes se desarrollan en la teoría, el equipo y la rúbrica de esta unidad. Si el uso previsto o la protección del taller no están claros, la práctica no se inicia. Las variantes de una fuente se conservan dentro de su contexto; no se mezclan pasos de métodos distintos por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario ficticio para análisis:** En una ficha ficticia se registran varios días de formación, una noche de enfriamiento brusco y agua visible al pie. Un compañero concluye que el frío garantiza mejor resistencia. Redacta una objeción fundada sin asignar un umbral inventado.

Antes de responder, enumera los hechos dados y los datos que has supuesto. Propón una decisión provisional y una condición que te haría revisarla. El caso, los ejercicios y las rúbricas son propuestas pedagógicas originales de la academia, pendientes de revisión docente; no son un protocolo de un organismo citado.

## Errores frecuentes y puntos críticos de seguridad

Usar solo la temperatura actual; confundir color con resistencia; extrapolar una observación puntual a toda la estructura; ignorar cambios entre aproximación y retorno.

No uses la ausencia de incidentes como prueba de seguridad. Las tareas con carga, herramientas o exposición necesitan control presencial competente. Ninguna respuesta escrita autoriza a escalar, montar un anclaje ni asistir a un pasajero.

## Material y equipo relacionado

Registro meteorológico con ubicación y hora, croquis de observación y fotografías fechadas. Casco, piolets y tornillos no son instrumentos que certifiquen estabilidad.

[Consultar inventario](../../equipo/). Registra documento y revisión, sin inventar inspecciones realizadas. Tener material no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con tus palabras: Distinguir congelación de agua y transformación de nieve.
- ¿Qué observación del caso apoya tu decisión y qué dato sigue faltando?
- ¿Qué error de esta unidad podrías reconocer documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Construye una cronología ficticia con tres momentos. Separa datos de estación, observaciones locales e hipótesis; señala dos decisiones que aún no puedes justificar.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Análisis de fotografías y cronologías con instructor. Si se realiza observación exterior, el instructor escoge un lugar sin exposición a caída de hielo y define límites de aproximación. No se golpea una estructura para «probarla» desde una zona expuesta.

## Evidencia requerida y criterios de competencia

- Diferencia origen glaciar y congelación de agua sin atribuir seguridad al nombre.
- Explica por qué un enfriamiento no ofrece una garantía.
- Identifica datos ausentes y propone una decisión que no dependa de inventarlos.

**COMPETENCIA:** estos criterios orientan la revisión. Cuando implican ejecución, el instructor debe observarla en un contexto definido, registrar resultado y lo que no se evaluó. No hay umbral automático de repeticiones, confianza o aciertos. La plataforma conserva una declaración personal y no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s7-formacion-hielo). Registra solo tareas realmente realizadas: fecha, lugar, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Mantén separados resultado observado, confianza y evaluación. No incluyas datos médicos ni datos privados de terceros.

## Relaciones con otros módulos

[Ruta invernal](../../invierno/), [formación glaciar](../../glaciar/), [encordamiento según contexto](../encordamiento-contexto/) y [anclajes y reuniones](../anclajes-reuniones/) aportan prerrequisitos. La aplicación alpina y el guiado requieren su propia formación y evaluación. [Volver a la secuencia de hielo](../../hielo/).
