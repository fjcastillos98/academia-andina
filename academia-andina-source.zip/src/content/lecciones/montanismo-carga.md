---
{
  "title": "Montañismo y entrenamiento con carga",
  "description": "Diseñar progresión de carga sin copiar estándares de otras poblaciones.",
  "module": "M22",
  "code": "E10-09",
  "order": 1009,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U10-09",
  "skills": [
    "s10-montanismo-carga"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Diseñar progresión de carga sin copiar estándares de otras poblaciones.",
    "Aplicar el concepto a una decisión de preparación de montaña y reconocer sus límites."
  ],
  "prerequisites": [
    "s10-entrenamiento-trekking"
  ],
  "sources": [
    "e10-load"
  ],
  "pending": [
    "Revisión por profesional del ejercicio e instructor de montaña pendiente. Nutrición y salud requieren revisión profesional específica; no se ha evaluado aptitud personal.",
    "Los casos y rúbricas son propuestas pedagógicas originales. La aplicación individual requiere evaluación, técnica y seguimiento.",
    "No se atribuyen requisitos de certificación, umbrales universales ni preparación técnica a los resultados físicos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un estudio militar permite…",
        "options": [
          "Analizar mecanismos con límites de transferencia.",
          "Copiar cualquier carga.",
          "Certificar pasajeros."
        ],
        "answer": 0,
        "explanation": "La población y la tarea delimitan conclusiones.",
        "rationales": [
          "La población y la tarea delimitan conclusiones.",
          "No individualiza ni garantiza seguridad.",
          "No evalúa a pasajeros."
        ],
        "source": "e10-load",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Saber caminar con mochila…",
        "options": [
          "Acredita manejo de crampones.",
          "No sustituye formación técnica.",
          "Garantiza ausencia de lesiones."
        ],
        "answer": 1,
        "explanation": "La formación sigue siendo necesaria.",
        "rationales": [
          "Son habilidades distintas.",
          "La formación sigue siendo necesaria.",
          "No elimina todos los riesgos."
        ],
        "source": "e10-load",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La progresión se revisa con…",
        "options": [
          "Solo el peso total.",
          "La fecha de cumbre como único criterio.",
          "Ejecución, tolerancia y recuperación."
        ],
        "answer": 2,
        "explanation": "Permite adaptar la tarea.",
        "rationales": [
          "Faltan otras variables.",
          "El plazo no demuestra preparación.",
          "Permite adaptar la tarea."
        ],
        "source": "e10-load",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "No convierte una muestra militar en norma personal.",
    "Registra peso y contexto.",
    "Separa acondicionamiento y maniobra técnica."
  ],
  "openAssessment": {
    "prompt": "Describe tres variables de una sesión con mochila y una forma de conservar comparabilidad entre ensayos ficticios.",
    "rubric": [
      "No convierte una muestra militar en norma personal.",
      "Registra peso y contexto.",
      "Separa acondicionamiento y maniobra técnica."
    ],
    "source": "e10-load",
    "difficulty": "integración"
  },
  "diagrams": [
    "e10-general-especifico"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN PROFESIONAL PENDIENTE.** Este contenido no prescribe un programa individual ni acredita competencia técnica. Los ejercicios numéricos y casos son ficticios. No introduzcas datos médicos, mediciones corporales privadas ni antecedentes de terceros.

## Conceptos clave y propósito

Carga transportada, distribución, marcha, pendiente, técnica y recuperación.

## Teoría y toma de decisiones

La mochila cambia la tarea. En investigación experimental, transportar carga modifica el coste energético y la mecánica de caminar. Eso respalda atender al peso y su distribución, pero no determina una carga segura universal para toda persona. [Estudio de marcha](#fuente-e10-load).

La preparación general desarrolla fuerza y resistencia. La específica incorpora equipo y demandas del objetivo de forma gradual, con observación de ajuste y movimiento. Para montañismo se añaden transiciones, calzado técnico y tareas que solo deben practicarse dentro de la formación apropiada.

Un entrenamiento con carga no es un permiso para usar crampones o piolet en terreno técnico. Las capacidades físicas apoyan la ejecución; no sustituyen aprendizaje ni supervisión. El entrenador y el instructor deben acordar qué parte del objetivo se trabaja en cada sesión.

En el caso original se añade mochila pesada a una sesión ya larga porque «falta poco para el viaje». El análisis identifica una concentración de cambios, ausencia de familiarización y poco tiempo de recuperación. La solución académica no asigna un porcentaje del peso corporal: pide rediseñar la progresión y revisar la viabilidad del objetivo.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación del aprendizaje:** Registra masa transportada, ajuste, superficie y duración; revisa con profesional una progresión compatible con la experiencia. Ensaya primero lo que pueda observarse de forma controlada. Si aparecen molestias persistentes o alteraciones funcionales, detén la progresión y solicita valoración, en vez de normalizarlas como adaptación inevitable.

La selección real de ejercicios, cargas, pruebas y progresión corresponde a una evaluación individual con profesionales. Las técnicas críticas de montaña requieren formación práctica y supervisión de instructor competente. El acondicionamiento físico no autoriza una maniobra.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un participante copia una carga militar publicada y la usa como requisito personal para trekking. Explica por qué la población y tarea del estudio importan.

Distingue dato, interpretación y decisión. Explica qué incertidumbre permanece. Los casos no representan un protocolo del organismo citado ni un criterio oficial de habilitación para guía.

## Errores frecuentes y puntos críticos de seguridad

Copiar kilos militares; aumentar carga y duración a la vez; correr cargado sin preparación; confundir tolerar peso con competencia de maniobra.

## Material y equipo relacionado

Mochila ajustable y contenido conocido, calzado y terreno controlado. Crampones, piolet y arnés requieren instrucción independiente.

[Consultar inventario](../../equipo/). Ajustar o poseer el equipo no demuestra dominarlo. Las prácticas técnicas se registran por separado del acondicionamiento.

## Autoevaluación y recuperación activa

- Explica la diferencia entre la capacidad que estudias y una tarea técnica de montaña.
- ¿Qué información falta en el caso y qué decisión modificaría?
- ¿Qué parte puede analizarse en escritorio y cuál necesita observación profesional?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Describe tres variables de una sesión con mochila y una forma de conservar comparabilidad entre ensayos ficticios.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Práctica de ajuste y marcha con carga individualizada bajo profesional; técnica de montaña solo con instructor competente.

## Evidencia requerida y criterios de competencia

- No convierte una muestra militar en norma personal.
- Registra peso y contexto.
- Separa acondicionamiento y maniobra técnica.

**COMPETENCIA:** estos criterios describen aprendizaje que debe observar un profesional en contexto. No acreditan aptitud médica, entrenamiento personal, guiado ni maniobra técnica. Una lectura, prueba física o quiz no otorga certificación. Marca pendiente lo que no se haya evaluado.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s10-montanismo-carga). Registra fecha, actividad, escenario, equipo, objetivo, errores, correcciones, supervisor y evidencia de aprendizaje. No guardes datos médicos ni contraseñas. No inventes sesiones, evaluaciones o repeticiones para completar la matriz.

## Relaciones con otros módulos

[Entrenamiento](../../entrenamiento/) · [Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Programa](../../programa/). Entrenamiento general, preparación específica, aclimatación y competencia técnica se relacionan, pero no son equivalentes.
