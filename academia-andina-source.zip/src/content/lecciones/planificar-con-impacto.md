---
{
  "title": "Planificar antes de salir",
  "description": "Relaciona objetivos, capacidades e información del lugar en una ficha de preparación.",
  "module": "M01",
  "code": "EST-01",
  "order": 2,
  "minutes": 12,
  "level": "Fundamentos",
  "status": "example",
  "reviewDate": "2026-10-21",
  "objectives": [
    "Identificar información faltante antes de decidir una salida.",
    "Separar una propuesta de itinerario de sus condiciones verificadas."
  ],
  "prerequisites": [
    "Lectura comprensiva; no se requiere ejecutar maniobras."
  ],
  "sources": [
    "lnt"
  ],
  "pending": [
    "Revisión pedagógica externa y ampliación del tema curricular.",
    "No incluye evaluación ni habilitación práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "En el caso hipotético, el acceso solo aparece en una publicación antigua. ¿Cómo lo registrarías?",
        "options": [
          "Confirmado, porque hay una fotografía.",
          "Pendiente de verificación con quien administra el acceso.",
          "Permitido mientras no exista una barrera."
        ],
        "answer": 1,
        "explanation": "La publicación histórica no prueba una autorización actual. El ejercicio exige identificar el vacío, no inventar una respuesta."
      },
      {
        "prompt": "¿Qué relación propone la preparación de una salida?",
        "options": [
          "Ajustar actividades a objetivos y capacidades del grupo.",
          "Mantener el objetivo aunque las capacidades no alcancen.",
          "Elegir solo por la fotografía de la cumbre."
        ],
        "answer": 0,
        "explanation": "Leave No Trace incluye objetivos, capacidades e información del área como elementos de preparación."
      }
    ]
  }
}
---


## Conceptos
Leave No Trace propone preparar las salidas considerando objetivos, capacidades de los participantes e información del área. Su primer principio incluye conocer las restricciones, prepararse para condiciones adversas y revisar la experiencia al regreso. Son orientaciones generales; no reemplazan la información vigente del administrador del lugar. [Fuente: Leave No Trace, Principle 1.]

Para organizar el estudio, esta academia propone una ficha de tres columnas: dato, evidencia y decisión pendiente. Se trata de una herramienta editorial para ordenar preguntas, no de un permiso ni de una matriz que garantice seguridad.

| Dato que necesitas | Evidencia a reunir | Si falta |
| --- | --- | --- |
| Objetivo de la actividad | Acuerdo con el grupo | Reformular antes de comprometer la salida |
| Acceso | Información del responsable del lugar | Mantenerlo como no confirmado |
| Capacidades relevantes | Conversación y evaluación apropiada | Definir qué debe comprobarse |
| Condiciones | Información fechada y aplicable al lugar | Registrar la incertidumbre |

## Ejemplo
Caso hipotético en el entorno de Puerto Montt: un grupo propone una caminata y aporta un relato antiguo de acceso. Anota cuándo se escribió, qué describe y qué no demuestra. No lo conviertas en una afirmación de acceso vigente.

## Errores frecuentes
Completar un formulario con suposiciones; tratar un dato sin fecha como actual; confundir una intención de viaje con una decisión respaldada por información suficiente.

## Límites
Aquí no se confirma ningún sendero, acceso, pronóstico, permiso o condición de montaña. La selección de una actividad real necesita evaluación del contexto. La lección no fija umbrales meteorológicos universales.

## Caso de estudio
Ejercicio ficticio: tienes una descripción de ruta de años anteriores, un grupo aún sin entrevistar y una fecha tentativa. Identifica tres vacíos. Una respuesta razonada menciona vigencia del acceso, capacidades y condiciones para la fecha; puede añadir otros con justificación.

## Recuperación activa
¿Qué distingue un dato de una suposición? ¿Qué información pedirías antes de convertir una idea en un compromiso con pasajeros?

## Ejercicio
Prepara una ficha de escritorio de una salida hipotética. Escribe «pendiente» donde no tengas evidencia e identifica quién podría proporcionar la información. No uses la ficha como autorización para salir.

## Criterios de revisión
La ficha debe distinguir datos confirmados y pendientes, asociar cada vacío a una acción de consulta y explicar cómo podría cambiar el objetivo. No constituye evaluación de guiado en terreno.

## Próximos pasos
Estudia los fundamentos de lectura cartográfica. Los módulos de meteorología, operación y gestión del riesgo siguen pendientes de desarrollo y revisión especializada.
