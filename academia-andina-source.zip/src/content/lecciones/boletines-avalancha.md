---
{
  "title": "Boletines: leer cobertura, problema y validez",
  "description": "Interpretar un boletín por región, altitud, orientación y tiempo.",
  "module": "M09",
  "code": "E5-07",
  "order": 506,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-07",
  "skills": [
    "s5-boletines-avalancha"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Interpretar un boletín por región, altitud, orientación y tiempo.",
    "Distinguir nivel de peligro de riesgo del grupo.",
    "Documentar ausencia de información verificada para Chile sin inventar un nivel."
  ],
  "prerequisites": [
    "s5-meteo-invernal"
  ],
  "sources": [
    "e5-danger-scale",
    "e5-eaws-problems",
    "e5-slf-bulletin",
    "e5-dmc-model"
  ],
  "pending": [
    "Revisión pedagógica y de instructor. Condiciones, cobertura de boletines y aplicación territorial real: PENDIENTE DE VERIFICACIÓN."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un boletín suizo sirve en Los Lagos para…",
        "options": [
          "Asignar el mismo nivel del día.",
          "Aprender el formato, sin trasladar condiciones.",
          "Reemplazar observaciones locales."
        ],
        "answer": 1,
        "explanation": "Su cobertura territorial es distinta.",
        "rationales": [
          "No corresponde al lugar.",
          "Uso educativo delimitado.",
          "No representa el terreno local."
        ],
        "source": "e5-slf-bulletin",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "El nivel de peligro describe…",
        "options": [
          "Una evaluación espacial y temporal del peligro.",
          "La competencia del guía.",
          "El riesgo exacto de cada persona."
        ],
        "answer": 0,
        "explanation": "La exposición y personas requieren análisis adicional.",
        "rationales": [
          "Definición apropiada.",
          "No evalúa habilidades.",
          "No es probabilidad individual."
        ],
        "source": "e5-danger-scale",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "DMC pronostica nieve. ¿Es un boletín de avalanchas?",
        "options": [
          "Sí, cualquier nieve define nivel.",
          "Sí, si es oficial.",
          "No; son productos con objetivos diferentes."
        ],
        "answer": 2,
        "explanation": "Autoridad del emisor no convierte un producto meteorológico en nivológico.",
        "rationales": [
          "No clasifica estabilidad.",
          "Confunde institución y producto.",
          "Distingue alcance."
        ],
        "source": "e5-dmc-model",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Identifica alcance y validez.",
    "Explica nivel, problema y exposición por separado.",
    "Declara información territorial no verificada."
  ],
  "openAssessment": {
    "prompt": "Analiza un boletín archivado real: nueve campos, dos límites y tres datos que tendrías que verificar para una salida distinta.",
    "rubric": [
      "Identifica alcance y validez.",
      "Explica nivel, problema y exposición por separado.",
      "Declara información territorial no verificada."
    ],
    "source": "e5-danger-scale",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Fecha, emisor, mapa, leyenda, problemas y texto explicativo deben conservarse juntos.

## Teoría y toma de decisiones

Un boletín de avalanchas sintetiza una evaluación para un área y un intervalo temporal. Para leerlo comienza por quién lo emite, cuándo se publicó y hasta cuándo es válido. Después comprueba la cobertura y la leyenda. Una imagen de un boletín sin fecha o mapa puede ser auténtica y, aun así, inaplicable a tu actividad. La escala y los símbolos se interpretan dentro del sistema del emisor, no por semejanza visual.

EAWS emplea cinco niveles: 1 bajo, 2 limitado o moderado según traducción, 3 notable o considerable, 4 fuerte o alto y 5 muy fuerte o muy alto. Consulta la versión oficial que acompañe al producto. El nivel relaciona estabilidad, distribución de esa estabilidad y tamaño esperado en una unidad espacial y temporal [fuente](#fuente-e5-danger-scale). No es una puntuación del usuario ni una probabilidad de accidente individual. Un nivel bajo tampoco equivale a ausencia de consecuencias en un lugar concreto.

Los problemas de avalancha complementan el nivel y la localización mediante tipo de inestabilidad, posibles desencadenantes y evolución. Orientaciones y cotas ayudan a delimitar dónde se concentra el problema, sin dibujar cada depósito local [fuente](#fuente-e5-eaws-problems). Tamaño y probabilidad son dimensiones distintas: la decisión debe considerar ambas, además de la exposición. Una franja fuera de la zona destacada no recibe automáticamente una garantía de estabilidad.

El servicio de SLF corresponde a Suiza y es útil para estudiar presentación y lenguaje [fuente](#fuente-e5-slf-bulletin). Un ejemplo extranjero nunca debe presentarse como boletín de Los Lagos. Para Chile, la consulta comienza por organismos oficiales y responsables territoriales pertinentes: DMC para productos meteorológicos, SENAPRED para información de emergencias y autoridades o administradores para restricciones del área. Esta investigación no verificó una cobertura pública de boletín nivológico para cada montaña priorizada. Se registra PENDIENTE DE VERIFICACIÓN; no se infiere que no haya ningún servicio ni se fabrica un boletín sustituto.

Un meteograma oficial es información meteorológica, no un boletín nivológico [DMC](#fuente-e5-dmc-model). Una observación de terreno es localizada y requiere fecha, posición y método. La decisión combina pronóstico, observación, terreno y capacidades; una observación favorable aislada no cancela un problema regional. Si aparecen señales preocupantes, el proceso debe permitir revisar la exposición aunque el plan inicial pareciera razonable.

Para el ejercicio, selecciona un boletín archivado de un emisor real y rotúlalo «ejemplo extranjero histórico». Extrae emisor, cobertura, hora, nivel, problemas, orientaciones, cotas, tamaño y evolución. Escribe qué términos no entiendes y consulta su leyenda. Luego redacta un párrafo sobre qué no puedes trasladar a Chile. No se pide una decisión de paso para la ruta del boletín: se evalúa lectura documental y reconocimiento de límites. Si no consigues el producto completo, el ejercicio queda incompleto, no aprobado por intuición.

## Qué observo, qué significa y qué no puedo concluir

No hay boletín actual incorporado ni cobertura chilena asumida; los ejemplos se etiquetan con ámbito real.

## Caso práctico y aplicación al guiado

Una captura de nivel 2 circula sin fecha ni región. ¿Qué debes recuperar antes de utilizarla?

## Errores frecuentes y señales de alerta

Leer solo el color; trasladar cotas entre regiones; confundir alerta de nevadas con peligro de avalancha; interpretar falta de boletín como peligro cero.

## Autoevaluación y respuesta razonada

Analiza un boletín archivado real: nueve campos, dos límites y tres datos que tendrías que verificar para una salida distinta.

## Ejercicios y práctica supervisada

Lectura de un producto completo archivado con revisión del instructor. No producir un boletín amateur para guiar al grupo.

## Evidencia requerida

- Identifica alcance y validez.
- Explica nivel, problema y exposición por separado.
- Declara información territorial no verificada.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-boletines-avalancha).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
