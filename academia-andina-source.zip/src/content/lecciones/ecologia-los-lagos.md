---
{
  "title": "Flora, fauna y ecosistemas: interpretar sin perturbar",
  "description": "Distinguir presencia documentada de avistamiento garantizado.",
  "module": "M15",
  "code": "E45-29",
  "order": 328,
  "minutes": 35,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U45-05",
  "skills": [
    "s45-ecologia-los-lagos"
  ],
  "critical": false,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir presencia documentada de avistamiento garantizado.",
    "Usar nombres científicos con cautela taxonómica.",
    "Diseñar una interpretación que reduzca perturbación e impactos."
  ],
  "prerequisites": [
    "s45-glaciologia-intro"
  ],
  "sources": [
    "conaf-puyehue",
    "conaf-lahuen",
    "mma-alerce",
    "mma-monito",
    "mma-carpintero",
    "mma-lagartija",
    "mma-ranita",
    "sbap-ranitas"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente.",
    "PENDIENTE DE VERIFICACIÓN TERRITORIAL: accesos, límites administrativos, rutas y condiciones actuales."
  ],
  "diagrams": [
    "territorio-evidencia"
  ],
  "preparation": [
    "Distinguir hechos atribuidos, inferencias y datos pendientes.",
    "Explicar por qué la ficha no valida acceso, ruta ni condiciones.",
    "Preparar una observación sin extracción ni alteración del entorno."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "conaf-puyehue",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una especie figura en la ficha de un parque. ¿Qué puedes prometer al pasajero?",
        "options": [
          "Que aparecerá en cualquier sendero.",
          "Una actividad de observación sin garantizar avistamiento.",
          "Que podrá tocarla si es nativa."
        ],
        "answer": 1,
        "explanation": "Un registro de presencia no garantiza encuentro ni autoriza manipulación.",
        "source": "conaf-puyehue",
        "difficulty": "intermedia",
        "rationales": [
          "Confunde presencia y detectabilidad.",
          "Respeta el alcance del dato y de la actividad.",
          "Origen no es permiso de contacto."
        ],
        "kind": "aplicación"
      },
      {
        "prompt": "La ficha antigua dice algo distinto de un registro reciente. ¿Cómo procedes?",
        "options": [
          "Ocultas la diferencia.",
          "Usas siempre el texto más largo.",
          "Conservas fecha y alcance y verificas la discrepancia."
        ],
        "answer": 2,
        "explanation": "La trazabilidad evita presentar una clasificación desactualizada como certeza.",
        "source": "mma-carpintero",
        "difficulty": "intermedia",
        "rationales": [
          "Elimina información útil para revisar.",
          "Extensión no demuestra actualidad.",
          "Es una revisión explícita de la incertidumbre."
        ],
        "kind": "aplicación"
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

Ecosistema conecta organismos con condiciones físicas y procesos. Bosque templado lluvioso y bosque valdiviano son conceptos ecológicos relacionados, pero no etiquetas que identifiquen toda la región sin matices. Bosque siempreverde describe persistencia de follaje; ambientes altoandinos cambian con altura, exposición, sustrato y nieve. Endémica significa restringida a un área definida; nativa, originaria del territorio considerado; exótica e invasora no son sinónimos.

## Teoría: del listado al encuentro responsable

CONAF describe en Puyehue comunidades y fauna como monito del monte y carpintero negro; Lahuen Ñadi presenta alerce junto con canelo, tepa, luma y otras especies [Referencia: conaf-puyehue](#fuente-conaf-puyehue) [Referencia: conaf-lahuen](#fuente-conaf-lahuen). Esos registros no significan que las mismas especies estén en cada cumbre o que un guía pueda prometer observarlas.

Las fichas de esta unidad incluyen identificación introductoria, hábitat, distribución atribuida y campos pendientes. Alerce no es exclusivo de Chile; monito del monte no debe confundirse con un roedor por su tamaño. Para carpintero negro, las diferencias de cabeza entre sexos ayudan, pero ninguna foto aislada reemplaza contraste. La lagartija manchada exige cautela ante variación y revisión taxonómica. Las fichas SIMBIO pueden contener campos vacíos o textos históricos: no completar automáticamente una distribución que no aparece.

La ranita de Darwin tiene un contexto de conservación que obliga a evitar manipulación. SBAP informó en 2026 del plan RECOGE [Referencia: sbap-ranitas](#fuente-sbap-ranitas). Conocer un plan no concede permiso para capturar animales, trasladarlos o intervenir su hábitat.

Para interpretar, organiza tres capas: qué observamos, qué se sabe de la especie y qué conducta adoptaremos. Si no identificas, “ave no determinada” es mejor que una certeza inventada. Si aparece un animal, el programa turístico debe adaptarse a una observación sin persecución; el horario o la fotografía prometida no justifican molestarlo.

No Deje Rastro se trabaja como criterio de planificación y conducta: prevenir residuos, evitar extracción, respetar fauna y otros visitantes y cumplir restricciones. La limpieza del equipo también forma parte de prevenir transporte involuntario de organismos. La lista regional de invasoras y protocolos específicos de bioseguridad quedan pendientes de validación; no aplicar productos ni retirar organismos por iniciativa propia.

## Caso práctico: el pasajero quiere acercarse

En un escenario ficticio, alguien pide mover una rama para fotografiar mejor a un animal. Explica por qué una foto no justifica alterar el refugio. Propón observar desde donde está el grupo o continuar sin avistamiento. Si no conoces la especie, evita prometer que no representa riesgo y consulta orientación competente.

## Errores frecuentes y señales de alerta

Confundir taxonomía antigua con vigente, convertir un listado regional en presencia local, usar sonidos para atraer fauna, revelar lugares sensibles o dar una receta universal ante todo animal. La categoría de conservación requiere fuente, jurisdicción y fecha.

## Autoevaluación y respuestas explicadas

¿Nativa equivale a endémica? No; la primera puede existir naturalmente en otros países. ¿No observar una especie prueba ausencia? No; detectabilidad y esfuerzo de observación importan.

## Ejercicios y práctica presencial

Diseña una parada interpretativa de tres minutos con un rasgo observable, una relación ecológica y una conducta concreta. Practica con un especialista desde un lugar permitido, sin colectar ni manipular.

## Evidencia requerida

Ficha de observación con identificación tentativa, fuente, incertidumbre y conducta del grupo; ninguna ubicación sensible ni datos privados. Evaluación humana de precisión y respeto.

## Relaciones con otras habilidades

Integra planificación, gestión de grupo, ética y registro. Las fichas son un inicio; inventarios completos, invasoras y respuesta específica ante fauna requieren ampliación validada.
