---
{
  "title": "Progresión glaciar: coordinar y reevaluar",
  "description": "Explicar por qué la coordinación afecta al sistema de protección.",
  "module": "M04",
  "code": "E6-04",
  "order": 604,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U6-04",
  "skills": [
    "s6-progresion-glaciar"
  ],
  "critical": true,
  "reviewDate": "2026-10-23",
  "objectives": [
    "Explicar por qué la coordinación afecta al sistema de protección.",
    "Identificar condiciones que exigen revisar el modo de progresión."
  ],
  "prerequisites": [
    "s6-grietas"
  ],
  "sources": [
    "e6-petzl-team",
    "e6-acc-team"
  ],
  "pending": [
    "Práctica presencial de marcha y comunicación, sin exposición real como primer taller. PENDIENTE DE VERIFICACIÓN.",
    "Revisión presencial por instructor competente pendiente. No se ha realizado ni aprobado ninguna práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una persona deja de comprender avisos. ¿Qué revisar?",
        "options": [
          "Solo su velocidad.",
          "Coordinación y viabilidad del método con ese grupo.",
          "Nada mientras esté atada."
        ],
        "answer": 1,
        "explanation": "La cuerda conecta personas y exige coordinación.",
        "rationales": [
          "No se justifica: La cuerda conecta personas y exige coordinación.",
          "Correcta: La cuerda conecta personas y exige coordinación.",
          "No se justifica: La cuerda conecta personas y exige coordinación."
        ],
        "source": "e6-petzl-team",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Cambia la consecuencia de una caída. ¿Se mantiene el método?",
        "options": [
          "Siempre.",
          "Si el grupo pagó.",
          "Debe reevaluarse con competencia apropiada."
        ],
        "answer": 2,
        "explanation": "Un método no se traslada automáticamente a otro terreno.",
        "rationales": [
          "No se justifica: Un método no se traslada automáticamente a otro terreno.",
          "No se justifica: Un método no se traslada automáticamente a otro terreno.",
          "Correcta: Un método no se traslada automáticamente a otro terreno."
        ],
        "source": "e6-petzl-team",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué evidencia sirve al debriefing?",
        "options": [
          "Aviso recibido, cambio observado y respuesta.",
          "Solo distancia total.",
          "Solo llegar a la cumbre."
        ],
        "answer": 0,
        "explanation": "Permite revisar cómo funcionó el equipo.",
        "rationales": [
          "Correcta: Permite revisar cómo funcionó el equipo.",
          "No se justifica: Permite revisar cómo funcionó el equipo.",
          "No se justifica: Permite revisar cómo funcionó el equipo."
        ],
        "source": "e6-petzl-team",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "Reconoce dependencia del grupo.",
    "No propone resolverlo solo aumentando velocidad.",
    "No declara segura la alternativa sin verificarla."
  ],
  "openAssessment": {
    "prompt": "Escenario de aula: cambia la visibilidad y dos integrantes avanzan a ritmos incompatibles. Propón qué debe detenerse y qué información exige el instructor antes de continuar.",
    "rubric": [
      "Reconoce dependencia del grupo.",
      "No propone resolverlo solo aumentando velocidad.",
      "No declara segura la alternativa sin verificarla."
    ],
    "source": "e6-petzl-team",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**CONTENIDO TEÓRICO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Holgura, Ritmo compartido, Exposición y cambio de terreno. La cuerda conecta a personas: un error de coordinación puede afectar al conjunto.

## Teoría y toma de decisiones

La progresión encordada conecta personas que avanzan como sistema. La función de la cuerda depende de configuración, coordinación, terreno y respuesta del equipo. Petzl muestra la importancia de controlar holgura y prever reserva en un ejemplo de dos. [Ejemplo del fabricante](#fuente-e6-petzl-team). No es una receta para cualquier número de integrantes o superficie, y no basta con estar unidos para neutralizar una caída.

El ritmo debe permitir que cada persona mantenga la tarea prevista y comunique una dificultad antes de que desordene al conjunto. Fatiga, tropiezos, pausas no avisadas o diferencias grandes de velocidad afectan a las demás personas. En un taller se observa cómo se comunica y conserva el control durante cambios de dirección o detenciones. La distancia no se aprende como un número que resuelve por sí solo todos esos problemas.

El modo de progresión se revisa cuando cambia el terreno. Un sistema pensado para una superficie glaciar no se traslada sin análisis a una ladera donde una caída podría arrastrar al resto. ACC insiste en las limitaciones de equipos pequeños y la necesidad de preparación para rescate. [Límites de equipo](#fuente-e6-acc-team). El instructor determina métodos apropiados y su transición; aquí se identifica el cambio de problema, no se enseña una técnica de cuerda corta para pasajeros.

Ejercicio de coordinación de mesa: dibuja una línea temporal con tres avisos —pérdida de visibilidad, fatiga y equipo que necesita revisión—. Para cada aviso indica quién lo recibe, qué tarea deja de ser fiable y qué condición permitiría continuar. Evita la respuesta genérica «seguir con cuidado»: especifica evidencia y responsabilidad. En una primera práctica presencial, la selección y protección del lugar corresponden al instructor, no a la ruta que el alumno desea completar.

## Procedimiento conceptual: objetivo, uso y límites

Explicar por qué la coordinación afecta al sistema de protección. Esta unidad se utiliza para preparar el análisis y un taller, no para ejecutar una maniobra sin entrenamiento. Un método útil en un escenario no se transporta automáticamente a hielo duro, terreno más inclinado o grupo diferente.

Las variantes técnicas mantienen el ámbito de la fuente citada. Antes de cambiar una configuración se deben revisar sus funciones, comprobaciones y límites con instructor; no se combinan pasos de escuelas distintas por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario hipotético de aula.** Dos integrantes avanzan a ritmos incompatibles y dejan de entender los avisos. Discutir solamente si la cumbre está cerca omite el funcionamiento de la cordada. Propón qué debe revisarse antes de cualquier avance.

## Errores frecuentes y puntos críticos

Acelerar para recuperar tiempo; tratar la cuerda como garantía; mantener el método pese a un cambio de consecuencias de caída.

No se atribuye una garantía de seguridad al equipo, al quiz ni a una práctica en condiciones diferentes. Si falta un dato esencial para justificar el objetivo, declarar ese vacío es parte del aprendizaje.

## Material y equipo relacionado

Arnés, cuerda, casco, crampones y piolet según contexto y manuales. Comunicación y gestión de reserva son habilidades, no accesorios.

[Inventario personal](../../equipo/): conserva referencia del manual y observaciones de inspección. El registro no declara aptitud de una pieza ni competencia de quien la porta.

## Autoevaluación y recuperación activa

- ¿Qué cambia para el resto cuando una persona se detiene sin avisar?
- ¿Qué dato distinguiría un problema de ritmo de un método inadecuado?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL de escritorio:** Escenario de aula: cambia la visibilidad y dos integrantes avanzan a ritmos incompatibles. Propón qué debe detenerse y qué información exige el instructor antes de continuar.

**PRÁCTICA SUPERVISADA:** el instructor adapta un taller con objetivos observables, protección y criterios de parada. No provocar caídas reales ni entrar a terreno expuesto para comprobar esta página. La evaluación presencial es independiente de la respuesta teórica.

## Evidencia requerida y criterios de competencia

- Reconoce dependencia del grupo.
- No propone resolverlo solo aumentando velocidad.
- No declara segura la alternativa sin verificarla.

Estos criterios valoran razonamiento; para una competencia práctica, el instructor debe definir y observar la ejecución en un contexto explícito. No se preasigna una evaluación por estudiar.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s6-progresion-glaciar). Registrar únicamente lo realizado: fecha, lugar, condiciones, objetivo, equipo, supervisor, resultado, errores, correcciones, evidencia, autonomía observada y próxima práctica. No guardar datos médicos ni información privada de pasajeros.

## Relaciones con etapas anteriores

[Glaciología introductoria](../glaciologia-intro/), [planificación invernal](../planificacion-invernal/), [encordamiento según contexto](../encordamiento-contexto/), [anclajes](../anclajes-reuniones/) y [ventaja mecánica](../ventaja-mecanica/). Estas dependencias orientan el estudio; no autorizan la aplicación técnica. [Ruta glaciar](../../glaciar/).
