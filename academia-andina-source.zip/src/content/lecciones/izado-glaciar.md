---
{
  "title": "Izado: sistema, fricción y control",
  "description": "Distinguir ventaja ideal y esfuerzo real.",
  "module": "M04",
  "code": "E6-09",
  "order": 609,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U6-09",
  "skills": [
    "s6-izado-glaciar"
  ],
  "critical": true,
  "reviewDate": "2026-10-23",
  "objectives": [
    "Distinguir ventaja ideal y esfuerzo real.",
    "Analizar carga, recorrido, reserva y participación de la persona."
  ],
  "prerequisites": [
    "s6-autorescate-grieta"
  ],
  "sources": [
    "e6-petzl-haul",
    "e6-petzl-edge",
    "e6-petzl-transfer"
  ],
  "pending": [
    "Compatibilidad exacta de cuerda/dispositivo, revisión de instructor y ensayo controlado. No dimensionar rescates con este ejercicio. PENDIENTE DE VERIFICACIÓN.",
    "Revisión presencial por instructor competente pendiente. No se ha realizado ni aprobado ninguna práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "600 N en modelo ideal 3:1 requieren…",
        "options": [
          "1800 N.",
          "200 N, antes de considerar pérdidas.",
          "200 kg."
        ],
        "answer": 1,
        "explanation": "600/3=200 N; no dimensiona un rescate.",
        "rationales": [
          "No se justifica: 600/3=200 N; no dimensiona un rescate.",
          "Correcta: 600/3=200 N; no dimensiona un rescate.",
          "No se justifica: 600/3=200 N; no dimensiona un rescate."
        ],
        "source": "e6-petzl-haul",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una ventaja ideal mayor implica…",
        "options": [
          "Más seguridad garantizada.",
          "Anclaje siempre menos cargado.",
          "Un compromiso de recorrido y sistema que debe evaluarse."
        ],
        "answer": 2,
        "explanation": "Ventaja mecánica no equivale a capacidad o seguridad.",
        "rationales": [
          "No se justifica: Ventaja mecánica no equivale a capacidad o seguridad.",
          "No se justifica: Ventaja mecánica no equivale a capacidad o seguridad.",
          "Correcta: Ventaja mecánica no equivale a capacidad o seguridad."
        ],
        "source": "e6-petzl-haul",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Micro Traxion y ATC Guide…",
        "options": [
          "Tienen funciones y condiciones que no se intercambian automáticamente.",
          "Son siempre equivalentes.",
          "No necesitan manual con la misma cuerda."
        ],
        "answer": 0,
        "explanation": "La comparación requiere documentación específica.",
        "rationales": [
          "Correcta: La comparación requiere documentación específica.",
          "No se justifica: La comparación requiere documentación específica.",
          "No se justifica: La comparación requiere documentación específica."
        ],
        "source": "e6-petzl-haul",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "Unidades y supuesto ideal correctos.",
    "Incluye pérdidas y transiciones.",
    "No convierte resultado en autorización de montaje."
  ],
  "openAssessment": {
    "prompt": "Modelo de escritorio: carga ideal 600 N y ventaja 3:1; esfuerzo ideal 200 N. Explica por qué no basta ese resultado para dimensionar anclaje, cuerda o número de rescatistas.",
    "rubric": [
      "Unidades y supuesto ideal correctos.",
      "Incluye pérdidas y transiciones.",
      "No convierte resultado en autorización de montaje."
    ],
    "source": "e6-petzl-haul",
    "difficulty": "integración"
  },
  "diagrams": [
    "e6-objetivos"
  ]
}
---

**CONTENIDO TEÓRICO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Ventaja mecánica ideal, Fricción, Captura de progreso, Anclaje y cargas adicionales. Comparar familias de sistemas por función y límites, no memorizar una sola configuración.

## Teoría y toma de decisiones

Un sistema de izado busca mover una carga bajo control. La ventaja mecánica ideal describe una relación de fuerzas en un modelo sin pérdidas; no es una garantía de esfuerzo real ni de resistencia del anclaje. Petzl compara varias familias de sistemas con compromisos de complejidad y cuerda. [Comparación técnica](#fuente-e6-petzl-haul). Elige primero el problema que debe resolverse y las capacidades disponibles, no el número de poleas más alto.

El borde, la fricción, la reserva, las transiciones y la participación de la persona afectan al trabajo. Un sistema puede ser favorable en un tramo y difícil de reorganizar en otro. La captura de progreso cumple una función diferente de la polea que cambia la dirección; ambas necesitan compatibilidad e inspección. Micro Traxion, ATC Guide y poleas no son piezas intercambiables por pertenecer al equipo de montaña.

Antes del izado, la carga necesita una organización estable y la situación debe evaluarse con protección. Petzl separa transferencia y acceso al borde en explicaciones distintas. [Transferencia](#fuente-e6-petzl-transfer) y [borde](#fuente-e6-petzl-edge). Compartir un anclaje no elimina las cargas que introduce quien se aproxima. No se dimensiona aquí el sistema ni se prescriben montajes para personas.

Ejercicio original: una carga ficticia de 600 N se mueve con un modelo ideal 3:1. El esfuerzo ideal es 200 N. Si la carga avanza 0,5 m, el modelo requiere 1,5 m de recorrido de tracción y conserva 300 J de trabajo. Esas cifras no incluyen pérdidas, peso de componentes ni transiciones; tampoco dicen la fuerza de cada anclaje. Explica tres razones por las que un cálculo correcto no autoriza un rescate. Después relaciona cada limitación con una observación o verificación que debe enseñar un instructor, sin convertir la respuesta escrita en prueba física.

## Procedimiento conceptual: objetivo, uso y límites

Distinguir ventaja ideal y esfuerzo real. Esta unidad se utiliza para preparar el análisis y un taller, no para ejecutar una maniobra sin entrenamiento. Petzl advierte de cargas de choque y riesgos adicionales si el rescatista carga el mismo sistema.

Las variantes técnicas mantienen el ámbito de la fuente citada. Antes de cambiar una configuración se deben revisar sus funciones, comprobaciones y límites con instructor; no se combinan pasos de escuelas distintas por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario hipotético de aula.** El grupo propone un sistema más complejo porque «tira menos». Falta cuerda disponible, la persona no puede colaborar y nadie ha practicado sus transiciones. Compara beneficios teóricos y capacidades reales.

## Errores frecuentes y puntos críticos

Confundir ventaja ideal con rendimiento; sumar componentes sin evaluar cargas; olvidar recorrido y reserva; creer que capturar progreso elimina toda necesidad de control.

No se atribuye una garantía de seguridad al equipo, al quiz ni a una práctica en condiciones diferentes. Si falta un dato esencial para justificar el objetivo, declarar ese vacío es parte del aprendizaje.

## Material y equipo relacionado

Cuerda, conectores, poleas, captura de progreso y anclajes del sistema exacto; manuales y método de formación. ATC Guide y Micro Traxion requieren funciones diferenciadas.

[Inventario personal](../../equipo/): conserva referencia del manual y observaciones de inspección. El registro no declara aptitud de una pieza ni competencia de quien la porta.

## Autoevaluación y recuperación activa

- ¿Por qué 3:1 no equivale a tres veces más seguridad?
- ¿Qué variable de trabajo aparece al aumentar la ventaja ideal?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL de escritorio:** Modelo de escritorio: carga ideal 600 N y ventaja 3:1; esfuerzo ideal 200 N. Explica por qué no basta ese resultado para dimensionar anclaje, cuerda o número de rescatistas.

**PRÁCTICA SUPERVISADA:** el instructor adapta un taller con objetivos observables, protección y criterios de parada. No provocar caídas reales ni entrar a terreno expuesto para comprobar esta página. La evaluación presencial es independiente de la respuesta teórica.

## Evidencia requerida y criterios de competencia

- Unidades y supuesto ideal correctos.
- Incluye pérdidas y transiciones.
- No convierte resultado en autorización de montaje.

Estos criterios valoran razonamiento; para una competencia práctica, el instructor debe definir y observar la ejecución en un contexto explícito. No se preasigna una evaluación por estudiar.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s6-izado-glaciar). Registrar únicamente lo realizado: fecha, lugar, condiciones, objetivo, equipo, supervisor, resultado, errores, correcciones, evidencia, autonomía observada y próxima práctica. No guardar datos médicos ni información privada de pasajeros.

## Relaciones con etapas anteriores

[Glaciología introductoria](../glaciologia-intro/), [planificación invernal](../planificacion-invernal/), [encordamiento según contexto](../encordamiento-contexto/), [anclajes](../anclajes-reuniones/) y [ventaja mecánica](../ventaja-mecanica/). Estas dependencias orientan el estudio; no autorizan la aplicación técnica. [Ruta glaciar](../../glaciar/).
