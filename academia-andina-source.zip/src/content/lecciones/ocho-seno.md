---
{
  "title": "Ocho por seno",
  "description": "Identificar nombre, variante y función de ocho por seno.",
  "module": "M07",
  "code": "E43-04",
  "order": 303,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U43-03",
  "skills": [
    "s43-ocho-seno"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Identificar nombre, variante y función de ocho por seno.",
    "Distinguir límites de uso, errores y compatibilidades pendientes.",
    "Preparar una revisión presencial con evidencia."
  ],
  "prerequisites": [
    "s43-ocho-simple"
  ],
  "sources": [
    "petzl-nudos-435"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "familias-ocho"
  ],
  "preparation": [
    "Función: conexión mediante esa gaza, según sistema definido.",
    "Error: cruces no previstos o confundir gaza con chicote.",
    "Compatibilidad: cuerda, conector y dirección se evalúan juntos."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "petzl-nudos-435",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "En el estudio de ocho por seno, ¿qué afirmación es defendible?",
        "options": [
          "Sustituye siempre al encordamiento reconstituido.",
          "Función: conexión mediante esa gaza, según sistema definido.",
          "No necesita revisar la conexión."
        ],
        "answer": 1,
        "explanation": "La función debe identificarse dentro del alcance descrito; no implica aptitud del conjunto.",
        "rationales": [
          "La afirmación omite contexto o atribuye una función no demostrada.",
          "Función: conexión mediante esa gaza, según sistema definido. Se mantiene su alcance específico.",
          "No permite evaluar el sistema completo ni sus límites."
        ],
        "source": "petzl-nudos-435",
        "difficulty": "básica",
        "kind": "conocimiento"
      },
      {
        "prompt": "El nudo parece correcto, pero no se ve su conexión. ¿Qué concluyes?",
        "options": [
          "El sistema ya está revisado.",
          "La conexión es necesariamente incorrecta.",
          "Falta información; no aprobar el conjunto por una sola parte."
        ],
        "answer": 2,
        "explanation": "La revisión debe distinguir lo observado de lo que aún no se puede comprobar.",
        "rationales": [
          "Extrapola una parte al conjunto.",
          "La falta de imagen no prueba un defecto.",
          "Conserva incertidumbre y pide una comprobación concreta."
        ],
        "source": "petzl-nudos-435",
        "difficulty": "intermedia",
        "kind": "errores"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

Nombre: ocho por seno; en esta academia, figura formada con cuerda doblada que produce una gaza. Característica: inspección del recorrido doble.

## Teoría: función, aplicación y límites

- Función: conexión mediante esa gaza, según sistema definido.

- Uso: analizar una conexión accesible que pueda recibir la gaza.

- No uso: no sustituir sin análisis al encordamiento reconstituido a través del arnés.

- Ventaja: distinguir una terminación de una unión.

- Limitación: una gaza correcta puede estar conectada en lugar incorrecto.

- Característica: inspección del recorrido doble.

La pregunta de estudio no termina al reconocer el nombre. Explica qué se pretende conectar, cuál es el recorrido de la carga y qué información falta para evaluar el conjunto. Distingue la observación directa de una suposición: no ver un defecto en una imagen no equivale a revisar todas las caras. En una sesión de guiado, pide al alumno describir la función con sus palabras antes de discutir rapidez o destreza.

[Referencia técnica: petzl-nudos-435](#fuente-petzl-nudos-435). Consulta los diagramas del fabricante para la configuración exacta; las láminas de esta academia analizan funciones y errores, no sustituyen esos diagramas ni el taller.

## Caso práctico y aplicación al guiado

Ejercicio original: un dibujo muestra nudo ordenado, pero no muestra soporte. Respuesta: no se puede evaluar el conjunto. Evidencia: ficha que distingue calidad del nudo y del sistema.

- Montaña: análisis de conexiones, no autorización de montaje.

- Guiado: explicar qué comprobará la segunda persona.

## Errores frecuentes y señales de alerta

Error: cruces no previstos o confundir gaza con chicote.

## Inspección y compatibilidades

Inspección: recorrido, vestido, extremos y conexión previstos.

Compatibilidad: cuerda, conector y dirección se evalúan juntos.

Se debe detener la propuesta si no se identifica la variante o el lugar de conexión. La revisión de extremos se hace según referencia aplicable; no se añade una cifra universal. La condición del material también necesita documentación e inspección, incluso cuando el recorrido del nudo parece correcto.

## Autoevaluación y respuestas explicadas

¿Reconocer una forma demuestra ejecución en terreno? **No: faltan selección, conexión, inspección, comunicación y desempeño bajo las condiciones evaluadas.**

¿Qué debes registrar si dos personas no coinciden en la variante? **Los nombres y diagramas utilizados, la fuente de cada uno y la discrepancia; resolverla con instructor antes de una aplicación.**

## Ejercicios y práctica presencial

Práctica: demostración supervisada sin exposición antes de evaluación situada.

Prepara una ficha de comparación entre la función prevista y una función que este estudio no autoriza. Explica un error posible sin introducirlo en material en uso. En taller, el instructor observa identificación, confección, vestido, ajuste y revisión cruzada con material didáctico y condiciones controladas. No se carga una persona ni se improvisa una maniobra durante el estudio individual.

## Evidencia requerida

Nombre y variante, fuente, combinación de material, observación del instructor, error detectado, corrección y nueva práctica. La evaluación presencial debe declarar contexto y límites; un cuestionario solo registra comprensión.

## Relaciones con otras habilidades

Este tema precede a revisión de nudos y encordamiento. No se utiliza el resultado del quiz como habilitación para asegurar, descender o rescatar.
