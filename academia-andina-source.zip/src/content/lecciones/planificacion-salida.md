---
{
  "title": "Planificación de una salida",
  "description": "Transformar una intención en un plan comunicable, revisable y con alternativas.",
  "module": "M01",
  "code": "P1-C",
  "order": 103,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "pilot",
  "reviewDate": "2026-10-22",
  "objectives": [
    "Redactar un plan de salida no técnica.",
    "Separar tiempo estimado, margen y hora de revisión.",
    "Preparar un aviso de itinerario sin prometer un rescate."
  ],
  "prerequisites": [
    "Estudiar Sistema 3×3 y explicar sus límites."
  ],
  "sources": [
    "lnt",
    "nps-equipo"
  ],
  "pending": [
    "Revisión pedagógica y validación de criterios por instructor competente.",
    "Aplicación territorial en Los Lagos: requiere verificación situada."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿Qué describe mejor una estimación de tiempo?",
        "options": [
          "Un resultado garantizado.",
          "Una hipótesis basada en condiciones y capacidades declaradas.",
          "Una obligación de mantener velocidad."
        ],
        "answer": 1,
        "explanation": "El tiempo debe revisarse con el grupo y las condiciones reales."
      },
      {
        "prompt": "Al modificar el itinerario, ¿qué falta revisar?",
        "options": [
          "Solo el destino final.",
          "Nada si se conoce el sector.",
          "El retorno, las alternativas y el aviso a quien conserva el plan."
        ],
        "answer": 2,
        "explanation": "Un cambio afecta tanto la logística como la información disponible fuera del grupo."
      }
    ]
  },
  "pilot": {
    "position": 3,
    "requires": [
      "sistema-3x3"
    ],
    "critical": false,
    "classifications": [
      "TEORÍA",
      "PROCEDIMIENTO",
      "PRÁCTICA INDIVIDUAL",
      "PRÁCTICA SUPERVISADA",
      "COMPETENCIA"
    ],
    "relatedModules": [
      "M01",
      "M00"
    ],
    "criteria": [
      "El plan permite reconstruir objetivo, retorno, alternativas, roles y comunicaciones; cada tiempo tiene un supuesto explícito y una revisión prevista."
    ]
  }
}
---
## Conceptos

**TEORÍA.** Un plan es una hipótesis de trabajo: objetivo, itinerario, personas, recursos y decisiones previstas. No es un compromiso de alcanzar una cumbre. La planificación incluye el regreso, los cambios de ruta y qué ocurrirá si falta una persona o un recurso.

Leave No Trace propone conocer restricciones, preparar el viaje y considerar impactos [Leave No Trace](#fuente-lnt). Eso no identifica los permisos vigentes de un lugar concreto: esos datos deben comprobarse con su administración. El NPS aconseja comunicar a otra persona dónde vas y cuándo esperas volver [National Park Service](#fuente-nps-equipo).

## Desarrollo teórico y toma de decisiones

**PROCEDIMIENTO · análisis y preparación.** Construye una ficha con: fecha y objetivo; participantes y experiencia pertinente; punto de partida y final; etapas y referencias cartográficas; estimaciones y su fundamento; alternativas; puntos de decisión; información meteorológica; equipo colectivo y responsable; comunicación prevista; contacto que conserva el plan y condición acordada para actuar si no hay aviso.

Distingue una **estimación** («creemos que tardaremos…») de un **límite de decisión** («a esta hora revisamos si seguimos…»). En este piloto no fijamos una velocidad universal de marcha: terreno, grupo y condiciones cambian el tiempo. Después de la actividad compara estimado y observado sin utilizar esa comparación para forzar a alguien a mantener un ritmo.

Antes de cerrar, pide a otra persona que explique el plan con sus propias palabras. Si solo el organizador entiende el retorno, la comunicación del plan falló.

## Ejemplo

Actividad didáctica original, no descripción de una ruta operativa.

## Caso de estudio

Caso ficticio: salida de ida y vuelta a un sendero conocido. La duración estimada procede de una caminata anterior con menos carga y otro grupo. Redacta qué parte de esa experiencia es transferible y qué parte no. Añade una alternativa corta y una forma de comunicar que cambiaste el plan.

Respuesta orientativa: la experiencia ayuda a reconocer referencias pero no asegura el mismo tiempo. La alternativa debe tener su propia lógica de regreso, y el contacto necesita saber qué mensajes esperar y qué significan.

## Errores frecuentes

Planificar solo el ascenso; usar tiempos de una aplicación sin contexto; no actualizar el aviso al cambiar de itinerario; confundir un contacto informado con un servicio de vigilancia.

## Límites y puntos críticos de seguridad

Accesos, cierres, permisos y alertas se verifican cerca de la salida. Ninguna ficha del piloto describe una ruta operativa ni un canal de rescate vigente.

## Material y equipo relacionado

Mapa, teléfono, respaldo de energía, frontal, abrigo y medios de comunicación seleccionados para el lugar. Asigna responsables de lo colectivo.

## Recuperación activa

- ¿Qué información necesita quien conserva tu aviso?
- ¿Qué supuesto cambiaría al añadir carga al grupo?

Responde antes de consultar el texto. Luego anota qué cambiaste y por qué; el recuerdo sin justificación no basta.

## Ejercicio y práctica

**PRÁCTICA INDIVIDUAL** limitada a análisis en mesa u observación segura. Completa un plan ficticio de una página. Intercámbialo con otra persona que debe detectar dos ambigüedades sin hacerte preguntas.

**PRÁCTICA SUPERVISADA.** Un instructor competente selecciona el contexto y observa la ejecución pertinente; este texto no autoriza a realizar maniobras técnicas sin esa formación. Antes de la sesión, acuerda objetivo, límites y cómo se interrumpirá el ejercicio.

## Registro de práctica

Abre el Diario de prácticas desde la navegación y selecciona esta habilidad. Registra fecha, lugar, condiciones, actividad, equipo, repeticiones, errores, correcciones y evidencia. Identifica al supervisor solo cuando estuvo presente. La confianza es una percepción, no un resultado de competencia. No incluyas datos médicos, contraseñas ni información privada de terceros.

## Criterios de revisión y competencia

**COMPETENCIA · evaluación pendiente.** El plan permite reconstruir objetivo, retorno, alternativas, roles y comunicaciones; cada tiempo tiene un supuesto explícito y una revisión prevista.

La evaluación debe indicar quién observó, qué contexto y evidencia revisó, qué criterio aplicó y cuál fue el resultado. El diario conserva una declaración del usuario: no verifica identidad ni credenciales del evaluador y no emite certificaciones. Una lectura o quiz nunca demuestra ejecución técnica.

## Próximos pasos y relación con otros módulos

Continúa con **Meteorología de montaña**.

Relación con el currículo original: M01. Esta secuencia pertenece al bloque piloto **Módulo 1 — Fundamentales**; no renumera las 376 entradas pendientes del mapa original. Meteorología, navegación y decisiones se revisitan en montaña estival, invernal y glaciar; no son prerrequisitos prácticos ya acreditados.
