---
{
  "title": "Especies invasoras y bioseguridad del equipo",
  "description": "Distingue introducción de invasión documentada.",
  "module": "M15",
  "code": "E11-07",
  "order": 1107,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U11-07",
  "skills": [
    "s11-invasoras-bioseguridad"
  ],
  "critical": false,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Distingue introducción de invasión documentada.",
    "Propone prevención sin captura ni tratamiento improvisado."
  ],
  "prerequisites": [
    "s11-endemismo-conservacion"
  ],
  "sources": [
    "e11-bioseguridad",
    "e11-vison"
  ],
  "pending": [
    "Revisión por especialista en ecología e instructor territorial pendiente. Los ejercicios no autorizan acceso, colecta o manejo de fauna.",
    "Categorías legales vigentes, protocolos de encuentro específicos y claves taxonómicas completas: requieren verificación.",
    "Casos, rúbricas y propuestas de práctica originales; no constituyen un protocolo oficial ni una certificación."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una especie desconocida debe…",
        "options": [
          "Capturarse por si es invasora.",
          "Identificarse y contrastarse antes de etiquetarla.",
          "Transportarse a otro sitio."
        ],
        "answer": 1,
        "explanation": "Requiere evidencia y referencia.",
        "rationales": [
          "El parecido no autoriza manejo.",
          "Requiere evidencia y referencia.",
          "Puede agravar el problema."
        ],
        "source": "e11-bioseguridad",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Barro de otro sitio en el calzado…",
        "options": [
          "Debe lavarse dentro del arroyo receptor.",
          "No merece revisión.",
          "Requiere limpieza en un lugar y método apropiados."
        ],
        "answer": 2,
        "explanation": "La prevención incluye lugar y gestión de residuos.",
        "rationales": [
          "Trasladaría material al medio receptor.",
          "Puede transportar material biológico.",
          "La prevención incluye lugar y gestión de residuos."
        ],
        "source": "e11-bioseguridad",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La limpieza registrada…",
        "options": [
          "No garantiza ausencia total de organismos.",
          "Certifica esterilidad.",
          "Sustituye instrucciones del área."
        ],
        "answer": 0,
        "explanation": "Es un control con límites.",
        "rationales": [
          "Es un control con límites.",
          "No existe tal garantía en el registro.",
          "El sitio puede exigir medidas específicas."
        ],
        "source": "e11-bioseguridad",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue introducción de invasión documentada.",
    "Propone prevención sin captura ni tratamiento improvisado.",
    "Define dónde limpiar y cómo comprobar el procedimiento."
  ],
  "openAssessment": {
    "prompt": "Diseña una lista de revisión para botas y bastones entre dos sitios ficticios: responsable, lugar de limpieza, instrucciones consultadas y límite del método.",
    "rubric": [
      "Distingue introducción de invasión documentada.",
      "Propone prevención sin captura ni tratamiento improvisado.",
      "Define dónde limpiar y cómo comprobar el procedimiento."
    ],
    "source": "e11-bioseguridad",
    "difficulty": "integración"
  },
  "diagrams": [
    "e11-impacto"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ECOLÓGICA PENDIENTE.** Observación responsable para estudio personal. No acredita identificación taxonómica, competencia profesional ni autorización de acceso. No guardes datos médicos ni localizaciones precisas de especies sensibles.

## Conceptos clave y propósito

Introducida, establecida e invasora no son sinónimos. Vía de introducción, dispersión secundaria y prevención. La apariencia de una especie no basta para decidir control.

## Teoría y toma de decisiones

El MMA identifica al visón como especie exótica invasora y documenta su problemática en Chiloé. Sus materiales también advierten confusiones con fauna nativa. El aprendizaje central para visitantes no es capturarlo: es evitar acciones improvisadas, conservar evidencia no perturbadora y consultar los canales institucionales aplicables.

Una especie introducida no debe etiquetarse automáticamente como invasora sin una evaluación pertinente. La invasión implica establecimiento, expansión e impactos que requieren documentación. Para el guía, la prevención comienza antes del traslado: calzado, bastones, ropa y equipo pueden transportar material entre lugares. Las recomendaciones del MMA incluyen limpieza de equipo; el método concreto debe adecuarse al material y a las instrucciones del área.

El principio de bioseguridad no autoriza verter productos al ambiente ni aplicar concentraciones químicas improvisadas. Elabora un circuito de revisión antes y después del uso, un lugar apropiado para limpiar y una forma de gestionar el material retirado según las indicaciones locales. Registrar una revisión no certifica ausencia de organismos: muestra que se siguió un procedimiento definido y que se conocen sus límites.

Referencias de esta unidad: [Fuente 1](#fuente-e11-bioseguridad) · [Fuente 2](#fuente-e11-vison). Los casos y las aplicaciones pedagógicas que siguen son elaboración original; no se atribuyen como protocolos de las fuentes.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — observación y decisión:** Objetivo: reducir transporte involuntario. Revisa instrucciones del sitio; inspecciona calzado y equipo; limpia en lugar apropiado antes de trasladarte; verifica compatibilidad con fabricante; registra pendiente o realizado. Variante: equipo seco frente a usado en agua; no asumas que necesitan el mismo método.

No manipules fauna, no recolectes material y no salgas del itinerario autorizado para completar el ejercicio. La conducción real y las maniobras técnicas requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un grupo llega de otro humedal con barro en las botas y propone lavarlas dentro del arroyo de destino. Identifica por qué el lugar de limpieza también importa.

## Errores frecuentes y puntos críticos de seguridad

Llamar invasora a toda especie desconocida; capturar un animal por parecido; trasladar plantas; limpiar descargando material en el sitio que se quiere proteger. No enseñar control letal ni manejo de fauna.

## Material y equipo relacionado

Cepillo y elementos de limpieza compatibles con el equipo y las instrucciones locales. Crampones y bastones también requieren inspección de material adherido; no aplicar químicos incompatibles.

[Revisar inventario](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica cómo comprobarías este criterio: Distingue introducción de invasión documentada.
- Explica cómo comprobarías este criterio: Propone prevención sin captura ni tratamiento improvisado.
- Explica cómo comprobarías este criterio: Define dónde limpiar y cómo comprobar el procedimiento.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Diseña una lista de revisión para botas y bastones entre dos sitios ficticios: responsable, lugar de limpieza, instrucciones consultadas y límite del método.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Demostración de inspección y limpieza con responsable del área o especialista, sin manipulación de fauna ni liberación de residuos al ambiente.

## Evidencia requerida y criterios de competencia

- Distingue introducción de invasión documentada.
- Propone prevención sin captura ni tratamiento improvisado.
- Define dónde limpiar y cómo comprobar el procedimiento.

**COMPETENCIA:** requiere observación y revisión humana en contexto. Una lectura, registro o quiz no certifica guiado, identificación experta ni maniobras. La plataforma no verifica credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s11-invasoras-bioseguridad) y [cuaderno de observación](../../ecologia/#observaciones). Separa ejercicio ficticio, observación real y práctica evaluada. Registra errores, correcciones, supervisor y evidencia sin inventar resultados. Mantén áreas generales; el texto libre no filtra automáticamente ubicaciones sensibles.

## Relaciones con otros módulos

[Ecología](../../ecologia/) · [Fichas de especies](../../especies/) · [Territorio](../../territorio/) · [Planificación](../../planificacion/) · [Programa](../../programa/). La interpretación ambiental se relaciona con geología, cartografía, gestión de grupos y patrimonio, sin sustituir su formación específica.
