---
{
  "title": "Enseñanza progresiva y adaptación",
  "description": "Ordena tareas con dificultad identificable.",
  "module": "M19",
  "code": "E16-03",
  "order": 1603,
  "minutes": 30,
  "level": "Intermedio",
  "status": "development",
  "unit": "U16-03",
  "skills": [
    "s16-ensenanza-progresiva"
  ],
  "critical": false,
  "reviewDate": "2026-10-28",
  "objectives": [
    "Ordena tareas con dificultad identificable.",
    "Adapta el apoyo sin rebajar el criterio a una impresión."
  ],
  "prerequisites": [
    "s16-briefing-participativo"
  ],
  "sources": [
    "e16-mt"
  ],
  "pending": [
    "Revisión por docente e instructor competente pendiente.",
    "Casos y rúbricas originales; no certifican guiado ni sustituyen formación técnica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Si una tarea no se comprende, conviene…",
        "options": [
          "Aumentar la presión para que aprenda.",
          "Identificar la dificultad y ajustar el apoyo.",
          "Anotar competencia para motivar."
        ],
        "answer": 1,
        "explanation": "Permite responder a una necesidad observada.",
        "rationales": [
          "La presión no identifica el problema.",
          "Permite responder a una necesidad observada.",
          "Falsea el registro."
        ],
        "source": "e16-mt",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Observar una demostración significa…",
        "options": [
          "Haber demostrado autonomía.",
          "Haber realizado una evaluación práctica.",
          "Haber presenciado una explicación, pendiente de ensayo."
        ],
        "answer": 2,
        "explanation": "Mantiene separado cada tipo de evidencia.",
        "rationales": [
          "No se observó ejecución propia.",
          "Falta una evaluación de la actuación.",
          "Mantiene separado cada tipo de evidencia."
        ],
        "source": "e16-mt",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué evidencia corresponde al ejercicio propuesto en esta unidad?",
        "options": [
          "Un registro de la tarea, errores y correcciones observados.",
          "Una declaración automática de competencia por leer.",
          "Una valoración del carácter de la persona."
        ],
        "answer": 0,
        "explanation": "La rúbrica pide observaciones de una tarea concreta; su evaluación sigue siendo humana.",
        "rationales": [
          "Es evidencia contextual del taller.",
          "Leer no demuestra ejecución.",
          "Se evalúan actuaciones, no etiquetas personales."
        ],
        "source": "e16-mt",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Ordena tareas con dificultad identificable.",
    "Adapta el apoyo sin rebajar el criterio a una impresión.",
    "Separa desafío educativo de exposición real."
  ],
  "openAssessment": {
    "prompt": "Diseña tres tareas de mesa sobre lectura de una ficha territorial. Para cada transición escribe evidencia necesaria, apoyo disponible y motivo para detener la progresión.",
    "rubric": [
      "Ordena tareas con dificultad identificable.",
      "Adapta el apoyo sin rebajar el criterio a una impresión.",
      "Separa desafío educativo de exposición real."
    ],
    "source": "e16-mt",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**BLOQUE EN DESARROLLO · REVISIÓN DOCENTE E INSTRUCTORA PENDIENTE.** Talleres de mesa con personajes ficticios, sin exposición en terreno ni datos personales.

## Conceptos clave y propósito

Una progresión docente organiza tareas de menor a mayor complejidad y adapta el apoyo a la evidencia observada. No consiste en aumentar la exposición al peligro para probar valentía.

## Teoría y alcance de la fuente

El marco de Mountain Training relaciona apoyo y desafío con las necesidades de cada participante. En esta academia se aplica como criterio de diseño de talleres, no como autorización de maniobras.

[Fuente conceptual y límites](#fuente-e16-mt). El diseño de tareas, preguntas y criterios siguiente es una propuesta original de la academia; no se atribuye a la organización citada ni constituye un estándar de acreditación.

## Aplicación docente propuesta

Propuesta de mesa: comienza identificando una sola referencia en un mapa; añade después una discrepancia entre dos documentos y pide una justificación. Cambia una dificultad por vez para saber qué produjo el error. Antes de continuar, explica qué observación permite pasar al siguiente ejercicio y qué observación requiere volver a una tarea anterior.

Una demostración puede hacer visible la decisión, pero mirar no demuestra ejecución. Alterna explicación, ensayo y revisión en un entorno que el instructor haya seleccionado. Si enseñas una habilidad crítica, el procedimiento técnico, los límites y la supervisión pertenecen a su formación específica; este bloque no los reemplaza. Ofrece otra forma de trabajar el mismo objetivo cuando una barrera de comunicación impida mostrar lo aprendido.

## Caso práctico

**Escenario ficticio:** En un ejercicio ficticio, una persona resuelve la primera tarea y otra todavía confunde el objetivo con el resultado.

Explica qué observación necesitas antes de concluir y qué parte de tu respuesta es todavía una hipótesis.

## Errores frecuentes

Confundir confianza con evidencia, registrar como realizada una práctica solo preparada y trasladar el resultado de una simulación a terreno real. Revisa también si describiste un hecho o una interpretación.

## Material y equipo

Cuaderno, tarjetas con roles ficticios y una ficha territorial de la academia. No se requieren cuerdas, anclajes ni exposición al terreno para estos ejercicios.

## Autoevaluación

- Ordena tareas con dificultad identificable.
- Adapta el apoyo sin rebajar el criterio a una impresión.
- Separa desafío educativo de exposición real.

## Ejercicios y práctica supervisada

Diseña tres tareas de mesa sobre lectura de una ficha territorial. Para cada transición escribe evidencia necesaria, apoyo disponible y motivo para detener la progresión.

En un taller con docente o instructor, alterna participante, facilitador y observador. Define antes el criterio y recoge después una corrección. El instructor decide si corresponde otra práctica; no aumentes exposición para producir evidencia.

## Evidencia requerida

Conserva objetivo, tarea, observación, error, corrección y próxima práctica. La revisión humana debe indicar contexto y límites; no basta una etiqueta de «logrado». El quiz registra conocimiento teórico y no cambia competencias prácticas.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s16-ensenanza-progresiva). Solo registra el taller después de realizarlo. No inventes supervisor, evaluación ni repeticiones.

## Relaciones con otros módulos

[Pedagogía y liderazgo](../../liderazgo/) · [Fundamentos de grupo](../../lecciones/grupo-liderazgo/) · [Programa](../../programa/). Las maniobras y decisiones técnicas requieren sus propias competencias y supervisión.
