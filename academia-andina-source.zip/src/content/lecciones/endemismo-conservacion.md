---
{
  "title": "Endemismo y conservación: leer categorías sin confundirlas",
  "description": "Distingue nativa, endémica y amenazada.",
  "module": "M15",
  "code": "E11-06",
  "order": 1106,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U11-06",
  "skills": [
    "s11-endemismo-conservacion"
  ],
  "critical": false,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Distingue nativa, endémica y amenazada.",
    "Atribuye categoría, escala y fecha sin afirmar vigencia no comprobada."
  ],
  "prerequisites": [
    "s11-fauna-evidencia"
  ],
  "sources": [
    "e11-rce",
    "e11-choroy",
    "e11-alerce"
  ],
  "pending": [
    "Revisión por especialista en ecología e instructor territorial pendiente. Los ejercicios no autorizan acceso, colecta o manejo de fauna.",
    "Categorías legales vigentes, protocolos de encuentro específicos y claves taxonómicas completas: requieren verificación.",
    "Casos, rúbricas y propuestas de práctica originales; no constituyen un protocolo oficial ni una certificación."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Endémica significa…",
        "options": [
          "Siempre en peligro.",
          "Exclusiva de cualquier parque donde aparezca.",
          "Distribución restringida al ámbito indicado."
        ],
        "answer": 2,
        "explanation": "Incluye la escala necesaria.",
        "rationales": [
          "Riesgo y distribución son conceptos distintos.",
          "El ámbito debe documentarse.",
          "Incluye la escala necesaria."
        ],
        "source": "e11-rce",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una noticia antigua basta para…",
        "options": [
          "Conocer lo que esa noticia decía, no asegurar la categoría vigente.",
          "Afirmar vigencia legal hoy.",
          "Corregir automáticamente un decreto."
        ],
        "answer": 0,
        "explanation": "Conserva fecha y alcance.",
        "rationales": [
          "Conserva fecha y alcance.",
          "Falta comprobar instrumento aplicable.",
          "No sustituye la fuente normativa."
        ],
        "source": "e11-rce",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Ante categorías de distinta escala…",
        "options": [
          "Escoge la más grave.",
          "Explica escala y fuente de cada una.",
          "Promedia ambas."
        ],
        "answer": 1,
        "explanation": "Permite interpretar sin mezclar.",
        "rationales": [
          "Ocultaría la diferencia metodológica.",
          "Permite interpretar sin mezclar.",
          "No son números promediables."
        ],
        "source": "e11-rce",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue nativa, endémica y amenazada.",
    "Atribuye categoría, escala y fecha sin afirmar vigencia no comprobada.",
    "Conserva discrepancias documentales como pendientes."
  ],
  "openAssessment": {
    "prompt": "Crea una matriz ficticia con columnas taxón, ámbito de endemismo, categoría citada, fecha, instrumento y estado de verificación. Deja explícitas las casillas sin dato.",
    "rubric": [
      "Distingue nativa, endémica y amenazada.",
      "Atribuye categoría, escala y fecha sin afirmar vigencia no comprobada.",
      "Conserva discrepancias documentales como pendientes."
    ],
    "source": "e11-rce",
    "difficulty": "integración"
  },
  "diagrams": [
    "e11-evidencia"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ECOLÓGICA PENDIENTE.** Observación responsable para estudio personal. No acredita identificación taxonómica, competencia profesional ni autorización de acceso. No guardes datos médicos ni localizaciones precisas de especies sensibles.

## Conceptos clave y propósito

Nativa: presente naturalmente en el ámbito considerado. Endémica: distribución restringida a un ámbito que debe nombrarse. Amenaza: riesgo de desaparición según evaluación y escala. Protección legal y categoría de conservación son campos distintos.

## Teoría y toma de decisiones

Decir “endémica” sin completar “de dónde” deja la afirmación incompleta. Un taxón puede ser nativo de Chile y también existir en Argentina; eso no lo convierte en endémico de Chile. La ficha del choroy (Enicognathus leptorhynchus) describe endemismo chileno. Esa información no implica que su distribución se limite a Los Lagos ni que toda población esté bajo una misma presión local.

La categoría de conservación exige fuente, fecha, taxón y ámbito. No se debe mezclar una categoría global con una nacional ni tratar una noticia antigua como instrumento vigente. En esta unidad se practica lectura documental; no se adjudica una categoría legal actual a partir de un resumen. Cuando el decreto o evaluación aplicable no está verificado, se escribe “requiere verificación”.

Una especie frecuente en un punto puede tener problemas a otra escala. El criterio de cuidado no depende de completar primero una etiqueta de amenaza: evitar perturbación sigue siendo pertinente. Para guiar, prepara una ficha que permita explicar qué se sabe, qué documento lo respalda y qué afirmación está pendiente.

Referencias de esta unidad: [Fuente 1](#fuente-e11-rce) · [Fuente 2](#fuente-e11-choroy) · [Fuente 3](#fuente-e11-alerce). Los casos y las aplicaciones pedagógicas que siguen son elaboración original; no se atribuyen como protocolos de las fuentes.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — observación y decisión:** Anota nombre científico, ámbito, fuente y fecha. Separa distribución, evaluación de amenaza y protección legal. Si dos fuentes discrepan, conserva ambas fechas y no elijas la más alarmante ni la más conveniente. Variante: ficha histórica frente a instrumento vigente verificado.

No manipules fauna, no recolectes material y no salgas del itinerario autorizado para completar el ejercicio. La conducción real y las maniobras técnicas requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un cartel antiguo llama vulnerable a una especie y una ficha posterior entrega otra categoría. Prepara una explicación que no declare vigencia sin revisar el instrumento correspondiente.

## Errores frecuentes y puntos críticos de seguridad

Equiparar endémica con amenazada; extrapolar una etiqueta global a Chile; reemplazar taxonomía sin revisión; usar una categoría como permiso para molestar.

## Material y equipo relacionado

Ficha documental y acceso a repositorios oficiales. No se necesita localizar individuos sensibles para aprender categorías.

[Revisar inventario](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica cómo comprobarías este criterio: Distingue nativa, endémica y amenazada.
- Explica cómo comprobarías este criterio: Atribuye categoría, escala y fecha sin afirmar vigencia no comprobada.
- Explica cómo comprobarías este criterio: Conserva discrepancias documentales como pendientes.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Crea una matriz ficticia con columnas taxón, ámbito de endemismo, categoría citada, fecha, instrumento y estado de verificación. Deja explícitas las casillas sin dato.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Revisión documental con especialista de conservación, contrastando ámbitos y fechas; no es una evaluación de población en terreno.

## Evidencia requerida y criterios de competencia

- Distingue nativa, endémica y amenazada.
- Atribuye categoría, escala y fecha sin afirmar vigencia no comprobada.
- Conserva discrepancias documentales como pendientes.

**COMPETENCIA:** requiere observación y revisión humana en contexto. Una lectura, registro o quiz no certifica guiado, identificación experta ni maniobras. La plataforma no verifica credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s11-endemismo-conservacion) y [cuaderno de observación](../../ecologia/#observaciones). Separa ejercicio ficticio, observación real y práctica evaluada. Registra errores, correcciones, supervisor y evidencia sin inventar resultados. Mantén áreas generales; el texto libre no filtra automáticamente ubicaciones sensibles.

## Relaciones con otros módulos

[Ecología](../../ecologia/) · [Fichas de especies](../../especies/) · [Territorio](../../territorio/) · [Planificación](../../planificacion/) · [Programa](../../programa/). La interpretación ambiental se relaciona con geología, cartografía, gestión de grupos y patrimonio, sin sustituir su formación específica.
