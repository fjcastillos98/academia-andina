---
{
  "title": "Piolet: herramienta, terreno y función",
  "description": "Reconocer partes y diferencias funcionales entre piolet de marcha y técnico.",
  "module": "M02",
  "code": "E5-18",
  "order": 517,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-15",
  "skills": [
    "s5-piolet"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Reconocer partes y diferencias funcionales entre piolet de marcha y técnico.",
    "Relacionar elección, longitud y compatibilidad con actividad concreta.",
    "Preparar inspección y práctica sin presumir capacidad por poseer equipo."
  ],
  "prerequisites": [
    "s5-cramponaje"
  ],
  "sources": [
    "e5-grivel-gzero",
    "e5-petzl-piolet",
    "e5-ms-winter"
  ],
  "pending": [
    "Revisión de instructor y contraste con manuales exactos del equipo disponible. Cualquier aplicación territorial permanece pendiente de reconocimiento y condiciones actuales."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "La empresa compra un piolet de marcha. ¿Qué demuestra?",
        "options": [
          "Que todos pueden usarlo.",
          "Que sirve para cualquier hielo.",
          "Solo disponibilidad de una herramienta por identificar e inspeccionar."
        ],
        "answer": 2,
        "explanation": "Compra y competencia son evidencias diferentes.",
        "rationales": [
          "Falta aprendizaje práctico.",
          "El uso depende del diseño.",
          "No asigna capacidad sin evaluación."
        ],
        "source": "e5-grivel-gzero",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué hacer ante holgura de una unión no explicada por el manual?",
        "options": [
          "Ignorarla si es pequeña.",
          "Aislar y consultar criterios del fabricante.",
          "Modificar la unión en terreno."
        ],
        "answer": 1,
        "explanation": "La incertidumbre requiere revisión competente.",
        "rationales": [
          "No verifica el defecto.",
          "Mantiene trazabilidad y límites.",
          "No hay autorización para improvisar."
        ],
        "source": "e5-petzl-piolet",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Piolet usado como apoyo implica…",
        "options": [
          "Una función distinta de un anclaje para personas.",
          "Resistencia del anclaje comprobada.",
          "Autodetención garantizada."
        ],
        "answer": 0,
        "explanation": "La función cambia el análisis necesario.",
        "rationales": [
          "Evita extrapolar entre usos.",
          "No hay evaluación del soporte.",
          "La detención depende del escenario."
        ],
        "source": "e5-ms-winter",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "Relaciona diseño con función.",
    "Reconoce defectos e incertidumbres que requieren revisión.",
    "Distingue apoyo, detención y anclaje sin extrapolar capacidades."
  ],
  "openAssessment": {
    "prompt": "Elabora una comparación de funciones de dos piolets concretos y declara qué no puede decidirse sin evaluación presencial.",
    "rubric": [
      "Relaciona diseño con función.",
      "Reconoce defectos e incertidumbres que requieren revisión.",
      "Distingue apoyo, detención y anclaje sin extrapolar capacidades."
    ],
    "source": "e5-grivel-gzero",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-piolet"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Identifica las partes en la herramienta real y su manual; una foto puede no revelar desgaste, uniones o modelo exacto.

## Teoría y toma de decisiones

El piolet es una herramienta cuya utilidad depende del diseño, el terreno y la habilidad. Reconoce cabeza, pico, pala o martillo según modelo, mango y extremo inferior o regatón cuando existe. No todos los modelos tienen las mismas piezas ni permiten los mismos usos. El nombre «técnico» no significa automáticamente más adecuado para una caminata; tampoco «clásico» describe por completo todas sus limitaciones.

Grivel presenta el G Zero como piolet clásico para marcha glaciar y rutas alpinas [fuente](#fuente-e5-grivel-gzero). Es una referencia útil para analizar el equipo previsto para Filo Austral, pero debe identificarse la generación y el manual de la unidad realmente adquirida. La página de catálogo actual no permite asumir que un ejemplar anterior comparta cada componente. No se prescribe longitud a partir de la estatura solamente: actividad, geometría, forma de uso prevista y evaluación presencial intervienen en la elección.

El piolet de marcha suele estudiarse como apoyo y herramienta de gestión de un resbalón dentro de una técnica aprendida. Un piolet técnico puede priorizar golpeo y agarre en terreno más inclinado, con geometrías distintas. Esta comparación funcional evita elegir por apariencia. «Apoyo», «bastón», «autoseguro» y «autodetención» nombran objetivos diferentes: facilitar equilibrio no equivale a detener una caída ya acelerada. Una herramienta en la mochila no participa en ninguna de esas funciones hasta que se utiliza correctamente.

La documentación de Petzl señala ejemplos de defectos que deben revisarse, como fisuras, deformación, desgaste excesivo y holgura de uniones [fuente](#fuente-e5-petzl-piolet). Para otra marca, consulta sus criterios propios. La inspección de aula debe describir, fotografiar si corresponde y consultar; no reparar mediante calentamiento, modificación o combinación no autorizada. Anota golpes relevantes y mantenimiento en el inventario. Si existe incertidumbre, aislar y revisar material es distinto de declararlo apto.

Un piolet puede aparecer en enseñanzas de anclajes en nieve, pero su presencia no valida un anclaje. El soporte, la nieve, la dirección, la geometría y la carga requieren una formación específica. En esta etapa solo se reconoce la diferencia entre herramienta de progresión y componente de un sistema. No se proporciona un montaje para suspender personas ni se deduce resistencia a partir del marcado del piolet.

El ejercicio de elección plantea una marcha sobre nieve de estado desconocido y un ascenso técnico distinto. Escribe qué información necesitas en cada caso y qué función esperas del equipo. Después compara un modelo de marcha con uno técnico usando sus manuales. La revisión presencial comprobará que puedes manejar la herramienta sin exponer a compañeros, cambiar de tarea y reconocer cuándo tu técnica no responde al escenario. La explicación verbal prepara ese taller, pero no demuestra ejecución. Vincula la práctica con la unidad de autodetención y con decisiones de retirada, conservando su evaluación independiente.

## Qué observo, qué significa y qué no puedo concluir

Usar un piolet como apoyo, autodetención o anclaje son habilidades distintas, todas con formación presencial donde corresponda. No se recomienda un modelo por el nombre de una montaña.

## Caso práctico y aplicación al guiado

Se ofrecen piolets G Zero para una actividad no descrita. Explica qué información falta antes de afirmar que son adecuados para pasajeros.

## Errores frecuentes y señales de alerta

Confundir tipo comercial con permiso de uso; escoger longitud por una regla única; ignorar desgaste; asumir capacidad de anclaje por tener piolet.

## Autoevaluación y respuesta razonada

Elabora una comparación de funciones de dos piolets concretos y declara qué no puede decidirse sin evaluación presencial.

## Ejercicios y práctica supervisada

Taller de identificación y manejo supervisado, en escenario escogido por instructor. Revisar manual y registrar observaciones, no resistencia supuesta.

## Evidencia requerida

- Relaciona diseño con función.
- Reconoce defectos e incertidumbres que requieren revisión.
- Distingue apoyo, detención y anclaje sin extrapolar capacidades.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-piolet).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
