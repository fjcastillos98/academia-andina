---
{
  "title": "Machard",
  "description": "Identificar nombre, variante y función de machard.",
  "module": "M07",
  "code": "E43-11",
  "order": 310,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U43-03",
  "skills": [
    "s43-machard"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Identificar nombre, variante y función de machard.",
    "Distinguir límites de uso, errores y compatibilidades pendientes.",
    "Preparar una revisión presencial con evidencia."
  ],
  "prerequisites": [
    "s43-prusik"
  ],
  "sources": [
    "petzl-friccion"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente.",
    "Equivalencia de nomenclatura regional pendiente de instructor."
  ],
  "diagrams": [
    "revision-visual"
  ],
  "preparation": [
    "Función: fricción; la variante autoblock de la fuente tiene bloqueo bidireccional.",
    "Error: «Machard» sin diagrama ni referencia.",
    "Compatibilidad: revisar cuerda, cordino y sistema."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "petzl-friccion",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "En el estudio de machard, ¿qué afirmación es defendible?",
        "options": [
          "Todas las variantes locales son idénticas.",
          "Función: fricción; la variante autoblock de la fuente tiene bloqueo bidireccional.",
          "El nombre basta sin esquema."
        ],
        "answer": 1,
        "explanation": "La función debe identificarse dentro del alcance descrito; no implica aptitud del conjunto.",
        "rationales": [
          "La afirmación omite contexto o atribuye una función no demostrada.",
          "Función: fricción; la variante autoblock de la fuente tiene bloqueo bidireccional. Se mantiene su alcance específico.",
          "No permite evaluar el sistema completo ni sus límites."
        ],
        "source": "petzl-friccion",
        "difficulty": "básica",
        "kind": "conocimiento"
      },
      {
        "prompt": "El nudo parece correcto, pero no se ve su conexión. ¿Qué concluyes?",
        "options": [
          "El sistema ya está revisado.",
          "La conexión es necesariamente incorrecta.",
          "Falta información; no aprobar el conjunto por una sola parte."
        ],
        "answer": 2,
        "explanation": "La revisión debe distinguir lo observado de lo que aún no se puede comprobar.",
        "rationales": [
          "Extrapola una parte al conjunto.",
          "La falta de imagen no prueba un defecto.",
          "Conserva incertidumbre y pide una comprobación concreta."
        ],
        "source": "petzl-friccion",
        "difficulty": "intermedia",
        "kind": "errores"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

Nombre: Machard; declarar si se estudia el autoblock mostrado por Petzl. No asumir que el término identifica todas las variantes locales. Característica: el esquema exacto debe acompañar al nombre.

## Teoría: función, aplicación y límites

- Función: fricción; la variante autoblock de la fuente tiene bloqueo bidireccional.

- Uso: comparar funciones y vocabulario con Prusik.

- No uso: no cambiar una variante por otra basándose solo en el nombre.

- Ventaja: la fuente describe facilidad de liberación del autoblock, sin convertirla en garantía bajo toda carga.

- Limitación: compatibilidad y disposición son específicas.

- Característica: el esquema exacto debe acompañar al nombre.

La pregunta de estudio no termina al reconocer el nombre. Explica qué se pretende conectar, cuál es el recorrido de la carga y qué información falta para evaluar el conjunto. Distingue la observación directa de una suposición: no ver un defecto en una imagen no equivale a revisar todas las caras. En una sesión de guiado, pide al alumno describir la función con sus palabras antes de discutir rapidez o destreza.

[Referencia técnica: petzl-friccion](#fuente-petzl-friccion). Consulta los diagramas del fabricante para la configuración exacta; las láminas de esta academia analizan funciones y errores, no sustituyen esos diagramas ni el taller.

## Caso práctico y aplicación al guiado

Ejercicio: dos instructores usan el mismo nombre para dibujos distintos. La respuesta adecuada es resolver identificación y fuente, no votar por familiaridad.

- Montaña: comparación conceptual de autobloqueantes.

- Guiado: acordar términos entre profesionales antes de actuar.

## Errores frecuentes y señales de alerta

Error: «Machard» sin diagrama ni referencia.

## Inspección y compatibilidades

Inspección: disposición y comportamiento previstos, sin normalizar cruces.

Compatibilidad: revisar cuerda, cordino y sistema.

Se debe detener la propuesta si no se identifica la variante o el lugar de conexión. La revisión de extremos se hace según referencia aplicable; no se añade una cifra universal. La condición del material también necesita documentación e inspección, incluso cuando el recorrido del nudo parece correcto.

## Autoevaluación y respuestas explicadas

¿Reconocer una forma demuestra ejecución en terreno? **No: faltan selección, conexión, inspección, comunicación y desempeño bajo las condiciones evaluadas.**

¿Qué debes registrar si dos personas no coinciden en la variante? **Los nombres y diagramas utilizados, la fuente de cada uno y la discrepancia; resolverla con instructor antes de una aplicación.**

## Ejercicios y práctica presencial

Práctica: taller supervisado y revisión de variante.

Prepara una ficha de comparación entre la función prevista y una función que este estudio no autoriza. Explica un error posible sin introducirlo en material en uso. En taller, el instructor observa identificación, confección, vestido, ajuste y revisión cruzada con material didáctico y condiciones controladas. No se carga una persona ni se improvisa una maniobra durante el estudio individual.

## Evidencia requerida

Nombre y variante, fuente, combinación de material, observación del instructor, error detectado, corrección y nueva práctica. La evaluación presencial debe declarar contexto y límites; un cuestionario solo registra comprensión.

## Relaciones con otras habilidades

Este tema precede a revisión de nudos y encordamiento. No se utiliza el resultado del quiz como habilitación para asegurar, descender o rescatar.

**PENDIENTE DE REVISIÓN DE INSTRUCTOR:** equivalencia entre el nombre local Machard y la variante autoblock de la fuente.
