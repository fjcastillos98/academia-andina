---
{
  "title": "Autorescate: capacidad real y contexto",
  "description": "Reconocer condiciones que permiten o impiden participar en la salida.",
  "module": "M04",
  "code": "E6-08",
  "order": 608,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U6-08",
  "skills": [
    "s6-autorescate-grieta"
  ],
  "critical": true,
  "reviewDate": "2026-10-23",
  "objectives": [
    "Reconocer condiciones que permiten o impiden participar en la salida.",
    "Separar ascender cuerda y superar el borde."
  ],
  "prerequisites": [
    "s6-detencion-grieta"
  ],
  "sources": [
    "e6-uiaa-self",
    "e6-petzl-edge"
  ],
  "pending": [
    "Revisión por instructor; atención clínica según formación sanitaria. No es algoritmo médico. PENDIENTE DE VERIFICACIÓN.",
    "Revisión presencial por instructor competente pendiente. No se ha realizado ni aprobado ninguna práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Persona consciente con bloqueador…",
        "options": [
          "Puede salir siempre.",
          "No necesita comunicación.",
          "Aún requiere capacidad funcional, técnica y sistema apropiado."
        ],
        "answer": 2,
        "explanation": "Conciencia y posesión de equipo no demuestran capacidad.",
        "rationales": [
          "No se justifica: Conciencia y posesión de equipo no demuestran capacidad.",
          "No se justifica: Conciencia y posesión de equipo no demuestran capacidad.",
          "Correcta: Conciencia y posesión de equipo no demuestran capacidad."
        ],
        "source": "e6-uiaa-self",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Llegar al borde…",
        "options": [
          "Puede requerir una transición adicional.",
          "Es lo mismo que salir.",
          "Elimina necesidad de estabilización."
        ],
        "answer": 0,
        "explanation": "Ascenso y superación del borde plantean problemas diferentes.",
        "rationales": [
          "Correcta: Ascenso y superación del borde plantean problemas diferentes.",
          "No se justifica: Ascenso y superación del borde plantean problemas diferentes.",
          "No se justifica: Ascenso y superación del borde plantean problemas diferentes."
        ],
        "source": "e6-uiaa-self",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Movilidad limitada cambia…",
        "options": [
          "Solo el tiempo del quiz.",
          "Las opciones realmente disponibles.",
          "Nada si hay cuerda."
        ],
        "answer": 1,
        "explanation": "No puede presuponerse colaboración.",
        "rationales": [
          "No se justifica: No puede presuponerse colaboración.",
          "Correcta: No puede presuponerse colaboración.",
          "No se justifica: No puede presuponerse colaboración."
        ],
        "source": "e6-uiaa-self",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "No presupone colaboración.",
    "Considera estabilización antes de mover cargas.",
    "Distingue conocer un dispositivo y haber practicado su uso."
  ],
  "openAssessment": {
    "prompt": "Compara persona capaz de colaborar, movilidad limitada y comunicación imposible. Identifica qué opciones deben revisarse con personal competente sin diagnosticar ni improvisar una maniobra.",
    "rubric": [
      "No presupone colaboración.",
      "Considera estabilización antes de mover cargas.",
      "Distingue conocer un dispositivo y haber practicado su uso."
    ],
    "source": "e6-uiaa-self",
    "difficulty": "integración"
  },
  "diagrams": [
    "e6-objetivos"
  ]
}
---

**CONTENIDO TEÓRICO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Capacidad funcional, Estabilización, Progresión y transición, Comunicación. UIAA presenta un caso condicionado a que la persona pueda moverse y sepa ascender. Estar consciente no demuestra esas condiciones.

## Teoría y toma de decisiones

Autorescate describe una participación activa de la persona atrapada en su recuperación, cuando su capacidad y el sistema lo permiten. UIAA plantea un caso que requiere movilidad, conocimiento de ascenso y estabilización en superficie. [Ejemplo UIAA](#fuente-e6-uiaa-self). Estar consciente o decir «me encuentro bien» no demuestra que se pueda ejecutar esa tarea con el equipo y posición reales.

Ascender por cuerda y superar el borde son problemas relacionados, pero diferentes. Pueden cambiar apoyo, roce, recorrido y comunicación. Petzl aborda la valoración de situación desde el borde con protección del rescatista; acercarse añade exposición y puede cargar el sistema. [Evaluación del borde](#fuente-e6-petzl-edge). La necesidad de observar no justifica aproximarse sin el método y protección apropiados.

Antes de elegir una opción, el análisis considera movilidad comunicada, material accesible, capacidad entrenada y coordinación de superficie. No se hace diagnóstico clínico en esta página ni se sustituye asistencia externa. Si la persona no puede colaborar, la opción prevista de autorescate deja de ser una capacidad disponible, aunque lleve bloqueadores. El equipo debe haber considerado esa posibilidad y los límites de lo que puede realizar.

Ejercicio: recibe tres tarjetas sucesivas —responde a la voz, comunica movilidad limitada, después no se entiende el mensaje—. Revisa tu hipótesis sin convertir una respuesta inicial en información permanente. Escribe qué dato pedirías, qué no puedes concluir y qué tarea requiere personal competente. La práctica de ascenso y transición se realiza en instalación protegida diseñada por instructor; no se aprende suspendiéndose de una cuerda montada a partir de la lectura. La revisión registra funciones observadas y condiciones, no una etiqueta general de autosuficiencia.

## Procedimiento conceptual: objetivo, uso y límites

Reconocer condiciones que permiten o impiden participar en la salida. Esta unidad se utiliza para preparar el análisis y un taller, no para ejecutar una maniobra sin entrenamiento. La comunicación entre superficie y persona atrapada sirve para revisar opciones; el material debe poder usarse en el contexto.

Las variantes técnicas mantienen el ámbito de la fuente citada. Antes de cambiar una configuración se deben revisar sus funciones, comprobaciones y límites con instructor; no se combinan pasos de escuelas distintas por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario hipotético de aula.** Una persona porta un dispositivo, pero nunca practicó ascenso ni paso del borde. El grupo supone que puede salir sola porque está consciente. Identifica las capacidades y condiciones que faltan.

## Errores frecuentes y puntos críticos

Presuponer colaboración; confundir conciencia con movilidad; aproximarse al borde sin protección; ignorar cargas compartidas.

No se atribuye una garantía de seguridad al equipo, al quiz ni a una práctica en condiciones diferentes. Si falta un dato esencial para justificar el objetivo, declarar ese vacío es parte del aprendizaje.

## Material y equipo relacionado

Equipo personal de ascenso/rescate compatible con cuerda y arnés; comunicación y material de apoyo. La disponibilidad no prueba capacidad.

[Inventario personal](../../equipo/): conserva referencia del manual y observaciones de inspección. El registro no declara aptitud de una pieza ni competencia de quien la porta.

## Autoevaluación y recuperación activa

- ¿Qué información podría descartar un autorescate inicialmente previsto?
- ¿Por qué llegar al borde no equivale a salir de la grieta?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL de escritorio:** Compara persona capaz de colaborar, movilidad limitada y comunicación imposible. Identifica qué opciones deben revisarse con personal competente sin diagnosticar ni improvisar una maniobra.

**PRÁCTICA SUPERVISADA:** el instructor adapta un taller con objetivos observables, protección y criterios de parada. No provocar caídas reales ni entrar a terreno expuesto para comprobar esta página. La evaluación presencial es independiente de la respuesta teórica.

## Evidencia requerida y criterios de competencia

- No presupone colaboración.
- Considera estabilización antes de mover cargas.
- Distingue conocer un dispositivo y haber practicado su uso.

Estos criterios valoran razonamiento; para una competencia práctica, el instructor debe definir y observar la ejecución en un contexto explícito. No se preasigna una evaluación por estudiar.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s6-autorescate-grieta). Registrar únicamente lo realizado: fecha, lugar, condiciones, objetivo, equipo, supervisor, resultado, errores, correcciones, evidencia, autonomía observada y próxima práctica. No guardar datos médicos ni información privada de pasajeros.

## Relaciones con etapas anteriores

[Glaciología introductoria](../glaciologia-intro/), [planificación invernal](../planificacion-invernal/), [encordamiento según contexto](../encordamiento-contexto/), [anclajes](../anclajes-reuniones/) y [ventaja mecánica](../ventaja-mecanica/). Estas dependencias orientan el estudio; no autorizan la aplicación técnica. [Ruta glaciar](../../glaciar/).
