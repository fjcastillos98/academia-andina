---
{
  "title": "Rescate en avalancha: escena, grupo y continuidad de la atención",
  "description": "Distinguir respuesta del grupo y rescate organizado.",
  "module": "M09",
  "code": "E5-15",
  "order": 514,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-12",
  "skills": [
    "s5-rescate-avalancha"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir respuesta del grupo y rescate organizado.",
    "Integrar búsqueda, sondaje, excavación, atención y comunicación sin perder seguridad.",
    "Analizar ocho escenarios con recursos e información limitados."
  ],
  "prerequisites": [
    "s5-excavacion",
    "s5-dva-multiples",
    "s5-sonda"
  ],
  "sources": [
    "e5-wms-resumen-avalancha",
    "e5-wms-enterramiento",
    "e5-sonda-icar"
  ],
  "pending": [
    "Revisión por instructor de avalanchas y profesional sanitario; protocolos locales de comunicación y atención pendientes."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿Qué diferencia rescate de compañeros y organizado?",
        "options": [
          "El organizado no necesita evaluar riesgos.",
          "Recursos, organización y capacidades, con continuidad entre respuestas.",
          "El de compañeros siempre basta."
        ],
        "answer": 1,
        "explanation": "Los recursos y formación condicionan tareas.",
        "rationales": [
          "La evaluación sigue siendo necesaria.",
          "Describe una diferencia contextual.",
          "Promete capacidad inexistente."
        ],
        "source": "e5-wms-enterramiento",
        "difficulty": "intermedia",
        "kind": "conocimiento"
      },
      {
        "prompt": "Una parte visible de una persona permite concluir…",
        "options": [
          "Que no hay trauma.",
          "Que ya no necesita atención.",
          "Solo una observación, pendiente de evaluación y acceso."
        ],
        "answer": 2,
        "explanation": "Visibilidad no resuelve estado clínico.",
        "rationales": [
          "No está evaluado.",
          "Omite riesgos.",
          "Separa dato y conclusión."
        ],
        "source": "e5-wms-resumen-avalancha",
        "difficulty": "intermedia",
        "kind": "errores"
      },
      {
        "prompt": "¿Qué implica una amenaza de segunda avalancha?",
        "options": [
          "Reevaluar la exposición y capacidad de intervención.",
          "Entrar con todo el grupo porque ya ocurrió una.",
          "Ignorarla si el DVA da una señal."
        ],
        "answer": 0,
        "explanation": "La seguridad de rescatistas sigue siendo parte de la escena.",
        "rationales": [
          "Reconoce riesgo dinámico.",
          "Multiplica exposición sin justificación.",
          "La señal no elimina amenazas."
        ],
        "source": "e5-sonda-icar",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Reconoce los ocho escenarios y sus cambios de recursos.",
    "Distingue evaluación de escena y evaluación clínica.",
    "Comunica hechos e incertidumbres sin inventar pronóstico o capacidad."
  ],
  "openAssessment": {
    "prompt": "Selecciona dos de los ocho escenarios y compara amenazas, recursos, datos faltantes, opciones, petición de apoyo y debriefing.",
    "rubric": [
      "Reconoce los ocho escenarios y sus cambios de recursos.",
      "Distingue evaluación de escena y evaluación clínica.",
      "Comunica hechos e incertidumbres sin inventar pronóstico o capacidad."
    ],
    "source": "e5-wms-resumen-avalancha",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-dva-flujo"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Distinguir hechos, amenazas, capacidad disponible e hitos de búsqueda/atención; observar cambios que obligan a reevaluar.

## Teoría y toma de decisiones

El rescate de compañeros comienza con las personas presentes y sus recursos; el rescate organizado agrega equipos, coordinación y capacidades especializadas. No son dos mundos separados: la respuesta inicial necesita transmitir información y facilitar continuidad. Tampoco son equivalentes a improvisar cualquier maniobra disponible en internet. Un guía aislado no puede asumir simultáneamente todas las funciones ni convertir a pasajeros sin formación en rescatistas técnicos por asignarles una tarea.

La seguridad de escena es dinámica. Hay que reconocer amenazas por encima, terreno de caída, otros riesgos locales y cambios durante la intervención. ICAR sitúa esa evaluación antes de exponer a equipos de sondaje organizados. [Riesgos de escena](#fuente-e5-sonda-icar). El hecho de que ya haya ocurrido una avalancha no demuestra que el área no pueda ser afectada nuevamente. Una evaluación secundaria de seguridad vuelve sobre la escena; no debe confundirse con la evaluación secundaria clínica de una persona.

Búsqueda, sonda y pala forman una cadena, pero el resultado perseguido es llegar a la persona y sostener atención y evacuación. WMS destaca que estos instrumentos exigen práctica y que la respuesta al enterramiento incluye aspectos médicos. [Resumen institucional](#fuente-e5-wms-resumen-avalancha). Vía aérea, respiración, lesiones e hipotermia requieren formación actualizada. Esta lección no entrega umbrales para decidir no reanimar ni permite inferir pronóstico desde profundidad, tiempo supuesto o temperatura ambiental. Las recomendaciones clínicas se estudian con instructores sanitarios y protocolos aplicables. [Referencia clínica](#fuente-e5-wms-enterramiento).

Ocho escenarios de mesa permiten reconocer cómo cambia el problema. **Una víctima:** coordinar localización y continuidad sin anunciar éxito al primer contacto. **Múltiples víctimas:** mantener recuentos y capacidad disponible, sin triaje basado en iconos. **Víctima superficial:** una parte visible no excluye trauma ni atrapamiento. **Víctima profunda:** la carga de trabajo y acceso adquieren relevancia; la profundidad no determina por sí sola el desenlace. **Segunda avalancha posible:** revisar exposición y alternativas antes de añadir personas. **Rescatista lesionado:** cambian recursos y número de personas que requieren ayuda. **Pérdida de señal:** conservar hipótesis y registro, sin eliminar desaparecidos. **Baja visibilidad:** la orientación y los límites del área conocida se vuelven parte central del análisis.

Cada escenario se resuelve con el mismo formato editorial, no con una respuesta universal: hechos atribuidos, datos faltantes, amenazas, personas disponibles, acciones dentro de la formación y petición de apoyo. Si falta información, debe decirse qué decisión impide tomar. «No sé si hay amenaza por encima» es diferente de «no vi ninguna». Esa diferencia importa al coordinar una intervención porque distingue ausencia de observación de evidencia de ausencia.

El mensaje externo debe describir localización verificable, situación, número conocido de personas, amenazas, acciones realizadas y necesidades. El medio y oportunidad dependen de recursos y escena; no se inventan tiempos de llegada ni cobertura. El plan debe considerar también a quienes no fueron afectados: mantener un grupo informado y protegido puede limitar el personal disponible para otras tareas. La VHF o comunicación satelital necesita procedimientos propios y gestión de interferencia respecto de búsqueda.

En el debriefing, reconstruye cambios de decisión en orden: qué dato apareció, quién lo comunicó y cómo cambió la acción. No evalúes solo si el escenario terminó bien. Una decisión puede haber sido mal fundada aunque el ejercicio resulte exitoso; reconocerlo evita normalizar errores. La evidencia de aprendizaje es un razonamiento explícito y una práctica supervisada con objetivos inertes. Los registros de la academia no deben guardar historias clínicas ni información privada de víctimas. Las competencias presenciales se observan y validan en un contexto definido por personas competentes, nunca por completar esta página.

## Qué observo, qué significa y qué no puedo concluir

Sin formación clínica no se extrapolan algoritmos; sin recursos no se presume capacidad de rescate organizado.

## Caso práctico y aplicación al guiado

Escenario ficticio: dos desaparecidos, una señal, visibilidad decreciente y un compañero lesionado. Construye un parte sin inventar diagnóstico ni resultado.

## Errores frecuentes y señales de alerta

Olvidar segunda amenaza; contar señales como personas; abandonar al grupo no afectado; suponer extracción igual a atención completa.

## Autoevaluación y respuesta razonada

Selecciona dos de los ocho escenarios y compara amenazas, recursos, datos faltantes, opciones, petición de apoyo y debriefing.

## Ejercicios y práctica supervisada

Simulación presencial coordinada con instructor de rescate y primeros auxilios, objetivos inertes, funciones y pausa de seguridad definidas.

## Evidencia requerida

- Reconoce los ocho escenarios y sus cambios de recursos.
- Distingue evaluación de escena y evaluación clínica.
- Comunica hechos e incertidumbres sin inventar pronóstico o capacidad.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-rescate-avalancha).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
