---
{
  "title": "Esquí y escalada: prácticas e instituciones distintas",
  "description": "Separa origen de una práctica y constitución institucional.",
  "module": "M17",
  "code": "E13-05",
  "order": 1305,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U13-05",
  "skills": [
    "s13-historia-esqui-escalada"
  ],
  "critical": false,
  "reviewDate": "2026-10-27",
  "objectives": [
    "Separa origen de una práctica y constitución institucional.",
    "Identifica qué documentan las fechas de 1924, 2007 y 2008."
  ],
  "prerequisites": [
    "s13-historia-equipo"
  ],
  "sources": [
    "e13-fis",
    "e13-uiaa"
  ],
  "pending": [
    "Revisión por historiador o especialista de patrimonio e instructor de montaña pendiente.",
    "Primeras ascensiones de Los Lagos, historia completa de escuelas técnicas y testimonios comunitarios requieren investigación y revisión adicionales.",
    "Casos y rúbricas son propuestas pedagógicas originales; no certifican guiado ni competencia práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "La fecha de fundación FIS señala…",
        "options": [
          "El primer uso humano de esquís.",
          "El origen de toda actividad invernal.",
          "Un cambio de organización internacional."
        ],
        "answer": 2,
        "explanation": "Es el alcance del congreso documentado.",
        "rationales": [
          "No trata de los primeros esquís.",
          "La actividad precede a la federación.",
          "Es el alcance del congreso documentado."
        ],
        "source": "e13-fis",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "IFSC en 2007 implica que…",
        "options": [
          "La escalada no existía antes.",
          "Se constituyó una organización independiente de competición.",
          "Todo escalador quedó certificado."
        ],
        "answer": 1,
        "explanation": "Coincide con el hito descrito.",
        "rationales": [
          "Confunde organización y práctica.",
          "Coincide con el hito descrito.",
          "Una fundación no certifica individuos."
        ],
        "source": "e13-uiaa",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un recorrido competitivo equivale a una salida autónoma…",
        "options": [
          "No: cambian objetivos, apoyo y contexto.",
          "Siempre, si comparten esquís.",
          "Sí, por tener una fecha oficial."
        ],
        "answer": 0,
        "explanation": "La comparación requiere distinguir escenarios.",
        "rationales": [
          "La comparación requiere distinguir escenarios.",
          "El equipo común no iguala condiciones.",
          "Una fecha no define el apoyo ni el terreno."
        ],
        "source": "e13-fis",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Separa origen de una práctica y constitución institucional.",
    "Identifica qué documentan las fechas de 1924, 2007 y 2008.",
    "Evita trasladar reglas de competición a autonomía en montaña."
  ],
  "openAssessment": {
    "prompt": "Escribe tres pares de afirmaciones: fecha organizativa válida y conclusión sobre el origen que esa fecha no permite.",
    "rubric": [
      "Separa origen de una práctica y constitución institucional.",
      "Identifica qué documentan las fechas de 1924, 2007 y 2008.",
      "Evita trasladar reglas de competición a autonomía en montaña."
    ],
    "source": "e13-fis",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ACADÉMICA PENDIENTE.** Historia documental e interpretación: no es formación para ejecutar maniobras. No guardes datos médicos, contraseñas, datos privados de terceros ni conocimientos de acceso restringido.

## Conceptos clave y propósito

Práctica, competición, federación, institucionalización y disciplina. Una fecha de fundación no es la fecha de invención de una actividad.

## Teoría y toma de decisiones

FIS documenta su constitución en Chamonix el 2 de febrero de 1924, durante el octavo Congreso Internacional de Esquí. La existencia de una comisión anterior y de ese número de congreso ya indica un proceso organizativo previo. Por tanto, 1924 sirve para fechar la federación, no el origen del desplazamiento con esquís.

La historia de UIAA describe la separación de la escalada de competición que condujo a IFSC en 2007 y la creación de ISMF en 2008 a partir de su estructura de competición de esquí de montaña. Son hitos de organización deportiva, no pruebas de que escalada y esquí de montaña nacieran en esos años. Tampoco las reglas de una competición pueden trasladarse sin más a una salida autónoma.

Para tu formación distingue el objetivo de cada escenario: resultado deportivo bajo reglas, aprendizaje técnico, desplazamiento o travesía. La historia ayuda a reconocer cómo se separan las instituciones; el análisis de una salida necesita además terreno, nieve, capacidades y decisiones actuales. La historia detallada del esquí chileno, los refugios regionales y las escuelas de escalada queda abierta a otro conjunto de documentos; no se completa con una cronología extranjera.

Fuentes de esta unidad: [Referencia 1](#fuente-e13-fis) · [Referencia 2](#fuente-e13-uiaa). Los ejercicios y criterios siguientes son diseño educativo original, no protocolos de las organizaciones citadas.

## Procedimiento: lectura, comprobaciones y variantes

**PROCEDIMIENTO — análisis documental:** Dibuja dos líneas: prácticas y organismos. Coloca únicamente fechas verificadas en organismos y deja en blanco los orígenes no investigados. Variante: añadir publicaciones de clubes sin suponer que sus reglas eran universales.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una presentación dice que el esquí comenzó en 1924 y la escalada en 2007. Corrige la confusión usando la clase de evento que documenta cada fuente.

## Errores frecuentes y puntos críticos de seguridad

Confundir deporte con federación; aplicar reglas de pista al terreno no controlado; tomar un calendario competitivo como itinerario de aprendizaje.

Las maniobras críticas requieren formación práctica y supervisión de instructor competente. Estudiar cómo se actuaba antiguamente no habilita a reproducirlo. Este taller no requiere exposición en terreno.

## Material y equipo relacionado

Cronología y fichas. Esquís, fijaciones y pieles pueden identificarse en imágenes; aquí no se realiza progresión ni ajuste técnico.

[Inventario educativo](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con una evidencia y un límite: Separa origen de una práctica y constitución institucional.
- Explica con una evidencia y un límite: Identifica qué documentan las fechas de 1924, 2007 y 2008.
- Explica con una evidencia y un límite: Evita trasladar reglas de competición a autonomía en montaña.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Escribe tres pares de afirmaciones: fecha organizativa válida y conclusión sobre el origen que esa fecha no permite.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Discusión con docente e instructor de esquí o escalada sobre diferencias de contexto; no incluye una salida ni habilita terreno invernal.

## Evidencia requerida y criterios de competencia

- Separa origen de una práctica y constitución institucional.
- Identifica qué documentan las fechas de 1924, 2007 y 2008.
- Evita trasladar reglas de competición a autonomía en montaña.

**COMPETENCIA:** se requiere revisión humana contextual del trabajo. Una lectura, quiz o guion no certifica guiado, interpretación profesional ni maniobras técnicas. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s13-historia-esqui-escalada). Registra fecha, lugar de estudio, documentos, habilidad, repeticiones, errores, correcciones, supervisor y evidencia textual no sensible. Diferencia taller ficticio y actividad real; no inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Historia y patrimonio](../../historia/) · [Territorio](../../territorio/) · [Geología](../../geologia/) · [Ecología](../../ecologia/) · [Programa](../../programa/). La interpretación histórica complementa la formación técnica; no sustituye condiciones ni permisos actuales.
