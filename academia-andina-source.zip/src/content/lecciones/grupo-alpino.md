---
{
  "title": "Gestión del grupo: roles, comunicación y capacidad real",
  "description": "Asignar funciones según capacidades observadas, no por posesión de equipo.",
  "module": "M06",
  "code": "E8-05",
  "order": 805,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U8-05",
  "skills": [
    "s8-grupo-alpino"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Asignar funciones según capacidades observadas, no por posesión de equipo.",
    "Comprobar comprensión y conservar opciones ante pérdida de capacidad."
  ],
  "prerequisites": [
    "s8-cuerda-alpina"
  ],
  "sources": [
    "e8-decision",
    "e8-plan"
  ],
  "pending": [
    "Revisión docente y práctica presencial por instructor alpino competente pendientes. No se ha observado ni aprobado una maniobra.",
    "Compatibilidad y manual del equipo personal pendientes de verificación; no se extrapolan ejemplos GRIGRI/REVERSO/RAD LINE a ATC Guide u otras cuerdas."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Nadie pregunta durante el briefing. Eso…",
        "options": [
          "Demuestra comprensión técnica.",
          "No basta para confirmar que todos comprendieron.",
          "Permite omitir práctica."
        ],
        "answer": 1,
        "explanation": "Pedir explicación ayuda a detectar diferencias. Asignar funciones según capacidades observadas, no por posesión de equipo.",
        "rationales": [
          "El silencio admite varias interpretaciones.",
          "Pedir explicación ayuda a detectar diferencias.",
          "Comprender y ejecutar son evidencias distintas."
        ],
        "source": "e8-decision",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Todo el material crítico lo lleva el experto. ¿Qué revisar?",
        "options": [
          "Solo el peso total.",
          "Solo la marca.",
          "Qué capacidad y recursos quedan si no puede actuar."
        ],
        "answer": 2,
        "explanation": "El plan debe considerar pérdida de capacidad. Asignar funciones según capacidades observadas, no por posesión de equipo.",
        "rationales": [
          "El peso no resuelve disponibilidad funcional.",
          "La marca no elimina la dependencia.",
          "El plan debe considerar pérdida de capacidad."
        ],
        "source": "e8-decision",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un aviso no se entiende. Se debe…",
        "options": [
          "Reconocer la incertidumbre y recuperar comunicación según lo acordado.",
          "Interpretar silencio como autorización.",
          "Actuar rápido para no retrasar."
        ],
        "answer": 0,
        "explanation": "No inventa un mensaje recibido. Asignar funciones según capacidades observadas, no por posesión de equipo.",
        "rationales": [
          "No inventa un mensaje recibido.",
          "El silencio no confirma una tarea.",
          "La prisa no aclara el aviso."
        ],
        "source": "e8-decision",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Comprueba comprensión con explicación del participante.",
    "Reconoce dependencia de una persona o recurso y sus consecuencias.",
    "Responde a incertidumbre de comunicación con revisión, no con suposición."
  ],
  "openAssessment": {
    "prompt": "Escribe un briefing de un minuto: objetivo, roles, límites, aviso de dificultad y retirada. Luego añade una respuesta de un participante que revele una interpretación diferente y cómo la aclararías.",
    "rubric": [
      "Comprueba comprensión con explicación del participante.",
      "Reconoce dependencia de una persona o recurso y sus consecuencias.",
      "Responde a incertidumbre de comunicación con revisión, no con suposición."
    ],
    "source": "e8-decision",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. Lecturas y cuestionarios no acreditan ejecución técnica ni guiado.**

## Conceptos clave y propósito

Briefing, comunicación confirmada, roles, fatiga, distribución de recursos y presión de grupo.

## Teoría y toma de decisiones

La organización de un grupo alpino incluye quién comprende cada tarea, quién puede ejecutarla y cómo se reconocerá una dificultad. Un reparto de roles que solo enumera nombres no resuelve esas preguntas. La experiencia declarada debe situarse en un contexto: alguien puede conocer senderismo y no haber realizado una transición técnica supervisada. [Fuente de contraste](#fuente-e8-decision).

Las comunicaciones técnicas se acuerdan y se confirman. Ruido, distancia, viento o falta de visión pueden hacer que un aviso no llegue. Un mensaje no recibido no debe interpretarse como autorización por silencio. Antes de una tarea el grupo debe saber cómo reconocer esa incertidumbre y qué condición obliga a detener y recuperar comunicación.

Pedir a un participante que explique su tarea ayuda a descubrir diferencias de comprensión. La técnica pedagógica no demuestra ejecución: se necesita también observar la práctica correspondiente. Un briefing eficaz deja espacio a dudas y límites sin convertirlos en un juicio personal.

La distribución de material se revisa por función y disponibilidad en un incidente. Si toda la capacidad técnica y todo el material crítico dependen de una sola persona, el plan tiene una dependencia que debe reconocerse. No se corrige simplemente dando más peso a otra persona; hay que comprobar capacidad de uso y acceso al recurso.

Una pérdida de precisión, una dificultad de comunicación o un cambio en la participación pueden alterar la viabilidad del plan. Se registran observaciones sin diagnosticar a la persona ni guardar datos médicos. Para Filo Austral, una práctica entre compañeros no demuestra preparación para asumir pasajeros; la responsabilidad de guiado necesita evaluación específica.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — análisis previo al taller.** Asignar funciones según capacidades observadas, no por posesión de equipo. Se utiliza al preparar una tarea o revisar un cambio de contexto. Las comprobaciones se organizan por función, soporte, equipo, capacidades y continuidad de protección. La teoría y la rúbrica especifican qué observar en esta unidad.

El instructor selecciona método, protección y condiciones de parada. Si falta una condición esencial o el grupo no comprende una función, no se inicia la maniobra. Las variantes se mantienen dentro del contexto de su fuente: una página sobre vía equipada, un producto o senderismo no constituye un procedimiento universal alpino.

## Caso práctico y aplicación al guiado

**Escenario de aula:** Escenario ficticio: una persona evita preguntar, otra lleva casi todo el material y el grupo usa señales no acordadas. Antes de salir del punto de reunión, redacta un briefing que haga visibles esas dependencias sin etiquetar a nadie como incapaz.

Distingue hechos, suposiciones y preguntas antes de proponer una decisión. Los ejercicios, casos y rúbricas son propuestas pedagógicas originales de la academia pendientes de revisión docente. No se presentan como protocolos de los organismos citados.

## Errores frecuentes y puntos críticos de seguridad

Confundir silencio con comprensión; asignar roles por equipo propio; centralizar toda capacidad; interpretar un aviso dudoso a conveniencia; registrar datos privados innecesarios.

Una práctica protegida tiene un alcance limitado; no valida todas las condiciones futuras. No se aprende una técnica crítica mediante una caída deliberada ni copiando una imagen en terreno expuesto.

## Material y equipo relacionado

Comunicaciones previstas y respaldo, recursos distribuidos según función, mapa compartido y equipo técnico compatible. VHF e InReach requieren capacidades y condiciones de uso verificadas.

[Consultar inventario](../../equipo/). Identifica modelo, documentación y datos pendientes. No inventes inspecciones ni atribuyas competencia a la compra de un dispositivo.

## Autoevaluación y recuperación activa

- Explica con un ejemplo: Asignar funciones según capacidades observadas, no por posesión de equipo.
- ¿Qué información falta en el caso y qué decisión depende de ella?
- ¿Qué parte puedes revisar documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Escribe un briefing de un minuto: objetivo, roles, límites, aviso de dificultad y retirada. Luego añade una respuesta de un participante que revele una interpretación diferente y cómo la aclararías.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Simulación de mesa con instructor y roles rotativos. Se introducen mensajes incompletos y ausencia ficticia de un recurso. Se observa cómo se confirma comprensión y revisa el plan, sin práctica expuesta.

## Evidencia requerida y criterios de competencia

- Comprueba comprensión con explicación del participante.
- Reconoce dependencia de una persona o recurso y sus consecuencias.
- Responde a incertidumbre de comunicación con revisión, no con suposición.

**COMPETENCIA:** la ejecución debe evaluarse presencialmente en un contexto explícito por instructor competente. Las respuestas escritas no sustituyen esa observación. Se registra qué ocurrió, qué no se evaluó y qué debe corregirse. No hay un número de repeticiones que otorgue competencia automáticamente.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s8-grupo-alpino). Registra solo lo realizado: fecha, lugar, actividad, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Confianza, resultado y evaluación son datos diferentes. No guardar datos médicos, contraseñas ni datos privados de terceros.

## Relaciones con otros módulos

Integra [hielo](../../hielo/), [glaciar](../../glaciar/), [planificación invernal](../planificacion-invernal/) y [anclajes y reuniones](../anclajes-reuniones/). El [programa](../../programa/) muestra prerrequisitos; son académicos, no habilitaciones. [Volver al bloque alpino](../../alpina/).
