---
{
  "title": "Autorescate alpino: estabilizar, comunicar y reconocer límites",
  "description": "Diferenciar problema técnico, situación de la persona y exposición del grupo.",
  "module": "M06",
  "code": "E8-07",
  "order": 807,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U8-07",
  "skills": [
    "s8-autorescate-alpino"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Diferenciar problema técnico, situación de la persona y exposición del grupo.",
    "Elegir prioridades conceptuales sin improvisar maniobras no entrenadas."
  ],
  "prerequisites": [
    "s8-progresion-alpina"
  ],
  "sources": [
    "e8-rescue",
    "e8-single"
  ],
  "pending": [
    "Revisión docente y práctica presencial por instructor alpino competente pendientes. No se ha observado ni aprobado una maniobra.",
    "Compatibilidad y manual del equipo personal pendientes de verificación; no se extrapolan ejemplos GRIGRI/REVERSO/RAD LINE a ATC Guide u otras cuerdas."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "La caída se detuvo. Esto significa…",
        "options": [
          "Que terminó el rescate.",
          "Que el sistema puede desconectarse.",
          "Que se resolvió un objetivo inicial y hay otros que evaluar."
        ],
        "answer": 2,
        "explanation": "Detención no equivale a recuperación. Diferenciar problema técnico, situación de la persona y exposición del grupo.",
        "rationales": [
          "Persisten tareas y amenazas posibles.",
          "No existe esa autorización automática.",
          "Detención no equivale a recuperación."
        ],
        "source": "e8-rescue",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una persona consciente…",
        "options": [
          "Puede no tener capacidad para ejecutar la maniobra propuesta.",
          "Siempre puede autorrescatarse.",
          "No requiere comunicación posterior."
        ],
        "answer": 0,
        "explanation": "La colaboración necesita valoración contextual. Diferenciar problema técnico, situación de la persona y exposición del grupo.",
        "rationales": [
          "La colaboración necesita valoración contextual.",
          "Conciencia no prueba movilidad ni técnica.",
          "La información puede cambiar."
        ],
        "source": "e8-rescue",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Tener comunicación satelital…",
        "options": [
          "Garantiza rescate inmediato.",
          "Es un recurso cuya disponibilidad y respuesta tienen límites.",
          "Permite omitir ubicación."
        ],
        "answer": 1,
        "explanation": "Comunicación y rescate son funciones distintas. Diferenciar problema técnico, situación de la persona y exposición del grupo.",
        "rationales": [
          "No se garantiza plazo ni recursos.",
          "Comunicación y rescate son funciones distintas.",
          "Una ubicación interpretable sigue siendo necesaria."
        ],
        "source": "e8-rescue",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue estabilización y recuperación sin saltar funciones.",
    "Reconoce límites de colaboración y del grupo sin diagnóstico inventado.",
    "Comunica ubicación, amenazas y necesidades dentro de su formación."
  ],
  "openAssessment": {
    "prompt": "Redacta una ficha de incidente ficticio con amenazas, función de protección actual, información faltante, capacidades y mensaje. No incluyas nombres, historias clínicas ni una secuencia improvisada de montaje.",
    "rubric": [
      "Distingue estabilización y recuperación sin saltar funciones.",
      "Reconoce límites de colaboración y del grupo sin diagnóstico inventado.",
      "Comunica ubicación, amenazas y necesidades dentro de su formación."
    ],
    "source": "e8-rescue",
    "difficulty": "integración"
  },
  "diagrams": [
    "e8-funciones"
  ]
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. Lecturas y cuestionarios no acreditan ejecución técnica ni guiado.**

## Conceptos clave y propósito

Seguridad de escena, estabilización, comunicación, capacidad funcional, recursos y límites de intervención.

## Teoría y toma de decisiones

Un incidente técnico no se reduce a una polea o un nudo. Hay una persona, un sistema, un terreno y un grupo con capacidades limitadas. Antes de elegir una maniobra se necesita reconocer qué amenaza sigue activa, qué función mantiene el control y qué información falta sobre la situación.

La estabilización y la recuperación son objetivos diferentes. Que la caída se haya detenido no significa que se pueda modificar el sistema sin consecuencias. Las técnicas de asistencia descritas por fabricantes pertenecen a configuraciones concretas y exigen formación. No se reúnen pasos de varios artículos como si fueran un procedimiento universal. [Fuente de contraste](#fuente-e8-rescue).

La capacidad de colaboración cambia las opciones. Una persona consciente puede no ser capaz de ejecutar lo que se le pide; no se presume movilidad ni habilidad por mantener conversación. Esta unidad no diagnostica ni prescribe atención clínica: la valoración y primeros auxilios deben mantenerse dentro de formación reconocida y apoyo especializado.

Pedir ayuda requiere comunicar información útil y reconocer incertidumbre: ubicación con referencia y sistema de coordenadas conocido, naturaleza del incidente, personas afectadas sin datos privados innecesarios, amenazas y recursos disponibles. El dispositivo satelital no garantiza tiempo de respuesta ni sustituye energía, recepción y un plan de comunicación.

En la preparación se analiza qué ocurre si quien sabe realizar la maniobra no puede actuar, si falta material o si el retorno previsto deja de ser posible. Los sistemas de izado y descenso requieren su propio entrenamiento y compatibilidad. El objetivo del ejercicio de mesa es identificar límites antes de que la presión favorezca una maniobra improvisada.

El ejemplo Petzl de segundo bloqueado usa REVERSO 4 y MICRO TRAXION. Tener ATC Guide no permite copiarlo: el aparato, el estado de carga y la cuerda disponible forman parte del contexto. Esta unidad no adapta ese montaje; lo utiliza para identificar dependencias y preguntas que resolver con instructor. [Ejemplo y límites](#fuente-e8-rescue).

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — análisis previo al taller.** Diferenciar problema técnico, situación de la persona y exposición del grupo. Se utiliza al preparar una tarea o revisar un cambio de contexto. Las comprobaciones se organizan por función, soporte, equipo, capacidades y continuidad de protección. La teoría y la rúbrica especifican qué observar en esta unidad.

El instructor selecciona método, protección y condiciones de parada. Si falta una condición esencial o el grupo no comprende una función, no se inicia la maniobra. Las variantes se mantienen dentro del contexto de su fuente: una página sobre vía equipada, un producto o senderismo no constituye un procedimiento universal alpino.

## Caso práctico y aplicación al guiado

**Escenario de aula:** Escenario ficticio: un segundo no puede continuar, existe comunicación y el grupo no ha practicado asistencia con el dispositivo disponible. Se desconoce si puede colaborar físicamente. Separa hechos, preguntas y funciones que no deben perderse; redacta un mensaje de solicitud de apoyo.

Distingue hechos, suposiciones y preguntas antes de proponer una decisión. Los ejercicios, casos y rúbricas son propuestas pedagógicas originales de la academia pendientes de revisión docente. No se presentan como protocolos de los organismos citados.

## Errores frecuentes y puntos críticos de seguridad

Elegir material antes de definir el problema; confundir conciencia y capacidad; alterar un sistema sin comprender qué protege; prometer rescate por tener señal; guardar datos médicos en el diario.

Una práctica protegida tiene un alcance limitado; no valida todas las condiciones futuras. No se aprende una técnica crítica mediante una caída deliberada ni copiando una imagen en terreno expuesto.

## Material y equipo relacionado

Equipo de rescate del método entrenado, cuerda, conectores y dispositivos compatibles; comunicaciones y energía; documentación de ubicación. ATC Guide y Micro Traxion no otorgan capacidad de rescate al portador.

[Consultar inventario](../../equipo/). Identifica modelo, documentación y datos pendientes. No inventes inspecciones ni atribuyas competencia a la compra de un dispositivo.

## Autoevaluación y recuperación activa

- Explica con un ejemplo: Diferenciar problema técnico, situación de la persona y exposición del grupo.
- ¿Qué información falta en el caso y qué decisión depende de ella?
- ¿Qué parte puedes revisar documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Redacta una ficha de incidente ficticio con amenazas, función de protección actual, información faltante, capacidades y mensaje. No incluyas nombres, historias clínicas ni una secuencia improvisada de montaje.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Simulación de mesa y taller protegido dirigido por instructor competente. Las maniobras de asistencia se practican con protección y evaluación explícitas; el instructor sanitario revisa cualquier componente de primeros auxilios.

## Evidencia requerida y criterios de competencia

- Distingue estabilización y recuperación sin saltar funciones.
- Reconoce límites de colaboración y del grupo sin diagnóstico inventado.
- Comunica ubicación, amenazas y necesidades dentro de su formación.

**COMPETENCIA:** la ejecución debe evaluarse presencialmente en un contexto explícito por instructor competente. Las respuestas escritas no sustituyen esa observación. Se registra qué ocurrió, qué no se evaluó y qué debe corregirse. No hay un número de repeticiones que otorgue competencia automáticamente.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s8-autorescate-alpino). Registra solo lo realizado: fecha, lugar, actividad, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Confianza, resultado y evaluación son datos diferentes. No guardar datos médicos, contraseñas ni datos privados de terceros.

## Relaciones con otros módulos

Integra [hielo](../../hielo/), [glaciar](../../glaciar/), [planificación invernal](../planificacion-invernal/) y [anclajes y reuniones](../anclajes-reuniones/). El [programa](../../programa/) muestra prerrequisitos; son académicos, no habilitaciones. [Volver al bloque alpino](../../alpina/).
