---
{
  "title": "Poleas, captura de progreso y Micro Traxion",
  "description": "Distinguir polea fija, móvil y bloqueadora por su función.",
  "module": "M07",
  "code": "E44-20",
  "order": 319,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U44-02",
  "skills": [
    "s44-poleas-bloqueadores"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir polea fija, móvil y bloqueadora por su función.",
    "Explicar captura de progreso y sus límites.",
    "Identificar la documentación de Micro Traxion que debe consultarse para una aplicación concreta."
  ],
  "prerequisites": [
    "s44-ventaja-mecanica"
  ],
  "sources": [
    "petzl-micro",
    "petzl-ma"
  ],
  "pending": [
    "Revisión pedagógica y práctica por instructor competente."
  ],
  "diagrams": [
    "polea-funciones"
  ],
  "preparation": [
    "Explicar los conceptos sin confundir un modelo con una maniobra.",
    "Reconocer al menos dos errores del caso y justificar una alternativa.",
    "Identificar la documentación y las competencias prácticas que faltan."
  ],
  "openAssessment": {
    "prompt": "Resuelve el caso de la lección: distingue hechos, incertidumbres, errores, alternativas y decisión justificada.",
    "rubric": [
      "Atribuye los datos y reconoce qué no se puede comprobar.",
      "Explica al menos un error y sus consecuencias sin inventar condiciones.",
      "Justifica una alternativa, su límite y qué requiere revisión presencial."
    ],
    "source": "petzl-micro",
    "difficulty": "integración"
  },
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una cuerda pasa por un dispositivo. ¿Demuestra compatibilidad?",
        "options": [
          "Sí.",
          "No: hay que comprobar el manual y la función.",
          "Solo si es nueva."
        ],
        "answer": 1,
        "explanation": "Compatibilidad incluye requisitos del modelo y uso.",
        "rationales": [
          "El paso físico no prueba desempeño permitido.",
          "Compatibilidad incluye requisitos del modelo y uso.",
          "Ser nueva no sustituye la documentación."
        ],
        "source": "petzl-micro",
        "kind": "aplicación",
        "difficulty": "intermedia"
      },
      {
        "prompt": "La captura de progreso…",
        "options": [
          "Resuelve cualquier transición a descenso.",
          "Convierte el equipo en asegurador universal.",
          "Retiene avance en una configuración definida; no valida otras funciones."
        ],
        "answer": 2,
        "explanation": "La función tiene límites específicos.",
        "rationales": [
          "La liberación debe analizarse por separado.",
          "No todos los bloqueadores tienen ese uso.",
          "La función tiene límites específicos."
        ],
        "source": "petzl-micro",
        "kind": "aplicación",
        "difficulty": "intermedia"
      }
    ]
  }
}
---
**CONTENIDO TEÓRICO — REQUIERE FORMACIÓN PRESENCIAL.** Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica.

## Conceptos clave y vocabulario

Polea fija y móvil describen su relación con el movimiento del sistema, no marcas distintas. Polea bloqueadora combina guiado de cuerda y captura de progreso en condiciones definidas. Un bloqueador permite una función de retención según su diseño; no es automáticamente un dispositivo de aseguramiento dinámico.

## Teoría y decisiones

Capturar progreso significa conservar el desplazamiento conseguido entre fases de tracción. Esa función no elimina la necesidad de controlar la carga ni resuelve cómo descender o liberar el sistema después. Un mecanismo puede estar instalado pero no activo en el modo esperado: identificación, configuración y prueba funcional pertenecen a la formación del modelo.

Micro Traxion se estudia como ejemplo específico de polea bloqueadora Petzl. Su documentación identifica usos, compatibilidades y configuraciones que deben contrastarse con el ejemplar; no se extrapolan a otro bloqueador ni a cualquier cuerda [Referencia: petzl-micro](#fuente-petzl-micro). Si una ficha comercial y un manual de otra revisión muestran rangos distintos, registra la discrepancia y consigue el documento correspondiente al producto antes del uso. La academia no resuelve esa discrepancia eligiendo el rango más amplio.

Al analizar un esquema, identifica dónde está la carga, qué componente cambia dirección, cuál retiene y qué ocurre si el operador deja de traccionar. Después pregunta si existe una transición prevista hacia descenso y quién puede dirigirla. El dispositivo que reduce esfuerzo no necesariamente permite efectuar esa transición de manera controlada.

Fricción depende de los elementos y su estado: una redirección sobre una superficie no equivale a una polea ideal. La eficiencia comercial de un componente no es la eficiencia completa de un rescate; incluye condiciones de ensayo y omite otras pérdidas. No debe usarse para prometer capacidad de izado de un pasajero.

En el inventario vincula marca, modelo, número identificable, manual y revisión, inspecciones y usos. Registra daño o incertidumbre sin convertir la ausencia de anotaciones en garantía de aptitud. La selección del sistema exige además formación de quienes lo operarán.

## Caso práctico y aplicación al guiado

Filo Austral incorpora una Micro Traxion. Un compañero propone sustituir con ella cualquier aparato de frenado y usar cualquier cuerda que entre. Construye una tabla función/documento/compatibilidad/límite; señala qué afirmaciones no están respaldadas y por qué no corresponde hacer una demostración con una persona suspendida.

## Errores frecuentes y señales de alerta

Confundir captura con aseguramiento; dar por activo el mecanismo; omitir dirección; mezclar fichas de generaciones; asumir que si la cuerda pasa, es compatible; no prever cómo cesar o invertir el movimiento.

## Autoevaluación y respuestas explicadas

¿Captura de progreso implica descenso controlado? **No: son funciones distintas.** ¿Dos poleas bloqueadoras son equivalentes? **No: hay que comparar documentación, modo y límites.**

## Ejercicios y práctica presencial

Ficha comparativa de una polea simple, Micro Traxion y un dispositivo tubular, sin atribuir funciones no documentadas. En presencial, instructor demuestra identificación de modo y revisión funcional sobre montaje didáctico autorizado.

## Evidencia requerida

Ficha del ejemplar, fuente/versiones, discrepancias resueltas y observación supervisada. La evaluación de selección no equivale a competencia para rescatar.

## Relaciones con otras habilidades

Revisa los prerrequisitos y el contrato de habilidad de esta unidad en el programa. Contrasta la explicación con las fuentes indicadas: las cifras de un ejercicio no son límites de uso de un equipo. Toda transferencia a una situación con personas requiere formación y revisión presencial.
