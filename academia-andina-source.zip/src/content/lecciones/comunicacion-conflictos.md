---
{
  "title": "Comunicación, escucha y desacuerdos",
  "description": "Separa observación de interpretación.",
  "module": "M19",
  "code": "E16-04",
  "order": 1604,
  "minutes": 30,
  "level": "Intermedio",
  "status": "development",
  "unit": "U16-04",
  "skills": [
    "s16-comunicacion-conflictos"
  ],
  "critical": false,
  "reviewDate": "2026-10-28",
  "objectives": [
    "Separa observación de interpretación.",
    "Escucha y reformula sin atribuir intenciones."
  ],
  "prerequisites": [
    "s16-ensenanza-progresiva"
  ],
  "sources": [
    "e16-nols"
  ],
  "pending": [
    "Revisión por docente e instructor competente pendiente.",
    "Casos y rúbricas originales; no certifican guiado ni sustituyen formación técnica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿Qué frase facilita revisar una conducta?",
        "options": [
          "Eres irresponsable.",
          "En esta ronda cambió el acuerdo sin avisar; revisémoslo.",
          "Siempre haces todo mal."
        ],
        "answer": 1,
        "explanation": "Identifica un episodio revisable.",
        "rationales": [
          "Etiqueta a la persona.",
          "Identifica un episodio revisable.",
          "Generaliza sin evidencia."
        ],
        "source": "e16-nols",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Ante una discrepancia de significado, primero…",
        "options": [
          "Pedir aclaración y reformular.",
          "Suponer mala intención.",
          "Hablar más fuerte."
        ],
        "answer": 0,
        "explanation": "Ayuda a localizar la diferencia.",
        "rationales": [
          "Ayuda a localizar la diferencia.",
          "Confunde interpretación con hecho.",
          "No verifica comprensión."
        ],
        "source": "e16-nols",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué evidencia corresponde al ejercicio propuesto en esta unidad?",
        "options": [
          "Un registro de la tarea, errores y correcciones observados.",
          "Una declaración automática de competencia por leer.",
          "Una valoración del carácter de la persona."
        ],
        "answer": 0,
        "explanation": "La rúbrica pide observaciones de una tarea concreta; su evaluación sigue siendo humana.",
        "rationales": [
          "Es evidencia contextual del taller.",
          "Leer no demuestra ejecución.",
          "Se evalúan actuaciones, no etiquetas personales."
        ],
        "source": "e16-nols",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Separa observación de interpretación.",
    "Escucha y reformula sin atribuir intenciones.",
    "Propone una petición verificable."
  ],
  "openAssessment": {
    "prompt": "Escribe una observación, una pregunta de aclaración y una petición. Ensáyalas con roles ficticios y recoge una corrección del observador.",
    "rubric": [
      "Separa observación de interpretación.",
      "Escucha y reformula sin atribuir intenciones.",
      "Propone una petición verificable."
    ],
    "source": "e16-nols",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**BLOQUE EN DESARROLLO · REVISIÓN DOCENTE E INSTRUCTORA PENDIENTE.** Talleres de mesa con personajes ficticios, sin exposición en terreno ni datos personales.

## Conceptos clave y propósito

La comunicación útil distingue una observación concreta, su efecto y una petición. En el taller se revisan conductas, no etiquetas personales.

## Teoría y alcance de la fuente

NOLS describe Expedition Behavior como acciones que sostienen el funcionamiento del grupo, con respeto, responsabilidad y resolución constructiva de conflictos. Se consulta su página institucional, no un programa de certificación.

[Fuente conceptual y límites](#fuente-e16-nols). El diseño de tareas, preguntas y criterios siguiente es una propuesta original de la academia; no se atribuye a la organización citada ni constituye un estándar de acreditación.

## Aplicación docente propuesta

Propuesta docente: frente a «nunca escuchas», ensaya «en las dos últimas intervenciones cambió la consigna antes de que terminara la pregunta; necesito terminarla y comprobar el acuerdo». La segunda formulación permite revisar un hecho y una acción sin presentar una intención ajena como certeza. Escuchar incluye pedir aclaración y resumir antes de responder.

En una simulación, asigna turnos y un observador para detectar interrupciones. No obligues a revelar experiencias personales para participar: usa personajes ficticios. Si el desacuerdo afecta una tarea crítica, no lo resuelvas como un simple concurso de argumentos; pausa el ejercicio y solicita al responsable competente que revise condiciones y límites. En una salida real prevalecen el plan y los procedimientos aplicables, fuera del alcance de este juego de roles.

## Caso práctico

**Escenario ficticio:** Dos participantes ficticios discuten porque uno cambia las tareas y el otro interpreta que su aporte no importa.

Explica qué observación necesitas antes de concluir y qué parte de tu respuesta es todavía una hipótesis.

## Errores frecuentes

Confundir confianza con evidencia, registrar como realizada una práctica solo preparada y trasladar el resultado de una simulación a terreno real. Revisa también si describiste un hecho o una interpretación.

## Material y equipo

Cuaderno, tarjetas con roles ficticios y una ficha territorial de la academia. No se requieren cuerdas, anclajes ni exposición al terreno para estos ejercicios.

## Autoevaluación

- Separa observación de interpretación.
- Escucha y reformula sin atribuir intenciones.
- Propone una petición verificable.

## Ejercicios y práctica supervisada

Escribe una observación, una pregunta de aclaración y una petición. Ensáyalas con roles ficticios y recoge una corrección del observador.

En un taller con docente o instructor, alterna participante, facilitador y observador. Define antes el criterio y recoge después una corrección. El instructor decide si corresponde otra práctica; no aumentes exposición para producir evidencia.

## Evidencia requerida

Conserva objetivo, tarea, observación, error, corrección y próxima práctica. La revisión humana debe indicar contexto y límites; no basta una etiqueta de «logrado». El quiz registra conocimiento teórico y no cambia competencias prácticas.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s16-comunicacion-conflictos). Solo registra el taller después de realizarlo. No inventes supervisor, evaluación ni repeticiones.

## Relaciones con otros módulos

[Pedagogía y liderazgo](../../liderazgo/) · [Fundamentos de grupo](../../lecciones/grupo-liderazgo/) · [Programa](../../programa/). Las maniobras y decisiones técnicas requieren sus propias competencias y supervisión.
