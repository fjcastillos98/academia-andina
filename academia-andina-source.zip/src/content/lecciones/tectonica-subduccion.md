---
{
  "title": "Tectónica y subducción: del movimiento de placas al magma",
  "description": "Explica fusión parcial y papel de fluidos sin reducirlos a roce.",
  "module": "M11",
  "code": "E12-01",
  "order": 1201,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U12-01",
  "skills": [
    "s12-tectonica-subduccion"
  ],
  "critical": false,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Explica fusión parcial y papel de fluidos sin reducirlos a roce.",
    "Distingue generación de magma, ascenso y erupción."
  ],
  "prerequisites": [
    "s45-vulcanologia-territorial"
  ],
  "sources": [
    "e12-subduction"
  ],
  "pending": [
    "Revisión por especialista en geología y vulcanología e instructor de montaña pendiente. No valida una ruta, acceso ni evacuación.",
    "Alertas actuales, restricciones, cotas discrepantes y condiciones de terreno requieren verificación independiente; no hay datos operativos en tiempo real.",
    "Casos, rúbricas y ejercicios originales. Las descripciones científicas no acreditan competencia técnica ni un protocolo universal de seguridad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "La explicación de subducción incluye…",
        "options": [
          "Fusión total inmediata de ambas placas.",
          "Fluidos que favorecen fusión parcial del manto suprayacente.",
          "Un océano superficial de lava."
        ],
        "answer": 1,
        "explanation": "Es el mecanismo simplificado de la fuente.",
        "rationales": [
          "No describe el modelo.",
          "Es el mecanismo simplificado de la fuente.",
          "Confunde interior y superficie."
        ],
        "source": "e12-subduction",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Todo magma generado…",
        "options": [
          "Erupciona necesariamente.",
          "Permite fechar una erupción.",
          "No necesariamente alcanza la superficie."
        ],
        "answer": 2,
        "explanation": "Separa generación y emisión.",
        "rationales": [
          "Puede permanecer y solidificarse en profundidad.",
          "Faltan datos y análisis específicos.",
          "Separa generación y emisión."
        ],
        "source": "e12-subduction",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una sección educativa…",
        "options": [
          "Necesita límites de escala y alcance.",
          "Es un corte medido de cualquier volcán.",
          "Determina una ruta segura."
        ],
        "answer": 0,
        "explanation": "Hace explícita la simplificación.",
        "rationales": [
          "Hace explícita la simplificación.",
          "No contiene esas mediciones.",
          "No evalúa exposición ni acceso."
        ],
        "source": "e12-subduction",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Explica fusión parcial y papel de fluidos sin reducirlos a roce.",
    "Distingue generación de magma, ascenso y erupción.",
    "Reconoce qué no puede concluirse de un modelo regional."
  ],
  "openAssessment": {
    "prompt": "Reconstruye el proceso en cinco frases y marca dos límites del esquema. Distingue una explicación causal de un pronóstico.",
    "rubric": [
      "Explica fusión parcial y papel de fluidos sin reducirlos a roce.",
      "Distingue generación de magma, ascenso y erupción.",
      "Reconoce qué no puede concluirse de un modelo regional."
    ],
    "source": "e12-subduction",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ESPECIALISTA PENDIENTE.** Estudio documental: no autoriza aproximación a fenómenos volcánicos ni acredita competencia de guía. No se publican alertas actuales. No guardes datos médicos ni contraseñas.

## Conceptos clave y propósito

Litosfera, placa, convergencia, subducción, manto, fusión parcial, ascenso y almacenamiento. Una explicación regional no es una imagen del sistema subterráneo de una cumbre concreta.

## Teoría y toma de decisiones

La litosfera está fragmentada en placas cuyo movimiento relativo puede producir convergencia. En una zona de subducción, una placa desciende bajo otra. El modelo educativo de USGS explica que los fluidos liberados por la placa descendente favorecen la fusión parcial del manto situado encima. No es correcto resumir la formación del magma como dos placas que se rozan hasta fundirse por completo.

Fusión parcial significa que solo una fracción del material se funde bajo determinadas condiciones. Parte del magma puede ascender y parte puede enfriarse en profundidad; no todo episodio magmático termina en erupción. Una flecha desde la placa hasta la cumbre simplifica varios procesos. El esquema debe declarar qué representa y qué omite: no revela dimensiones, tiempos ni geometrías locales.

Para estudiar Los Lagos, relaciona este modelo general con la ubicación del arco volcánico y luego consulta trabajos específicos del edificio. Un marco tectónico explica contexto, pero no fecha la siguiente erupción ni permite interpretar un sismo aislado. El aprendizaje se comprueba cuando puedes reconstruir la cadena causal y señalar qué dato adicional necesitaría una afirmación local.

Fuentes de esta unidad: [Referencia 1](#fuente-e12-subduction). Las aplicaciones de estudio y casos siguientes son elaboración pedagógica original, no protocolos de esas organizaciones.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — lectura y análisis documental:** Dibuja placa descendente, manto suprayacente y posible recorrido del magma; etiqueta el papel de los fluidos y la fusión parcial. Separa modelo general de observación local. Variante: comparar una sección educativa con un mapa regional; sus escalas y perspectivas son distintas.

El ejercicio se realiza en escritorio o lugar autorizado. No expongas al grupo para comprobar actividad, gases, temperatura o estabilidad. Las maniobras críticas de montaña requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una persona afirma que cualquier sismo cercano implica magma a punto de salir. Explica por qué el contexto tectónico no determina por sí solo el origen y significado de una señal.

## Errores frecuentes y puntos críticos de seguridad

Fundir toda la placa en el dibujo; describir el manto como un océano de lava; convertir un modelo general en pronóstico o corte exacto del Calbuco.

## Material y equipo relacionado

Papel, lápiz y esquema con fuente. El GPS ubica al observador, no mide un reservorio magmático.

[Consultar inventario](../../equipo/). Poseer un dispositivo o equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Justifica con un ejemplo y un límite: Explica fusión parcial y papel de fluidos sin reducirlos a roce.
- Justifica con un ejemplo y un límite: Distingue generación de magma, ascenso y erupción.
- Justifica con un ejemplo y un límite: Reconoce qué no puede concluirse de un modelo regional.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Reconstruye el proceso en cinco frases y marca dos límites del esquema. Distingue una explicación causal de un pronóstico.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Revisión de dibujos con docente o especialista en geología; sin experimentos térmicos ni visita a zonas activas.

## Evidencia requerida y criterios de competencia

- Explica fusión parcial y papel de fluidos sin reducirlos a roce.
- Distingue generación de magma, ascenso y erupción.
- Reconoce qué no puede concluirse de un modelo regional.

**COMPETENCIA:** estos criterios requieren revisión humana contextual. Leer, resolver un quiz o presentar un documento no certifica guiado ni ejecución de maniobras. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s12-tectonica-subduccion). Registra fecha, escenario, fuente, errores, correcciones, supervisor y evidencia de aprendizaje. Separa ejercicio ficticio de actividad real. No inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Geología y vulcanología](../../geologia/) · [Fichas territoriales](../../territorio/) · [Ecología](../../ecologia/) · [Glaciar](../../glaciar/) · [Planificación](../../planificacion/) · [Programa](../../programa/). El conocimiento del origen del relieve complementa la planificación; no reemplaza información actual ni evaluación de terreno.
