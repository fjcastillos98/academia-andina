---
{
  "title": "Interpretación ambiental: del dato al guion",
  "description": "Redactar una idea central vinculada a un recurso observable.",
  "module": "M19",
  "code": "E22-02",
  "order": 2202,
  "minutes": 40,
  "level": "Intermedio",
  "status": "development",
  "unit": "U22-02",
  "skills": [
    "s22-interpretacion-con-evidencia"
  ],
  "critical": false,
  "reviewDate": "2026-10-28",
  "objectives": [
    "Redactar una idea central vinculada a un recurso observable.",
    "Separar dato documentado, inferencia y pregunta abierta.",
    "Revisar un guion con evidencia y respuesta de la audiencia."
  ],
  "prerequisites": [
    "Estudiar ética profesional y patrimonio vivo."
  ],
  "sources": [
    "e22-nps"
  ],
  "pending": [
    "Revisión docente y contextual pendiente.",
    "No se realizaron consultas comunitarias ni se verificaron permisos o hechos ambientales locales."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Dos imágenes sin fecha muestran diferencias. ¿Qué conclusión corresponde?",
        "options": [
          "El turismo causó el cambio.",
          "Se pueden describir diferencias, pero falta contexto para explicar un cambio.",
          "El sitio no sufrió alteraciones."
        ],
        "answer": 1,
        "explanation": "Ajusta la conclusión a la evidencia.",
        "rationales": [
          "La causalidad no está sustentada.",
          "Ajusta la conclusión a la evidencia.",
          "La ausencia de contexto tampoco demuestra ausencia de cambio."
        ],
        "source": "e22-nps",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué hace útil una idea central?",
        "options": [
          "Acumula todos los nombres.",
          "Evita cualquier pregunta.",
          "Expresa una relación sustentable con los apoyos del guion."
        ],
        "answer": 2,
        "explanation": "Conecta tema y evidencia.",
        "rationales": [
          "Una lista no organiza el significado.",
          "Las preguntas pueden revelar límites.",
          "Conecta tema y evidencia."
        ],
        "source": "e22-nps",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Cómo revisar si se entendió el límite de una explicación?",
        "options": [
          "Pedir que identifiquen la idea y una incertidumbre.",
          "Contar aplausos.",
          "Declarar competencia al finalizar."
        ],
        "answer": 0,
        "explanation": "Produce una respuesta examinable.",
        "rationales": [
          "Produce una respuesta examinable.",
          "El entusiasmo no prueba comprensión.",
          "Terminar no acredita competencia."
        ],
        "source": "e22-nps",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "openAssessment": {
    "prompt": "Entrega una primera versión, la observación de un compañero y la corrección justificada del ejercicio.",
    "rubric": [
      "Redactar una idea central vinculada a un recurso observable.",
      "Separar dato documentado, inferencia y pregunta abierta.",
      "Revisar un guion con evidencia y respuesta de la audiencia."
    ],
    "source": "e22-nps",
    "difficulty": "integración"
  }
}
---

**CONTENIDO EN DESARROLLO · TALLER DE MESA · REVISIÓN DOCENTE PENDIENTE.**

## Conceptos clave y propósito

Un guion interpretativo ayuda a relacionar algo observable con una idea que resulte comprensible y relevante para la audiencia. El tema interpretativo expresa una relación que el guion puede sostener; no es solo una lista de nombres. «Bosque» nombra un asunto; una frase sobre cómo nuestras observaciones cambian al comparar dos fotografías propone una relación que puede discutirse.

Esta unidad enseña a construir un guion educativo, no a identificar especies ni a determinar procesos geológicos desde una imagen. Las afirmaciones ambientales necesitan sus fuentes y alcance propios.

## Teoría y alcance de la fuente

El NPS describe la interpretación como una relación entre conocimiento del recurso, conocimiento de la audiencia y una técnica apropiada; también destaca investigación y vínculos entre recursos tangibles y significados. [Referencia NPS](#fuente-e22-nps). La página consultada aborda interpretación histórica estadounidense. Su uso aquí es una adaptación didáctica a un taller ambiental, pendiente de revisión; no valida automáticamente una explicación de Los Lagos.

El procedimiento siguiente, las tarjetas y el guion de ejemplo son originales de la academia. No se atribuyen al NPS ni constituyen su currículo completo.

## Construir una idea con evidencia

Selecciona un recurso que puedas mostrar sin modificarlo: una fotografía de práctica, un mapa público o una ficha documental. Define qué parte se puede observar y qué parte solo conoces por una fuente. Una imagen puede mostrar formas y colores; por sí sola no fija especie, edad o causa de una transformación.

Formula una frase central y elige dos apoyos. Para cada apoyo escribe afirmación, fuente, fecha o contexto y límite. Una afirmación demasiado amplia debe acotarse antes de hacerse más entretenida. Si la fuente describe una cuenca, no la traslades sin justificación a cualquier ladera de la región.

Distingue tres registros en el borrador: **observo**, **la fuente documenta** y **propongo interpretar**. El tercero puede ser una pregunta o analogía, pero no debe disfrazarse de hecho. «Este lugar guarda memoria» puede funcionar como metáfora; no sustituye una explicación documentada de cambios ni autoriza a atribuirle un significado comunitario.

Piensa en la audiencia mediante preguntas, no suposiciones. ¿Qué sabe del recurso? ¿Qué espera de la explicación? ¿Qué término conviene aclarar? Evita pedir experiencias privadas. Una pregunta como «¿qué diferencia ven entre estas dos tarjetas?» ofrece una entrada común; después puedes preguntar qué evidencia haría falta para explicarla.

## Guion breve y revisión

La pauta de aula organiza apertura, idea central, dos apoyos, pregunta y cierre. La apertura invita a observar; la idea centra el relato; los apoyos muestran de dónde sale; la pregunta deja espacio a otra interpretación; el cierre recupera el límite y una acción educativa apropiada. No fija una duración universal para guiar: en terreno, la oportunidad de detenerse y hablar depende de la planificación y condiciones.

Una acción educativa no necesita intervenir el sitio. Comparar documentos, revisar una atribución o anotar una pregunta puede ser suficiente. No recolectes organismos, muevas piedras ni difundas ubicaciones sensibles para mejorar una presentación.

Evalúa comprensión mediante una tarea: pide que la persona repita la idea central y señale una incertidumbre. El aplauso, una fotografía o el número de datos recordados no demuestran por sí solos que distinguió evidencia y explicación. Si la audiencia entendió una certeza donde había una hipótesis, revisa el lenguaje antes de añadir más contenido.

## Caso práctico: dos imágenes, una historia demasiado rápida

**Escenario ficticio:** dos tarjetas muestran un sendero con apariencia diferente. No tienen fecha, escala ni confirmación de que se tomaron en el mismo lugar. El borrador afirma «el turismo destruyó este bosque».

Respuesta orientativa: las tarjetas permiten discutir diferencias visibles, pero no sostienen identidad del sitio, cambio temporal ni causalidad. Reformula la idea: «Comparar imágenes exige saber qué representan antes de explicar un cambio». Pide fecha, posición y contexto; si no existen, conserva el caso como ejercicio de incertidumbre. No declares que la actividad turística fue inocua: esa afirmación tampoco está demostrada.

## Ejemplo de cierre revisado

«Hemos descrito dos imágenes y detectado información que falta. Nuestra primera explicación podía sonar convincente, pero necesitamos contexto para sostenerla. Antes de compartir un relato ambiental, comprobemos qué dice realmente cada documento». Este cierre corresponde solo a las tarjetas ficticias y no afirma un estado ambiental local.

## Errores frecuentes

Acumular nombres sin una relación clara; inventar causalidad para dar dramatismo; mezclar escala regional y observación puntual; usar una leyenda sin atribución como dato científico; tratar toda incertidumbre como ausencia de conocimiento; evaluar solo el entusiasmo del público.

## Autoevaluación

Escribe la idea central en una frase. Subraya los hechos, rodea las inferencias y marca una pregunta pendiente. Si todas las frases son afirmaciones absolutas, comprueba si ocultaste límites de escala, fecha o fuente.

## Ejercicios y revisión

Prepara el [taller de guion](../../interpretacion/) con materiales ficticios o públicos. Un compañero identifica la idea central y busca una afirmación sin apoyo. Revisa el guion y explica qué cambió. La práctica docente con audiencia real queda pendiente; no se acredita desempeño profesional por escribirlo.

## Evidencia requerida

Guion inicial y revisado, dos apoyos con fuente y límite, respuesta de prueba de un compañero y una corrección justificada. La rúbrica valora claridad de tema, separación de registros, adecuación del lenguaje y respeto de contenidos que no corresponde difundir.

## Relaciones con otros módulos

Integra [comunicación intercultural](../comunicacion-intercultural/), [patrimonio vivo](../historia-patrimonio-vivo/), [síntesis geológica](../sintesis-geologica/) y las fichas de [ecología](../../ecologia/). Verifica cada hecho local antes de usarlo fuera del aula.
