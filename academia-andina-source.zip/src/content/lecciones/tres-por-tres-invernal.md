---
{
  "title": "3×3 invernal: nueve cruces, decisiones revisables",
  "description": "Aplicar condiciones, terreno y personas en tres escalas.",
  "module": "M13",
  "code": "E5-23",
  "order": 522,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-20",
  "skills": [
    "s5-tres-por-tres-invernal"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Aplicar condiciones, terreno y personas en tres escalas.",
    "Actualizar hipótesis al pasar de planificación a lugar y zona de decisión.",
    "Explicar por qué nueve casillas completas no autorizan una maniobra."
  ],
  "prerequisites": [
    "s5-planificacion-invernal"
  ],
  "sources": [
    "e5-kat-3x3",
    "e5-kat-learning",
    "e5-dmc-model"
  ],
  "pending": [
    "Revisión pedagógica y de instructor. Condiciones, cobertura de boletines y aplicación territorial real: PENDIENTE DE VERIFICACIÓN."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Las dimensiones del 3×3 son…",
        "options": [
          "Cumbre, descenso y rescate.",
          "Condiciones, terreno y personas.",
          "Mapa, GPS y brújula."
        ],
        "answer": 1,
        "explanation": "Son las tres dimensiones del marco.",
        "rationales": [
          "Son fases u objetivos distintos.",
          "Estructura correcta.",
          "Son recursos, no dimensiones."
        ],
        "source": "e5-kat-3x3",
        "difficulty": "intermedia",
        "kind": "conocimiento"
      },
      {
        "prompt": "Una discrepancia local respecto del plan exige…",
        "options": [
          "Revisar la hipótesis y decisión.",
          "Mantener el plan porque fue aprobado.",
          "Esperar a estar en la pendiente final."
        ],
        "answer": 0,
        "explanation": "La matriz es iterativa.",
        "rationales": [
          "Actualiza con evidencia.",
          "Congela información previa.",
          "Puede perder opciones."
        ],
        "source": "e5-kat-3x3",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "Nueve casillas completas significan…",
        "options": [
          "Competencia de guía.",
          "Estabilidad demostrada.",
          "Información organizada que aún requiere juicio y formación."
        ],
        "answer": 2,
        "explanation": "El formato no valida ejecución.",
        "rationales": [
          "No hay evaluación práctica.",
          "No es prueba de estabilidad.",
          "Alcance adecuado."
        ],
        "source": "e5-kat-learning",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Conserva las nueve relaciones de escala y dimensión.",
    "Actualiza decisiones ante nueva evidencia.",
    "Declara límites y responsabilidad sin autorización automática."
  ],
  "openAssessment": {
    "prompt": "Completa un 3×3 antes y después de un cambio ficticio. Marca la casilla que modificó tu decisión y explica el motivo.",
    "rubric": [
      "Conserva las nueve relaciones de escala y dimensión.",
      "Actualiza decisiones ante nueva evidencia.",
      "Declara límites y responsabilidad sin autorización automática."
    ],
    "source": "e5-kat-3x3",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-3x3"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Una celda útil relaciona evidencia, incertidumbre y decisión; una lista de palabras sin consecuencia no cumple esa función.

## Teoría y toma de decisiones

El 3×3 organiza preguntas en tres escalas y tres dimensiones. En la adaptación educativa usada aquí, las escalas son regional, local y zona de decisión; las dimensiones son condiciones, terreno y personas. Se basa en el marco de prevención de KAT/SLF. La matriz permite ordenar y volver a contrastar información, no sumar casillas para obtener un permiso de paso [folleto](#fuente-e5-kat-3x3). La unidad inicial de 3×3 ya introdujo el hábito; ahora se aplica a incertidumbres invernales.

A escala regional, condiciones reúne pronóstico, información de nieve y evolución esperada con sus coberturas. Terreno identifica opciones de itinerario, orientaciones, cotas y posibles áreas excluidas. Personas considera formación, experiencia observada, equipo, expectativas y recursos del grupo. Estas casillas deben contener preguntas que afecten al plan. «Consultar el tiempo» es una tarea; «el pronóstico no cubre la altura propuesta y por eso no puedo sostener ese horario» es una relación entre información y decisión.

A escala local se contrasta lo planificado con lo encontrado sin asumir que una vista desde el inicio representa toda la montaña. Condiciones pregunta qué cambió y qué señales son relevantes. Terreno pregunta si referencias, acceso y conexión con zonas superiores coinciden con la representación usada. Personas pregunta cómo está funcionando el grupo, si el equipo es compatible y si el briefing fue comprendido. Si la comparación falla, hay que revisar el objetivo; no basta escribir la discrepancia y continuar igual.

En la zona de decisión, las preguntas se vuelven específicas: qué problema afecta al tramo considerado, dónde quedaría expuesto el grupo y qué capacidad real permite ejecutar la opción. «Más adelante veremos» puede consumir la posibilidad de retirarse. La zona debe permitir decidir antes de comprometerse; elegir dónde y cómo hacerlo requiere formación presencial y evaluación del terreno. La matriz no prescribe un lugar universal ni una distancia entre participantes.

Cada celda puede etiquetarse como dato atribuido, observación o información faltante. Esta convención es una herramienta editorial de la academia. La DMC aporta productos meteorológicos cuya emisión y alcance deben conservarse [fuente](#fuente-e5-dmc-model); no llenan automáticamente la casilla de estabilidad del manto. Los datos de personas se registran sin información clínica ni privada. El resultado esperado es una decisión con responsable, límites y próxima reevaluación.

Caso ficticio: regionalmente se planificó una caminata con apoyo de un pronóstico válido; localmente hay transporte de nieve no previsto y un integrante no domina su equipo. Completa las nueve casillas, pero destaca cuáles impiden llegar a la zona de decisión propuesta. Después modifica el objetivo para mantenerlo dentro de capacidades conocidas. Explica por qué una matriz completa puede concluir «no continuar». SLF recuerda que sus materiales necesitan formación y conocimientos previos [fuente](#fuente-e5-kat-learning); completar este ejercicio demuestra comprensión del marco, no juicio profesional ni competencia práctica.

## Qué observo, qué significa y qué no puedo concluir

Adaptación didáctica del marco KAT; no es un algoritmo de reducción ni reemplaza juicio profesional.

## Caso práctico y aplicación al guiado

El plan regional parece coherente, pero localmente falla la compatibilidad de equipo de un pasajero. ¿Qué casillas y decisiones se actualizan?

## Errores frecuentes y señales de alerta

Completar una vez y archivar; promediar casillas; llegar al tramo comprometido antes de decidir; mezclar pronóstico y observación.

## Autoevaluación y respuesta razonada

Completa un 3×3 antes y después de un cambio ficticio. Marca la casilla que modificó tu decisión y explica el motivo.

## Ejercicios y práctica supervisada

Aplicar las nueve celdas a un caso ficticio y repetir tras recibir una nueva observación. Revisión con instructor.

## Evidencia requerida

- Conserva las nueve relaciones de escala y dimensión.
- Actualiza decisiones ante nueva evidencia.
- Declara límites y responsabilidad sin autorización automática.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-tres-por-tres-invernal).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
