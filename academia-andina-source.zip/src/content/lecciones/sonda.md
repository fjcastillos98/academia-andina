---
{
  "title": "Sonda: confirmación espacial y lectura del contacto",
  "description": "Identificar segmentos, tensión, bloqueo y escala de una sonda.",
  "module": "M09",
  "code": "E5-13",
  "order": 512,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-10",
  "skills": [
    "s5-sonda"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Identificar segmentos, tensión, bloqueo y escala de una sonda.",
    "Distinguir sondaje de precisión de búsqueda organizada por líneas.",
    "Explicar la información que aporta el contacto y la que sigue faltando."
  ],
  "prerequisites": [
    "s5-dva-multiples"
  ],
  "sources": [
    "e5-sonda-ortovox",
    "e5-sonda-canada",
    "e5-sonda-icar"
  ],
  "pending": [
    "Selección de longitud y modelo para operación Filo Austral: PENDIENTE DE VERIFICACIÓN con instructor."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿Qué aporta la sonda?",
        "options": [
          "Confirmación espacial y profundidad, sin diagnóstico clínico.",
          "Un pronóstico meteorológico.",
          "Identidad y estado vital automáticos."
        ],
        "answer": 0,
        "explanation": "El contacto tiene alcance mecánico y espacial.",
        "rationales": [
          "Describe función y límite.",
          "No corresponde al instrumento.",
          "Atribuye datos no medidos."
        ],
        "source": "e5-sonda-ortovox",
        "difficulty": "intermedia",
        "kind": "conocimiento"
      },
      {
        "prompt": "El patrón tras búsqueda fina y una línea organizada son…",
        "options": [
          "Siempre idénticos.",
          "Respuestas a problemas y recursos diferentes.",
          "Intercambiables sin entrenamiento."
        ],
        "answer": 1,
        "explanation": "Una localización acotada difiere de cubrir un área organizada.",
        "rationales": [
          "Ignora objetivos diferentes.",
          "Distingue contexto y método.",
          "Omite formación y coordinación."
        ],
        "source": "e5-sonda-icar",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Por qué conservar una referencia tras contacto?",
        "options": [
          "Para certificar al rescatista.",
          "Para demostrar supervivencia.",
          "Para orientar la excavación sin perder la localización."
        ],
        "answer": 2,
        "explanation": "La siguiente fase depende de información espacial.",
        "rationales": [
          "No es acreditación.",
          "No determina estado clínico.",
          "Relaciona las fases."
        ],
        "source": "e5-sonda-canada",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Monta e inspecciona según manual en evaluación presencial.",
    "Distingue sondaje de precisión y organizado.",
    "Comunica resultado y límites conservando referencia."
  ],
  "openAssessment": {
    "prompt": "Compara sondaje de precisión y búsqueda organizada: objetivo, datos previos, recursos y errores que no deben confundirse.",
    "rubric": [
      "Monta e inspecciona según manual en evaluación presencial.",
      "Distingue sondaje de precisión y organizado.",
      "Comunica resultado y límites conservando referencia."
    ],
    "source": "e5-sonda-ortovox",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-sonda"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Reconocer segmentos asentados, tensión y bloqueo correctos según modelo, escala legible y referencia conservada.

## Teoría y toma de decisiones

La sonda transforma una estimación de posición en una comprobación física bajo la nieve. Permite conservar una referencia espacial y aportar profundidad al trabajo posterior; no informa por sí sola sobre vía aérea, identidad o lesiones. Una lectura pequeña del DVA y un contacto son evidencias diferentes. La primera procede de señal procesada, el segundo de una interacción mecánica que debe interpretarse durante formación. Confundirlos favorece excavaciones mal ubicadas o declaraciones prematuras de éxito.

Una sonda plegable contiene segmentos, un elemento de tensión, conexiones, punta, sistema de bloqueo y marcas. ORTOVOX muestra que existen sistemas de ensamblaje y cierre diferentes. [Componentes](#fuente-e5-sonda-ortovox). La longitud útil y rigidez deben ser adecuadas al contexto; comprar una cifra mayor no resuelve un cierre defectuoso ni garantiza reconocer contactos. Revisa daños, ensamblaje completo, tensión y funcionamiento conforme al fabricante. No se supone que todos los cordones, cierres y repuestos sean intercambiables.

El sondaje posterior al DVA busca confirmar una localización acotada. Avalanche Canada enseña un patrón sistemático alrededor del punto de menor lectura y conservar la sonda como referencia después del contacto. [Sondaje de compañeros](#fuente-e5-sonda-canada). La sistematicidad evita repetir huecos arbitrariamente o abandonar el lugar sin saber qué se comprobó. Ángulo, separación y profundidad se aprenden presencialmente según el método; no se transforma un diagrama sin escala en una plantilla de terreno. Un contacto dudoso exige la respuesta enseñada por instructor, no la afirmación automática «es una víctima».

El sondaje organizado aborda un problema distinto, por ejemplo una persona sin transmisión detectable. ICAR diferencia estrategias dirigidas a indicios y líneas organizadas, con coordinación, especificaciones y evaluación de riesgos propias. [Recomendación2025](#fuente-e5-sonda-icar). Una línea de personas no funciona por estar alineada: requiere cobertura, disciplina de movimiento, referencias y dirección. No debe confundirse esa organización profesional con el patrón de precisión utilizado tras una búsqueda fina. La selección de estrategia depende de datos, recursos y amenazas.

Ejercicio de mesa: un croquis muestra un punto instrumental, dos contactos sin confirmar y un sector que nadie ha revisado. Representa cada categoría con un símbolo distinto y explica qué mensaje enviarías al responsable. Añade la tarjeta «el bloqueo se afloja al retirar la sonda». Discute cómo ese defecto afecta a la evidencia y al trabajo: un instrumento que cambia de configuración no puede tratarse como si hubiera funcionado normalmente. El inventario debe registrar el defecto y la intervención, no solo que se utilizó ese día.

Otra comparación: el grupo A registra «tocamos algo»; el B anota el objetivo del ejercicio, quién observó el contacto, cómo se conservó la referencia y qué corrigió el instructor. El segundo registro es más útil para aprender, aunque no tenga un tiempo espectacular. No es una evaluación clínica y no debe contener información sensible de pacientes. Para entrenamiento se emplean blancos inertes protegidos, nunca personas enterradas para simular realismo.

Localizar no termina el rescate. Falta crear un acceso eficaz, atender y coordinar evacuación, manteniendo seguridad de participantes. La profundidad es un dato para planear trabajo; no una regla suficiente para decidir pronóstico o abandonar a alguien. En guiado, la revisión previa debe comprobar que el equipo está accesible y que los participantes entrenaron su despliegue con guantes y bajo supervisión. El desempeño se evalúa con criterios explícitos de montaje, interpretación, referencia y comunicación, separados del quiz conceptual de esta unidad.

## Qué observo, qué significa y qué no puedo concluir

Contacto no confirma identidad o viabilidad; patrón de precisión no equivale a línea organizada.

## Caso práctico y aplicación al guiado

Una sonda pierde tensión y el grupo da por comprobado el sector. Explica por qué el registro debe describir el defecto.

## Errores frecuentes y señales de alerta

Montaje parcial; bloqueo omitido; saltos sin patrón; retirar la referencia sin coordinación; confundir contacto con rescate terminado.

## Autoevaluación y respuesta razonada

Compara sondaje de precisión y búsqueda organizada: objetivo, datos previos, recursos y errores que no deben confundirse.

## Ejercicios y práctica supervisada

Montaje e identificación de contactos sobre objetivos inertes con instructor; repetir con guantes. Nunca enterrar personas.

## Evidencia requerida

- Monta e inspecciona según manual en evaluación presencial.
- Distingue sondaje de precisión y organizado.
- Comunica resultado y límites conservando referencia.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-sonda).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
