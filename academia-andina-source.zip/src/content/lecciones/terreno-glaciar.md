---
{
  "title": "Terreno glaciar: conexiones y cambio",
  "description": "Distinguir observación de superficie e información subyacente.",
  "module": "M04",
  "code": "E6-02",
  "order": 602,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U6-02",
  "skills": [
    "s6-terreno-glaciar"
  ],
  "critical": true,
  "reviewDate": "2026-10-23",
  "objectives": [
    "Distinguir observación de superficie e información subyacente.",
    "Reconocer que un itinerario histórico no documenta las condiciones presentes."
  ],
  "prerequisites": [
    "s6-glaciologia"
  ],
  "sources": [
    "e6-nsidc-science",
    "e6-nps-crevasses"
  ],
  "pending": [
    "Reconocimiento territorial por guía competente; no añadir itinerarios reales sin fuentes y actualización. PENDIENTE DE VERIFICACIÓN.",
    "Revisión presencial por instructor competente pendiente. No se ha realizado ni aprobado ninguna práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un track antiguo cruza una zona hoy oculta. ¿Qué demuestra?",
        "options": [
          "Transitabilidad actual.",
          "Ausencia de grietas.",
          "Una línea histórica cuya aplicabilidad requiere revisión."
        ],
        "answer": 2,
        "explanation": "La posición registrada no valida las condiciones actuales.",
        "rationales": [
          "No se justifica: La posición registrada no valida las condiciones actuales.",
          "No se justifica: La posición registrada no valida las condiciones actuales.",
          "Correcta: La posición registrada no valida las condiciones actuales."
        ],
        "source": "e6-nsidc-science",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una superficie continua bajo nieve permite concluir…",
        "options": [
          "Que no hay fracturas.",
          "Que la cubierta puede ocultar información.",
          "Que el soporte es uniforme."
        ],
        "answer": 1,
        "explanation": "La continuidad visible no revela todo el hielo subyacente.",
        "rationales": [
          "No se justifica: La continuidad visible no revela todo el hielo subyacente.",
          "Correcta: La continuidad visible no revela todo el hielo subyacente.",
          "No se justifica: La continuidad visible no revela todo el hielo subyacente."
        ],
        "source": "e6-nsidc-science",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "¿Qué exige una alternativa más corta?",
        "options": [
          "Su propia revisión de exposición y tránsito.",
          "Solo medir kilómetros.",
          "Nada si está en el mapa."
        ],
        "answer": 0,
        "explanation": "La alternativa es otra propuesta por evaluar.",
        "rationales": [
          "Correcta: La alternativa es otra propuesta por evaluar.",
          "No se justifica: La alternativa es otra propuesta por evaluar.",
          "No se justifica: La alternativa es otra propuesta por evaluar."
        ],
        "source": "e6-nsidc-science",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "No trata el croquis como ruta.",
    "Distingue escala regional de observación puntual.",
    "Expone al menos una razón para aplazar la decisión."
  ],
  "openAssessment": {
    "prompt": "Compara dos croquis ficticios de la misma cuenca y marca qué información falta para valorar una propuesta de recorrido.",
    "rubric": [
      "No trata el croquis como ruta.",
      "Distingue escala regional de observación puntual.",
      "Expone al menos una razón para aplazar la decisión."
    ],
    "source": "e6-nsidc-science",
    "difficulty": "integración"
  },
  "diagrams": [
    "e6-evidencia"
  ]
}
---

**CONTENIDO TEÓRICO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Zonas de acumulación y ablación, Cambios de pendiente y flujo, Cubierta nival y visibilidad. Construir una ficha de observación con orientación, cota, fecha y escala; la incertidumbre forma parte del registro.

## Teoría y toma de decisiones

Leer terreno glaciar exige distinguir forma visible, proceso que podría explicarla e información que permanece oculta. Cambios en pendiente o dirección del flujo pueden modificar la deformación del hielo; grietas y sectores fracturados forman parte de esa dinámica. No existe una regla visual que localice todas las fracturas. [Procesos](#fuente-e6-nsidc-science) y [grietas](#fuente-e6-nps-crevasses) aportan un lenguaje para formular hipótesis, no una autorización de paso.

La cubierta nival puede ocultar discontinuidades. Una fotografía con superficie continua y otra con hielo expuesto pueden representar el mismo lugar en momentos diferentes; no basta elegir la imagen que resulte más tranquilizadora. La cartografía, la visibilidad y la observación presencial tienen escalas y límites propios. Una huella descargada describe dónde pasó alguien o dónde dibujó una línea, sin verificar cómo se encuentra hoy ese recorrido.

En una ficha de lectura separa tres zonas: área observada directamente, área inferida por continuidad y área desconocida. Describe además qué terreno se conecta por encima o hacia los lados y qué parte del grupo quedaría expuesta al avanzar. No asignes una salida de emergencia solo porque el mapa muestre menos distancia. La alternativa necesita información sobre su propia exposición y posibilidad de tránsito.

Ejercicio: dos croquis ficticios muestran un cambio de pendiente y una zona que desaparece bajo nubes. El primero conserva una línea antigua de marcha; el segundo solo tiene observaciones del día. Redacta una decisión condicionada y especifica qué dato haría revisarla. Una buena respuesta puede aplazar el objetivo si no existe evidencia suficiente. Para el guía, explicar esa limitación antes de entrar es parte del trabajo, no una falla que deba ocultarse.

## Procedimiento conceptual: objetivo, uso y límites

Distinguir observación de superficie e información subyacente. Esta unidad se utiliza para preparar el análisis y un taller, no para ejecutar una maniobra sin entrenamiento. Comparar mapas de fechas distintas, señalando qué cambió y qué no puede saberse con ellos.

Las variantes técnicas mantienen el ámbito de la fuente citada. Antes de cambiar una configuración se deben revisar sus funciones, comprobaciones y límites con instructor; no se combinan pasos de escuelas distintas por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario hipotético de aula.** El track de otra temporada atraviesa un sector que hoy no se distingue. El grupo insiste en que la pantalla confirma la ruta. Separa posición instrumental, línea histórica y conocimiento del terreno actual.

## Errores frecuentes y puntos críticos

Confundir posición con transitabilidad; llenar vacíos del mapa por intuición; elegir alternativa sin evaluarla.

No se atribuye una garantía de seguridad al equipo, al quiz ni a una práctica en condiciones diferentes. Si falta un dato esencial para justificar el objetivo, declarar ese vacío es parte del aprendizaje.

## Material y equipo relacionado

Cartografía, brújula, GPS y comunicación complementarios. Cuerda, arnés y equipo de progresión requieren identificación y práctica previa.

[Inventario personal](../../equipo/): conserva referencia del manual y observaciones de inspección. El registro no declara aptitud de una pieza ni competencia de quien la porta.

## Autoevaluación y recuperación activa

- ¿Qué parte del croquis es observación y cuál inferencia?
- ¿Por qué un desvío más corto puede no reducir exposición?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL de escritorio:** Compara dos croquis ficticios de la misma cuenca y marca qué información falta para valorar una propuesta de recorrido.

**PRÁCTICA SUPERVISADA:** el instructor adapta un taller con objetivos observables, protección y criterios de parada. No provocar caídas reales ni entrar a terreno expuesto para comprobar esta página. La evaluación presencial es independiente de la respuesta teórica.

## Evidencia requerida y criterios de competencia

- No trata el croquis como ruta.
- Distingue escala regional de observación puntual.
- Expone al menos una razón para aplazar la decisión.

Estos criterios valoran razonamiento; para una competencia práctica, el instructor debe definir y observar la ejecución en un contexto explícito. No se preasigna una evaluación por estudiar.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s6-terreno-glaciar). Registrar únicamente lo realizado: fecha, lugar, condiciones, objetivo, equipo, supervisor, resultado, errores, correcciones, evidencia, autonomía observada y próxima práctica. No guardar datos médicos ni información privada de pasajeros.

## Relaciones con etapas anteriores

[Glaciología introductoria](../glaciologia-intro/), [planificación invernal](../planificacion-invernal/), [encordamiento según contexto](../encordamiento-contexto/), [anclajes](../anclajes-reuniones/) y [ventaja mecánica](../ventaja-mecanica/). Estas dependencias orientan el estudio; no autorizan la aplicación técnica. [Ruta glaciar](../../glaciar/).
