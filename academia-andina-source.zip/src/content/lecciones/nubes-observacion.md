---
{
  "title": "Nubes, ondas de montaña y observación",
  "description": "Reconocer rasgos de los diez géneros sin atribuirles un pronóstico fijo.",
  "module": "M10",
  "code": "E4-08",
  "order": 208,
  "minutes": 45,
  "level": "Intermedio",
  "status": "development",
  "reviewDate": "2026-10-22",
  "unit": "U4-08",
  "skills": [
    "s4-nubes-observacion"
  ],
  "critical": false,
  "objectives": [
    "Reconocer rasgos de los diez géneros sin atribuirles un pronóstico fijo.",
    "Explicar lenticulares y flujo sobre relieve con límites.",
    "Registrar observación, hipótesis y decisión por separado."
  ],
  "prerequisites": [
    "Completar estudio de Fundamentales; la práctica previa debe revisarse presencialmente.",
    "Estudiar Pronósticos y decisiones operacionales."
  ],
  "sources": [
    "omm-guia",
    "omm-lenticularis",
    "nws-ondas"
  ],
  "pending": [
    "Revisión pedagógica y evaluación situada por instructor competente.",
    "Condiciones, accesos, permisos y compatibilidad del equipo requieren verificación para cada actividad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una lenticular aparentemente estacionaria…",
        "options": [
          "Demuestra ausencia de viento.",
          "Puede mantenerse ligada a una onda mientras circula aire.",
          "Mide la velocidad del viento del sendero."
        ],
        "answer": 1,
        "explanation": "El patrón de nube y el movimiento del aire son fenómenos diferentes."
      },
      {
        "prompt": "Altocumulus lenticularis combina…",
        "options": [
          "Un género y una especie.",
          "Dos velocidades.",
          "Una alerta y una ruta."
        ],
        "answer": 0,
        "explanation": "La denominación describe clasificación, no seguridad operacional."
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

**TEORÍA.** El género organiza tipos principales; una especie describe características dentro de esa clasificación. “Lenticularis” no es un undécimo género. Revisa la tabla de los diez géneros del piloto; aquí la usamos para comparar observaciones y argumentar incertidumbres, no para memorizar una lista aislada.

## Teoría: una lectura visual ordenada

La guía de la OMM distingue cirrus de aspecto filamentoso, cirrostratus como velo y cirrocumulus como pequeños elementos; altostratus como capa extensa y altocumulus como elementos estructurados; nimbostratus asociado a precipitación persistente; stratocumulus con elementos redondeados bajos y stratus como capa; cumulus con contornos definidos y cumulonimbus de gran desarrollo vertical, a veces con yunque [Referencia: omm-guia](#fuente-omm-guia). Estos rasgos introductorios no reemplazan la guía completa.

No identifiques la altura exacta por la perspectiva. Una nube puede ocultar otra y la iluminación modifica la apariencia. Describe primero forma, distribución, continuidad, borde, relación con relieve y evolución. Si no distingues stratus de otra capa, registra “capa baja aparente; identificación pendiente” en lugar de inventar seguridad taxonómica.

El significado para el guía depende del contexto: una nube que tapa una referencia cambia la navegación aunque no sepas su género; una identificación muy segura tampoco informa por sí sola de precipitación o viento que habrá horas después. El objetivo es conectar observación con preguntas, no producir un pronóstico casero a partir de etiquetas.

## Lenticulares y ondas de montaña

La OMM describe lenticularis como forma de lente o almendra, vinculada a varios géneros, incluido Altocumulus [Referencia: omm-lenticularis](#fuente-omm-lenticularis). **Altocumulus lenticularis** combina género y especie. Su aparición no demuestra una velocidad de viento a nivel del sendero.

El estudio del NWS explica que flujo estable sobre relieve puede producir ondas; si hay humedad suficiente pueden formarse nubes en la parte ascendente. El patrón puede mantenerse casi estacionario mientras circula aire y puede asociarse a turbulencia [Referencia: nws-ondas](#fuente-nws-ondas). No se trasladan aquí cifras de ese estudio a Los Lagos.

Una nube aparentemente inmóvil no significa aire inmóvil. Tampoco la ausencia de lenticulares demuestra ausencia de viento: para que se vea una nube hacen falta condiciones de humedad y condensación. “Nube orográfica” describe relación de formación con relieve, no una categoría que por sí sola apruebe una salida.

## Protocolo de observación de estudio

Registra hora, posición general del observador, dirección de mirada y un dibujo o descripción. Mantén separados: observación (“borde definido”), hipótesis (“posible lenticular”), confianza (“tentativa”) y pregunta operacional (“¿qué información de viento falta?”). Para comparar dos momentos procura conservar el punto de vista; si cambia, decláralo.

No registres datos personales de terceros ni uses la práctica como motivo para acercarte a terreno expuesto. Una serie de dibujos puede resultar más honesta que una fotografía sin escala, hora o contexto. El instructor puede evaluar cómo justificas o corriges la identificación.

## Caso práctico: Osorno, observación ficticia

Desde un lugar seguro se observa una forma lenticular y en otra dirección una capa oculta parte del relieve. El grupo debate solo si la primera nube “es bonita o peligrosa”. Reorienta la conversación: qué se ve, qué no se sabe, qué producto consultar y qué referencia del itinerario ya no está disponible.

Respuesta orientativa: separar la hipótesis de onda del hecho de pérdida de visibilidad. Ninguna fotografía permite declarar un itinerario seguro. La decisión debe considerar también grupo, tiempo, terreno y alternativas.

## Errores frecuentes y señales de alerta

Asignar una velocidad por la forma; confundir especie y género; atribuir la misma evolución a todas las capas; interpretar cada cirrus como llegada inevitable de un frente; no registrar el cambio de posición del observador. Una identificación que exige ignorar rasgos contradictorios necesita revisión.

## Autoevaluación y respuestas explicadas

1. ¿Por qué una lenticular puede parecer quieta con flujo de aire? **El patrón de formación puede permanecer ligado a la onda mientras el aire atraviesa la zona.**
2. ¿Qué puedes decidir solo con el nombre de la nube? **No puedes aprobar una ruta. Puedes formular preguntas para contrastar con previsión y condiciones locales.**

## Ejercicios y práctica presencial

Compara pares: cirrus/cirrostratus, altocumulus/altostratus, stratus/stratocumulus y cumulus/cumulonimbus usando el atlas. Describe un rasgo útil y una limitación para cada par. Registra tres observaciones desde un lugar seguro. En revisión supervisada, explica una identificación que cambiaste y por qué.

## Evidencia requerida

Serie contextualizada, comparación con la fuente y corrección argumentada. La precisión de vocabulario es una parte; reconocer límites de inferencia es otra.

## Relaciones con otras habilidades

Esta unidad se integra en la ruta estival. Consulta la ficha de habilidad y sus prerrequisitos en el programa. Registra práctica y evaluación por separado: estudiar y responder correctamente no acredita ejecución. Los ejercicios son propuestas didácticas originales; los casos no son rutas operativas.
