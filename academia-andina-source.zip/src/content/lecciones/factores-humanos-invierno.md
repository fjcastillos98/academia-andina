---
{
  "title": "Factores humanos: reconocer presión antes de decidir",
  "description": "Identificar sesgos en argumentos de un caso.",
  "module": "M13",
  "code": "E5-16",
  "order": 515,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-13",
  "skills": [
    "s5-factores-humanos-invierno"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Identificar sesgos en argumentos de un caso.",
    "Diseñar mecanismos de comunicación que permitan disentir.",
    "Revisar el proceso sin atribuir una causa psicológica única."
  ],
  "prerequisites": [
    "s5-rescate-avalancha"
  ],
  "sources": [
    "e5-human",
    "e5-heuristics-study",
    "e5-kat-learning"
  ],
  "pending": [
    "Revisión pedagógica y de instructor. Condiciones, cobertura de boletines y aplicación territorial real: PENDIENTE DE VERIFICACIÓN."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "«Otros pasaron» demuestra…",
        "options": [
          "Estabilidad de toda la ladera.",
          "Una observación limitada, no garantía.",
          "Ausencia de capas débiles."
        ],
        "answer": 1,
        "explanation": "La prueba social no sustituye evaluación.",
        "rationales": [
          "Extrapola resultado ajeno.",
          "Delimita evidencia.",
          "No se examinó estructura."
        ],
        "source": "e5-heuristics-study",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "Saber nombrar sesgos…",
        "options": [
          "Elimina su influencia.",
          "Hace innecesario briefing.",
          "Permite reconocerlos, pero no inmuniza."
        ],
        "answer": 2,
        "explanation": "Los procesos humanos requieren trabajo continuo.",
        "rationales": [
          "Afirmación injustificada.",
          "Pierde comunicación.",
          "Mantiene capacidad de revisión."
        ],
        "source": "e5-human",
        "difficulty": "intermedia",
        "kind": "decisiones"
      },
      {
        "prompt": "¿Qué debriefing aporta más?",
        "options": [
          "Qué datos y argumentos guiaron la decisión en ese momento.",
          "Solo si hubo cumbre.",
          "Quién merece la culpa."
        ],
        "answer": 0,
        "explanation": "Se evalúa el proceso con información disponible.",
        "rationales": [
          "Permite revisar aprendizaje.",
          "Confunde objetivo y calidad.",
          "Reduce comunicación."
        ],
        "source": "e5-human",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Identifica el argumento y no solo la etiqueta.",
    "Solicita evidencia que pueda contradecir el plan.",
    "Comunica límites y alternativa respetuosamente."
  ],
  "openAssessment": {
    "prompt": "Reescribe una conversación con presión de cumbre para recuperar observaciones, desacuerdo y una decisión justificable.",
    "rubric": [
      "Identifica el argumento y no solo la etiqueta.",
      "Solicita evidencia que pueda contradecir el plan.",
      "Comunica límites y alternativa respetuosamente."
    ],
    "source": "e5-human",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Busca expresiones que sustituyen evidencia por inversión, autoridad, costumbre o presencia de otros.

## Teoría y toma de decisiones

Los factores humanos incluyen cómo percibimos, seleccionamos y discutimos información. Conocer nieve y terreno no elimina sesgos. Los atajos cognitivos ayudan en la vida diaria, pero pueden hacer que se omitan señales o se sostengan decisiones poco justificadas [Avalanche.org](#fuente-e5-human). En esta unidad las etiquetas sirven para formular preguntas sobre un argumento, no para diagnosticar personas ni explicar por sí solas un accidente.

El compromiso con un objetivo aparece cuando el tiempo o esfuerzo invertido se usa como razón para continuar, aunque las condiciones hayan cambiado. La familiaridad convierte «he pasado antes» en «sé cómo está ahora». La prueba social o efecto manada confunde presencia de otros con evaluación suficiente. La escasez —pocos días disponibles, buena nieve que podría desaparecer— puede aumentar presión por aprovechar la ocasión. El trabajo de McCammon estudió asociaciones entre heurísticas y accidentes recreativos; no demuestra que todos los grupos actúen igual [fuente](#fuente-e5-heuristics-study).

En ejercicios de guiado añadimos situaciones de autoridad, confirmación, exceso de confianza y comunicación deficiente. Una persona experimentada puede tener información útil, pero su autoridad no hace visible un dato que no se observó. El sesgo de confirmación aparece cuando se buscan solo señales compatibles con el plan. La normalización se expresa en «siempre lo hacemos así y nunca pasó nada». Summit fever nombra presión por la cumbre; el problema observable es que el objetivo desplaza criterios acordados. Estas expresiones deben relacionarse con conductas concretas antes de usarlas en un debriefing.

Para Filo Austral, la presión puede incluir expectativas del pasajero, una fotografía prometida, transporte o temor a decepcionar. Un mecanismo útil de aula es exigir que cada propuesta mencione una evidencia que la apoye y otra que la cuestione. Otra práctica es pedir primero la observación de quien habló menos, antes de que la opinión del líder ancle toda la conversación. Son ejercicios pedagógicos, no garantías contra sesgos ni protocolos profesionales validados por esta plataforma.

La comunicación debe permitir que una señal cambie el plan. Si el briefing promete escuchar inquietudes pero luego ridiculiza al pasajero cansado, el sistema pierde información. Un desacuerdo no se resuelve por votación sobre la estabilidad del manto: se aclaran hechos, capacidades, responsabilidades y límites. El guía debe explicar por qué una preferencia no compensa una incertidumbre crítica, y comprobar que el grupo puede ejecutar la alternativa elegida.

En el caso de aula, un grupo con retraso encuentra huellas y alguien dice que sería absurdo volver tras viajar tanto. Identifica dos argumentos que no describen el estado del manto. Propón una conversación que recupere información sin acusar a nadie de imprudente. Después introduce un resultado favorable y pregunta si cambia la calidad del razonamiento original. Aprender de una decisión exige revisar lo que se sabía en ese momento, no juzgar únicamente por suerte o desenlace. La práctica de liderazgo necesita observación presencial y retroalimentación.

## Qué observo, qué significa y qué no puedo concluir

Una etiqueta de sesgo no diagnostica ni demuestra causa única; no reemplaza información de nieve y terreno.

## Caso práctico y aplicación al guiado

«Ya vinimos hasta acá» y «otro grupo subió» aparecen como justificación. Reescribe la discusión con hechos y límites.

## Errores frecuentes y señales de alerta

Acusar en vez de preguntar; creer que conocer sesgos inmuniza; evaluar solo por resultado; silenciar pasajeros.

## Autoevaluación y respuesta razonada

Reescribe una conversación con presión de cumbre para recuperar observaciones, desacuerdo y una decisión justificable.

## Ejercicios y práctica supervisada

Role-play con turnos de observación y revisión humana; registrar frases y cambios de decisión sin datos personales.

## Evidencia requerida

- Identifica el argumento y no solo la etiqueta.
- Solicita evidencia que pueda contradecir el plan.
- Comunica límites y alternativa respetuosamente.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-factores-humanos-invierno).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
