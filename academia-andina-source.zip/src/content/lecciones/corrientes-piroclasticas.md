---
{
  "title": "Corrientes piroclásticas: reconocer el proceso y evitar falsas analogías",
  "description": "Distingue corriente piroclástica, lava y lahar.",
  "module": "M11",
  "code": "E12-05",
  "order": 1205,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U12-05",
  "skills": [
    "s12-corrientes-piroclasticas"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Distingue corriente piroclástica, lava y lahar.",
    "Reconoce más de un mecanismo de generación."
  ],
  "prerequisites": [
    "s12-tefra-ceniza"
  ],
  "sources": [
    "e12-pdc"
  ],
  "pending": [
    "Revisión por especialista en geología y vulcanología e instructor de montaña pendiente. No valida una ruta, acceso ni evacuación.",
    "Alertas actuales, restricciones, cotas discrepantes y condiciones de terreno requieren verificación independiente; no hay datos operativos en tiempo real.",
    "Casos, rúbricas y ejercicios originales. Las descripciones científicas no acreditan competencia técnica ni un protocolo universal de seguridad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una corriente piroclástica incluye…",
        "options": [
          "Gas y fragmentos calientes.",
          "Solo roca fundida continua.",
          "Solo agua limpia."
        ],
        "answer": 0,
        "explanation": "Define la mezcla descrita.",
        "rationales": [
          "Define la mezcla descrita.",
          "Corresponde a otra simplificación de proceso.",
          "No describe el fenómeno."
        ],
        "source": "e12-pdc",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Sin columna alta visible…",
        "options": [
          "No puede haber colapso de domo.",
          "No se descarta ese origen de corriente.",
          "Todo acceso queda habilitado."
        ],
        "answer": 1,
        "explanation": "La ausencia de esa señal no prueba ausencia del proceso.",
        "rationales": [
          "Confunde mecanismos distintos.",
          "La ausencia de esa señal no prueba ausencia del proceso.",
          "Observación y autorización son diferentes."
        ],
        "source": "e12-pdc",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Un ejemplo de velocidad publicado…",
        "options": [
          "Permite calcular un escape personal seguro.",
          "Anula las zonas restringidas.",
          "No es una regla operacional de huida."
        ],
        "answer": 2,
        "explanation": "Conserva el límite del dato general.",
        "rationales": [
          "No representa todas las condiciones ni capacidades.",
          "No cambia las instrucciones.",
          "Conserva el límite del dato general."
        ],
        "source": "e12-pdc",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue corriente piroclástica, lava y lahar.",
    "Reconoce más de un mecanismo de generación.",
    "Rechaza falsas garantías de escape o protección personal."
  ],
  "openAssessment": {
    "prompt": "Compara lava, lahar y corriente piroclástica en tres columnas: componentes, mecanismos descritos y conclusión que no permite la comparación.",
    "rubric": [
      "Distingue corriente piroclástica, lava y lahar.",
      "Reconoce más de un mecanismo de generación.",
      "Rechaza falsas garantías de escape o protección personal."
    ],
    "source": "e12-pdc",
    "difficulty": "integración"
  },
  "diagrams": [
    "e12-procesos"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ESPECIALISTA PENDIENTE.** Estudio documental: no autoriza aproximación a fenómenos volcánicos ni acredita competencia de guía. No se publican alertas actuales. No guardes datos médicos ni contraseñas.

## Conceptos clave y propósito

Corriente de densidad piroclástica, mezcla de gas y fragmentos calientes, flujo concentrado, nube diluida, colapso de columna y colapso de domo. Una clasificación conceptual no permite estimar alcance en terreno.

## Teoría y toma de decisiones

USGS describe flujos piroclásticos como mezclas calientes de gases y fragmentos que se desplazan rápidamente. Entre sus orígenes incluye colapso de columna eruptiva y de domos o frentes de lava. No son una colada de roca fundida ni un lahar de agua y sedimento, aunque una crisis pueda combinar procesos.

Una corriente puede presentar componentes con distinta concentración de partículas. Esa complejidad hace incorrecto interpretar cualquier nube baja como un fenómeno inofensivo o asumir que todo sigue exactamente el eje de un cauce. No se deduce un alcance seguro de una ilustración general. Los estudios y mapas locales establecen escenarios con hipótesis que hay que conservar.

La formación académica no debe convertirse en un juego de calcular si se puede correr más rápido que el fenómeno. La prioridad del ejercicio es reconocer errores de planificación: entrar en zonas restringidas, utilizar distancias universales o tratar una protección personal como suficiente. La respuesta real se rige por instrucciones de las autoridades y planificación previa; aquí no se propone una maniobra universal de escape.

Fuentes de esta unidad: [Referencia 1](#fuente-e12-pdc). Las aplicaciones de estudio y casos siguientes son elaboración pedagógica original, no protocolos de esas organizaciones.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — lectura y análisis documental:** Identifica mezcla, origen y diferencia frente a lava o lahar. Lee el alcance del escenario documentado y anota lo que no evalúa. Variante: colapso de columna frente a colapso de domo; no asumir que todos los eventos necesitan una columna alta visible.

El ejercicio se realiza en escritorio o lugar autorizado. No expongas al grupo para comprobar actividad, gases, temperatura o estabilidad. Las maniobras críticas de montaña requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un grupo cree que la ausencia de una gran columna permite acercarse a un domo. Explica por qué esa observación no excluye el mecanismo que estudias.

## Errores frecuentes y puntos críticos de seguridad

Confundir nube caliente con niebla; calcular una velocidad de huida a partir de cifras generales; tomar un relieve pequeño como barrera garantizada; entrar para fotografiar un evento.

## Material y equipo relacionado

Mapa oficial y plan de comunicaciones para estudio. Casco, arnés, VHF o inReach no neutralizan una corriente piroclástica.

[Consultar inventario](../../equipo/). Poseer un dispositivo o equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Justifica con un ejemplo y un límite: Distingue corriente piroclástica, lava y lahar.
- Justifica con un ejemplo y un límite: Reconoce más de un mecanismo de generación.
- Justifica con un ejemplo y un límite: Rechaza falsas garantías de escape o protección personal.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Compara lava, lahar y corriente piroclástica en tres columnas: componentes, mecanismos descritos y conclusión que no permite la comparación.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Simulación de revisión de plan con instructor y especialista; sin exposición a un evento ni simulación física de mezcla caliente.

## Evidencia requerida y criterios de competencia

- Distingue corriente piroclástica, lava y lahar.
- Reconoce más de un mecanismo de generación.
- Rechaza falsas garantías de escape o protección personal.

**COMPETENCIA:** estos criterios requieren revisión humana contextual. Leer, resolver un quiz o presentar un documento no certifica guiado ni ejecución de maniobras. La plataforma no verifica identidad o credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s12-corrientes-piroclasticas). Registra fecha, escenario, fuente, errores, correcciones, supervisor y evidencia de aprendizaje. Separa ejercicio ficticio de actividad real. No inventes una evaluación para completar la matriz.

## Relaciones con otros módulos

[Geología y vulcanología](../../geologia/) · [Fichas territoriales](../../territorio/) · [Ecología](../../ecologia/) · [Glaciar](../../glaciar/) · [Planificación](../../planificacion/) · [Programa](../../programa/). El conocimiento del origen del relieve complementa la planificación; no reemplaza información actual ni evaluación de terreno.
