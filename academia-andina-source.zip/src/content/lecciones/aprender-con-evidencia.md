---
{
  "title": "Aprender con evidencia",
  "description": "Organiza tu regreso al estudio y distingue recordar una idea de demostrar una habilidad.",
  "module": "M00",
  "code": "FUND-01",
  "order": 1,
  "minutes": 12,
  "level": "Fundamentos",
  "status": "example",
  "reviewDate": "2026-10-21",
  "objectives": [
    "Distinguir teoría, práctica supervisada y evaluación presencial.",
    "Escribir un objetivo de repaso verificable."
  ],
  "prerequisites": [
    "Lectura comprensiva; no se requiere ejecutar maniobras."
  ],
  "sources": [
    "academia"
  ],
  "pending": [
    "Revisión pedagógica externa y ampliación del tema curricular.",
    "No incluye evaluación ni habilitación práctica."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿Qué acredita aprobar este cuestionario?",
        "options": [
          "Comprensión de las preguntas de esta lección.",
          "Habilitación para guiar una cordada.",
          "Competencia práctica en rescate."
        ],
        "answer": 0,
        "explanation": "El resultado solo describe esta evaluación teórica. No observa ejecución, terreno ni toma de decisiones presencial."
      },
      {
        "prompt": "Tras recordar el nombre de un nudo, ¿qué evidencia falta para considerarlo evaluado en la práctica?",
        "options": [
          "Una insignia digital.",
          "Una evaluación presencial con fecha, evaluador, contexto y observaciones.",
          "Haber visitado la página."
        ],
        "answer": 1,
        "explanation": "Recordar un nombre no demuestra selección, ejecución ni comprobación de un sistema. La academia exige evidencia presencial explícita."
      }
    ]
  }
}
---


## Conceptos
Esta academia usa tres niveles separados. **A: conocimiento teórico** registra lectura y respuestas. **B: práctica supervisada** necesita una actividad acompañada por una persona competente. **C: competencia evaluada** requiere una evaluación presencial registrada con fecha, evaluador, contexto y observaciones. Esta clasificación es una decisión editorial del proyecto, no una certificación de una institución externa.

La experiencia previa orienta el diagnóstico, pero no completa automáticamente ninguna casilla. Para retomar tu formación, escribe lo que puedes explicar hoy y lo que necesitas volver a observar o practicar. Un resultado teórico describe respuestas a preguntas concretas; no prueba desempeño con fatiga, exposición o responsabilidad sobre pasajeros.

| Evidencia | Lo que registra | Lo que no demuestra |
| --- | --- | --- |
| Lectura marcada | Declaración personal de estudio | Comprensión comprobada |
| Cuestionario | Respuestas a esa versión | Ejecución de una maniobra |
| Práctica supervisada | Actividad acompañada | Evaluación aprobada automáticamente |
| Evaluación presencial | Desempeño observado en un contexto | Competencia ilimitada o permanente |

## Ejemplo
Ejemplo hipotético para retomar la formación desde Puerto Montt: puedes describir qué es una reunión, pero no recuerdas cómo comprobar un montaje. Registra la brecha y prepara preguntas para un instructor; no uses una marca de lectura como evidencia de ejecución.

## Errores frecuentes
Confundir familiaridad con dominio; marcar todo como aprendido porque ya se vio en una carrera; ocultar dudas para mantener una imagen de experiencia. La propuesta de estudio aquí es registrar las dudas como tareas concretas.

## Límites
Esta lección explica el funcionamiento de la academia. No enseña una maniobra y no verifica títulos, registros profesionales ni habilitaciones. Las matrices prácticas y su historial presencial se desarrollarán en una etapa posterior.

## Caso de estudio
Una persona aprueba todas las preguntas sobre un descenso, pero no tiene una evaluación presencial reciente. ¿Qué podría mostrar al instructor? Sus resultados y preguntas. ¿Qué no debería inferir de ellos? Que está preparada para descender un pasajero.

## Recuperación activa
Sin mirar la tabla, explica la diferencia entre los tres niveles. Después identifica una habilidad que recuerdas conceptualmente y otra que necesitas revisar con supervisión.

## Ejercicio
En tus notas escribe: «Puedo explicar… / Necesito repasar… / Necesito observar o practicar con instructor…». Es un ejercicio de escritorio; no montes sistemas de cuerda para completarlo.

## Criterios de revisión
Tu respuesta debe separar los tres tipos de evidencia, identificar una brecha concreta y proponer una siguiente acción. Es una rúbrica de reflexión; no evalúa competencia práctica.

## Próximos pasos
Continúa con planificación. Para las técnicas críticas, utiliza el mapa curricular como lista de temas pendientes y acuerda práctica presencial con un instructor competente.
