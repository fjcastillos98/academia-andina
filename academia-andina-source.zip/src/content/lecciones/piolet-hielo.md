---
{
  "title": "Piolet técnico: colocación, carga y economía de movimiento",
  "description": "Diferenciar piolet de marcha y herramienta técnica sin extrapolar usos.",
  "module": "M05",
  "code": "E7-04",
  "order": 704,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U7-04",
  "skills": [
    "s7-piolet-hielo"
  ],
  "critical": true,
  "reviewDate": "2026-10-25",
  "objectives": [
    "Diferenciar piolet de marcha y herramienta técnica sin extrapolar usos.",
    "Explicar la relación entre colocación, equilibrio y esfuerzo."
  ],
  "prerequisites": [
    "s7-cramponaje-hielo"
  ],
  "sources": [
    "e7-accessbook",
    "e7-movement"
  ],
  "pending": [
    "Revisión de instructor de hielo pendiente; no se ha observado ni aprobado ninguna práctica.",
    "Compatibilidad y manual de los modelos personales pendientes de verificación; ninguna pieza se considera apta por aparecer en el inventario.",
    "El video técnico se verificó solo por su texto introductorio; revisión audiovisual completa con instructor pendiente."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una herramienta de marcha…",
        "options": [
          "Es automáticamente adecuada para hielo vertical.",
          "Sustituye tornillos si tiene hoja metálica.",
          "Necesita revisión de uso previsto antes de otro contexto."
        ],
        "answer": 2,
        "explanation": "El manual y el contexto son necesarios. Diferenciar piolet de marcha y herramienta técnica sin extrapolar usos.",
        "rationales": [
          "Los diseños y usos difieren.",
          "Compartir material no iguala funciones.",
          "El manual y el contexto son necesarios."
        ],
        "source": "e7-accessbook",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Más fuerza al golpear demuestra…",
        "options": [
          "Una colocación fiable.",
          "Solo mayor fuerza aplicada, no estabilidad demostrada.",
          "Un anclaje de reunión."
        ],
        "answer": 1,
        "explanation": "El resultado requiere evaluación contextual. Diferenciar piolet de marcha y herramienta técnica sin extrapolar usos.",
        "rationales": [
          "No valida la estructura ni la colocación.",
          "El resultado requiere evaluación contextual.",
          "Una colocación de progresión no es una reunión."
        ],
        "source": "e7-accessbook",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una cinta de retención debe…",
        "options": [
          "Tratarse según su función y manual.",
          "Usarse como aseguramiento por defecto.",
          "Considerarse irrompible."
        ],
        "answer": 0,
        "explanation": "No se debe inferir una función de protección. Diferenciar piolet de marcha y herramienta técnica sin extrapolar usos.",
        "rationales": [
          "No se debe inferir una función de protección.",
          "La función no se presume por su apariencia.",
          "Ningún componente permite esa garantía."
        ],
        "source": "e7-accessbook",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Distingue herramienta de progresión y protección.",
    "Controla herramienta y desplazamiento bajo observación presencial.",
    "Describe un error y una corrección observable sin atribuir capacidad universal."
  ],
  "openAssessment": {
    "prompt": "Dibuja una herramienta sin esquema operativo y etiqueta funciones. Añade una tabla: uso previsto documentado, uso supuesto y pregunta al instructor.",
    "rubric": [
      "Distingue herramienta de progresión y protección.",
      "Controla herramienta y desplazamiento bajo observación presencial.",
      "Describe un error y una corrección observable sin atribuir capacidad universal."
    ],
    "source": "e7-accessbook",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO. REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. El estudio y el quiz no acreditan una maniobra ni capacidad de guiado.**

## Conceptos clave y propósito

Herramienta, hoja, empuñadura, colocación, dirección de carga y coordinación.

## Teoría y toma de decisiones

Una herramienta para escalada en hielo y un piolet de marcha pueden compartir vocabulario sin tener el mismo diseño o usos previstos. La geometría, hoja y empuñadura forman un conjunto. Identificar la función del producto es el primer paso documental; poseer un piolet no demuestra que sea apropiado para el objetivo.

La técnica básica de Petzl integra colocaciones de herramientas con apoyos de pies y posición corporal. El objetivo educativo es reconocer cómo un movimiento desequilibrado puede aumentar esfuerzo y disminuir precisión. Golpear más fuerte no demuestra por sí mismo una colocación mejor ni diagnostica estabilidad del hielo. [Fuente de contraste](#fuente-e7-accessbook).

Hay que diferenciar una colocación que permite avanzar de un anclaje de protección. Una herramienta usada durante el movimiento no sustituye automáticamente a una protección diseñada para detener una caída. Tampoco una cinta de retención puede presumirse elemento de aseguramiento: su función y limitaciones pertenecen a su manual.

En un taller, el instructor observa preparación del movimiento, control de la herramienta, equilibrio, carga y retirada. El alumno debe poder explicar qué información le falta cuando una colocación resulta dudosa. La corrección no consiste solo en repetir más veces: debe identificar qué cambió y si el efecto se observó de nuevo en condiciones comparables.

## Procedimiento: función, comprobaciones y límites

**PROCEDIMIENTO — marco de análisis previo al taller.** Objetivo: Diferenciar piolet de marcha y herramienta técnica sin extrapolar usos. Se utiliza para preparar el aprendizaje y detectar vacíos antes de una tarea real. Identifica la función, los componentes, la información que falta y las consecuencias de un error. Contrasta la versión de la fuente con el modelo de equipo y el método del instructor. No hay una configuración universal derivada de esta página.

Las comprobaciones relevantes se desarrollan en la teoría, el equipo y la rúbrica de esta unidad. Si el uso previsto o la protección del taller no están claros, la práctica no se inicia. Las variantes de una fuente se conservan dentro de su contexto; no se mezclan pasos de métodos distintos por semejanza visual.

## Caso práctico y aplicación al guiado

**Escenario ficticio para análisis:** El grupo dispone de piolets Grivel G-Zero destinados a otra actividad y decide llamarlos «técnicos» por llevar hoja metálica. Redacta la comprobación documental necesaria sin afirmar que ese modelo sirve para hielo vertical.

Antes de responder, enumera los hechos dados y los datos que has supuesto. Propón una decisión provisional y una condición que te haría revisarla. El caso, los ejercicios y las rúbricas son propuestas pedagógicas originales de la academia, pendientes de revisión docente; no son un protocolo de un organismo citado.

## Errores frecuentes y puntos críticos de seguridad

Igualar herramienta a protección; atribuir resistencia de aseguramiento a un accesorio; usar fuerza excesiva como sustituto de lectura; comparar herramientas sin sus manuales.

No uses la ausencia de incidentes como prueba de seguridad. Las tareas con carga, herramientas o exposición necesitan control presencial competente. Ninguna respuesta escrita autoriza a escalar, montar un anclaje ni asistir a un pasajero.

## Material y equipo relacionado

Herramienta y hoja compatibles, manual y estado de componentes; casco y protección del taller. Los G-Zero del inventario no se declaran aptos para este bloque sin comprobar uso previsto.

[Consultar inventario](../../equipo/). Registra documento y revisión, sin inventar inspecciones realizadas. Tener material no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica con tus palabras: Diferenciar piolet de marcha y herramienta técnica sin extrapolar usos.
- ¿Qué observación del caso apoya tu decisión y qué dato sigue faltando?
- ¿Qué error de esta unidad podrías reconocer documentalmente y cuál exige observar la ejecución?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Dibuja una herramienta sin esquema operativo y etiqueta funciones. Añade una tabla: uso previsto documentado, uso supuesto y pregunta al instructor.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Taller protegido de manejo y movimiento preparado por instructor. Se revisan distancias entre participantes y trayectorias de herramientas. El instructor evalúa las colocaciones; el texto no enseña a probarlas mediante cargas improvisadas.

## Evidencia requerida y criterios de competencia

- Distingue herramienta de progresión y protección.
- Controla herramienta y desplazamiento bajo observación presencial.
- Describe un error y una corrección observable sin atribuir capacidad universal.

**COMPETENCIA:** estos criterios orientan la revisión. Cuando implican ejecución, el instructor debe observarla en un contexto definido, registrar resultado y lo que no se evaluó. No hay umbral automático de repeticiones, confianza o aciertos. La plataforma conserva una declaración personal y no verifica credenciales ni certifica.

## Registro de práctica

[Abrir diario de esta habilidad](../../practicas/?habilidad=s7-piolet-hielo). Registra solo tareas realmente realizadas: fecha, lugar, condiciones, habilidad, equipo, repeticiones, errores, correcciones, supervisor, evidencia y próxima acción. Mantén separados resultado observado, confianza y evaluación. No incluyas datos médicos ni datos privados de terceros.

## Relaciones con otros módulos

[Ruta invernal](../../invierno/), [formación glaciar](../../glaciar/), [encordamiento según contexto](../encordamiento-contexto/) y [anclajes y reuniones](../anclajes-reuniones/) aportan prerrequisitos. La aplicación alpina y el guiado requieren su propia formación y evaluación. [Volver a la secuencia de hielo](../../hielo/).
