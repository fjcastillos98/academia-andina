---
{
  "title": "Ecosistemas de Los Lagos: leer relaciones y escalas",
  "description": "Distingue ecosistema, hábitat y área administrativa con un ejemplo.",
  "module": "M15",
  "code": "E11-01",
  "order": 1101,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U11-01",
  "skills": [
    "s11-ecosistemas-los-lagos"
  ],
  "critical": false,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Distingue ecosistema, hábitat y área administrativa con un ejemplo.",
    "Separa observación, hipótesis y fuente documental."
  ],
  "prerequisites": [
    "s45-ecologia-los-lagos"
  ],
  "sources": [
    "e11-regional",
    "e11-puyehue",
    "e11-vpr"
  ],
  "pending": [
    "Revisión por especialista en ecología e instructor territorial pendiente. Los ejercicios no autorizan acceso, colecta o manejo de fauna.",
    "Categorías legales vigentes, protocolos de encuentro específicos y claves taxonómicas completas: requieren verificación.",
    "Casos, rúbricas y propuestas de práctica originales; no constituyen un protocolo oficial ni una certificación."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Una ficha de parque permite afirmar…",
        "options": [
          "Que cada sendero contiene todas las especies listadas.",
          "Que hay presencia documentada en el ámbito descrito.",
          "Que habrá avistamientos mañana."
        ],
        "answer": 1,
        "explanation": "Respeta el alcance de la fuente.",
        "rationales": [
          "La escala es distinta.",
          "Respeta el alcance de la fuente.",
          "Una lista no predice encuentros."
        ],
        "source": "e11-regional",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Una ladera sin árboles demuestra…",
        "options": [
          "Tala reciente.",
          "Ausencia de vida.",
          "Solo ausencia visible de árboles en esa observación."
        ],
        "answer": 2,
        "explanation": "No atribuye una causa sin comprobarla.",
        "rationales": [
          "Falta evidencia causal.",
          "Otros organismos pueden estar presentes.",
          "No atribuye una causa sin comprobarla."
        ],
        "source": "e11-regional",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Para interpretar una foto conviene registrar…",
        "options": [
          "Fecha, lugar general y límites.",
          "Solo su color.",
          "Una especie aunque no se distinga."
        ],
        "answer": 0,
        "explanation": "Da contexto al dato.",
        "rationales": [
          "Da contexto al dato.",
          "No identifica el ambiente por sí solo.",
          "Inventaría una identificación."
        ],
        "source": "e11-regional",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Distingue ecosistema, hábitat y área administrativa con un ejemplo.",
    "Separa observación, hipótesis y fuente documental.",
    "Explica por qué la escala limita una conclusión."
  ],
  "openAssessment": {
    "prompt": "Construye una tabla de cinco afirmaciones sobre un paisaje ficticio: observación, interpretación o dato documental; indica escala y límite de cada una.",
    "rubric": [
      "Distingue ecosistema, hábitat y área administrativa con un ejemplo.",
      "Separa observación, hipótesis y fuente documental.",
      "Explica por qué la escala limita una conclusión."
    ],
    "source": "e11-regional",
    "difficulty": "integración"
  },
  "diagrams": [
    "e11-evidencia"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ECOLÓGICA PENDIENTE.** Observación responsable para estudio personal. No acredita identificación taxonómica, competencia profesional ni autorización de acceso. No guardes datos médicos ni localizaciones precisas de especies sensibles.

## Conceptos clave y propósito

Ecosistema: organismos y medio físico en interacción. Hábitat: condiciones y recursos de un organismo. Comunidad: conjunto de poblaciones. Paisaje: mosaico de ambientes. Una unidad administrativa no es una unidad ecológica.

## Teoría y toma de decisiones

La primera tarea de interpretación no es enumerar especies: es explicar qué observas, a qué escala y con qué evidencia. Una ficha de parque delimita un área, mientras una observación describe un lugar y momento. No son intercambiables. CONAF documenta bosques y ambientes de altura en Puyehue y Vicente Pérez Rosales; estas descripciones son puntos de partida, no un inventario de cada sendero.

Para estudiar un paisaje separa componentes físicos (sustrato, agua, relieve, exposición), estructura visible (dosel, sotobosque, suelo cubierto) y señales biológicas. Después plantea relaciones como hipótesis. Ver un sector húmedo con abundante cobertura vegetal permite describir coexistencia; atribuirla exclusivamente a una causa requeriría más observaciones. El vocabulario evita convertir una explicación plausible en un hecho local demostrado.

Un recorrido regional puede cruzar varios ambientes sin que exista una cota única que los separe. La exposición y la historia de perturbaciones hacen insuficiente una regla basada solo en altitud. Trabaja con un croquis conceptual, conserva la fuente del nombre del ambiente y marca aquello que requiere comprobación. Para un guía, reconocer lo que falta conocer es parte de una interpretación responsable.

Referencias de esta unidad: [Fuente 1](#fuente-e11-regional) · [Fuente 2](#fuente-e11-puyehue) · [Fuente 3](#fuente-e11-vpr). Los casos y las aplicaciones pedagógicas que siguen son elaboración original; no se atribuyen como protocolos de las fuentes.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — observación y decisión:** Objetivo: describir un paisaje sin sobreinterpretarlo. Delimita el área y la fecha; registra tres rasgos visibles; compara una fuente de escala compatible; separa hechos e hipótesis. Variante: revisión de fotografías con autoría y contexto frente a observación directa. Límite: una imagen no representa todas las estaciones.

No manipules fauna, no recolectes material y no salgas del itinerario autorizado para completar el ejercicio. La conducción real y las maniobras técnicas requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Dos fotografías muestran bosque y una ladera abierta. Un visitante concluye que el segundo sector fue talado. ¿Qué otras explicaciones y evidencias faltan antes de afirmarlo?

## Errores frecuentes y puntos críticos de seguridad

Confundir región con ecosistema; llamar degradado a todo terreno abierto; usar un mapa general como inventario puntual. No abandones el itinerario para completar un registro.

## Material y equipo relacionado

Cuaderno, lápiz, mapa de referencia y cámara sin necesidad de geolocalización. El GPS de navegación sirve al itinerario; no es necesario publicar coordenadas biológicas.

[Revisar inventario](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica cómo comprobarías este criterio: Distingue ecosistema, hábitat y área administrativa con un ejemplo.
- Explica cómo comprobarías este criterio: Separa observación, hipótesis y fuente documental.
- Explica cómo comprobarías este criterio: Explica por qué la escala limita una conclusión.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Construye una tabla de cinco afirmaciones sobre un paisaje ficticio: observación, interpretación o dato documental; indica escala y límite de cada una.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Con especialista territorial, comparar dos ambientes desde un recorrido permitido y revisar las inferencias sin colectar organismos.

## Evidencia requerida y criterios de competencia

- Distingue ecosistema, hábitat y área administrativa con un ejemplo.
- Separa observación, hipótesis y fuente documental.
- Explica por qué la escala limita una conclusión.

**COMPETENCIA:** requiere observación y revisión humana en contexto. Una lectura, registro o quiz no certifica guiado, identificación experta ni maniobras. La plataforma no verifica credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s11-ecosistemas-los-lagos) y [cuaderno de observación](../../ecologia/#observaciones). Separa ejercicio ficticio, observación real y práctica evaluada. Registra errores, correcciones, supervisor y evidencia sin inventar resultados. Mantén áreas generales; el texto libre no filtra automáticamente ubicaciones sensibles.

## Relaciones con otros módulos

[Ecología](../../ecologia/) · [Fichas de especies](../../especies/) · [Territorio](../../territorio/) · [Planificación](../../planificacion/) · [Programa](../../programa/). La interpretación ambiental se relaciona con geología, cartografía, gestión de grupos y patrimonio, sin sustituir su formación específica.
