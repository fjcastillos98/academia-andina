---
{
  "title": "Frío: balance térmico, signos y decisiones",
  "description": "Explicar mecanismos de intercambio térmico y respuestas del organismo.",
  "module": "M12",
  "code": "E5-26",
  "order": 525,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-23",
  "skills": [
    "s5-frio-fisiologia"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Explicar mecanismos de intercambio térmico y respuestas del organismo.",
    "Reconocer señales que requieren protección y evaluación médica.",
    "Distinguir wind chill, temperatura ambiental y temperatura corporal."
  ],
  "prerequisites": [
    "s5-grupo-invernal"
  ],
  "sources": [
    "e5-frio-cdc",
    "e5-nws-cold",
    "e5-heat-openstax"
  ],
  "pending": [
    "Revisión de instructor y contraste con manuales exactos del equipo disponible. Cualquier aplicación territorial permanece pendiente de reconocimiento y condiciones actuales."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Ropa mojada con aire sobre cero excluye hipotermia. ¿Es correcto?",
        "options": [
          "Sí, solo ocurre bajo cero.",
          "No, humedad y exposición también importan.",
          "Sí, si la persona camina."
        ],
        "answer": 1,
        "explanation": "La temperatura del aire no es el único determinante.",
        "rationales": [
          "Excluye situaciones descritas por CDC.",
          "Integra exposición y pérdidas.",
          "Actividad no garantiza balance térmico."
        ],
        "source": "e5-frio-cdc",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Wind chill de −11 °C significa…",
        "options": [
          "Temperatura corporal de −11 °C.",
          "Que una botella necesariamente llega a −11 °C.",
          "Un índice de enfriamiento bajo condiciones del modelo."
        ],
        "answer": 2,
        "explanation": "El índice no es temperatura de todo objeto o persona.",
        "rationales": [
          "Confunde variables.",
          "El viento no enfría el objeto bajo el aire por sí solo.",
          "Respeta su alcance."
        ],
        "source": "e5-nws-cold",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Contacto directo con nieve se relaciona especialmente con…",
        "options": [
          "Conducción.",
          "Solo radiación solar.",
          "Ningún intercambio térmico."
        ],
        "answer": 0,
        "explanation": "El contacto permite transferencia térmica.",
        "rationales": [
          "Identifica el mecanismo.",
          "Omite el contacto.",
          "Niega intercambio físico."
        ],
        "source": "e5-heat-openstax",
        "difficulty": "intermedia",
        "kind": "aplicación"
      }
    ]
  },
  "preparation": [
    "Relaciona exposición con mecanismos sin porcentajes universales.",
    "Reconoce señales y solicita evaluación/apoyo apropiados.",
    "No transforma un índice ambiental en diagnóstico o plazo individual."
  ],
  "openAssessment": {
    "prompt": "Analiza un caso ficticio de frío, viento y humedad: identifica mecanismos, signos que cambiarían la decisión y límites de tu formación WFR.",
    "rubric": [
      "Relaciona exposición con mecanismos sin porcentajes universales.",
      "Reconoce señales y solicita evaluación/apoyo apropiados.",
      "No transforma un índice ambiental en diagnóstico o plazo individual."
    ],
    "source": "e5-frio-cdc",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-capas"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Reconoce cambios respecto del estado previo: destreza, comunicación, marcha y conducta. Describe signos y ambiente; no deduzcas temperatura central de la sensación térmica.

## Teoría y toma de decisiones

La termorregulación mantiene el balance entre producción y pérdida de calor. El metabolismo aporta calor; ante enfriamiento, respuestas como temblor y reducción de circulación periférica pueden ayudar a conservarlo, pero no garantizan que el balance se sostenga. OpenStax describe termorregulación y mecanismos de intercambio [fuente](#fuente-e5-heat-openstax). No se asigna un porcentaje universal de pérdida a cada vía: ropa, humedad, viento, actividad y contacto cambian el escenario.

Conducción es intercambio por contacto; convección implica movimiento de aire o agua junto al cuerpo; radiación intercambia energía sin contacto; evaporación requiere energía para que agua pase a vapor. En un ejercicio, identifica qué mecanismos intervienen cuando una persona se sienta en nieve, permanece con ropa mojada o queda expuesta al viento. Varias vías actúan simultáneamente. Una capa exterior puede limitar una influencia mientras el aislamiento insuficiente deja otra sin resolver.

Hipotermia afecta la temperatura corporal y puede comprometer pensamiento y movimiento. El CDC señala que también puede ocurrir con exposición húmeda a temperaturas ambientales no extremas. Temblor, agotamiento, torpeza, confusión, alteración del habla o somnolencia son señales relevantes [fuente](#fuente-e5-frio-cdc). No hay que esperar a medir una temperatura para reconocer un problema que requiere protección, evaluación y ayuda. A la vez, estos signos no autorizan a inventar un diagnóstico exacto ni a excluir otras causas.

Congelación es lesión local por congelación de tejidos; no es sinónimo de hipotermia. Cambios de color, pérdida de sensibilidad o aspecto anormal pueden exigir atención. También existen lesiones por frío sin congelación, que esta introducción no diagnostica. La respuesta debe seguir formación WFR y orientación médica apropiada. Se evita reproducir un algoritmo de recalentamiento, medicación o evacuación; el objetivo es detectar, proteger de exposición adicional y coordinar atención sin demoras injustificadas.

El índice wind chill del NWS expresa enfriamiento asociado a viento y temperatura para piel expuesta, dentro del dominio de su modelo [fuente](#fuente-e5-nws-cold). No representa temperatura interna, ni hace que un objeto se enfríe por debajo de la temperatura ambiente, ni predice un plazo individual de supervivencia. En el laboratorio se convierten unidades antes de calcular. Un número correcto no permite decidir cuánto tiempo puede seguir un pasajero con ropa mojada.

Prevención incluye organizar capas y reservas para cambios de esfuerzo, humedad y pausas. Alimentación e hidratación forman parte de la planificación, sin prescribir aquí cantidades ni asumir que comer corrige un deterioro clínico. El guía debe poder reconocer cambios de funcionamiento y comunicar observaciones concretas. En el diario registra aprendizaje de un caso ficticio o práctica, evitando datos médicos de pasajeros. La rúbrica evalúa si distingues mecanismo, señal, incertidumbre y acción dentro de tu formación. La competencia de atención exige prácticas y evaluación presencial, independiente de este quiz.

## Qué observo, qué significa y qué no puedo concluir

Contenido educativo relacionado con WFR. No reemplaza evaluación médica ni entrenamiento de primeros auxilios. No utilizar como única preparación para una emergencia.

## Caso práctico y aplicación al guiado

Con aire por encima de cero, una persona mojada pierde destreza y se muestra confusa. Explica por qué descartar enfriamiento por no haber helada sería incorrecto.

## Errores frecuentes y señales de alerta

Esperar signos graves; confundir congelación e hipotermia; convertir wind chill en temperatura corporal; presentar comida o ejercicio como tratamiento suficiente.

## Autoevaluación y respuesta razonada

Analiza un caso ficticio de frío, viento y humedad: identifica mecanismos, signos que cambiarían la decisión y límites de tu formación WFR.

## Ejercicios y práctica supervisada

Caso de escritorio y taller WFR con instructor: reconocer cambios, describir exposición y comunicar necesidades. No provocar enfriamiento real para practicar.

## Evidencia requerida

- Relaciona exposición con mecanismos sin porcentajes universales.
- Reconoce señales y solicita evaluación/apoyo apropiados.
- No transforma un índice ambiental en diagnóstico o plazo individual.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-frio-fisiologia).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
