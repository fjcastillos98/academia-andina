---
{
  "title": "Nutrición deportiva: sostener el trabajo y la recuperación",
  "description": "Relacionar disponibilidad de alimentos, carga y recuperación sin prescribir una dieta.",
  "module": "M22",
  "code": "E10-13",
  "order": 1013,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U10-13",
  "skills": [
    "s10-nutricion-entrenamiento"
  ],
  "critical": true,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Relacionar disponibilidad de alimentos, carga y recuperación sin prescribir una dieta.",
    "Aplicar el concepto a una decisión de preparación de montaña y reconocer sus límites."
  ],
  "prerequisites": [
    "s10-recuperacion-sueno"
  ],
  "sources": [
    "e10-nutrition"
  ],
  "pending": [
    "Revisión por profesional del ejercicio e instructor de montaña pendiente. Nutrición y salud requieren revisión profesional específica; no se ha evaluado aptitud personal.",
    "Los casos y rúbricas son propuestas pedagógicas originales. La aplicación individual requiere evaluación, técnica y seguimiento.",
    "No se atribuyen requisitos de certificación, umbrales universales ni preparación técnica a los resultados físicos."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Las calorías de un reloj…",
        "options": [
          "Son estimaciones, no una receta individual.",
          "Definen exactamente la ingesta.",
          "Garantizan balance energético."
        ],
        "answer": 0,
        "explanation": "Tienen incertidumbre y falta contexto.",
        "rationales": [
          "Tienen incertidumbre y falta contexto.",
          "No son medición suficiente.",
          "No permiten esa garantía."
        ],
        "source": "e10-nutrition",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "La nutrición específica incluye…",
        "options": [
          "Solo suplementos.",
          "Ensayar acceso y preparación en la actividad.",
          "Eliminar comidas por falta de tiempo."
        ],
        "answer": 1,
        "explanation": "La logística afecta consumo real.",
        "rationales": [
          "No sustituye alimentación.",
          "La logística afecta consumo real.",
          "Debe revisarse la organización."
        ],
        "source": "e10-nutrition",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Los macros personales se diseñan…",
        "options": [
          "Copiando a otro deportista.",
          "Por el tamaño de mochila.",
          "Con evaluación profesional e individual."
        ],
        "answer": 2,
        "explanation": "Es el contexto adecuado.",
        "rationales": [
          "Las necesidades difieren.",
          "No describe la demanda completa.",
          "Es el contexto adecuado."
        ],
        "source": "e10-nutrition",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Relaciona alimentación y demanda.",
    "Propone organización viable.",
    "No prescribe a partir de un reloj."
  ],
  "openAssessment": {
    "prompt": "Diseña una lista de preparación de alimentos para un día ficticio y una alternativa de transporte.",
    "rubric": [
      "Relaciona alimentación y demanda.",
      "Propone organización viable.",
      "No prescribe a partir de un reloj."
    ],
    "source": "e10-nutrition",
    "difficulty": "integración"
  },
  "diagrams": []
}
---

**TEORÍA EN DESARROLLO · REVISIÓN PROFESIONAL PENDIENTE.** Este contenido no prescribe un programa individual ni acredita competencia técnica. Los ejercicios numéricos y casos son ficticios. No introduzcas datos médicos, mediciones corporales privadas ni antecedentes de terceros.

## Conceptos clave y propósito

Energía, carbohidratos, proteínas, grasas, hidratación y logística alimentaria.

## Teoría y toma de decisiones

La nutrición deportiva se organiza alrededor de la actividad, recuperación y necesidades individuales. Los carbohidratos aportan combustible, la proteína participa en reparación y adaptación y las grasas cumplen funciones energéticas y estructurales. No existe una distribución única para todas las sesiones y personas. [Posición sobre nutrición deportiva](#fuente-e10-nutrition).

La preparación general incluye hábitos y acceso regular a comida; la específica ensaya alimentos, transporte y preparación que podrán usarse en montaña. El problema puede ser logístico antes que matemático: una ración inaccesible durante la jornada no se consume por aparecer en una planilla.

En el caso original, el horario obliga a salir sin comida preparada y la sesión se alarga. El ejercicio reorganiza compras, preparación y acceso, sin calcular un déficit ni compensar con suplementos. Las calorías estimadas por un reloj no determinan cuánto debe comer una persona.

El diseño individual de ingesta, restricciones y necesidades clínicas corresponde a nutricionista y otros profesionales cuando proceda. Esta lección no introduce datos corporales ni prescribe macros. Los suplementos no se asumen necesarios, eficaces o libres de riesgos por su publicidad.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — preparación del aprendizaje:** Revisa con profesional objetivos y demandas. En el ejercicio, planifica acceso antes, durante y después de una sesión ficticia y una alternativa si el horario cambia. No uses restricción alimentaria como ejercicio ni extrapoles necesidades de otro atleta.

La selección real de ejercicios, cargas, pruebas y progresión corresponde a una evaluación individual con profesionales. Las técnicas críticas de montaña requieren formación práctica y supervisión de instructor competente. El acondicionamiento físico no autoriza una maniobra.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Una persona ficticia prepara el equipo pero no reserva tiempo para comida. Propón cambios de organización que no dependan de una cifra de calorías.

Distingue dato, interpretación y decisión. Explica qué incertidumbre permanece. Los casos no representan un protocolo del organismo citado ni un criterio oficial de habilitación para guía.

## Errores frecuentes y puntos críticos de seguridad

Usar el reloj como receta; confundir suplemento y base alimentaria; ignorar acceso y preparación; copiar macros de otra persona.

## Material y equipo relacionado

Recipientes y raciones ensayadas, agua y medios de preparación. El inventario es logístico, no una receta clínica.

[Consultar inventario](../../equipo/). Ajustar o poseer el equipo no demuestra dominarlo. Las prácticas técnicas se registran por separado del acondicionamiento.

## Autoevaluación y recuperación activa

- Explica la diferencia entre la capacidad que estudias y una tarea técnica de montaña.
- ¿Qué información falta en el caso y qué decisión modificaría?
- ¿Qué parte puede analizarse en escritorio y cuál necesita observación profesional?

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Diseña una lista de preparación de alimentos para un día ficticio y una alternativa de transporte.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Taller de logística con revisión por nutricionista para cualquier adaptación individual.

## Evidencia requerida y criterios de competencia

- Relaciona alimentación y demanda.
- Propone organización viable.
- No prescribe a partir de un reloj.

**COMPETENCIA:** estos criterios describen aprendizaje que debe observar un profesional en contexto. No acreditan aptitud médica, entrenamiento personal, guiado ni maniobra técnica. Una lectura, prueba física o quiz no otorga certificación. Marca pendiente lo que no se haya evaluado.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s10-nutricion-entrenamiento). Registra fecha, actividad, escenario, equipo, objetivo, errores, correcciones, supervisor y evidencia de aprendizaje. No guardes datos médicos ni contraseñas. No inventes sesiones, evaluaciones o repeticiones para completar la matriz.

## Relaciones con otros módulos

[Entrenamiento](../../entrenamiento/) · [Altitud](../../altitud/) · [Plan de salida](../../planificacion/) · [Programa](../../programa/). Entrenamiento general, preparación específica, aclimatación y competencia técnica se relacionan, pero no son equivalentes.
