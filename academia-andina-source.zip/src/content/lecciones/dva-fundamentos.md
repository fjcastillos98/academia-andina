---
{
  "title": "DVA: transmisión, búsqueda y comprobaciones",
  "description": "Distinguir emisión y recepción de un DVA de la comunicación por radio o satélite.",
  "module": "M09",
  "code": "E5-08",
  "order": 507,
  "minutes": 35,
  "level": "Intermedio",
  "status": "development",
  "unit": "U5-08",
  "skills": [
    "s5-dva-fundamentos"
  ],
  "critical": true,
  "reviewDate": "2026-10-22",
  "objectives": [
    "Distinguir emisión y recepción de un DVA de la comunicación por radio o satélite.",
    "Preparar una revisión documental y funcional del modelo exacto.",
    "Explicar la cadena de búsqueda, localización, excavación y atención."
  ],
  "prerequisites": [
    "s5-boletines-avalancha"
  ],
  "sources": [
    "e5-barryvox-manual",
    "e5-icar-dva",
    "e5-bd-interferencia"
  ],
  "pending": [
    "Modelo del DVA personal y avisos del fabricante: PENDIENTE DE VERIFICACIÓN."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "¿Qué hace un DVA en emisión?",
        "options": [
          "Emite una señal localizable por un receptor compatible.",
          "Llama automáticamente a una central de rescate.",
          "Pronostica estabilidad del manto."
        ],
        "answer": 0,
        "explanation": "Emisión y comunicaciones externas son funciones diferentes.",
        "rationales": [
          "Describe su función.",
          "Confunde DVA con comunicación satelital.",
          "No es un instrumento nivológico."
        ],
        "source": "e5-barryvox-manual",
        "difficulty": "intermedia",
        "kind": "conocimiento"
      },
      {
        "prompt": "¿Qué demuestra ver la pantalla encendida?",
        "options": [
          "Que el usuario está capacitado.",
          "Que el aparato muestra alimentación, sin completar todas las comprobaciones.",
          "Que cualquier pila será válida."
        ],
        "answer": 1,
        "explanation": "La pantalla es evidencia limitada.",
        "rationales": [
          "Capacidad exige práctica.",
          "Aún falta modo y funcionamiento.",
          "El fabricante especifica alimentación."
        ],
        "source": "e5-icar-dva",
        "difficulty": "intermedia",
        "kind": "errores"
      },
      {
        "prompt": "¿Cómo abordar una VHF junto al DVA?",
        "options": [
          "Suponer que son compatibles por ser de montaña.",
          "Fijar una distancia inventada.",
          "Revisar interferencias y recomendaciones de los equipos para cada modo."
        ],
        "answer": 2,
        "explanation": "La proximidad de electrónica merece gestión explícita.",
        "rationales": [
          "La categoría comercial no elimina interferencia.",
          "No hay base para un valor arbitrario.",
          "Usa documentación y contexto."
        ],
        "source": "e5-bd-interferencia",
        "difficulty": "intermedia",
        "kind": "decisiones"
      }
    ]
  },
  "preparation": [
    "Identifica modos y funciones sin atribuir llamada de emergencia al DVA.",
    "Encuentra en su manual baterías, comprobación e interferencias y declara lo que desconoce.",
    "Explica por qué un chequeo o quiz no acredita rescate."
  ],
  "openAssessment": {
    "prompt": "Construye una lista razonada de evidencias necesarias antes de aceptar que el DVA propio está preparado para una práctica.",
    "rubric": [
      "Identifica modos y funciones sin atribuir llamada de emergencia al DVA.",
      "Encuentra en su manual baterías, comprobación e interferencias y declara lo que desconoce.",
      "Explica por qué un chequeo o quiz no acredita rescate."
    ],
    "source": "e5-barryvox-manual",
    "difficulty": "integración"
  },
  "diagrams": [
    "e5-dva-partes",
    "e5-dva-flujo"
  ]
}
---

**CONTENIDO TEÓRICO — REQUIERE PRÁCTICA PRESENCIAL Y SUPERVISIÓN DE INSTRUCTOR COMPETENTE. NO UTILIZAR ESTA LECCIÓN COMO ÚNICA PREPARACIÓN PARA UNA SITUACIÓN REAL DE EMERGENCIA.**

## Conceptos clave y propósito

Reconocer en el aparato propio el modo mostrado, estado del seguro, avisos y referencia de manual; no memorizar una imagen genérica.

## Teoría y toma de decisiones

Un DVA es un dispositivo de búsqueda de víctimas de avalancha: durante la actividad emite una señal para que otros equipos compatibles puedan localizarlo; en búsqueda recibe y procesa señales. No transmite una solicitud de rescate a una central ni permite conversar. Un InReach, un GPS o una VHF cumplen otras funciones y no reemplazan al DVA. En el manual Barryvox consultado se identifica la frecuencia 457 kHz y la compatibilidad con equipos conformes a EN 300 718; eso no significa que todos los menús, alarmas y funciones sean iguales. [Manual del ejemplo](#fuente-e5-barryvox-manual).

La preparación empieza identificando qué aparato se tiene, no suponiendo que la palabra ARVA describe un modelo concreto. Localiza selector y seguro, pantalla, altavoz, indicador de batería, sistema de porte y compartimento de alimentación. Explica qué indica cada uno y qué no demuestra. Un icono de batería no verifica por sí solo transmisión adecuada, estado del selector, integridad de antenas ni capacidad de búsqueda del usuario. El encendido y la prueba automática son una parte; la comprobación funcional y de grupo añade evidencia entre aparatos. Tipo de pila, umbral de reemplazo, almacenamiento y servicio se obtienen del manual, sin mezclar criterios de modelos distintos.

El alcance no es un círculo garantizado dibujado alrededor del usuario. La orientación relativa, interferencias, aparato y condiciones afectan a la recepción. Una cifra comercial máxima tampoco es el ancho de banda que debe aplicarse sin cambios en una búsqueda. Black Diamond documenta que electrónica y objetos cercanos pueden alterar el desempeño. Las medidas difieren entre emisión y búsqueda; se revisan también teléfono, reloj, radio, prendas calefactadas y otros dispositivos. [Interferencias](#fuente-e5-bd-interferencia). La lección no fija una separación universal: exige reconocer posibles fuentes, consultar instrucciones y entrenar una respuesta a lecturas anómalas.

ICAR recomienda evaluar el funcionamiento antes del uso, después de un daño y mantener la práctica; registrar equipo no equivale a demostrar capacidad. [Criterio institucional](#fuente-e5-icar-dva). En el inventario personal registra modelo y manual, intervenciones y defectos. Si se detecta funcionamiento dudoso, eso exige retirar el equipo del servicio para evaluación según fabricante, no ocultar el aviso para continuar el programa. La conservación del registro permite distinguir un chequeo realizado de uno que simplemente estaba previsto.

La cadena conceptual del rescate incluye evaluar escena, organizar funciones y modos, buscar señal, aproximarse, acotar la posición, confirmar mediante sonda, excavar y atender. Primaria, secundaria y fina son palabras usadas por algunas escuelas; señal, aproximación y búsqueda fina explican mejor qué problema se intenta resolver. La atención y la coordinación externa no esperan a que un programa complete una lista: su organización depende de seguridad, recursos y formación. Aprender los nombres permite comunicar una fase; no permite inferir que la escena admite entrada.

Ejercicio de mesa: recibes tres tarjetas ficticias: «pantalla encendida», «compañero confirma recepción» y «manual de otro modelo». Clasifícalas como evidencia limitada, evidencia funcional parcial y documento incorrecto. Diseña una ficha con modelo, revisión, resultado observado y duda pendiente. Luego explica a un pasajero por qué llevarlo apagado o en un modo incorrecto anula la función esperada, y por qué llevarlo correctamente tampoco evita una avalancha. El resultado de aprendizaje es una explicación verificable, no una autorización para conducir personas por terreno de avalancha.

## Qué observo, qué significa y qué no puedo concluir

No conocer modelo y revisión impide especificar pilas, intervalos, distancias y mandos. Un chequeo no garantiza funcionamiento futuro.

## Caso práctico y aplicación al guiado

Un pasajero ofrece su GPS como reemplazo del DVA y otro muestra una pantalla encendida sin confirmar el modo. Explica dos funciones diferentes y la comprobación que falta.

## Errores frecuentes y señales de alerta

Confundir DVA con baliza satelital; comprobar solo porcentaje; extrapolar el manual; ignorar interferencias y avisos.

## Autoevaluación y respuesta razonada

Construye una lista razonada de evidencias necesarias antes de aceptar que el DVA propio está preparado para una práctica.

## Ejercicios y práctica supervisada

Taller presencial de identificación y chequeo cruzado con instructor, equipos de entrenamiento y fuera de terreno de avalancha. No enterrar personas.

## Evidencia requerida

- Identifica modos y funciones sin atribuir llamada de emergencia al DVA.
- Encuentra en su manual baterías, comprobación e interferencias y declara lo que desconoce.
- Explica por qué un chequeo o quiz no acredita rescate.

Registra únicamente prácticas realizadas: contexto, supervisor, equipo, resultado, errores y correcciones. [Abrir diario](../../practicas/?habilidad=s5-dva-fundamentos).

## Relaciones con etapas anteriores y próximos pasos

Revisa los fundamentos que afectan a esta decisión: [riesgo decisiones](../riesgo-decisiones/), [carta brujula](../carta-brujula/), [pronostico decision](../pronostico-decision/), [grupo liderazgo](../grupo-liderazgo/), [equipamiento](../equipamiento/). La secuencia teórica no demuestra capacidad de ejecución. [Ruta invernal](../../invierno/).
