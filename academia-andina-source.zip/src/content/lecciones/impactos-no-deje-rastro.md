---
{
  "title": "Impactos del turismo y No Deje Rastro: decidir antes de actuar",
  "description": "Relaciona una acción turística con un impacto acumulativo.",
  "module": "M15",
  "code": "E11-09",
  "order": 1109,
  "minutes": 30,
  "level": "Fundamentos",
  "status": "development",
  "unit": "U11-09",
  "skills": [
    "s11-impactos-no-deje-rastro"
  ],
  "critical": false,
  "reviewDate": "2026-10-26",
  "objectives": [
    "Relaciona una acción turística con un impacto acumulativo.",
    "Distingue principio educativo de permiso local."
  ],
  "prerequisites": [
    "s11-fauna-conducta"
  ],
  "sources": [
    "e11-ndr"
  ],
  "pending": [
    "Revisión por especialista en ecología e instructor territorial pendiente. Los ejercicios no autorizan acceso, colecta o manejo de fauna.",
    "Categorías legales vigentes, protocolos de encuentro específicos y claves taxonómicas completas: requieren verificación.",
    "Casos, rúbricas y propuestas de práctica originales; no constituyen un protocolo oficial ni una certificación."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un principio general de mínimo impacto…",
        "options": [
          "Autoriza siempre una fogata pequeña.",
          "Reemplaza un cierre.",
          "Debe aplicarse junto a las reglas del lugar."
        ],
        "answer": 2,
        "explanation": "Reconoce el marco local.",
        "rationales": [
          "No otorga permiso.",
          "Un cierre no se anula por el principio.",
          "Reconoce el marco local."
        ],
        "source": "e11-ndr",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Biodegradable significa…",
        "options": [
          "Que puede dejarse en cualquier sitio.",
          "Que no determina por sí solo una disposición adecuada.",
          "Que nunca altera el entorno."
        ],
        "answer": 1,
        "explanation": "La gestión depende del contexto y reglas.",
        "rationales": [
          "El origen orgánico no autoriza abandono.",
          "La gestión depende del contexto y reglas.",
          "Puede producir efectos."
        ],
        "source": "e11-ndr",
        "difficulty": "intermedia",
        "kind": "aplicación"
      },
      {
        "prompt": "Evaluar impactos acumulativos exige…",
        "options": [
          "Considerar repetición y concentración de uso.",
          "Mirar solo una acción aislada.",
          "Valorar únicamente la intención."
        ],
        "answer": 0,
        "explanation": "Incluye la presión agregada.",
        "rationales": [
          "Incluye la presión agregada.",
          "Omite parte del problema.",
          "La buena intención no elimina el efecto."
        ],
        "source": "e11-ndr",
        "difficulty": "intermedia",
        "kind": "caso"
      }
    ]
  },
  "preparation": [
    "Relaciona una acción turística con un impacto acumulativo.",
    "Distingue principio educativo de permiso local.",
    "Propone prevención y revisión con responsables definidos."
  ],
  "openAssessment": {
    "prompt": "Completa una matriz de tres acciones: impacto posible, medida preventiva, responsable, regla por consultar e indicador de revisión.",
    "rubric": [
      "Relaciona una acción turística con un impacto acumulativo.",
      "Distingue principio educativo de permiso local.",
      "Propone prevención y revisión con responsables definidos."
    ],
    "source": "e11-ndr",
    "difficulty": "integración"
  },
  "diagrams": [
    "e11-impacto"
  ]
}
---

**TEORÍA EN DESARROLLO · REVISIÓN ECOLÓGICA PENDIENTE.** Observación responsable para estudio personal. No acredita identificación taxonómica, competencia profesional ni autorización de acceso. No guardes datos médicos ni localizaciones precisas de especies sensibles.

## Conceptos clave y propósito

Impacto acumulativo, pisoteo, erosión, residuos, ruido y medidas de prevención. Los siete principios de Leave No Trace son un marco educativo; no sustituyen permisos, cierres ni reglas del lugar.

## Teoría y toma de decisiones

El marco Leave No Trace abarca preparación, selección de superficies, residuos, conservación de lo encontrado, fuego, fauna y consideración hacia otras personas. Aquí se estudia mediante casos originales y atribución; no como licencia para aplicar una misma receta en cualquier área protegida.

Un acto pequeño puede repetirse por muchos visitantes. El análisis debe incluir frecuencia, concentración espacial y posibilidad de recuperación, no solo la intención de una persona. El atajo que parece ahorrar unos pasos puede generar una nueva huella si el grupo lo repite. Observa el efecto y consulta las indicaciones del área antes de elegir alternativas.

Al planificar, decide cómo reducir residuos y qué harás si un servicio previsto no existe. No se ofrece una profundidad universal para enterrar desechos ni autorización genérica de fogata: el sitio, su normativa y sus condiciones pueden impedir esas prácticas. Una regla local más restrictiva prevalece sobre un ejemplo educativo general. El éxito de la actividad incluye el cuidado del lugar y la convivencia, además de completar el recorrido.

Referencias de esta unidad: [Fuente 1](#fuente-e11-ndr). Los casos y las aplicaciones pedagógicas que siguen son elaboración original; no se atribuyen como protocolos de las fuentes.

## Procedimiento: objetivo, comprobaciones y variantes

**PROCEDIMIENTO — observación y decisión:** Identifica actividad, receptor y posible impacto; verifica regla local; elige prevención; asigna responsable; revisa después. Variante: sitio con infraestructura frente a sitio sin ella; la ausencia de instalaciones no autoriza improvisar eliminación de residuos.

No manipules fauna, no recolectes material y no salgas del itinerario autorizado para completar el ejercicio. La conducción real y las maniobras técnicas requieren formación práctica y supervisión de instructor competente.

## Caso práctico y aplicación al guiado

**Escenario ficticio:** Un grupo propone dispersarse fuera del sendero para evitar un charco y dejar cáscaras porque son biodegradables. Analiza ambas decisiones sin asumir que biodegradable significa inocuo en ese sitio.

## Errores frecuentes y puntos críticos de seguridad

Confundir reducir impacto con ausencia de impacto; justificar residuos orgánicos; improvisar fuego; copiar una práctica de otro país sin revisar reglas locales.

## Material y equipo relacionado

Recipientes y bolsas para gestionar residuos, equipamiento permitido y plan de contingencia. La disponibilidad de un hornillo tampoco reemplaza las restricciones del área.

[Revisar inventario](../../equipo/). Poseer equipo no demuestra saber utilizarlo.

## Autoevaluación y recuperación activa

- Explica cómo comprobarías este criterio: Relaciona una acción turística con un impacto acumulativo.
- Explica cómo comprobarías este criterio: Distingue principio educativo de permiso local.
- Explica cómo comprobarías este criterio: Propone prevención y revisión con responsables definidos.

## Ejercicios y práctica supervisada

**PRÁCTICA INDIVIDUAL — escritorio:** Completa una matriz de tres acciones: impacto posible, medida preventiva, responsable, regla por consultar e indicador de revisión.

**PRÁCTICA SUPERVISADA — propuesta pendiente:** Inspección educativa del recorrido con responsable autorizado, sin abrir huellas ni realizar pruebas de impacto. Discutir alternativas sobre escenarios existentes.

## Evidencia requerida y criterios de competencia

- Relaciona una acción turística con un impacto acumulativo.
- Distingue principio educativo de permiso local.
- Propone prevención y revisión con responsables definidos.

**COMPETENCIA:** requiere observación y revisión humana en contexto. Una lectura, registro o quiz no certifica guiado, identificación experta ni maniobras. La plataforma no verifica credenciales del evaluador.

## Registro de práctica

[Diario de esta habilidad](../../practicas/?habilidad=s11-impactos-no-deje-rastro) y [cuaderno de observación](../../ecologia/#observaciones). Separa ejercicio ficticio, observación real y práctica evaluada. Registra errores, correcciones, supervisor y evidencia sin inventar resultados. Mantén áreas generales; el texto libre no filtra automáticamente ubicaciones sensibles.

## Relaciones con otros módulos

[Ecología](../../ecologia/) · [Fichas de especies](../../especies/) · [Territorio](../../territorio/) · [Planificación](../../planificacion/) · [Programa](../../programa/). La interpretación ambiental se relaciona con geología, cartografía, gestión de grupos y patrimonio, sin sustituir su formación específica.
