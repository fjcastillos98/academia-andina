---
{
  "title": "GPS, navegación y pérdida de orientación",
  "description": "Distinguir recepción satelital, mapas offline y conectividad.",
  "module": "M14",
  "code": "E4-05",
  "order": 205,
  "minutes": 45,
  "level": "Intermedio",
  "status": "development",
  "reviewDate": "2026-10-22",
  "unit": "U4-05",
  "skills": [
    "s4-gps-contingencias"
  ],
  "critical": true,
  "objectives": [
    "Distinguir recepción satelital, mapas offline y conectividad.",
    "Preparar tracks y waypoints con procedencia y límites.",
    "Diseñar una respuesta conservadora a pérdida de orientación."
  ],
  "prerequisites": [
    "Completar estudio de Fundamentales; la práctica previa debe revisarse presencialmente.",
    "Estudiar Cartografía, brújula y orientación por terreno."
  ],
  "sources": [
    "gps-precision",
    "garmin-gps",
    "nps-marcha"
  ],
  "pending": [
    "Revisión pedagógica y evaluación situada por instructor competente.",
    "Condiciones, accesos, permisos y compatibilidad del equipo requieren verificación para cada actividad."
  ],
  "quiz": {
    "version": 1,
    "questions": [
      {
        "prompt": "Un GPS tiene posición, pero falta el mapa. ¿Qué falla?",
        "options": [
          "Necesariamente el satélite.",
          "La cartografía disponible; son funciones distintas.",
          "La rotación de la Tierra."
        ],
        "answer": 1,
        "explanation": "Recepción, cartografía y comunicaciones deben comprobarse por separado."
      },
      {
        "prompt": "En whiteout, un punto GPS…",
        "options": [
          "No muestra por sí solo peligros o transitabilidad del terreno.",
          "Garantiza que el siguiente paso es adecuado.",
          "Reemplaza formación glaciar."
        ],
        "answer": 0,
        "explanation": "La posición no aporta toda la información necesaria para desplazarse."
      }
    ]
  }
}
---
## Conceptos clave y vocabulario

**TEORÍA.** Un **waypoint** guarda una posición nombrada; un **track** registra una sucesión de puntos; una **ruta** puede organizar puntos previstos para navegar. El significado exacto de los menús depende de la aplicación. Un registro de que alguien pasó no confirma acceso, condición actual, dirección adecuada ni dificultad para tu grupo.

Garmin explica que el posicionamiento GPS se obtiene de señales satelitales [Referencia: garmin-gps](#fuente-garmin-gps). Eso es distinto de descargar cartografía o enviar mensajes por red móvil. “Sin señal” puede significar falta de cobertura celular, falta de posición GNSS o falta de un mapa descargado: identifica cuál falla antes de decidir.

## Teoría: precisión y consistencia

GPS.gov identifica geometría satelital, obstrucción, condiciones atmosféricas y receptor como factores de precisión; también distingue errores del mapa de errores de posicionamiento [Referencia: gps-precision](#fuente-gps-precision). Un trazo que atraviesa una pared puede reflejar error, procesamiento o cartografía inadecuada. La cantidad de decimales no demuestra exactitud.

Antes de una salida formativa verifica, sin depender de cobertura, que el mapa necesario abre a las escalas pertinentes, que los archivos tienen procedencia, que el formato de coordenadas coincide con el plan y que puedes reconocer la posición en un lugar conocido. Documenta qué aplicación, mapa y configuración usaste. No supongas que todos los equipos exportan igual.

## Preparar la navegación y sus respaldos

Asigna a cada tramo una referencia de inicio, una referencia de confirmación y un punto de revisión. Los waypoints son más útiles si su nombre comunica función, por ejemplo “decisión de retorno”, en lugar de una numeración que nadie entiende. No marques un punto como escape si no has comprobado su sentido operativo.

Haz un presupuesto de energía basado en pruebas del dispositivo: duración de pantalla, grabación, frío, edad de batería y recarga pueden cambiar el resultado. Dos teléfonos con un solo mapa o cargador comparten dependencias. Un mapa físico y una brújula solo constituyen respaldo utilizable si alguien sabe interpretarlos. Evita confundir la batería disponible con capacidad de navegación.

## Noche, niebla y whiteout

La oscuridad limita referencias visuales; la niebla puede ocultarlas aunque sea de día. **Whiteout** describe pérdida de contraste que dificulta distinguir relieve y horizonte sobre un entorno nevado: no es simplemente “se apagó el GPS”. El dispositivo puede dar posición sin que la persona identifique una cornisa, grieta o cambio de pendiente.

Esta materia requiere práctica presencial supervisada por un instructor competente. El estudio de esta lección no acredita competencia práctica. Aquí no se enseña a atravesar terreno glaciar o nevado en whiteout. La formación inicial usa simulaciones de mesa y entornos conocidos, sin crear deliberadamente una pérdida de orientación real.

## Pérdida de orientación: preguntas antes de actuar

Ante una discrepancia, interrumpe el avance no justificado y reúne la información disponible desde una posición apropiada al contexto. ¿Cuál fue la última posición confirmada? ¿Qué referencias siguen siendo fiables? ¿Qué cambió? ¿Qué supone cada alternativa? No persigas la línea de la pantalla hacia un peligro para “volver al track”.

Si las dudas no se resuelven dentro de la capacidad del equipo, el plan de contingencia puede exigir ayuda externa. Retroceder tampoco es una receta universal: condiciones y ruta de retorno deben evaluarse. El objetivo es evitar convertir incertidumbre en exposición adicional.

## Caso práctico: Calbuco, simulación

Durante un descenso ficticio, una persona conserva posición GPS pero no tiene cartografía; otra ve un track descargado sin fecha. Se reduce la visibilidad y el grupo quiere tomar una línea más directa. No se afirma que exista un descenso practicable en esa dirección.

El alumno debe distinguir las fallas, identificar información faltante y plantear alternativas. Respuesta orientativa: no interpretar el atajo digital como validación de terreno. Revisar última referencia confirmada, condiciones del grupo, comunicación y contingencia antes de desplazarse.

## Errores frecuentes y señales de alerta

Seguir la flecha sin observar; tratar exactitud mostrada como garantizada; perder mapas al cerrar sesión; confundir navegación offline con mensajería offline; grabar sin comprobar batería. La contradicción persistente entre terreno y pantalla es una señal para revisar, no para elegir automáticamente una de las dos.

## Autoevaluación y respuestas explicadas

1. ¿Puede haber posición sin internet? **Sí, recepción satelital y red móvil son funciones distintas; mapas y servicios deben estar preparados para funcionar sin conexión.**
2. ¿Un track reciente demuestra que tu grupo puede recorrerlo? **No acredita condiciones, permisos, destrezas ni capacidad de retorno del grupo.**

## Ejercicios y práctica presencial

En casa comprueba un mapa descargado y documenta sus dependencias. En un recorrido urbano conocido, acompañado, compara tres posiciones con referencias visibles y registra discrepancias. No desactives recursos necesarios en una salida real para simular una emergencia. Con instructor, practica comunicación de posición y revisión cruzada antes de abordar condiciones difíciles.

## Evidencia requerida

Ficha del dispositivo y mapa, prueba offline, referencias contrastadas, plan de energía y decisión razonada ante una discrepancia. No entregues ubicaciones privadas ni datos de pasajeros.

## Relaciones con otras habilidades

Esta unidad se integra en la ruta estival. Consulta la ficha de habilidad y sus prerrequisitos en el programa. Registra práctica y evaluación por separado: estudiar y responder correctamente no acredita ejecución. Los ejercicios son propuestas didácticas originales; los casos no son rutas operativas.
