import type { Question } from './schemas.ts';
export function grade(questions:Question[],answers:number[]){
 if(!questions.length||answers.length!==questions.length||answers.some((a,i)=>!Number.isInteger(a)||a<0||a>=questions[i].options.length))throw new Error('Responde todas las preguntas con una opción válida.');
 const correct=answers.filter((a,i)=>a===questions[i].answer).length;
 return {correct,total:questions.length,passed:correct===questions.length};
}
export function theoryStatus(studied:boolean,passed:boolean){return passed?'Evaluación teórica aprobada':studied?'Estudiada':'No estudiada';}
export function normalize(s:string){return s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();}
export type SearchItem={title:string;description:string;content:string;href:string;kind:string;module:string};
export function search(items:SearchItem[],query:string,kind='todos'){
 const terms=normalize(query).split(' ').filter(Boolean);
 return items.filter(i=>(kind==='todos'||i.kind===kind)&&terms.every(t=>normalize(`${i.title} ${i.description} ${i.content}`).includes(t))).sort((a,b)=>Number(b.kind==='Lección')-Number(a.kind==='Lección'));
}
export function withBase(base:string,path=''){return `${base.replace(/\/$/,'')}/${path.replace(/^\//,'')}`;}
