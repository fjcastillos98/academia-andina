import {routeProgress} from './route-progress';
import {ecologyUI} from './ecology-client';
import {winterPlanUI} from './winter-client';
import {equipmentUI} from './equipment-client';
import {assessmentAt,type Assessment} from './assessments';
import type {Skill} from './competencies';
import {practiceUI} from './practice-client';
import { grade, normalize, search, theoryStatus, withBase, type SearchItem } from './learning';
import { emptyEntry, emptyState, parseBackup, readState, writeState, type State } from './state';
import type { Question } from './schemas';
type Learning={id:string;title:string;href:string;quiz:{version:number;questions:Question[]};pilot?:{critical:boolean;criteria:string[]}};
const $=<T extends HTMLElement=HTMLElement>(id:string)=>document.getElementById(id) as T|null;
const base=import.meta.env.BASE_URL;
const key=`filo-austral:academia:v1:${base}`;
function message(text:string){const box=$('storage-message');if(box){box.textContent=text;box.hidden=false;}}
function errorText(e:unknown){return e instanceof Error?e.message:'Ocurrió un error inesperado.';}
function el<K extends keyof HTMLElementTagNameMap>(tag:K,text='',className=''){const e=document.createElement(tag);e.textContent=text;e.className=className;return e;}
async function json<T>(path:string):Promise<T>{const response=await fetch(withBase(base,path));if(!response.ok)throw new Error(`No se pudo cargar ${path}. Recarga la página para reintentar.`);return response.json();}
async function setupSearch(){
 const input=$<HTMLInputElement>('search-query'),kind=$<HTMLSelectElement>('search-kind'),out=$('search-results'),count=$('search-count');
 if(!input||!kind||!out||!count)return;
 try{
 input.value=new URLSearchParams(location.search).get('q')||'';const items=await json<SearchItem[]>('search-index.json');
 const update=()=>{const results=search(items,input.value,kind.value);out.replaceChildren();count.textContent=`${results.length} ${results.length===1?'resultado':'resultados'}${results.length>80?' · se muestran los primeros 80; afina la búsqueda':''}`;
 if(!results.length){out.append(el('p','No encontramos coincidencias. Prueba otro término o cambia el tipo de contenido.'));return;}
 for(const item of results.slice(0,80)){const a=el('a','','search-result');a.href=item.href;a.append(el('span',`${item.kind}${item.module?' · '+item.module:''}`,'badge'),el('h2',item.title),el('p',item.description));out.append(a);}};
 input.addEventListener('input',update);kind.addEventListener('change',update);update();
 }catch(e){count.textContent=errorText(e);}
}
const moduleInput=$<HTMLInputElement>('module-filter');moduleInput?.addEventListener('input',()=>{let visible=0;document.querySelectorAll<HTMLElement>('[data-module-text]').forEach(card=>{card.hidden=!normalize(card.dataset.moduleText||'').includes(normalize(moduleInput.value));if(!card.hidden)visible++;});$('module-count')!.textContent=`${visible} asignaturas`;$('modules-empty')!.hidden=visible>0;});
function unavailableProgress(){
 for(const id of ['notebook','practice-history']){const node=$(id);if(node){node.replaceChildren(el('p','No se pudieron cargar los registros. Revisa el aviso de error y recarga la página. Tus datos guardados no se han modificado.','notice'));node.setAttribute('role','status');}}

 document.querySelectorAll<HTMLElement>('[data-state]').forEach(node=>{node.textContent='Datos no disponibles';});
 for(const id of ['studied-count','passed-count']){const node=$(id);if(node)node.textContent='No disponible';}
 const progress=$<HTMLProgressElement>('study-progress');if(progress)progress.hidden=true;
 document.querySelectorAll<HTMLElement>('[data-route-summary]').forEach(node=>{node.textContent='Progreso no disponible. Revisa el aviso de error y vuelve a cargar la página.';});
 document.querySelectorAll<HTMLAnchorElement>('[data-route-next]').forEach(node=>{node.hidden=true;});
}
async function setupLearning(){
 let lessons:Learning[];try{lessons=await json<Learning[]>('learning-data.json');}catch(e){unavailableProgress();message(errorText(e));return;}
 let program:{skills:Skill[];assessments:Assessment[]};try{program=await json('program-data.json');}catch(e){unavailableProgress();message(errorText(e));return;}
 const questions=(id:string,version:number)=>assessmentAt(program.assessments,id,version).questions;
 const knownSkills=program.skills.map(s=>s.id);
 const known=lessons.map(l=>l.id);let state=emptyState(),readable=true;
 const validateAttempts=(candidate:State)=>{if(candidate.practices.some(p=>!knownSkills.includes(p.skill)))throw new Error('El diario contiene habilidades desconocidas.');for(const [id,entry] of Object.entries(candidate.lessons)){const lesson=lessons.find(l=>l.id===id)!;for(const a of entry.attempts)grade(questions(lesson.id,a.version),a.answers);}return candidate;};
 try{state=validateAttempts(readState(localStorage,key,known,knownSkills));}catch(e){readable=false;message('No se pudieron leer tus datos. No se sobrescribirán. '+errorText(e));}
 const passed=(l:Learning)=>state.lessons[l.id]?.attempts.some(a=>grade(questions(l.id,a.version),a.answers).passed)||false;
 const status=(l:Learning)=>theoryStatus(state.lessons[l.id]?.studied||false,passed(l));
 const commit=(candidate:State)=>{try{const previous=localStorage.getItem(key);if(previous&&!localStorage.getItem(key+':before-v3')&&JSON.parse(previous).version<3)localStorage.setItem(key+':before-v3',previous);writeState(localStorage,key,candidate);state=candidate;readable=true;refresh();return true;}catch{message('No se pudo guardar: almacenamiento bloqueado o lleno. Tu cambio no está confirmado. Exporta una copia de lo disponible.');return false;}};
 const modify=(id:string,fn:(entry:State['lessons'][string])=>void)=>{if(!readable){message('No se guardó: primero recupera tus datos importando un respaldo válido.');return false;}const next=structuredClone(state);next.lessons[id]??=emptyEntry();fn(next.lessons[id]);return commit(next);};
 let refreshPractices=()=>{},refreshEquipment=()=>{},refreshEcology=()=>{};
 function refresh(){
 refreshPractices();refreshEquipment();refreshEcology();
 document.querySelectorAll<HTMLElement>('[data-study-route]').forEach(node=>{
 const summary=node.querySelector<HTMLElement>('[data-route-summary]')!;
 const link=node.querySelector<HTMLAnchorElement>('[data-route-next]')!;
 if(!readable){summary.textContent='Progreso no disponible: recupera un respaldo válido en el cuaderno.';link.hidden=true;return;}
 const ids=JSON.parse(node.dataset.studyRoute!) as string[];
 const progress=routeProgress(ids,id=>!!state.lessons[id]?.studied,id=>{const l=lessons.find(l=>l.id===id);return !!l&&passed(l);});
 summary.textContent=`${progress.read}/${progress.total} lecturas estudiadas · ${progress.approved}/${progress.total} evaluaciones teóricas aprobadas.`;
 link.hidden=false;
 const next=lessons.find(l=>l.id===progress.next);
 if(next){link.href=next.href;link.textContent=`Continuar lectura: ${next.title}`;}
 else {link.href=withBase(base,'cuaderno/');link.textContent='Lecturas registradas: revisar notas y evaluaciones en el cuaderno';}
 });
 const studied=lessons.filter(l=>state.lessons[l.id]?.studied).length;
 if($('studied-count'))$('studied-count')!.textContent=readable?`${studied} / ${lessons.length}`:'No disponible';
 if($('passed-count'))$('passed-count')!.textContent=readable?String(lessons.filter(passed).length):'—';
 const progress=$<HTMLProgressElement>('study-progress');if(progress){progress.hidden=!readable;progress.value=studied;}
 document.querySelectorAll<HTMLElement>('[data-state]').forEach(node=>{const l=lessons.find(l=>l.id===node.dataset.state);if(l)node.textContent=readable?status(l):'Datos no disponibles';},()=>readable);
 const id=$('lesson')?.dataset.id;
 if(id){const e=state.lessons[id];const fav=$('favorite');if(fav){fav.setAttribute('aria-pressed',String(e?.favorite||false));fav.textContent=e?.favorite?'Quitar de favoritos':'Guardar en favoritos';}const mark=$('mark-studied');if(mark){mark.textContent=e?.studied?'Estudiada ✓':'Marcar como estudiada';(mark as HTMLButtonElement).disabled=!!e?.studied;}}
 const notebook=$('notebook');if(notebook){notebook.replaceChildren();if(!readable){notebook.append(el('p','No se pudieron leer tus datos. Puedes recuperar una copia válida desde el panel de respaldo.'));return;}
 const entries=lessons.filter(l=>state.lessons[l.id]);if(!entries.length)notebook.append(el('p','Tu cuaderno está vacío. Abre una lección y guarda una nota, un favorito o un resultado.','panel'));
 for(const l of entries){const e=state.lessons[l.id],card=el('section','','panel'),a=el('a',l.title);a.href=l.href;const heading=el('h2');heading.append(a);card.append(el('span',e.favorite?'★ Favorito':'Registro de estudio','badge'),heading,el('p',status(l)));if(e.note)card.append(el('p',e.note,'note-text'));if(e.attempts.length){const list=el('ol','','attempts');for(const attempt of [...e.attempts].reverse()){const g=grade(questions(l.id,attempt.version),attempt.answers);list.append(el('li',`${new Date(attempt.date).toLocaleString('es-CL')} · ${g.correct}/${g.total} · ${g.passed?'Teoría aprobada':'Por repasar'} · versión ${attempt.version}`));}card.append(el('h3','Historial de intentos'),list);}notebook.append(card);}}
 }
 refreshPractices=practiceUI(program.skills.map(s=>({...s,href:lessons.find(l=>l.id===s.lessonIds[0])!.href})),()=>state,candidate=>{if(!readable){message('No se guardó: recupera primero un respaldo válido.');return false;}return commit(candidate);},id=>{const l=lessons.find(l=>l.id===(program.skills.find(s=>s.id===id)?.lessonIds[0]||id))!;return readable?status(l):'Datos no disponibles';},()=>readable);
 refreshEquipment=equipmentUI(()=>state,candidate=>readable&&commit(candidate));
 refreshEcology=ecologyUI(()=>state,candidate=>readable&&commit(candidate),()=>readable);
 refresh();
 winterPlanUI(()=>state,candidate=>readable&&commit(candidate),()=>readable);
 const response=$<HTMLTextAreaElement>('open-response');if(response){const responseKey=response.dataset.key!;if(!response.value)response.value=state.responses[responseKey]||'';$('save-response')?.addEventListener('click',()=>{if(!readable){message('Recupera primero tus datos.');return;}const next=structuredClone(state);next.responses[responseKey]=response.value;if(commit(next))message('Respuesta guardada. Revisión humana pendiente.');});}
 const id=$('lesson')?.dataset.id,lesson=lessons.find(l=>l.id===id);
 if(id&&lesson){const note=$<HTMLTextAreaElement>('lesson-note');if(note&&!note.value)note.value=state.lessons[id]?.note||'';
 $('save-note')?.addEventListener('click',()=>{if(note&&modify(id,e=>{e.note=note.value;})){$('note-status')!.textContent='Nota guardada en este navegador.';message('Nota guardada.');}});
 $('mark-studied')?.addEventListener('click',()=>{if(modify(id,e=>{e.studied=true;}))message('Estudio registrado. La práctica sigue sin evaluar.');});
 $('favorite')?.addEventListener('click',()=>{if(modify(id,e=>{e.favorite=!e.favorite;}))message('Favoritos actualizados.');});
 $('quiz-form')?.addEventListener('submit',event=>{event.preventDefault();const form=event.currentTarget as HTMLFormElement;const data=new FormData(form);try{const answers=lesson.quiz.questions.map((_,i)=>{const a=data.get(`q${i}`);return a===null?-1:Number(a);});const result=grade(lesson.quiz.questions,answers);
 lesson.quiz.questions.forEach((q,i)=>{const node=$(`feedback-${i}`)!;node.hidden=false;node.classList.toggle('wrong',answers[i]!==q.answer);node.textContent=`${answers[i]===q.answer?'Correcta.':'Por repasar.'} ${q.explanation}${q.rationales?' '+q.rationales.map((r,j)=>`Opción ${j+1}: ${r}`).join(' '):''}`;});
 const saved=modify(id,e=>{e.studied=true;e.attempts.push({date:new Date().toISOString(),version:lesson.quiz.version,answers});});
 $('quiz-result')!.textContent=`${result.correct}/${result.total}. ${result.passed?'Evaluación teórica aprobada.':'Revisa las explicaciones y vuelve a intentarlo.'} No acredita competencia práctica.${saved?' Intento guardado.':' No se pudo guardar este intento.'}`;
 }catch(e){$('quiz-result')!.textContent=errorText(e);}});
 }
 $('export-backup')?.addEventListener('click',()=>{try{if(!readable)throw new Error('No se puede exportar un estado que no se pudo leer. Recupera antes una copia válida.');const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'});const link=el('a');const href=URL.createObjectURL(blob);link.href=href;link.download=`filo-austral-respaldo-${new Date().toISOString().slice(0,10)}.json`;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(href),1000);message('Respaldo preparado para descargar.');}catch(e){message(errorText(e));}});
 let pending:State|null=null;
 const input=$<HTMLInputElement>('import-backup');
 input?.addEventListener('change',async()=>{pending=null;$('import-review')!.hidden=true;const file=input.files?.[0];if(!file)return;try{if(file.size>2_000_000)throw new Error('El archivo supera el límite de 2 MB.');pending=validateAttempts(parseBackup(await file.text(),known,knownSkills));const values=Object.values(pending.lessons);$('import-status')!.textContent='Respaldo válido. Revisa el resumen antes de confirmar.';$('import-summary')!.textContent=`Resumen: equipo (${pending.equipment.length}), respuestas abiertas (${Object.keys(pending.responses).length}), prácticas (${pending.practices.length}), lecciones (${values.length}), notas (${values.filter(e=>e.note).length}), favoritos (${values.filter(e=>e.favorite).length}) e intentos (${values.reduce((n,e)=>n+e.attempts.length,0)}).`;$('import-review')!.hidden=false;}catch(e){$('import-status')!.textContent=errorText(e);}});
 $('cancel-import')?.addEventListener('click',()=>{pending=null;input!.value='';$('import-review')!.hidden=true;$('import-status')!.textContent='Importación cancelada. No se modificaron tus datos.';});
 $('confirm-import')?.addEventListener('click',()=>{if(pending&&commit(pending)){pending=null;input!.value='';$('import-review')!.hidden=true;$('import-status')!.textContent='Respaldo importado. Tus registros fueron reemplazados.';message('Importación completada.');}});
}
void setupSearch();void setupLearning();
