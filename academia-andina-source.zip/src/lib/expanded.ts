import {caseSchema,diagramSchema,mountainSchema,speciesSchema} from './territory.ts';
import type {LessonMeta} from './schemas.ts';
export function validateExpanded(input:{mountains:unknown[];species:unknown[];cases:unknown[];diagrams:unknown[];sourceIds:string[];lessons:{id:string;data:LessonMeta}[];diagramFiles:string[]}){
 const mountains=input.mountains.map(m=>mountainSchema.parse(m)),species=input.species.map(s=>speciesSchema.parse(s)),cases=input.cases.map(c=>caseSchema.parse(c)),diagrams=input.diagrams.map(d=>diagramSchema.parse(d));
 const fail=(s:string)=>{throw new Error('Ampliación incompleta: '+s);};
 for(const collection of [mountains,species,cases,diagrams])if(new Set(collection.map(x=>x.id)).size!==collection.length)fail('Identificadores duplicados');
 for(const entry of [...mountains,...species,...cases])if(entry.sources.some(id=>!input.sourceIds.includes(id)))fail('Fuente desconocida de '+entry.id);
 for(const c of cases)if(c.lessons.some(id=>!input.lessons.some(l=>l.id===id)))fail('Lección desconocida del caso '+c.id);
 for(const d of diagrams)if(!input.diagramFiles.includes(d.id+'.svg'))fail('SVG ausente '+d.id);
 for(const l of input.lessons){for(const id of l.data.diagrams||[])if(!diagrams.some(d=>d.id===id))fail('Diagrama desconocido de '+l.id);if(/^(E4[345]|E(?:[56789]|10|11|12|13)-)/.test(l.data.code)&&(!l.data.preparation?.length||!l.data.openAssessment))fail('Preparación y evaluación abierta de '+l.id);}
 return {mountains,species,cases,diagrams};
}
