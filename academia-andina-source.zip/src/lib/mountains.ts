import original from '../data/mountains.json';
import additions from '../data/mountains14.json';
export default [...original,...additions];
