import {z} from 'zod';
export const territorialFields=['location','altitude','administration','geologicalClassification','origin','geology','glaciology','routes','access','hazards','seasonality','history','ascents','heritage','protectedAreas','officialInformation'] as const;
const evidenceSchema=z.object({mountainId:z.string().min(1),field:z.enum(territorialFields),state:z.enum(['atribuido','pendiente']),sourceIds:z.array(z.string().min(1)),limit:z.string().trim().min(1)}).strict();
export function validateTerritorialEvidence(input:unknown,mountains:{id:string;sources:string[]}[],sources:string[]){
 const rows=z.array(evidenceSchema).parse(input),keys=new Set<string>();
 for(const row of rows){const m=mountains.find(m=>m.id===row.mountainId),key=row.mountainId+':'+row.field;
 if(!m)throw new Error('Evidencia territorial: montaña desconocida '+row.mountainId);
 if(keys.has(key))throw new Error('Evidencia territorial duplicada: '+key);keys.add(key);
 if(row.state==='atribuido'&&!row.sourceIds.length)throw new Error('Dato atribuido sin fuente: '+key);
 if(row.sourceIds.some(s=>!sources.includes(s)||!m.sources.includes(s)))throw new Error('Fuente territorial desconocida: '+key);
 }
 for(const m of mountains)for(const f of territorialFields)if(!keys.has(m.id+':'+f))throw new Error('Falta evidencia territorial: '+m.id+':'+f);
 return rows;
}
export const territorialCases=[
 {id:'altura',title:'Cota de catálogo',text:'Caso ficticio: una ficha publica una altitud, sin identificar el punto medido ni el datum vertical.',options:['Usarla para calcular automáticamente la dificultad.','Conservar la atribución y contrastar punto, datum y edición cartográfica.','Promediarla con cualquier cifra de Internet.'],answer:1,explanation:'La altitud atribuida no resuelve la identidad del punto ni su referencia vertical. El contraste necesita metadatos; promediar cifras incompatibles oculta el problema.'},
 {id:'erupcion',title:'Reporte histórico incierto',text:'Caso ficticio: el resumen menciona actividad, pero la tabla del catálogo la clasifica como incierta.',options:['Presentarla como confirmada.','Borrar toda referencia al episodio.','Explicar la atribución y conservar expresamente la incertidumbre.'],answer:2,explanation:'El resumen y la tabla deben leerse juntos. La incertidumbre forma parte del dato: conservarla permite investigar sin afirmar ni negar más de lo documentado.'},
 {id:'ruta',title:'Del paisaje al itinerario',text:'Caso ficticio: conoces la clasificación volcánica y la ubicación general; desconoces permisos, terreno y condiciones.',options:['Preparar solicitudes de información antes de decidir una ruta.','Elegir el volcán más bajo porque debe ser más seguro.','Considerar autorizado el acceso porque existe una ficha.'],answer:0,explanation:'Una ficha geológica no acredita permiso, dificultad ni condiciones. Define qué falta, quién puede verificarlo y cuándo; una menor altitud no determina menor exposición.'}
] as const;
export function reviewTerritorialCase(id:unknown,answer:unknown){const c=territorialCases.find(c=>c.id===id);if(!c)throw new Error('Caso territorial desconocido');const n=z.number().int().min(0).max(2).parse(answer);return {correct:n===c.answer,explanation:(n===c.answer?'Conclusión fundamentada. ':'Revisa la inferencia. ')+c.explanation};}
