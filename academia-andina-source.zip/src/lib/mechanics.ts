export function idealForce(load:number,ratio:number){if(!Number.isFinite(load)||!Number.isFinite(ratio)||load<=0||ratio<1)throw new Error('Usa una carga positiva en N y una ventaja igual o mayor a 1.');return load/ratio;}
export function idealTravel(height:number,ratio:number){if(!Number.isFinite(height)||height<=0)throw new Error('La altura debe ser positiva.');idealForce(1,ratio);return height*ratio;}
export const mechanicsProblems=[
{id:'a',prompt:'Modelo 2:1, carga 120 N: esfuerzo ideal en N',answer:60,tolerance:.01,explanation:'120/2 = 60 N. Sin fricción; no es una capacidad de equipo.'},
{id:'b',prompt:'Modelo 3:1: elevar 0,4 m exige recorrido ideal de entrada en m',answer:1.2,tolerance:.01,explanation:'3 × 0,4 = 1,2 m. El trabajo se conserva en el modelo ideal.'},
{id:'c',prompt:'Modelo 4:1, carga 200 N: esfuerzo ideal en N',answer:50,tolerance:.01,explanation:'200/4 = 50 N. La fuerza real exige evaluar las pérdidas.'},
{id:'d',prompt:'Modelo 5:1: elevar 0,2 m exige recorrido ideal de entrada en m',answer:1,tolerance:.01,explanation:'5 × 0,2 = 1 m. Más ventaja no crea energía.'},
{id:'e',prompt:'Carga 150 N y esfuerzo medido 80 N: ventaja real (sin unidades)',answer:1.875,tolerance:.001,explanation:'150/80 = 1,875. Es un dato ficticio del ejercicio, no de Micro Traxion.'},
{id:'f',prompt:'Compuesto ideal 2×3, carga 180 N: esfuerzo en N',answer:30,tolerance:.01,explanation:'180/(2×3) = 30 N, solo si las etapas están conectadas con esa relación.'}
];
export function checkNumeric(raw:string,expected:number,tolerance:number){if(!raw.trim())return {valid:false,correct:false};const value=Number(raw.trim().replace(',','.'));if(!Number.isFinite(value))return {valid:false,correct:false};return {valid:true,correct:Math.abs(value-expected)<=tolerance};}
