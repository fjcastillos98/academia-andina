import {altitudeScenarios,sleepingChanges} from './altitude';
const select=document.getElementById('altitude-scenario') as HTMLSelectElement|null;
const body=document.getElementById('altitude-rows'),question=document.getElementById('altitude-question');
function render(){const scenario=altitudeScenarios.find(s=>s.id===select?.value);if(!scenario||!body||!question)return;body.replaceChildren();for(const row of sleepingChanges([...scenario.nights])){const tr=document.createElement('tr');for(const value of [String(row.night),`${row.altitude} m`,row.change===null?'Sin noche previa en el ejemplo':`${row.change>0?'+':''}${row.change} m`]){const td=document.createElement('td');td.textContent=value;tr.append(td);}body.append(tr);}question.textContent=scenario.question;}
select?.addEventListener('change',render);render();
