import raw from '../../data/curriculum.json';
import { validateCurriculum } from './schemas';
import { withBase } from './learning';
export const curriculum=validateCurriculum(raw);
export const url=(path='')=>withBase(import.meta.env.BASE_URL,path);
export const shortTitle=(title:string)=>title.split(' — ').slice(1).join(' — ').replace(/ \(referencia formativa.*$/,'');
