import winterTemplates from '../data/winter-templates.json';
import glacierTemplates from '../data/glacier-templates.json';
import iceTemplates from '../data/ice-templates.json';
import alpineTemplates from '../data/alpine-templates.json';
import altitudeTemplates from '../data/altitude-templates.json';
import trainingTemplates from '../data/training-templates.json';
import ecologyTemplates from '../data/ecology-templates.json';
import geologyTemplates from '../data/geology-templates.json';
import historyTemplates from '../data/history-templates.json';
import leadershipTemplates from '../data/leadership-templates.json';
const templates=[...winterTemplates,...glacierTemplates,...iceTemplates,...alpineTemplates,...altitudeTemplates,...trainingTemplates,...ecologyTemplates,...geologyTemplates,...historyTemplates,...leadershipTemplates];
import {observedEvidence} from './winter';
import {learningState,type Skill as SkillData} from './competencies';
import {skillEvidence,validatePractice} from './practices';
import type {State} from './state';
type Skill=SkillData&{href:string};
const node=(tag:string,text:string)=>{const n=document.createElement(tag);n.textContent=text;return n;};
export function practiceUI(skills:Skill[],getState:()=>State,save:(s:State)=>boolean,theory:(id:string)=>string,isReadable=()=>true){
 const form=document.getElementById('practice-form') as HTMLFormElement|null;
 if(!form)return ()=>{};
 const known=skills.map(s=>s.id);
 const field=(name:string)=>form.elements.namedItem(name) as HTMLInputElement|HTMLSelectElement|HTMLTextAreaElement;
 const status=document.getElementById('practice-status')!;
 const criteria=()=>{const s=skills.find(s=>s.id===field('skill').value);document.getElementById('practice-criteria')!.textContent=`${s?.critical?'Maniobra crítica: el trabajo individual se limita a mesa, sin cargas ni montajes para personas. ':''}Criterio para revisión: ${s?.criteria.join(' ')}`;};
 const reset=()=>{form.reset();field('id').value='';document.getElementById('practice-heading')!.textContent='Registrar práctica';criteria();};
 const selected=new URLSearchParams(location.search).get('habilidad');if(selected&&known.includes(selected))field('skill').value=selected;
 document.getElementById('apply-winter-template')?.addEventListener('click',()=>{const selected=(document.getElementById('winter-template') as HTMLSelectElement).value;const t=templates.find(t=>t.id===selected);const note=document.getElementById('winter-template-status')!;if(!t){note.textContent='Selecciona una plantilla.';return;}if(field('id').value){note.textContent='Estás editando un registro. Limpia el formulario antes de preparar una práctica nueva.';return;}field('skill').value=t.skill;for(const k of ['objective','exercises','equipment'] as const)if(!field(k).value)field(k).value=t[k];field('mode').value=t.supervised?'supervisada':'individual';criteria();note.textContent=t.review;});
 criteria();field('skill').addEventListener('change',criteria);
 document.getElementById('cancel-practice')!.addEventListener('click',()=>{reset();status.textContent='Formulario limpio; no se borraron registros.';});
 form.addEventListener('submit',event=>{event.preventDefault();try{
 const raw=Object.fromEntries(new FormData(form));raw.id=String(raw.id||crypto.randomUUID?.()||`p-${Date.now()}-${Array.from(crypto.getRandomValues(new Uint32Array(2))).join('-')}`);
 const p=validatePractice({...raw,equipmentIds:new FormData(form).getAll('equipmentIds'),repetitions:Number(raw.repetitions),confidence:Number(raw.confidence)},known);
 const next=structuredClone(getState());const index=next.practices.findIndex(r=>r.id===p.id);if(index<0)next.practices.push(p);else next.practices[index]=p;
 if(save(next)){reset();status.textContent='Práctica guardada. Una evaluación declarada no es una certificación.';}
 }catch(e){status.textContent=e instanceof Error?e.message:'No se guardó la práctica.';}});
 return ()=>{
 const state=getState();const inventory=field('equipmentIds') as HTMLSelectElement;const selected=Array.from(inventory.selectedOptions).map(o=>o.value);inventory.replaceChildren();for(const e of state.equipment){const o=new Option(`${e.category} · ${e.brand} ${e.model}`,e.id);o.selected=selected.includes(e.id);inventory.append(o);}const matrix=document.getElementById('skill-matrix')!,history=document.getElementById('practice-history')!;matrix.replaceChildren();history.replaceChildren();if(!isReadable()){history.append(node('p','Datos no disponibles. Recupera un respaldo válido; no se sobrescribirán los registros.'));return;}
 for(const s of skills){const e=skillEvidence(state,s.id),row=node('tr',''),heading=node('th',''),a=node('a',s.title) as HTMLAnchorElement;a.href=s.href;heading.setAttribute('scope','row');heading.append(a);row.append(heading);for(const t of [theory(s.id),String(e.count)+' registros',String(e.supervised)+' supervisadas',String(e.evaluations)+' evaluaciones',observedEvidence(state,s.id),learningState(state,s)])row.append(node('td',t));matrix.append(row);}
 if(!state.practices.length)history.append(node('p','Aún no hay prácticas registradas.'));
 for(const p of [...state.practices].sort((a,b)=>b.date.localeCompare(a.date))){const card=node('section','');card.className='panel';card.append(node('h3',`${p.date} · ${skills.find(s=>s.id===p.skill)?.title}`));
 const labels={exercises:'Ejercicios',observations:'Observaciones',nextPractice:'Próxima práctica',objective:'Objetivo',result:'Resultado',autonomy:'Autonomía observada',equipmentIds:'Equipo vinculado (ID)',place:'Lugar',activity:'Actividad',conditions:'Condiciones',equipment:'Equipo',repetitions:'Repeticiones',errors:'Errores',corrections:'Correcciones',supervisor:'Supervisor',evidence:'Evidencia',confidence:'Confianza / 5',mode:'Modalidad',evaluation:'Resultado declarado',evaluator:'Evaluador',evaluationDate:'Fecha de evaluación',criterion:'Criterio y contexto'};
 for(const [key,label] of Object.entries(labels)){const value=p[key as keyof typeof p];card.append(node('p',`${label}: ${value||'No registrado'}`));}
 const edit=node('button','Editar registro') as HTMLButtonElement;edit.type='button';edit.addEventListener('click',()=>{for(const [key,value] of Object.entries(p)){if(key==='equipmentIds'){for(const option of (field(key) as HTMLSelectElement).options)option.selected=p.equipmentIds.includes(option.value);}else if(field(key))field(key).value=String(value);}criteria();document.getElementById('practice-heading')!.textContent='Editar práctica';status.textContent='Editando registro existente.';form.scrollIntoView({behavior:'smooth'});field('skill').focus();});card.append(edit);history.append(card);}
 };
}
