import {practiceSchema,type State} from './state.ts';
export function skillEvidence(state:State,skill:string){
 const records=state.practices.filter(p=>p.skill===skill);
 const evaluated=records.filter(p=>p.evaluation!=='pendiente').sort((a,b)=>(b.evaluationDate.localeCompare(a.evaluationDate)||b.date.localeCompare(a.date)||b.id.localeCompare(a.id)));
 // Conflicting evaluations on the most recent date are treated conservatively.
 const latest=evaluated[0];const sameDate=latest?evaluated.filter(p=>p.evaluationDate===latest.evaluationDate):[];
 const result=sameDate.some(p=>p.evaluation==='en-desarrollo')?'en-desarrollo':latest?.evaluation;
 return {count:records.length,supervised:records.filter(p=>p.mode==='supervisada').length,evaluations:evaluated.length,competence:result==='lograda'?'Lograda en contexto · declaración no verificada':result==='en-desarrollo'?'En desarrollo':'Sin evaluar'};
}
export function validatePractice(raw:unknown,known:string[]){const r=practiceSchema.safeParse(raw);if(!r.success)throw new Error(r.error.issues.map(i=>`${i.path.length?i.path.join('.')+': ':''}${i.message}`).join(' · '));if(!known.includes(r.data.skill))throw new Error('Habilidad desconocida para el piloto.');return r.data;}
