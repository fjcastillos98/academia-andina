import type {State} from './state.ts';
export type Skill={id:string;title:string;module:string;lessonIds:string[];requires:string[];critical:boolean;criteria:string[];status:string};
export function learningState(state:State,skill:Pick<Skill,'id'|'lessonIds'>){
 const practices=state.practices.filter(p=>p.skill===skill.id);
 const evaluations=practices.filter(p=>p.evaluation!=='pendiente').sort((a,b)=>b.evaluationDate.localeCompare(a.evaluationDate));
 if(evaluations.length){const date=evaluations[0].evaluationDate;if(evaluations.some(p=>p.evaluationDate===date&&p.evaluation==='en-desarrollo'))return 'REQUIERE REFUERZO';return 'COMPETENTE VALIDADO';}
 if(practices.some(p=>p.mode==='supervisada'))return 'PRACTICADO CON SUPERVISIÓN';
 if(practices.length||skill.lessonIds.some(id=>{const e=state.lessons[id];return e&&(e.studied||e.note||e.attempts.length);}))return 'ESTUDIANDO';
 return 'NO INICIADO';
}
export const evaluationDisclaimer='Evaluación presencial declarada. La plataforma no verifica identidad ni credenciales del evaluador; no emite certificación.';
