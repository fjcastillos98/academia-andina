export function routeProgress(ids:string[],studied:(id:string)=>boolean,passed:(id:string)=>boolean){
 const read=ids.filter(studied).length;
 const approved=ids.filter(passed).length;
 const next=ids.find(id=>!studied(id))??null;
 return {read,approved,total:ids.length,next};
}
