import {alpineTime,alpineTimeFields,type AlpineTimeInput} from './alpine';
const form=document.getElementById('alpine-time') as HTMLFormElement|null;
const output=document.getElementById('alpine-time-result');
if(form&&output)form.addEventListener('submit',event=>{
 event.preventDefault();
 try{
  const data=new FormData(form);
  const values=Object.fromEntries(alpineTimeFields.map(k=>{const raw=data.get(k);return [k,typeof raw==='string'&&raw.trim()?Number(raw):NaN];})) as AlpineTimeInput;
  const r=alpineTime(values);
  output.textContent=`Total: ${r.total} min. Escalada: ${r.climbing} min; transiciones: ${r.changes} min. ${r.remaining>=0?`Diferencia con el tiempo disponible: ${r.remaining} min.`:`Se excede el tiempo disponible por ${-r.remaining} min.`} No incluye pausas ni contingencias. Una diferencia positiva no demuestra que la salida sea viable o segura.`;
 }catch(error){output.textContent=error instanceof Error?error.message:'No se pudo calcular el ejercicio.';}
});
