import {documentExercises,reviewDocument} from './geology';
const form=document.getElementById('document-exercise') as HTMLFormElement|null;
if(form){const select=document.getElementById('document-type') as HTMLSelectElement,excerpt=document.getElementById('document-excerpt')!,result=document.getElementById('document-result')!;
select.addEventListener('change',()=>{const d=documentExercises.find(d=>d.id===select.value);if(d)excerpt.textContent=d.excerpt;result.textContent='Selecciona qué conclusión respalda el documento.';});
form.addEventListener('submit',event=>{event.preventDefault();try{const answer=new FormData(form).get('claim');if(!answer){result.textContent='Selecciona una conclusión antes de comprobar.';return;}result.textContent=reviewDocument(select.value,answer).explanation+' Ejercicio ficticio: no otorga competencia ni autorización de salida.';}catch{result.textContent='Selección no válida. Revisa las opciones.';}});}
