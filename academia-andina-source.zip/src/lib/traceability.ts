export type TraceRow = {entry:string;status:string;links:{lesson:string;quote:string;scope:string;gap:string}[];note:string};
export function validateTraceability(rows:TraceRow[], entries:{id:string}[], lessons:Map<string,string>) {
 const expected=new Set(entries.map(e=>e.id)); const seen=new Set<string>(); const errors:string[]=[];
 for(const r of rows){
  if(!expected.has(r.entry)||seen.has(r.entry)) errors.push(`Entrada desconocida o repetida: ${r.entry}`);
  seen.add(r.entry);
  if(!['sin-revisar','sin-vinculo-propuesto','propuesta-parcial'].includes(r.status)) errors.push(`Estado inválido: ${r.entry}`);
  if((r.status==='propuesta-parcial')!==(r.links.length>0)) errors.push(`Estado incoherente: ${r.entry}`);
  const linked=new Set<string>();
  for(const l of r.links){
   if(linked.has(l.lesson)) errors.push(`Vínculo repetido: ${r.entry}`); linked.add(l.lesson);
   if(!l.quote.trim()||!lessons.get(l.lesson)?.includes(l.quote)) errors.push(`Evidencia ausente: ${r.entry}/${l.lesson}`);
   if(!l.scope.trim()||!l.gap.trim()) errors.push(`Alcance o vacío ausente: ${r.entry}`);
  }
 }
 for(const id of expected) if(!seen.has(id)) errors.push(`Entrada omitida: ${id}`);
 return errors;
}
