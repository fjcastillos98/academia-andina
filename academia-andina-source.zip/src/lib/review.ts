import {z} from 'zod';
const text=z.string().trim().min(1);
export const reviewStationSchema=z.object({id:text,title:text,lesson:text,skill:text,goal:text,finding:text,checks:z.array(text).min(3),practice:text,criteria:z.array(text).min(3),stop:text,sources:z.array(z.object({title:text,url:z.url()}).strict()).min(1),consulted:z.iso.date(),status:z.literal('pending-instructor')}).strict();
export function validateReview(raw:unknown[],lessons:string[],skills:string[]){const stations=raw.map(s=>reviewStationSchema.parse(s));if(new Set(stations.map(s=>s.id)).size!==stations.length)throw new Error('Revisión: ID duplicado');for(const s of stations){if(!lessons.includes(s.lesson)||!skills.includes(s.skill))throw new Error('Revisión: lección/habilidad desconocida en '+s.id);}return stations;}
