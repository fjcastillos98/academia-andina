/** Solo aritmética de un itinerario ficticio. No clasifica riesgo ni aptitud. */
export function sleepingChanges(nights:number[]){
 if(nights.length<2||nights.length>30||Array.from(nights).some(n=>!Number.isFinite(n)||n<0||n>9000))throw new Error('Indica entre 2 y 30 pernoctas, con cotas de 0 a 9000 m.');
 return nights.map((altitude,i)=>({night:i+1,altitude,change:i===0?null:altitude-nights[i-1]}));
}
export const altitudeScenarios=[
 {id:'escalonado',title:'A · Noches intermedias',nights:[2800,3200,3600,3600],question:'¿Qué información falta sobre el traslado inicial y la respuesta individual?'},
 {id:'comprimido',title:'B · Calendario comprimido',nights:[2800,3600,4000,4000],question:'¿Qué cambió al eliminar una noche intermedia? No evalúes solo el promedio.'},
 {id:'retorno',title:'C · Regreso a menor cota',nights:[2800,3200,2800,2800],question:'¿Qué datos del terreno y del grupo faltan para valorar la retirada?'}
] as const;
