import {skillSchema,pathSchema,hasCycle,curriculumV2Schema,lessonSchema,sourcesSchema} from './schemas.ts';
import {assessmentSchema} from './assessments.ts';
export function validateProgram(raw:any){
 const c=curriculumV2Schema.parse(raw.curriculum),skills=raw.skills.map((s:unknown)=>skillSchema.parse(s)),paths=raw.paths.map((p:unknown)=>pathSchema.parse(p)),assessments=raw.assessments.map((a:unknown)=>assessmentSchema.parse(a));
 const lessons=raw.lessons.map((l:any)=>({id:l.id,data:lessonSchema.parse(l.data)})),sources=sourcesSchema.parse(raw.sources);
 const fail=(message:string)=>{throw new Error('Programa incompleto: '+message);};
 const unique=(ids:string[],label:string)=>{if(new Set(ids).size!==ids.length)fail(label+' duplicados');};
 unique(skills.map((s:any)=>s.id),'Habilidades');unique(paths.map((p:any)=>p.id),'Rutas');unique(lessons.map((l:any)=>l.id),'Lecciones');unique(assessments.map((a:any)=>`${a.lesson}:${a.version}`),'Evaluaciones');
 const lessonIds=lessons.map((l:any)=>l.id),skillIds=skills.map((s:any)=>s.id),unitIds=c.units.map(u=>u.id),moduleIds=c.modules.map(m=>m.id),pathIds=paths.map((p:any)=>p.id);
 for(const s of skills)if(!moduleIds.includes(s.module)||s.lessonIds.some((id:string)=>!lessonIds.includes(id))||s.requires.some((id:string)=>!skillIds.includes(id)))fail('Relaciones de habilidad '+s.id);
 for(const p of paths)if(p.lessonIds.some((id:string)=>!lessonIds.includes(id))||p.unitIds.some((id:string)=>!unitIds.includes(id))||p.requires.some((id:string)=>!pathIds.includes(id)))fail('Relaciones de ruta '+p.id);
 if(hasCycle(skills)||hasCycle(paths))fail('Ciclo de habilidades o rutas');
 for(const u of c.units)if(u.lessonIds.some(id=>!lessonIds.includes(id)))fail('Lección de unidad '+u.id);
 for(const l of lessons){for(const q of l.data.quiz.questions){if(q.source&&!l.data.sources.includes(q.source))fail("Fuente de pregunta "+l.id);if(l.data.code.match(/^(E4[345]|E(?:[56789]|10|11|12|13|16)-)/)&&(!q.source||!q.difficulty||!q.rationales||!q.kind))fail("Metadatos de evaluación "+l.id);}if(l.data.openAssessment&&!l.data.sources.includes(l.data.openAssessment.source))fail("Fuente de respuesta abierta "+l.id);if(l.data.sources.some((id:string)=>!sources.some(s=>s.id===id&&s.lessons.includes(l.id))))fail('Fuente de '+l.id);if(l.data.status==='development'&&(!unitIds.includes(l.data.unit)||!l.data.skills?.length))fail('Unidad/habilidad de '+l.id);for(const id of l.data.skills||[])if(!skills.some((s:any)=>s.id===id&&s.lessonIds.includes(l.id)))fail('Habilidad de '+l.id);const a=assessments.find((a:any)=>a.lesson===l.id&&a.version===l.data.quiz.version);if(!a||JSON.stringify(a.questions)!==JSON.stringify(l.data.quiz.questions))fail('Evaluación versionada de '+l.id);}
 for(const a of assessments)if(!lessonIds.includes(a.lesson))fail('Evaluación huérfana '+a.id);
 for(const source of sources)if(source.lessons.some(id=>!lessonIds.includes(id)))fail('Referencia huérfana '+source.id);
 return {c,skills,paths,assessments};
}
