import {z} from 'zod';
const text=z.string().trim().min(1);
const schema=z.array(z.object({id:z.string().regex(/^[a-z0-9-]+$/),title:text,context:text,lessons:z.array(text).min(1),events:z.array(z.object({title:text,information:text,prompt:text,review:text}).strict()).min(3),deliverable:text,rubric:z.array(text).min(3)}).strict()).min(1);
export function validateExpeditions(raw:unknown,lessonIds:string[]){const cases=schema.parse(raw);if(new Set(cases.map(c=>c.id)).size!==cases.length)throw new Error('Caso duplicado');for(const c of cases)if(c.lessons.some(id=>!lessonIds.includes(id)))throw new Error('Lectura inexistente');return cases;}
