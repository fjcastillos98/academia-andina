import {observationKey,parseObservations} from './ecology.ts';
import { z } from 'zod';
import {equipmentSchema} from './equipment.ts';
const entry=z.object({studied:z.boolean(),favorite:z.boolean(),note:z.string().max(10000),attempts:z.array(z.object({date:z.iso.datetime(),version:z.number().int().positive(),answers:z.array(z.number().int().nonnegative()).max(50)}).strict()).max(10000)}).strict();
export const practiceSchema=z.object({
 exercises:z.string().max(3000).default(''),observations:z.string().max(3000).default(''),nextPractice:z.string().max(2000).default(''),
 objective:z.string().max(2000).default(''),result:z.string().max(2000).default(''),autonomy:z.enum(['no-evaluada','asistida','supervisada','autonomia-observada']).default('no-evaluada'),equipmentIds:z.array(z.string()).max(100).default([]),
 id:z.string().regex(/^[a-z0-9-]+$/),skill:z.string().regex(/^[a-z0-9-]+$/),date:z.iso.date(),
 place:z.string().trim().min(1).max(200),activity:z.string().trim().min(1).max(500),conditions:z.string().trim().min(1).max(1000),equipment:z.string().max(1000),repetitions:z.number().int().min(1).max(10000),
 errors:z.string().trim().min(1).max(2000),corrections:z.string().trim().min(1).max(2000),supervisor:z.string().max(200),evidence:z.string().max(2000),confidence:z.number().int().min(1).max(5),
 mode:z.enum(['individual','supervisada']),evaluation:z.enum(['pendiente','en-desarrollo','lograda']),evaluator:z.string().max(200),evaluationDate:z.union([z.literal(''),z.iso.date()]),criterion:z.string().max(2000)
}).strict().superRefine((p,ctx)=>{
 if(p.mode==='supervisada'&&!p.supervisor.trim())ctx.addIssue({code:'custom',message:'Indica el supervisor de la práctica supervisada.'});
 if(p.evaluation!=='pendiente'&&(!p.evaluator.trim()||!p.evaluationDate||!p.criterion.trim()||!p.evidence.trim()||p.mode!=='supervisada'))ctx.addIssue({code:'custom',message:'Una evaluación requiere práctica supervisada, evaluador, fecha, criterio observado y evidencia.'});
 if(p.evaluationDate&&p.evaluationDate<p.date)ctx.addIssue({code:'custom',message:'La evaluación no puede ser anterior a la práctica.'});
});
const oldBackupSchema=z.object({app:z.literal('filo-austral-academia'),version:z.literal(1),lessons:z.record(z.string().regex(/^[a-z0-9-]+$/),entry)}).strict();
const v2Schema=z.object({app:z.literal('filo-austral-academia'),version:z.literal(2),lessons:z.record(z.string().regex(/^[a-z0-9-]+$/),entry),practices:z.array(practiceSchema).max(500)}).strict().refine(s=>new Set(s.practices.map(p=>p.id)).size===s.practices.length,{message:'Hay prácticas duplicadas.'});
export const backupSchema=z.object({app:z.literal('filo-austral-academia'),version:z.literal(3),lessons:v2Schema.shape.lessons,practices:z.array(practiceSchema).max(500),equipment:z.array(equipmentSchema).max(500),responses:z.record(z.string(),z.string().max(20000))}).strict().superRefine((s,ctx)=>{try{parseObservations(s.responses[observationKey]);}catch(e){ctx.addIssue({code:'custom',message:e instanceof Error?e.message:'Cuaderno inválido'});}for(const ids of [s.practices.map(p=>p.id),s.equipment.map(e=>e.id)])if(new Set(ids).size!==ids.length)ctx.addIssue({code:'custom',message:'Identificadores duplicados'});for(const p of s.practices)if(p.equipmentIds.some(id=>!s.equipment.some(e=>e.id===id)))ctx.addIssue({code:'custom',message:'Equipo vinculado desconocido'});});
export type State=z.infer<typeof backupSchema>;
export const emptyState=():State=>({app:'filo-austral-academia',version:3,lessons:{},practices:[],equipment:[],responses:{}});
export const emptyEntry=()=>({studied:false,favorite:false,note:'',attempts:[] as State['lessons'][string]['attempts']});
export function parseBackup(raw:string,known:string[],knownSkills:string[]=known):State{
 if(raw.length>2_000_000)throw new Error('El respaldo supera el límite de 2 MB.');
 let input:unknown;try{input=JSON.parse(raw);}catch{throw new Error('El archivo no contiene JSON válido.');}
 const legacy=oldBackupSchema.safeParse(input);
 if(legacy.success)input={...legacy.data,version:2,practices:[]};
 const previous=v2Schema.safeParse(input);
 if(previous.success)input={...previous.data,version:3,equipment:[],responses:{}};
 const result=backupSchema.safeParse(input);
 if(!result.success)throw new Error('Respaldo incompatible o incompleto. Usa una exportación versión 1, 2 o 3 de esta academia; revisa los campos de práctica y evaluación.');
 if(Object.keys(result.data.lessons).some(id=>!known.includes(id))||result.data.practices.some(p=>!knownSkills.includes(p.skill)))throw new Error('El respaldo contiene lecciones desconocidas para esta versión. No se importó.');
 return result.data;
}
export interface Store {getItem(key:string):string|null;setItem(key:string,value:string):void}
export function readState(storage:Store,key:string,known:string[],knownSkills:string[]=known){const raw=storage.getItem(key);return raw===null?emptyState():parseBackup(raw,known,knownSkills);}
export function writeState(storage:Store,key:string,state:State){const raw=JSON.stringify(backupSchema.parse(state));if(new TextEncoder().encode(raw).length>2_000_000)throw new Error('El respaldo supera 2 MB; el cambio no se guardó.');storage.setItem(key,raw);}
