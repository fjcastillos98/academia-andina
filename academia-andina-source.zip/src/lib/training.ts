import {z} from 'zod';
const sessionSchema=z.object({minutes:z.number().positive().max(1440),rpe:z.number().min(0).max(10),ascent:z.number().min(0).max(10000),descent:z.number().min(0).max(10000),pack:z.number().min(0).max(100)});
/** Aritmética descriptiva; no estima aptitud, calorías ni riesgo. */
export function describeSession(input:unknown){const s=sessionSchema.parse(input);return {...s,load:s.minutes*s.rpe,verticalRate:s.ascent/(s.minutes/60)};}
export const trainingScenarios=[
{id:'general',title:'A · Sesión general',minutes:60,rpe:6,ascent:0,descent:0,pack:0},
{id:'sendero',title:'B · Sendero con carga',minutes:90,rpe:4,ascent:600,descent:600,pack:5},
{id:'ascenso',title:'C · Ascenso más breve',minutes:60,rpe:6,ascent:600,descent:600,pack:5}
] as const;
