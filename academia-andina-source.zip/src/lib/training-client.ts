import {describeSession,trainingScenarios} from './training';
const select=document.querySelector<HTMLSelectElement>('#training-scenario');
select?.addEventListener('change',()=>{const s=trainingScenarios.find(s=>s.id===select.value);if(!s)return;const r=describeSession(s);for(const [key,value] of Object.entries(r)){const cell=document.getElementById('training-'+key);if(cell)cell.textContent=String(value);} });
