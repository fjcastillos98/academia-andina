import {z} from 'zod';
const text=z.string().trim().min(1);
const local=z.string().regex(/^[a-z0-9-]+\/$/);
const schema=z.object({path:text,blocks:z.array(z.object({id:text,title:text,purpose:text,lessons:z.array(text).min(1),evidence:text,workshop:local}).strict()).min(1),integrator:local}).strict();
export function validateStudyRoute(raw:unknown,paths:{id:string;lessonIds:string[]}[],lessonIds:string[]){
 const route=schema.parse(raw),path=paths.find(p=>p.id===route.path);
 if(!path)throw new Error('Ruta no registrada');
 if(new Set(route.blocks.map(b=>b.id)).size!==route.blocks.length)throw new Error('Bloque duplicado');
 const ids=route.blocks.flatMap(b=>b.lessons);
 if(new Set(ids).size!==ids.length)throw new Error('Lección repetida');
 if(ids.some(id=>!lessonIds.includes(id)))throw new Error('Lección inexistente');
 if(JSON.stringify(ids)!==JSON.stringify(path.lessonIds))throw new Error('Secuencia distinta del programa');
 return route;
}
