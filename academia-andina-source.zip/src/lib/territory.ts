import {z} from 'zod';
const text=z.string().trim().min(1),id=z.string().regex(/^[a-z0-9-]+$/);
export const mountainSchema=z.object({id,name:text,aliases:z.array(text),location:text,altitude:text,administration:text,geologicalClassification:text,origin:text,geology:text,glaciology:text,routes:text,access:text,hazards:text,seasonality:text,history:text,ascents:text,heritage:text,protectedAreas:text,officialInformation:text,sources:z.array(text).min(1),exercise:text,status:text}).strict();
export const speciesSchema=z.object({id,commonName:text,scientificName:text,identification:text,habitat:text,distribution:text,ecologicalImportance:text,threats:text,behavior:text,visitorRelation:text,guideAction:text,sources:z.array(text).min(1),status:text}).strict();
export const diagramSchema=z.object({id,title:text,alt:text,caption:text}).strict();
export const caseSchema=z.object({id,title:text,intro:text,sections:z.array(z.object({title:text,body:text}).strict()).min(3),sources:z.array(text).min(1),lessons:z.array(text).min(1),status:text,dimensions:z.array(text).optional()}).strict();
