import {z} from 'zod';
const text=z.string().trim().min(1);
const id=z.string().regex(/^[a-z0-9-]+$/);
const schema=z.object({id,title:text,context:text,stages:z.array(z.object({id,title:text,information:text,task:text,evidence:text,review:text,lessons:z.array(text).min(1),dependsOn:z.array(id)}).strict()).min(2),checks:z.array(z.object({id,stages:z.array(id).min(2),question:text,failure:text,repair:text}).strict()).min(1)}).strict();
export function validateIntegration(raw:unknown,lessonIds:string[]){
 const data=schema.parse(raw),seen=new Set<string>();
 for(const stage of data.stages){
  if(seen.has(stage.id))throw new Error('Momento duplicado');
  if(stage.dependsOn.some(id=>!seen.has(id)))throw new Error('Dependencia no anterior');
  if(stage.lessons.some(id=>!lessonIds.includes(id)))throw new Error('Lección inexistente');
  seen.add(stage.id);
 }
 const checkIds=new Set<string>();
 for(const check of data.checks){
  if(checkIds.has(check.id))throw new Error('Contraste duplicado');checkIds.add(check.id);
  if(new Set(check.stages).size!==check.stages.length||check.stages.some(id=>!seen.has(id)))throw new Error('Momentos de contraste inválidos');
 }
 return data;
}
