type Route={id:string;title:string;lessonIds:string[]};
export function lessonRoutes(id:string,paths:Route[]){
 return paths.flatMap(path=>{const index=path.lessonIds.indexOf(id);return index<0?[]:[{id:path.id,title:path.title,position:index+1,total:path.lessonIds.length,previous:path.lessonIds[index-1]??null,next:path.lessonIds[index+1]??null}];});
}
