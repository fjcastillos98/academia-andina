import { z } from 'zod';
const text = z.string().trim().min(1, 'Este campo no puede quedar vacío');
export const questionSchema = z.object({prompt:text, options:z.array(text).min(2), answer:z.number().int().nonnegative(), explanation:text,source:text.optional(),difficulty:z.enum(['básica','intermedia','integración']).optional(),kind:z.enum(['conocimiento','aplicación','errores','decisiones','caso']).optional(),rationales:z.array(text).optional()}).strict().refine(q=>q.answer<q.options.length&&(!q.rationales||q.rationales.length===q.options.length),{message:'La respuesta correcta debe existir entre las opciones'});
export const lessonSchema = z.object({
 diagrams:z.array(text).optional(),preparation:z.array(text).optional(),openAssessment:z.object({prompt:text,rubric:z.array(text).min(2),source:text,difficulty:text}).optional(),title:text, description:text, module:z.string().regex(/^M\d{2}$/), code:text, order:z.number().int(), minutes:z.number().positive(), level:z.enum(['Fundamentos','Intermedio']),
 status:z.enum(['example','pilot','development']), unit:text.optional(), skills:z.array(text).optional(), critical:z.boolean().optional(), pilot:z.object({position:z.number().int().min(1).max(10),requires:z.array(text),critical:z.boolean(),classifications:z.array(z.enum(['TEORÍA','PROCEDIMIENTO','PRÁCTICA INDIVIDUAL','PRÁCTICA SUPERVISADA','COMPETENCIA'])).length(5),relatedModules:z.array(text).min(1),criteria:z.array(text).min(1)}).strict().optional(), reviewDate:z.string().regex(/^\d{4}-\d{2}-\d{2}$/), objectives:z.array(text).min(1), prerequisites:z.array(text), sources:z.array(text).min(1), pending:z.array(text).min(1), quiz:z.object({version:z.number().int().positive(), questions:z.array(questionSchema).min(2)})
}).strict().refine(l=>l.status!=='pilot'||!!l.pilot,{message:'El piloto necesita secuencia, clasificación y criterios'});
export const legacyCurriculumSchema = z.object({version:z.literal(1),reviewDate:text,note:text,modules:z.array(z.object({id:z.string().regex(/^M\d{2}$/),title:text,editorialStatus:z.enum(['planned','draft']),topics:z.array(text).min(1),prerequisites:z.array(text),prerequisiteStatus:z.literal('provisional'),missing:z.array(text).min(1)})).length(24,'El mapa debe conservar sus 24 bloques')}).superRefine((data,ctx)=>{
 const ids = data.modules.map(m=>m.id);
 if(new Set(ids).size!==ids.length) ctx.addIssue({code:'custom',message:'Hay códigos de módulo duplicados'});
 if(data.modules.reduce((n,m)=>n+m.topics.length,0)!==376) ctx.addIssue({code:'custom',message:'Deben conservarse las 376 entradas de alcance'});
 for(const m of data.modules) for(const id of m.prerequisites) if(!ids.includes(id)||id===m.id) ctx.addIssue({code:'custom',message:`Prerrequisito inválido ${id} en ${m.id}`});
 const visiting=new Set<string>(),done=new Set<string>();
 const visit=(id:string):boolean=>{if(visiting.has(id))return true;if(done.has(id))return false;visiting.add(id);for(const d of data.modules.find(m=>m.id===id)?.prerequisites||[])if(visit(d))return true;visiting.delete(id);done.add(id);return false;};
 if(ids.some(visit))ctx.addIssue({code:'custom',message:'Los prerrequisitos forman un ciclo'});
});
const moduleSchema=legacyCurriculumSchema.shape.modules.element;
export const curriculumV2Schema=z.object({version:z.literal(2),reviewDate:text,note:text,modules:z.array(moduleSchema).min(1),program:z.object({id:text,title:text,legacyArchive:text}),entries:z.array(z.object({id:text,module:text,title:text,status:z.enum(['planned','draft','reviewed']),origin:text})),units:z.array(z.object({id:text,module:text,title:text,lessonIds:z.array(text),requires:z.array(text),status:z.enum(['planned','draft','reviewed'])})),futureDependencies:z.array(z.object({module:text,requires:z.array(text),practicalReviewRequired:z.boolean()}))}).superRefine((c,ctx)=>{
 if(c.entries.filter(e=>e.origin==='etapa1').length!==376||c.modules.reduce((n,m)=>n+m.topics.length,0)<376)ctx.addIssue({code:'custom',message:'Deben conservarse las 376 entradas originales'});
 const unique=(ids:string[],label:string)=>{if(new Set(ids).size!==ids.length)ctx.addIssue({code:'custom',message:`${label}: identificadores duplicados`});};
 const modules=c.modules.map(m=>m.id),units=c.units.map(u=>u.id);unique(modules,'Módulos');unique(units,'Unidades');unique(c.entries.map(e=>e.id),'Entradas');
 for(const e of [...c.entries,...c.units])if(!modules.includes(e.module))ctx.addIssue({code:'custom',message:`Módulo desconocido en ${e.id}`});
 for(const m of c.modules)for(const id of m.prerequisites)if(!modules.includes(id))ctx.addIssue({code:'custom',message:'Prerrequisito inválido '+id});
 for(const u of c.units)for(const id of u.requires)if(!units.includes(id))ctx.addIssue({code:'custom',message:'Unidad previa desconocida '+id});
 for(const d of c.futureDependencies)if(!modules.includes(d.module)||d.requires.some(id=>!modules.includes(id)))ctx.addIssue({code:'custom',message:'Dependencia futura desconocida'});
 for(const graph of [c.modules.map(m=>({id:m.id,requires:m.prerequisites})),c.units,c.futureDependencies.map(d=>({id:d.module,requires:d.requires}))])if(hasCycle(graph))ctx.addIssue({code:'custom',message:'Las dependencias forman un ciclo'});
});
export function hasCycle(graph:{id:string;requires:string[]}[]){const active=new Set<string>(),done=new Set<string>();const visit=(id:string):boolean=>{if(active.has(id))return true;if(done.has(id))return false;active.add(id);if((graph.find(n=>n.id===id)?.requires||[]).some(visit))return true;active.delete(id);done.add(id);return false;};return graph.some(n=>visit(n.id));}
export const curriculumSchema=z.union([legacyCurriculumSchema,curriculumV2Schema]);
export const skillSchema=z.object({description:text.optional(),level:text.optional(),practiceRequired:text.optional(),supervisionRequired:z.boolean().optional(),evidence:z.array(text).optional(),evaluation:text.optional(),id:text,title:text,module:text,lessonIds:z.array(text).min(1),requires:z.array(text),critical:z.boolean(),criteria:z.array(text).min(1),status:z.enum(['planned','available'])}).strict();
export const pathSchema=z.object({id:text,title:text,unitIds:z.array(text),lessonIds:z.array(text).min(1),requires:z.array(text)}).strict();
export type Question=z.infer<typeof questionSchema>;
export type LessonMeta=z.infer<typeof lessonSchema>;
export function validateCurriculum(input:unknown){const r=curriculumSchema.safeParse(input);if(!r.success)throw new Error('Currículo inválido: '+r.error.issues.map(e=>`${e.path.join('.')}: ${e.message}`).join('; '));return r.data;}
export const requiredSections=['Conceptos','Ejemplo','Errores frecuentes','Límites','Caso de estudio','Recuperación activa','Ejercicio','Criterios de revisión','Próximos pasos'];
export function validateLessonBody(body:string){const missing=requiredSections.filter(s=>!body.includes('## '+s));if(missing.length)throw new Error('Lección incompleta. Faltan apartados: '+missing.join(', '));}
export const sourcesSchema=z.array(z.object({id:text,title:text,organization:text,url:z.url().nullable(),published:z.iso.date().nullable(),consulted:z.iso.date(),type:text,limitations:text,lessons:z.array(text).min(1),verification:z.enum(['verified','pending']).optional(),supports:z.array(text).optional(),reviewedAt:z.iso.date().optional()}).strict()).min(1);
export const glossarySchema=z.array(z.object({id:z.string().regex(/^[a-z0-9-]+$/),term:text,definition:text,source:text}).strict()).min(1);

export const pilotSections=['Desarrollo teórico y toma de decisiones','Material y equipo relacionado','Registro de práctica','Criterios de revisión y competencia','Próximos pasos y relación con otros módulos'];
export function validatePilotBody(body:string){validateLessonBody(body);const missing=pilotSections.filter(s=>!body.includes('## '+s));if(missing.length)throw new Error('Piloto incompleto: '+missing.join(', '));}
