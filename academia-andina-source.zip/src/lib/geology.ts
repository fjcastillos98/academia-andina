import {z} from 'zod';
const text=z.string().trim().min(1);
export const geologyCaseSchema=z.object({id:text,name:text,conclusion:text,evidence:text,uncertainties:text,sourceIds:z.array(text).min(1)}).strict();
export function validateGeologyCases(input:unknown,mountains:string[],sources:string[]){const r=z.array(geologyCaseSchema).parse(input);if(new Set(r.map(c=>c.id)).size!==r.length)throw new Error('Suplementos geológicos: identificador duplicado.');for(const c of r){if(!mountains.includes(c.id))throw new Error('Suplemento sin ficha territorial: '+c.id);if(c.sourceIds.some(id=>!sources.includes(id)))throw new Error('Fuente geológica desconocida: '+c.id);}return r;}
const typeSchema=z.enum(['estudio','reporte','mapa','restriccion']);
const claimSchema=z.enum(['origen','actividad','escenario','acceso']);
export const documentExercises=[
{id:'estudio',title:'A · Estudio geológico ficticio',excerpt:'El estudio distingue un edificio erosionado y centros superpuestos. No analiza actividad presente ni acceso.',answer:'origen',limit:'Respalda una interpretación de origen y estructura dentro del alcance del estudio; no fecha una erupción futura.'},
{id:'reporte',title:'B · Reporte técnico ficticio',excerpt:'El documento describe mediciones durante un periodo identificado. No contiene instrucciones del administrador del sendero.',answer:'actividad',limit:'Respalda lo reportado para ese periodo; no demuestra que la misma situación se mantenga ni autoriza acceso.'},
{id:'mapa',title:'C · Mapa de peligros ficticio',excerpt:'La leyenda representa un escenario de lahares para una cuenca. No muestra todos los procesos volcánicos.',answer:'escenario',limit:'Permite interpretar ese escenario y sus hipótesis; fuera del polígono no significa riesgo cero.'},
{id:'restriccion',title:'D · Aviso de acceso ficticio',excerpt:'El administrador comunica una restricción para un sector y periodo determinados. No ofrece una historia eruptiva.',answer:'acceso',limit:'Documenta la restricción indicada. No certifica seguridad de otros sectores ni reemplaza información técnica.'}
] as const;
export function reviewDocument(type:unknown,claim:unknown){const t=typeSchema.parse(type),c=claimSchema.parse(claim),doc=documentExercises.find(d=>d.id===t)!;return {correct:c===doc.answer,explanation:(c===doc.answer?'Correspondencia correcta. ':'Revisa la función del documento. ')+doc.limit};}
