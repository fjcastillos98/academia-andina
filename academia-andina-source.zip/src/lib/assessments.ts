import {questionSchema} from './schemas.ts';
import {z} from 'zod';
export const assessmentSchema=z.object({id:z.string().min(1),version:z.number().int().positive(),lesson:z.string().min(1),kind:z.literal('theory'),questions:z.array(questionSchema).min(2)}).strict();
export type Assessment=z.infer<typeof assessmentSchema>;
export function assessmentAt(registry:Assessment[],id:string,version:number){const found=registry.find(a=>a.lesson===id&&a.version===version);if(!found)throw new Error(`Evaluación histórica no disponible: ${id} v${version}. No se modificaron datos.`);return found;}
