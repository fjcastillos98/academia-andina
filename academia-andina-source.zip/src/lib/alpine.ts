export const alpineTimeFields=['approach','pitches','minutesPerPitch','transitions','minutesPerTransition','descent','available'] as const;
export type AlpineTimeInput=Record<typeof alpineTimeFields[number],number>;
/** Educational arithmetic only: no model of route feasibility or safety. */
export function alpineTime(input:AlpineTimeInput){
 for(const key of alpineTimeFields){const n=input[key];if(!Number.isFinite(n)||n<0||n>10080)throw new Error('Introduce valores finitos entre 0 y 10080.');}
 for(const key of ['pitches','transitions'] as const)if(!Number.isInteger(input[key])||input[key]>100)throw new Error('Largos y transiciones deben ser cantidades enteras entre 0 y 100.');
 const climbing=input.pitches*input.minutesPerPitch,changes=input.transitions*input.minutesPerTransition;
 const total=input.approach+climbing+changes+input.descent;
 return {climbing,changes,total,remaining:input.available-total};
}
