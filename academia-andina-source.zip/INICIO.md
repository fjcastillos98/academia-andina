# Academia Andina · Guía de inicio

Entrega local 0.32.0 · 30 de octubre de 2026.

## Qué recibes

Código fuente, contenido, evaluaciones, recursos, pruebas e informes dentro de `academia/`. No incluye dependencias ni una aplicación instalable de Windows o Android. Se ejecuta como una web local. No se publicó en internet.

El catálogo tiene 175 lecciones, 16 rutas y seis objetivos de entrada. La compilación genera 286 páginas. Las lecturas y cuestionarios no acreditan competencias prácticas. El cierre de esta versión no completa ni valida el currículo académico.

## Instalar en un computador

1. Extrae el ZIP en una carpeta nueva, separada del manual original.
2. Usa Node.js 24 o superior y npm. El entorno de verificación usó Node 24.22.1 y npm 11.9.0. Para instalar dependencias se necesita conexión a internet.
3. Abre una terminal en la carpeta `academia`, donde está `package.json`.
4. Ejecuta, una línea a la vez:

```text
npm ci
npm run dev -- --host 127.0.0.1
```

Abre la dirección local que indique Astro, normalmente `http://127.0.0.1:4321/`. Mantén la terminal abierta; Ctrl+C detiene el servidor. No abras los archivos HTML por doble clic. Usa siempre la misma dirección y puerto para conservar el acceso al registro de ese navegador.

El ZIP no se abre directamente como una app en Android. Para usarla desde otro dispositivo haría falta configurar un servidor accesible; esa configuración y la publicación quedan fuera de esta entrega.

## Primera sesión

1. En «Elegir qué estudiar», selecciona un objetivo; si estás retomando, empieza por Fundamentales.
2. Consulta los prerrequisitos y abre una lección. La ruta sugiere la primera lectura no marcada como estudiada, no tu última visita.
3. Estudia, responde el cuestionario y revisa las explicaciones. La aprobación teórica requiere todas las respuestas correctas.
4. Guarda notas con su botón. Los talleres de respuesta abierta también requieren guardado manual.
5. Usa el cuaderno para revisar notas, favoritos e intentos. Las respuestas abiertas se consultan en su taller correspondiente.
6. Registra prácticas únicamente cuando hayan ocurrido, con su contexto y evidencia. El sistema no verifica credenciales ni certifica habilidades.

## Respaldar y recuperar

En «Mi cuaderno → Copia de seguridad», exporta el JSON y comprueba que se descargó. Guarda una copia antes de cambiar de equipo, navegador, dirección o versión. El ZIP del proyecto no contiene tus registros personales.

Para recuperar, selecciona el JSON (máximo 2 MB), revisa el resumen y confirma el reemplazo. Cancelar no importa los registros. La importación reemplaza los datos actuales: no fusiona dos respaldos. Incluye notas, favoritos, intentos, respuestas abiertas, equipo y prácticas. Exporta primero lo que quieras conservar.

El JSON no está cifrado. No incluyas datos médicos, contraseñas ni datos privados de pasajeros. Borrar datos del navegador o usar sesiones privadas puede hacer que se pierdan los registros. No existe sincronización automática entre dispositivos.

Si aparece un error, no borres el almacenamiento para intentar arreglarlo. Conserva el respaldo y revisa el mensaje. Si no se pueden leer los datos, el programa evita sobrescribirlos; una copia válida permite recuperarlos.

## Resolver problemas frecuentes

| Situación | Acción |
| --- | --- |
| npm no se reconoce | Comprueba la instalación de Node/npm y abre de nuevo la terminal |
| No encuentra package.json | Abre la terminal dentro de academia |
| La página no abre | Mantén activo el servidor y usa la dirección y puerto que muestra la terminal |
| No aparecen mis notas | Revisa navegador, perfil, dirección, puerto y base; usa un respaldo si cambiaste de entorno |
| Error al importar | Lee el motivo; no edites el JSON a ciegas ni confirmes otro reemplazo sin conservar una copia |
| Enlaces rotos tras cambiar base | Recompila con la base correcta y sirve el resultado; consulta mantenimiento |

La lectura y navegación básica funcionan sin JavaScript; búsqueda, cuestionarios y guardado requieren activarlo. La revisión visual e interactiva final todavía está pendiente, como detalla el acta de aceptación.
