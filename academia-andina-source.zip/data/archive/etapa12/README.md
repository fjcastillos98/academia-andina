# Estado previo a Etapa 13

Copias de datos para verificar conservación del contenido anterior. El manifiesto docs/etapa13/historical-sha256.json cubre 361 archivos académicos previos.
