# Estado previo a Etapa 12

Copias de datos de la Etapa 11 utilizadas por las pruebas de conservación. No modificar como parte de ampliaciones posteriores. El manifiesto docs/etapa12/historical-sha256.json conserva hashes de 339 archivos históricos.
