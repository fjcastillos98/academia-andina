# Estado anterior a Etapa 11

Copias de los cinco conjuntos de datos antes de ampliar ecología. El manifiesto docs/etapa11/historical-sha256.json conserva 317 archivos académicos (137 lecciones, 137 cuestionarios y 43 SVG).
