import { defineConfig } from 'astro/config';
const base = process.env.BASE_PATH || '/';
if (!/^\/(?:[a-zA-Z0-9_-]+\/)*$/.test(base)) throw new Error('BASE_PATH debe empezar y terminar con /; ejemplo: /academia-andina/');
export default defineConfig({ output: 'static', vite: { server: { allowedHosts: ['terminal.local'] } }, server: { host: '0.0.0.0' }, site: process.env.SITE_URL || 'https://fjcastillos98.github.io', base, trailingSlash: 'always', devToolbar: { enabled: false } });
