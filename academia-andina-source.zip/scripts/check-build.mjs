import {readFileSync,readdirSync,existsSync} from 'node:fs';
import {join} from 'node:path';
const base=process.env.BASE_PATH||'/';
function files(dir){return readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(join(dir,e.name)):[join(dir,e.name)]);}
const html=files('dist').filter(f=>f.endsWith('.html'));let links=0;const errors=[];
for(const file of html){const source=readFileSync(file,'utf8');for(const m of source.matchAll(/href="#(fuente-[^"]+)"/g))if(!source.includes(`id="${m[1]}"`))errors.push(`${file}: referencia sin destino ${m[1]}`);for(const m of source.matchAll(/(?:href|src)="([^"]+)"/g)){const value=m[1];if(!value.startsWith('/')||value.startsWith('//'))continue;links++;if(!value.startsWith(base)){errors.push(`${file}: fuera de base ${value}`);continue;}const path=value.slice(base.length).split(/[?#]/)[0];const target=join('dist',path||'index.html');if(!existsSync(target)&&!existsSync(join(target,'index.html')))errors.push(`${file}: destino ausente ${value}`);}}
const index=JSON.parse(readFileSync('dist/search-index.json','utf8'));if(index.filter(i=>i.kind==='Tema pendiente').length!==376)errors.push('Índice: faltan entradas pendientes');
for(const item of index){const path=item.href.slice(base.length).split('#')[0];if(!item.href.startsWith(base)||!existsSync(join('dist',path,'index.html')))errors.push(`Búsqueda: enlace roto ${item.href}`);}
if(errors.length){console.error(errors.join('\n'));process.exit(1);}console.log(`OK: ${html.length} páginas, ${links} enlaces/recursos internos, ${index.length} resultados de búsqueda. Base: ${base}`);
