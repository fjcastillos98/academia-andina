// Evita reutilizar contenido transformado con una BASE_PATH anterior.
import {rmSync} from 'node:fs';
for (const path of ['dist', '.astro', 'node_modules/.astro', 'node_modules/.vite']) {
  rmSync(new URL('../' + path, import.meta.url), {recursive: true, force: true});
}
