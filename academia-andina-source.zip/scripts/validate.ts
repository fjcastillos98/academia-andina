import {validateTerritorialEvidence} from '../src/lib/territory14.ts';
import {validateHistory} from '../src/lib/history.ts';
import {validateGeologyCases} from '../src/lib/geology.ts';
import {validateReview} from '../src/lib/review.ts';
import {validateWinter} from '../src/lib/winter.ts';
import {validateExpanded} from '../src/lib/expanded.ts';
import {validateProgram} from '../src/lib/program.ts';
import { readFileSync, readdirSync } from 'node:fs';
import { curriculumSchema, lessonSchema, validateLessonBody, sourcesSchema, glossarySchema, validatePilotBody } from '../src/lib/schemas.ts';
const errors:string[]=[];
const data=JSON.parse(readFileSync('data/curriculum.json','utf8'));
const archived=JSON.parse(readFileSync("data/archive/curriculum.v1.json","utf8"));for(const original of archived.modules){const current=data.modules.find((m:{id:string})=>m.id===original.id);if(!current||JSON.stringify(current)!==JSON.stringify(original))errors.push("Se alteró el módulo histórico "+original.id);}
const parsed=curriculumSchema.safeParse(data);
if(!parsed.success)for(const e of parsed.error.issues)errors.push(`curriculum.json → ${e.path.join('.')||'estructura'}: ${e.message}`);
const sources=JSON.parse(readFileSync('src/data/sources.json','utf8')) as {id:string;lessons:string[]}[];
const sourceResult=sourcesSchema.safeParse(sources);
if(!sourceResult.success)for(const e of sourceResult.error.issues)errors.push(`sources.json → ${e.path.join('.')}: ${e.message}`);
if(new Set(sources.map(s=>s.id)).size!==sources.length)errors.push('sources.json → Identificadores duplicados');
const glossaryResult=glossarySchema.safeParse(JSON.parse(readFileSync('src/data/glossary.json','utf8')));
if(!glossaryResult.success)for(const e of glossaryResult.error.issues)errors.push(`glossary.json → ${e.path.join('.')}: ${e.message}`);
else {if(new Set(glossaryResult.data.map(t=>t.id)).size!==glossaryResult.data.length)errors.push('glossary.json → Identificadores duplicados');for(const term of glossaryResult.data)if(!sources.some(s=>s.id===term.source))errors.push(`glossary.json → Fuente desconocida para ${term.term}`);}
const files=readdirSync('src/content/lecciones').filter(f=>f.endsWith('.md'));
for(const source of sources)for(const id of source.lessons)if(!files.includes(id+'.md'))errors.push(`sources.json → Lección inexistente: ${id}`);
const codes=new Set<string>();
const pilots:{id:string;position:number;requires:string[]}[]=[];
for(const file of files){try{const raw=readFileSync(`src/content/lecciones/${file}`,'utf8');const match=raw.match(/^---\n([\s\S]*?)\n---\n([\s\S]*)$/);if(!match)throw new Error('Falta frontmatter JSON delimitado por ---');const result=lessonSchema.safeParse(JSON.parse(match[1]));if(!result.success){for(const e of result.error.issues)errors.push(`${file} → ${e.path.join('.')}: ${e.message}`);continue;}
 const lesson=result.data;if(codes.has(lesson.code))throw new Error('Código de lección duplicado');codes.add(lesson.code);
 if(!data.modules.some((m:{id:string})=>m.id===lesson.module))throw new Error('La asignatura indicada no existe');
 for(const source of lesson.sources)if(!sources.some(s=>s.id===source&&s.lessons.includes(file.replace('.md',''))))throw new Error(`Fuente sin referencia cruzada: ${source}`);
 if(lesson.status!=='development')validateLessonBody(match[2]);else for(const h of ['Conceptos clave','Teoría','Caso práctico','Errores frecuentes','Autoevaluación','Ejercicios','Evidencia requerida','Relaciones'])if(!match[2].includes('## '+h))throw new Error('Falta apartado: '+h);
 if(lesson.pilot){validatePilotBody(match[2]);pilots.push({id:file.replace('.md',''),...lesson.pilot});for(const id of lesson.pilot.relatedModules)if(!data.modules.some((m:{id:string})=>m.id===id))throw new Error(`Módulo relacionado desconocido: ${id}`);}
 }catch(e){errors.push(`${file} → ${e instanceof Error?e.message:e}`);}}
pilots.sort((a,b)=>a.position-b.position);
if(pilots.length!==10||pilots.some((p,i)=>p.position!==i+1||p.requires.some(id=>!pilots.slice(0,i).some(x=>x.id===id))))errors.push('Piloto: se requieren diez posiciones únicas y prerrequisitos anteriores existentes.');
try{validateProgram({curriculum:data,skills:JSON.parse(readFileSync('data/skills.json','utf8')),paths:JSON.parse(readFileSync('data/learning-paths.json','utf8')),sources,assessments:readdirSync('src/data/assessments').map(f=>JSON.parse(readFileSync('src/data/assessments/'+f,'utf8'))),lessons:files.map(f=>({id:f.slice(0,-3),data:JSON.parse(readFileSync('src/content/lecciones/'+f,'utf8').split('---\n')[1])}))});}catch(e){errors.push(String(e));}
try{const read=(f:string)=>JSON.parse(readFileSync(f,'utf8'));validateExpanded({mountains:[...read('src/data/mountains.json'),...read('src/data/mountains14.json')],species:read('src/data/species.json'),cases:read('src/data/cases.json'),diagrams:read('src/data/diagrams.json'),sourceIds:sources.map(s=>s.id),lessons:files.map(f=>({id:f.slice(0,-3),data:JSON.parse(readFileSync('src/content/lecciones/'+f,'utf8').split('---\n')[1])})),diagramFiles:readdirSync('public/diagramas')});}catch(e){errors.push(String(e));}
try{const read=(p:string)=>JSON.parse(readFileSync(p,'utf8'));validateWinter({templates:[...read('src/data/winter-templates.json'),...read('src/data/glacier-templates.json'),...read('src/data/ice-templates.json'),...read('src/data/alpine-templates.json'),...read('src/data/altitude-templates.json'),...read('src/data/training-templates.json'),...read('src/data/ecology-templates.json'),...read('src/data/geology-templates.json'),...read('src/data/history-templates.json'),...read('src/data/leadership-templates.json')],cards:read('src/data/winter-equipment.json'),skills:read('data/skills.json').map((s:any)=>s.id),sources:sources.map(s=>s.id)});}catch(e){errors.push(String(e));}
try{validateReview(JSON.parse(readFileSync('src/data/review51.json','utf8')),files.map(f=>f.slice(0,-3)),JSON.parse(readFileSync('data/skills.json','utf8')).map((s:any)=>s.id));}catch(e){errors.push(String(e));}
try{validateGeologyCases(JSON.parse(readFileSync('src/data/geology-cases.json','utf8')),JSON.parse(readFileSync('src/data/mountains.json','utf8')).map((m:any)=>m.id),sources.map(s=>s.id));}catch(e){errors.push(String(e));}
try{validateHistory(JSON.parse(readFileSync('src/data/history-events.json','utf8')),sources.map(s=>s.id));}catch(e){errors.push(String(e));}
try{validateTerritorialEvidence(JSON.parse(readFileSync('src/data/mountain-evidence14.json','utf8')),JSON.parse(readFileSync('src/data/mountains14.json','utf8')),sources.map(s=>s.id));}catch(e){errors.push(String(e));}
if(errors.length){console.error('No se puede compilar: corrige estos contenidos incompletos.\n'+errors.map(e=>'• '+e).join('\n'));process.exit(1);}console.log(`Contenido válido: 24 bloques, 376 entradas pendientes, ${files.length} lecturas (piloto, ejemplos históricos y unidades en desarrollo).`);
