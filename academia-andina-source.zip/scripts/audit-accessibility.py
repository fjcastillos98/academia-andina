"""Inspección estática parcial; no sustituye navegador ni evaluación WCAG."""
import json, os
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit, unquote
class Page(HTMLParser):
 def __init__(self,text):
  super().__init__(convert_charrefs=True);self.ids=[];self.links=[];self.controls=[];self.labels=set();self.stack=[];self.h1=0;self.main=0;self.images=[];self.lang=None;self.feed(text)
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if a.get('id'):self.ids.append(a['id'])
  if tag=='html':self.lang=a.get('lang')
  if tag=='h1':self.h1+=1
  if tag=='main':self.main+=1
  if tag=='a' and a.get('href'):self.links.append(a['href'])
  if tag=='img':self.images.append(a)
  if tag=='label' and a.get('for'):self.labels.add(a['for'])
  if tag in ('input','select','textarea') and a.get('type') not in ('hidden','submit','button','reset'):
   self.controls.append((a,'label' in self.stack))
  if tag not in ('area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'):self.stack.append(tag)
 def handle_endtag(self,tag):
  if tag in self.stack:self.stack=self.stack[:len(self.stack)-1-self.stack[::-1].index(tag)]
base=os.environ.get('BASE_PATH','/')
root=Path('dist'); pages={f:Page(f.read_text()) for f in root.rglob('*.html')};issues=[];anchors=controls=0
for f,p in pages.items():
 def add(kind,detail):issues.append({'page':str(f.relative_to(root)),'kind':kind,'detail':detail})
 if p.lang!='es':add('idioma',str(p.lang))
 if p.h1!=1:add('h1',str(p.h1))
 if p.main!=1:add('main',str(p.main))
 for id,count in Counter(p.ids).items():
  if count>1:add('id duplicado',id)
 for img in p.images:
  if 'alt' not in img:add('imagen sin alt',img.get('src',''))
 for a,wrapped in p.controls:
  controls+=1
  if not (wrapped or a.get('id') in p.labels or a.get('aria-label') or (a.get('aria-labelledby') and all(x in p.ids for x in a['aria-labelledby'].split()))):add('control sin etiqueta detectable',a.get('id') or a.get('name') or str(a))
 for href in p.links:
  u=urlsplit(href)
  if not u.fragment or u.scheme or u.netloc:continue
  if u.path and not u.path.startswith(base):continue
  target=f if not u.path else root/unquote(u.path[len(base):])
  if target.is_dir():target=target/'index.html'
  if target not in pages:continue
  anchors+=1
  if unquote(u.fragment) not in pages[target].ids:add('ancla sin destino',href)
report={'scope':'Inspección estática parcial, sin navegador ni certificación de accesibilidad','base':base,'pages':len(pages),'controls':controls,'anchors':anchors,'issues':issues}
print(json.dumps(report,ensure_ascii=False,indent=2))
